/**
 * fancy font handler
 *
 * converts outgoing message text into unicode "fancy" characters (monospace by
 * default) so every command gets styled output without touching each command
 * file. the patch is applied once to the api object after login, so anything
 * that calls api.sendMessage / api.editMessage is covered automatically.
 *
 * things that are deliberately NOT converted, because converting them breaks
 * real functionality:
 *   - mention tags  -> sendMessage locates mentions with body.indexOf(tag),
 *                      so the tag text must stay byte identical
 *   - urls / emails -> fancy codepoints make links unclickable
 *   - anything wrapped in the NO_FONT markers
 */

const ALPHA_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const ALPHA_LOWER = "abcdefghijklmnopqrstuvwxyz";
const DIGITS = "0123456789";

/**
 * style definitions. `upper` / `lower` / `digit` are the first codepoint of the
 * contiguous unicode range. `except` patches the holes that unicode left in
 * some ranges (those letters live in the older letterlike-symbols block).
 */
const STYLE_DEFS = {
	monospace: {
		label: "monospace",
		upper: 0x1d670,
		lower: 0x1d68a,
		digit: 0x1d7f6
	},
	bold: {
		label: "bold",
		upper: 0x1d400,
		lower: 0x1d41a,
		digit: 0x1d7ce
	},
	italic: {
		label: "italic",
		upper: 0x1d434,
		lower: 0x1d44e,
		except: { h: 0x210e }
	},
	bolditalic: {
		label: "bold italic",
		upper: 0x1d468,
		lower: 0x1d482
	},
	sans: {
		label: "sans",
		upper: 0x1d5a0,
		lower: 0x1d5ba,
		digit: 0x1d7e2
	},
	sansbold: {
		label: "sans bold",
		upper: 0x1d5d4,
		lower: 0x1d5ee,
		digit: 0x1d7ec
	},
	script: {
		label: "script",
		upper: 0x1d49c,
		lower: 0x1d4b6,
		except: {
			B: 0x212c, E: 0x2130, F: 0x2131, H: 0x210b, I: 0x2110,
			L: 0x2112, M: 0x2133, R: 0x211b,
			e: 0x212f, g: 0x210a, o: 0x2134
		}
	},
	doublestruck: {
		label: "double struck",
		upper: 0x1d538,
		lower: 0x1d552,
		digit: 0x1d7d8,
		except: {
			C: 0x2102, H: 0x210d, N: 0x2115, P: 0x2119,
			Q: 0x211a, R: 0x211d, Z: 0x2124
		}
	},
	fraktur: {
		label: "fraktur",
		upper: 0x1d504,
		lower: 0x1d51e,
		except: { C: 0x212d, H: 0x210c, I: 0x2111, R: 0x211c, Z: 0x2128 }
	},
	fullwidth: {
		label: "fullwidth",
		upper: 0xff21,
		lower: 0xff41,
		digit: 0xff10
	}
};

// small caps has no contiguous range at all, so it is a plain lookup table
const SMALLCAPS = {
	a: "ᴀ", b: "ʙ", c: "ᴄ", d: "ᴅ", e: "ᴇ", f: "ꜰ", g: "ɢ", h: "ʜ", i: "ɪ",
	j: "ᴊ", k: "ᴋ", l: "ʟ", m: "ᴍ", n: "ɴ", o: "ᴏ", p: "ᴘ", q: "ǫ", r: "ʀ",
	s: "s", t: "ᴛ", u: "ᴜ", v: "ᴠ", w: "ᴡ", x: "x", y: "ʏ", z: "ᴢ"
};

const DEFAULT_STYLE = "monospace";

// text between these markers is left exactly as written
const NO_FONT_OPEN = "\u2063[[raw]]";
const NO_FONT_CLOSE = "[[/raw]]\u2063";

const URL_REGEX = /\b(?:https?:\/\/|www\.)[^\s<>"']+/gi;
const EMAIL_REGEX = /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g;

const mapCache = new Map();

/** builds (and caches) a plain char -> styled char lookup table for a style */
function buildMap(styleName) {
	if (mapCache.has(styleName)) return mapCache.get(styleName);

	const map = new Map();

	if (styleName === "smallcaps") {
		for (const [plain, styled] of Object.entries(SMALLCAPS)) {
			map.set(plain, styled);
			map.set(plain.toUpperCase(), styled);
		}
		mapCache.set(styleName, map);
		return map;
	}

	const def = STYLE_DEFS[styleName];
	if (!def) {
		mapCache.set(styleName, map);
		return map;
	}

	const fill = (chars, base) => {
		if (!base) return;
		for (let i = 0; i < chars.length; i++) {
			map.set(chars[i], String.fromCodePoint(base + i));
		}
	};

	fill(ALPHA_UPPER, def.upper);
	fill(ALPHA_LOWER, def.lower);
	fill(DIGITS, def.digit);

	// patch the reserved holes so we never emit a blank/undefined glyph
	for (const [plain, codepoint] of Object.entries(def.except || {})) {
		map.set(plain, String.fromCodePoint(codepoint));
	}

	mapCache.set(styleName, map);
	return map;
}

function listStyles() {
	return [...Object.keys(STYLE_DEFS), "smallcaps"];
}

function isStyle(name) {
	return typeof name === "string" && listStyles().includes(name.toLowerCase());
}

function styleLabel(name) {
	const key = String(name || "").toLowerCase();
	if (key === "smallcaps") return "small caps";
	return (STYLE_DEFS[key] && STYLE_DEFS[key].label) || key;
}

/** raw conversion of a whole string, with no protection logic */
function stylize(text, styleName = DEFAULT_STYLE, options = {}) {
	if (text === null || text === undefined) return text;
	const str = String(text);
	const key = String(styleName).toLowerCase();
	const map = buildMap(key);
	if (map.size === 0) return str;

	const keepNumbers = options.convertNumbers === false;
	let out = "";

	// iterate by codepoint so existing emoji/surrogate pairs survive intact
	for (const char of str) {
		if (keepNumbers && char >= "0" && char <= "9") {
			out += char;
			continue;
		}
		out += map.get(char) || char;
	}
	return out;
}

/** marks a chunk of text so the handler never restyles it */
function raw(text) {
	return `${NO_FONT_OPEN}${text}${NO_FONT_CLOSE}`;
}

function collectRanges(text, regex) {
	const ranges = [];
	regex.lastIndex = 0;
	let match;
	while ((match = regex.exec(text)) !== null) {
		ranges.push([match.index, match.index + match[0].length]);
		if (match[0].length === 0) regex.lastIndex++;
	}
	return ranges;
}

/** every occurrence of a literal needle, used to shield mention tags */
function collectLiteralRanges(text, needle) {
	const ranges = [];
	if (!needle) return ranges;
	let from = 0;
	let at = text.indexOf(needle, from);
	while (at !== -1) {
		ranges.push([at, at + needle.length]);
		from = at + needle.length;
		at = text.indexOf(needle, from);
	}
	return ranges;
}

function mergeRanges(ranges) {
	if (ranges.length === 0) return ranges;
	const sorted = ranges.slice().sort((a, b) => a[0] - b[0]);
	const merged = [sorted[0]];
	for (let i = 1; i < sorted.length; i++) {
		const last = merged[merged.length - 1];
		if (sorted[i][0] <= last[1]) {
			last[1] = Math.max(last[1], sorted[i][1]);
		} else {
			merged.push(sorted[i]);
		}
	}
	return merged;
}

/**
 * converts text while protecting urls, emails, explicit raw blocks and any
 * literal strings passed in `protect` (mention tags).
 */
function apply(text, options = {}) {
	if (text === null || text === undefined) return text;
	let str = String(text);
	if (str.length === 0) return str;

	const styleName = options.style || DEFAULT_STYLE;
	const protect = [];

	if (options.skipUrls !== false) {
		protect.push(...collectRanges(str, URL_REGEX));
		protect.push(...collectRanges(str, EMAIL_REGEX));
	}

	for (const needle of options.protect || []) {
		if (typeof needle === "string" && needle.length > 0) {
			protect.push(...collectLiteralRanges(str, needle));
		}
	}

	// explicit raw blocks: shield the inner text, then drop the markers later
	const rawRanges = [];
	let searchFrom = 0;
	let open = str.indexOf(NO_FONT_OPEN, searchFrom);
	while (open !== -1) {
		const close = str.indexOf(NO_FONT_CLOSE, open + NO_FONT_OPEN.length);
		if (close === -1) break;
		rawRanges.push([open, close + NO_FONT_CLOSE.length]);
		searchFrom = close + NO_FONT_CLOSE.length;
		open = str.indexOf(NO_FONT_OPEN, searchFrom);
	}
	protect.push(...rawRanges);

	const shielded = mergeRanges(protect);

	let out = "";
	let cursor = 0;
	for (const [start, end] of shielded) {
		if (start > cursor) {
			out += stylize(str.slice(cursor, start), styleName, options);
		}
		out += str.slice(start, end);
		cursor = end;
	}
	if (cursor < str.length) {
		out += stylize(str.slice(cursor), styleName, options);
	}

	// strip the markers now that conversion is done
	return out.split(NO_FONT_OPEN).join("").split(NO_FONT_CLOSE).join("");
}

/**
 * safety switches. styling must never be the reason a message fails to send,
 * so any send error on a styled payload turns styling off (for that thread
 * first, then globally if it keeps happening) and the plain text is resent.
 */
const disabledThreads = new Set();
let failureCount = 0;
let killSwitch = false;
const MAX_FAILURES = 3;

// styled characters are surrogate pairs, so a converted body is roughly twice
// the utf-16 length of the original. anything near facebook's message limit is
// left as plain text instead of risking a rejected send.
const MAX_STYLE_LENGTH = 4000;

function noteFailure(threadID) {
	failureCount++;
	if (threadID) disabledThreads.add(String(threadID));
	if (failureCount >= MAX_FAILURES) killSwitch = true;

	try {
		const logger = require("./logs.js");
		logger(
			`fancy font disabled ${killSwitch ? "globally" : `for thread ${threadID}`} after a failed send, messages will use plain text`,
			"error"
		);
	} catch (error) {}
}

function isKilled() {
	return killSwitch;
}

/** clears the safety switches, used by the font command when re-enabling */
function reset(threadID) {
	if (threadID) disabledThreads.delete(String(threadID));
	else disabledThreads.clear();
	failureCount = 0;
	killSwitch = false;
}

/** global defaults from config.json, with sane fallbacks */
function globalSettings() {
	const cfg = (global.config && global.config.fancyfont) || {};
	return {
		enabled: killSwitch ? false : cfg.enabled !== false,
		style: isStyle(cfg.style) ? String(cfg.style).toLowerCase() : DEFAULT_STYLE,
		convertNumbers: cfg.convertNumbers !== false,
		skipUrls: cfg.skipUrls !== false
	};
}

/** per group override stored in threadData, falling back to the global config */
function settingsFor(threadID) {
	const base = globalSettings();
	if (!base.enabled) return base;
	if (!threadID) return base;
	// a previous send failed on this thread, keep it on plain text
	if (disabledThreads.has(String(threadID))) return { ...base, enabled: false };

	try {
		const data = global.data && global.data.threadData
			? global.data.threadData.get(String(threadID))
			: null;
		const local = data && data.fancyfont;
		if (!local) return base;

		return {
			enabled: typeof local.enabled === "boolean" ? local.enabled : base.enabled,
			style: isStyle(local.style) ? String(local.style).toLowerCase() : base.style,
			convertNumbers: typeof local.convertNumbers === "boolean"
				? local.convertNumbers
				: base.convertNumbers,
			skipUrls: base.skipUrls
		};
	} catch (error) {
		return base;
	}
}

function mentionTags(msg) {
	if (!msg || !msg.mentions) return [];
	const list = Array.isArray(msg.mentions)
		? msg.mentions
		: Object.values(msg.mentions).map(tag => ({ tag }));
	return list
		.map(item => (item && typeof item.tag === "string" ? item.tag : null))
		.filter(Boolean);
}

/** styles an outgoing sendMessage payload, string or object form */
function transform(msg, threadID) {
	const settings = settingsFor(threadID);
	if (!settings.enabled) return msg;

	if (typeof msg === "string" || typeof msg === "number") {
		const str = String(msg);
		if (str.length === 0 || str.length > MAX_STYLE_LENGTH) return msg;
		return apply(str, settings);
	}

	if (msg && typeof msg === "object" && typeof msg.body === "string" && msg.body.length > 0) {
		if (msg.body.length > MAX_STYLE_LENGTH) return msg;
		const styled = apply(msg.body, { ...settings, protect: mentionTags(msg) });

		// every mention tag must still be findable byte for byte, sendMessage
		// locates them with body.indexOf(tag) and errors out when it can't
		for (const tag of mentionTags(msg)) {
			if (styled.indexOf(tag) === -1) return msg;
		}

		return { ...msg, body: styled };
	}

	return msg;
}

/**
 * wraps api.sendMessage / api.editMessage once per api instance so every
 * command, event and handler produces styled text.
 */
function patchApi(api) {
	if (!api || api.__fancyFontPatched) return api;

	const originalSend = api.sendMessage;
	if (typeof originalSend === "function") {
		api.sendMessage = function (msg, threadID, ...rest) {
			const self = this;
			const plain = () => originalSend.call(self, msg, threadID, ...rest);

			if (killSwitch) return plain();

			let payload = msg;
			try {
				payload = transform(msg, threadID);
			} catch (error) {
				noteFailure(threadID);
				return plain();
			}

			// nothing was styled, no need for the retry safety net
			if (payload === msg) return plain();

			const [callback, ...tail] = rest;

			// callback form : wrap it so a styled send that errors is retried
			// as plain text before the caller ever sees a failure
			if (typeof callback === "function") {
				let retried = false;
				const guarded = function (err, info) {
					if (err && !retried) {
						retried = true;
						noteFailure(threadID);
						return originalSend.call(self, msg, threadID, callback, ...tail);
					}
					return callback.apply(this, arguments);
				};
				return originalSend.call(self, payload, threadID, guarded, ...tail);
			}

			// promise form (and the api.sendMessage(text, tid, messageID) form,
			// where callback is actually the reply id) : catch and resend plain
			try {
				const result = originalSend.call(self, payload, threadID, ...rest);
				if (result && typeof result.catch === "function") {
					return result.catch(error => {
						noteFailure(threadID);
						return plain();
					});
				}
				return result;
			} catch (error) {
				noteFailure(threadID);
				return plain();
			}
		};
	}

	const originalEdit = api.editMessage;
	if (typeof originalEdit === "function") {
		api.editMessage = function (text, messageID, callback) {
			let payload = text;
			try {
				const settings = globalSettings();
				payload = settings.enabled && typeof text === "string" && text.length <= MAX_STYLE_LENGTH
					? apply(text, settings)
					: text;
			} catch (error) {
				payload = text;
			}
			return originalEdit.call(this, payload, messageID, callback);
		};
	}

	api.__fancyFontPatched = true;
	return api;
}

module.exports = {
	DEFAULT_STYLE,
	apply,
	stylize,
	raw,
	listStyles,
	isStyle,
	styleLabel,
	settingsFor,
	globalSettings,
	transform,
	patchApi,
	isKilled,
	reset
};
