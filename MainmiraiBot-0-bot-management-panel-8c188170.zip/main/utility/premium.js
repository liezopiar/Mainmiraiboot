// shared helpers for the premium system (users + pending requests)
//
// storage lives in config.json :
//   haspremiumcmd   -> array of entries. an entry is either a legacy plain id
//                      ("100012345") or an object :
//                      { userID, addedAt, addedBy, expiresAt }
//                      no expiresAt (or null) means permanent access.
//   premiumrequests -> array of { userID, name, reason, threadID, time, requestedAt }
//
// every write keeps the file and global.config in sync so the running bot and
// the next restart always see the same list.

const path = require("path");
const { writeFileSync } = require("fs-extra");

const CONFIG_PATH = path.join(__dirname, "../../config.json");

// ── duration helpers ──────────────────────────────────────────────────────────
//
// durations are stored on an entry as `expiresAt` (ms epoch).
// an entry with no `expiresAt` never expires.

const SECOND = 1000;
const MINUTE = 60 * SECOND;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;
const WEEK = 7 * DAY;
const MONTH = 30 * DAY;
const YEAR = 365 * DAY;

// longest aliases first so "mo"/"month" is never eaten by "m" (minutes)
const UNITS = [
	{ ms: MONTH, names: ["months", "month", "mons", "mon", "mo"] },
	{ ms: MINUTE, names: ["minutes", "minute", "mins", "min", "m"] },
	{ ms: YEAR, names: ["years", "year", "yrs", "yr", "y"] },
	{ ms: WEEK, names: ["weeks", "week", "wks", "wk", "w"] },
	{ ms: DAY, names: ["days", "day", "d"] },
	{ ms: HOUR, names: ["hours", "hour", "hrs", "hr", "h"] },
	{ ms: SECOND, names: ["seconds", "second", "secs", "sec", "s"] }
];

const PERMANENT = ["perm", "perma", "permanent", "permanently", "forever", "inf", "infinite", "0"];

const ALL_NAMES = UNITS.reduce((acc, u) => acc.concat(u.names), []);
// e.g. "1hr", "2 d", "1 months", "1week2d"
const TOKEN_REGEX = new RegExp(`(\\d+)\\s*(${ALL_NAMES.join("|")})(?![a-z])`, "gi");

function unitToMs(name) {
	const lower = String(name).toLowerCase();
	const found = UNITS.find(u => u.names.includes(lower));
	return found ? found.ms : 0;
}

/**
 * parse a human duration into milliseconds.
 * accepts "1hr", "2d", "3d", "1week", "1 months", "1h30m", "perm".
 * returns { ms, permanent, label, consumed } or null when nothing could be parsed.
 * `consumed` is the raw matched text so the caller can strip it from a reason.
 */
function parseDuration(input) {
	if (!input) return null;
	const text = String(input).trim();
	if (!text) return null;

	const firstWord = text.split(/\s+/)[0].toLowerCase();
	if (PERMANENT.includes(firstWord)) {
		return { ms: 0, permanent: true, label: "permanent", consumed: firstWord };
	}

	TOKEN_REGEX.lastIndex = 0;
	let ms = 0;
	let consumedEnd = -1;
	let match;
	while ((match = TOKEN_REGEX.exec(text)) !== null) {
		// only accept tokens at the very start of the string (or directly chained onto
		// a previous one) so words inside a reason are never read as a duration
		const leading = text.slice(0, match.index).trim();
		if (consumedEnd === -1 && leading.length !== 0) break;
		if (consumedEnd !== -1 && text.slice(consumedEnd, match.index).trim().length !== 0) break;

		ms += parseInt(match[1], 10) * unitToMs(match[2]);
		consumedEnd = match.index + match[0].length;
	}

	if (ms <= 0) return null;
	return {
		ms,
		permanent: false,
		label: formatDuration(ms),
		consumed: text.slice(0, consumedEnd)
	};
}

/** turn milliseconds into a short readable label like "2 days 3 hours" */
function formatDuration(ms) {
	if (!ms || ms <= 0) return "0 seconds";
	const parts = [];
	const steps = [
		{ ms: YEAR, one: "year", many: "years" },
		{ ms: MONTH, one: "month", many: "months" },
		{ ms: WEEK, one: "week", many: "weeks" },
		{ ms: DAY, one: "day", many: "days" },
		{ ms: HOUR, one: "hour", many: "hours" },
		{ ms: MINUTE, one: "minute", many: "minutes" },
		{ ms: SECOND, one: "second", many: "seconds" }
	];
	let left = ms;
	for (const step of steps) {
		if (left < step.ms) continue;
		const count = Math.floor(left / step.ms);
		left -= count * step.ms;
		parts.push(`${count} ${count === 1 ? step.one : step.many}`);
		if (parts.length === 2) break;
	}
	return parts.join(" ") || "0 seconds";
}

/** human readable time left ("permanent", "2 days 3 hours", "expired") */
function formatRemaining(expiresAt) {
	if (!expiresAt) return "permanent";
	const left = Number(expiresAt) - Date.now();
	if (left <= 0) return "expired";
	return formatDuration(left);
}

/**
 * pull a duration out of a token list, keeping the other tokens untouched.
 * handles the split form too ("7 d", "1 month") by peeking at the next token.
 * returns { duration, rest } where duration is the raw text (or null).
 */
function extractDuration(tokens) {
	const list = (Array.isArray(tokens) ? tokens : []).map(t => String(t == null ? "" : t)).filter(Boolean);
	const rest = [];
	let duration = null;

	for (let i = 0; i < list.length; i++) {
		const token = list[i];
		if (duration) {
			rest.push(token);
			continue;
		}

		if (PERMANENT.includes(token.toLowerCase()) && token !== "0") {
			duration = token;
			continue;
		}

		// "7d", "1h30m" — a full duration inside one token
		if (/^\d+[a-z]/i.test(token) && parseDuration(token)) {
			duration = token;
			continue;
		}

		// "7 d", "1 month" — the number and the unit arrived as two tokens
		if (/^\d+$/.test(token) && i + 1 < list.length) {
			const joined = `${token}${list[i + 1]}`;
			if (/^[a-z]+$/i.test(list[i + 1]) && parseDuration(joined)) {
				duration = joined;
				i++;
				continue;
			}
		}

		rest.push(token);
	}

	return { duration, rest };
}

/** read config.json fresh from disk (bypassing the require cache) */
function loadConfig() {
	delete require.cache[require.resolve(CONFIG_PATH)];
	const config = require(CONFIG_PATH);
	config.haspremiumcmd = Array.isArray(config.haspremiumcmd) ? config.haspremiumcmd : [];
	config.premiumrequests = Array.isArray(config.premiumrequests) ? config.premiumrequests : [];
	config.premiumcodes = Array.isArray(config.premiumcodes) ? config.premiumcodes : [];
	config.premiumdenied = Array.isArray(config.premiumdenied) ? config.premiumdenied : [];
	return config;
}

/** persist config.json and mirror the premium fields into the live globals */
function saveConfig(config) {
	writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
	if (global.config) {
		global.config.haspremiumcmd = config.haspremiumcmd;
		global.config.premiumrequests = config.premiumrequests;
		global.config.premiumcodes = config.premiumcodes;
	}
	return config;
}

/** turn a legacy id string or an object into the object shape */
function normalize(entry) {
	if (entry === null || typeof entry === "undefined") return null;
	if (typeof entry === "object") {
		if (!entry.userID) return null;
		return {
			userID: String(entry.userID),
			addedAt: entry.addedAt || null,
			addedBy: entry.addedBy ? String(entry.addedBy) : null,
			expiresAt: entry.expiresAt ? Number(entry.expiresAt) : null
		};
	}
	return { userID: String(entry), addedAt: null, addedBy: null, expiresAt: null };
}

/** normalized premium list, taken from the given config or from disk */
function getList(config) {
	const source = config ? config.haspremiumcmd : (global.config && global.config.haspremiumcmd) || loadConfig().haspremiumcmd;
	return (source || []).map(normalize).filter(Boolean);
}

function isExpired(entry) {
	return !!(entry && entry.expiresAt && Number(entry.expiresAt) <= Date.now());
}

/** find a user's entry, ignoring expired ones */
function find(userID, config) {
	const id = String(userID);
	return getList(config).find(entry => entry.userID === id && !isExpired(entry)) || null;
}

/** does this user currently have premium access ? */
function isPremium(userID) {
	return !!find(userID);
}

/** time left label for a user ("permanent", "2 days 3 hours", "expired") */
function remaining(userID) {
	const entry = find(userID);
	if (!entry) return "expired";
	return formatRemaining(entry.expiresAt);
}

/**
 * grant premium to a user.
 * duration : null / "perm" for permanent, or anything bantime can parse ("7d", "1 month").
 * returns { entry, extended, label } or throws on an invalid duration.
 */
function addPremium(userID, { duration, addedBy } = {}) {
	const id = String(userID);
	const config = loadConfig();

	let expiresAt = null;
	let label = "permanent";
	if (duration) {
		const parsed = parseDuration(duration);
		if (!parsed) {
			const error = new Error(`invalid duration "${duration}"`);
			error.code = "INVALID_DURATION";
			throw error;
		}
		if (!parsed.permanent) {
			expiresAt = Date.now() + parsed.ms;
			label = parsed.label;
		}
	}

	// drop every stored copy of this id (fixes the old duplicate-entry bug)
	const others = config.haspremiumcmd.map(normalize).filter(Boolean).filter(entry => entry.userID !== id);
	const previous = find(id, config);
	const extended = !!previous;

	// extending a timed user stacks on top of the time they still have left
	if (extended && previous.expiresAt && expiresAt) {
		expiresAt = Number(previous.expiresAt) + (expiresAt - Date.now());
		label = formatRemaining(expiresAt);
	}

	const entry = {
		userID: id,
		addedAt: Date.now(),
		addedBy: addedBy ? String(addedBy) : (previous && previous.addedBy) || null,
		expiresAt
	};

	config.haspremiumcmd = [...others, entry];
	// granting access also clears any request the user had waiting
	config.premiumrequests = config.premiumrequests.filter(r => String(r.userID) !== id);
	saveConfig(config);

	return { entry, extended, label };
}

/** revoke premium. returns true when something was actually removed. */
function removePremium(userID) {
	const id = String(userID);
	const config = loadConfig();
	const before = config.haspremiumcmd.length;
	config.haspremiumcmd = config.haspremiumcmd.map(normalize).filter(Boolean).filter(entry => entry.userID !== id);
	if (config.haspremiumcmd.length === before) return false;
	saveConfig(config);
	return true;
}

/** rewrite the stored list in the object shape without changing who is on it */
function migrate() {
	const config = loadConfig();
	const needs = config.haspremiumcmd.some(entry => typeof entry !== "object" || entry === null);
	if (!needs) {
		if (global.config) global.config.haspremiumcmd = config.haspremiumcmd;
		return false;
	}
	config.haspremiumcmd = config.haspremiumcmd.map(normalize).filter(Boolean);
	saveConfig(config);
	return true;
}

/** remove every expired user, returns the ids that lost access */
function sweepExpired() {
	const config = loadConfig();
	const entries = config.haspremiumcmd.map(normalize).filter(Boolean);
	const expired = entries.filter(isExpired).map(entry => entry.userID);
	if (!expired.length) return [];
	config.haspremiumcmd = entries.filter(entry => !isExpired(entry));
	saveConfig(config);
	return expired;
}

/**
 * move premium time from one member to another.
 * the giver must be premium ; a timed giver pays the time out of their own balance
 * (they must keep at least a minute left), a permanent giver pays nothing.
 * returns { ok: true, ... } or { ok: false, reason } where reason is
 * "self" | "duration" | "nopremium" | "notenough".
 */
function giftPremium(fromID, toID, duration) {
	const from = String(fromID);
	const to = String(toID);
	if (from === to) return { ok: false, reason: "self" };

	const parsed = parseDuration(duration);
	if (!parsed || parsed.permanent || parsed.ms <= 0) return { ok: false, reason: "duration" };

	const giver = find(from);
	if (!giver) return { ok: false, reason: "nopremium" };

	const left = giver.expiresAt ? Number(giver.expiresAt) - Date.now() : null;
	// a timed giver has to stay premium after the gift, so keep a 1 minute floor
	if (left !== null && left - parsed.ms < 60 * 1000) {
		return { ok: false, reason: "notenough", left: Math.max(0, left) };
	}

	// credit the receiver first so a crash can never burn time without granting it
	const result = addPremium(to, { duration, addedBy: from });

	let giverLeft = null;
	if (left !== null) {
		// addPremium rewrote config.json, so re-read before touching the giver
		const config = loadConfig();
		config.haspremiumcmd = getList(config).map(entry =>
			entry.userID === from && entry.expiresAt
				? { ...entry, expiresAt: Number(entry.expiresAt) - parsed.ms }
				: entry
		);
		saveConfig(config);
		giverLeft = Number(giver.expiresAt) - parsed.ms;
	}

	return {
		ok: true,
		entry: result.entry,
		extended: result.extended,
		ms: parsed.ms,
		label: parsed.label,
		permanentGiver: left === null,
		giverLeft
	};
}

// ── pending requests ──────────────────────────────────────────────────────────

function getRequests() {
	return loadConfig().premiumrequests;
}

/** queue a request, replacing any earlier one from the same user */
function addRequest({ userID, name, reason, threadID }) {
	const id = String(userID);
	const config = loadConfig();
	const request = {
		userID: id,
		name: name || "Facebook User",
		reason: reason || "no reason given",
		threadID: threadID ? String(threadID) : null,
		requestedAt: Date.now()
	};
	config.premiumrequests = [...config.premiumrequests.filter(r => String(r.userID) !== id), request];
	saveConfig(config);
	return request;
}

function findRequest(userID) {
	const id = String(userID);
	return getRequests().find(r => String(r.userID) === id) || null;
}

/** drop a request from the queue, returns the removed request or null */
function removeRequest(userID) {
	const id = String(userID);
	const config = loadConfig();
	const request = config.premiumrequests.find(r => String(r.userID) === id) || null;
	if (!request) return null;
	config.premiumrequests = config.premiumrequests.filter(r => String(r.userID) !== id);
	saveConfig(config);
	return request;
}

/** 1-based spot in the queue (oldest request first), or 0 when not queued */
function requestPosition(userID) {
	const id = String(userID);
	const queue = [...getRequests()].sort((a, b) => (a.requestedAt || 0) - (b.requestedAt || 0));
	return queue.findIndex(r => String(r.userID) === id) + 1;
}

// ── denied requests ───────────────────────────────────────────────────────────
//
// a deny is remembered so the user cannot immediately spam another request.
// the cooldown is `global.config.premiumRequestCooldownHours` hours (default 24).

const DEFAULT_DENY_COOLDOWN_HOURS = 24;

function denyCooldownMs() {
	const hours = Number((global.config || {}).premiumRequestCooldownHours);
	return (Number.isFinite(hours) && hours >= 0 ? hours : DEFAULT_DENY_COOLDOWN_HOURS) * 60 * 60 * 1000;
}

function getDenied(config) {
	const source = config ? config.premiumdenied : loadConfig().premiumdenied;
	return Array.isArray(source) ? source : [];
}

/** remember that a request was denied (replaces an older deny for the same user) */
function addDenied({ userID, reason, by } = {}) {
	const id = String(userID);
	const config = loadConfig();
	const record = {
		userID: id,
		reason: reason || null,
		by: by ? String(by) : null,
		deniedAt: Date.now()
	};
	config.premiumdenied = [...getDenied(config).filter(d => String(d.userID) !== id), record];
	saveConfig(config);
	return record;
}

function findDenied(userID) {
	const id = String(userID);
	return getDenied().find(d => String(d.userID) === id) || null;
}

function clearDenied(userID) {
	const id = String(userID);
	const config = loadConfig();
	const denied = getDenied(config);
	const next = denied.filter(d => String(d.userID) !== id);
	if (next.length === denied.length) return false;
	config.premiumdenied = next;
	saveConfig(config);
	return true;
}

/**
 * is the user still inside their post-deny cooldown ?
 * returns { blocked, msLeft, record } — msLeft is 0 when they are free to request.
 */
function denyCooldown(userID) {
	const record = findDenied(userID);
	if (!record) return { blocked: false, msLeft: 0, record: null };
	const msLeft = Number(record.deniedAt) + denyCooldownMs() - Date.now();
	if (msLeft <= 0) return { blocked: false, msLeft: 0, record };
	return { blocked: true, msLeft, record };
}

// ── redeem codes ──────────────────────────────────────────────────────────────
//
// a code is { code, duration, uses, usedBy: [], createdBy, createdAt }
// `duration` is the raw label the operator typed (null = permanent premium)
// `uses` is how many times the code may still be redeemed.

const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

// the bot styles every outgoing message with fancyfont, so the code the user
// copies back is usually made of unicode look alikes (𝙿𝚁𝙴𝙼-𝙰7𝙺2) instead of
// plain ascii. these two helpers undo that so a redeem never fails just
// because of how the code was displayed or pasted.
const FANCY_FALLBACK = {
	"ᴀ": "A", "ʙ": "B", "ᴄ": "C", "ᴅ": "D", "ᴇ": "E", "ꜰ": "F", "ɢ": "G",
	"ʜ": "H", "ɪ": "I", "ᴊ": "J", "ᴋ": "K", "ʟ": "L", "ᴍ": "M", "ɴ": "N",
	"ᴏ": "O", "ᴘ": "P", "ǫ": "Q", "ʀ": "R", "ᴛ": "T", "ᴜ": "U", "ᴠ": "V",
	"ᴡ": "W", "ʏ": "Y", "ᴢ": "Z"
};

/** turn styled unicode letters/digits back into plain ascii */
function decodeFancy(text) {
	// NFKD folds the mathematical / fullwidth / letterlike blocks back to ascii
	const folded = String(text == null ? "" : text)
		.normalize("NFKD")
		.replace(/[\u0300-\u036f\u2063]/g, "");
	let out = "";
	for (const char of folded) out += FANCY_FALLBACK[char] || char;
	return out;
}

/**
 * comparison key for a code : styled characters folded to ascii, uppercased,
 * every separator/space dropped and the "PREM" label made optional.
 * so "prem-a7k2-9xq4", "𝙿𝚁𝙴𝙼-𝙰7𝙺2-9𝚇𝚀4", "PREM A7K2 9XQ4" and "a7k29xq4"
 * all resolve to the same code.
 */
function codeKey(input) {
	const cleaned = decodeFancy(input).toUpperCase().replace(/[^A-Z0-9]/g, "");
	if (!cleaned) return "";
	return cleaned.startsWith("PREM") ? cleaned.slice(4) : cleaned;
}

/** does the text the user sent look like a redeem code at all ? */
function looksLikeCode(input) {
	// a stored code always keys to 8 characters, and an existing code always wins
	if (findCode(input)) return true;
	return codeKey(input).length >= 8;
}

/** pretty form of a code as it is stored ("PREM-A7K2-9XQ4") */
function formatCode(input) {
	const key = codeKey(input);
	if (key.length === 8) return `PREM-${key.slice(0, 4)}-${key.slice(4)}`;
	return key ? `PREM-${key}` : "";
}

function getCodes(config) {
	const source = config ? config.premiumcodes : loadConfig().premiumcodes;
	return Array.isArray(source) ? source : [];
}

/** generate a readable code like "PREM-A7K2-9XQ4" */
function generateCode() {
	const block = () => Array.from({ length: 4 }, () => CODE_ALPHABET[Math.floor(Math.random() * CODE_ALPHABET.length)]).join("");
	return `PREM-${block()}-${block()}`;
}

/** create a new redeem code. throws INVALID_DURATION when the duration is unreadable. */
function createCode({ duration, uses, createdBy } = {}) {
	if (duration) {
		const parsed = parseDuration(duration);
		if (!parsed) {
			const error = new Error(`invalid duration "${duration}"`);
			error.code = "INVALID_DURATION";
			throw error;
		}
	}

	const config = loadConfig();
	const existing = getCodes(config).map(entry => entry.code);
	let code = generateCode();
	while (existing.includes(code)) code = generateCode();

	const record = {
		code,
		duration: duration || null,
		uses: Math.max(1, parseInt(uses, 10) || 1),
		usedBy: [],
		createdBy: createdBy ? String(createdBy) : null,
		createdAt: Date.now()
	};

	config.premiumcodes = [...getCodes(config), record];
	saveConfig(config);
	return record;
}

function findCode(code) {
	const key = codeKey(code);
	if (!key) return null;
	return getCodes().find(entry => codeKey(entry.code) === key) || null;
}

function removeCode(code) {
	const key = codeKey(code);
	if (!key) return false;
	const config = loadConfig();
	const codes = getCodes(config);
	const next = codes.filter(entry => codeKey(entry.code) !== key);
	if (next.length === codes.length) return false;
	config.premiumcodes = next;
	saveConfig(config);
	return true;
}

/** drop every code that has no uses left, returns how many were purged */
function clearUsedCodes() {
	const config = loadConfig();
	const codes = getCodes(config);
	const next = codes.filter(entry => (parseInt(entry.uses, 10) || 0) > 0);
	const purged = codes.length - next.length;
	if (!purged) return 0;
	config.premiumcodes = next;
	saveConfig(config);
	return purged;
}

/**
 * redeem a code for a user.
 * returns { ok: true, entry, label, code } or { ok: false, reason } where reason is
 * "notfound" | "used" | "already".
 */
function redeemCode(code, userID) {
	const id = String(userID);
	const key = codeKey(code);
	if (!key) return { ok: false, reason: "notfound" };

	const config = loadConfig();
	const codes = getCodes(config);
	const record = codes.find(entry => codeKey(entry.code) === key);

	if (!record) return { ok: false, reason: "notfound" };
	if ((record.usedBy || []).map(String).includes(id)) return { ok: false, reason: "already" };
	if ((parseInt(record.uses, 10) || 0) <= 0) return { ok: false, reason: "used" };

	let result;
	try {
		result = addPremium(id, { duration: record.duration, addedBy: record.createdBy });
	} catch (error) {
		// a code created with a duration the parser can no longer read must not
		// silently swallow the claim, tell the caller instead
		return { ok: false, reason: "duration", code: record.code };
	}

	// addPremium rewrote config.json, so re-read before touching the codes.
	// spent codes are kept (uses : 0) so a second attempt says "already used"
	// instead of the misleading "that code is not valid".
	const fresh = loadConfig();
	fresh.premiumcodes = getCodes(fresh).map(entry => {
		if (codeKey(entry.code) !== key) return entry;
		return {
			...entry,
			uses: Math.max(0, (parseInt(entry.uses, 10) || 1) - 1),
			usedBy: [...(entry.usedBy || []), id],
			lastUsedAt: Date.now()
		};
	});
	saveConfig(fresh);

	const label = result.entry.expiresAt ? formatRemaining(result.entry.expiresAt) : "permanent";
	return { ok: true, entry: result.entry, extended: result.extended, label, code: record.code };
}

module.exports = {
	CONFIG_PATH,
	PERMANENT,
	parseDuration,
	formatDuration,
	formatRemaining,
	extractDuration,
	loadConfig,
	saveConfig,
	normalize,
	getList,
	isExpired,
	find,
	isPremium,
	remaining,
	addPremium,
	removePremium,
	giftPremium,
	migrate,
	sweepExpired,
	getRequests,
	addRequest,
	findRequest,
	removeRequest,
	requestPosition,
	getDenied,
	addDenied,
	findDenied,
	clearDenied,
	denyCooldown,
	getCodes,
	generateCode,
	createCode,
	findCode,
	removeCode,
	clearUsedCodes,
	redeemCode,
	decodeFancy,
	codeKey,
	looksLikeCode,
	formatCode
};
