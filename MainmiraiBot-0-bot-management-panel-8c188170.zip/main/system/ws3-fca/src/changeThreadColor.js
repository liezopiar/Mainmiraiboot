"use strict";

const utils = require("../utils");
// @NethWs3Dev

module.exports = function (defaultFuncs, api, ctx) {
  return function changeThreadColor(color, threadID, callback) {
    let resolveFunc = function () {};
    let rejectFunc = function () {};
    const returnPromise = new Promise(function (resolve, reject) {
      resolveFunc = resolve;
      rejectFunc = reject;
    });

    if (!callback) {
      callback = function (err) {
        if (err) {
          return rejectFunc(err);
        }
        resolveFunc(err);
      };
    }

    if (!isNaN(color)) {
      color = color.toString();
    }
    // API only accepts lowercase letters in hex string
    const validatedColor = color !== null && color !== undefined ? String(color).toLowerCase() : color;

    // current messenger mutation (relay) - this is the one that actually works today
    function modernRequest() {
      const form = {
        fb_api_caller_class: "RelayModern",
        fb_api_req_friendly_name: "useChangeThreadThemeMutation",
        variables: JSON.stringify({
          input: {
            client_mutation_id: Math.round(Math.random() * 1024).toString(),
            actor_id: ctx.userID,
            thread_id: String(threadID),
            theme_id: validatedColor,
            source: "SETTINGS",
          },
        }),
        server_timestamps: true,
        doc_id: "6626861617379549",
        av: ctx.userID,
      };

      return defaultFuncs
        .post("https://www.facebook.com/api/graphql/", ctx.jar, form)
        .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
        .then(function (resData) {
          if (!resData) throw { error: "changeThreadColor: empty response" };
          if (resData.errors || resData.error) throw resData;
          const payload =
            resData.data &&
            (resData.data.message_thread_change_theme ||
              resData.data.messenger_thread_change_theme);
          // some accounts return an empty data object even on success, so only
          // fail when facebook explicitly reports an error above
          return payload || resData;
        });
    }

    // legacy graphqlbatch endpoint, kept as a fallback for older sessions
    function legacyRequest() {
      const form = {
        dpr: 1,
        queries: JSON.stringify({
          o0: {
            doc_id: "1727493033983591",
            query_params: {
              data: {
                actor_id: ctx.userID,
                client_mutation_id: "0",
                source: "SETTINGS",
                theme_id: validatedColor,
                thread_id: String(threadID),
              },
            },
          },
        }),
      };

      return defaultFuncs
        .post("https://www.facebook.com/api/graphqlbatch/", ctx.jar, form)
        .then(utils.parseAndCheckLogin(ctx, defaultFuncs))
        .then(function (resData) {
          if (!Array.isArray(resData) || resData.length === 0) {
            throw { error: "changeThreadColor: empty response" };
          }
          if (resData[resData.length - 1].error_results > 0) {
            throw new utils.CustomError(resData[0].o0.errors);
          }
          return resData;
        });
    }

    modernRequest()
      .then(function () {
        return callback();
      })
      .catch(function (modernErr) {
        return legacyRequest()
          .then(function () {
            return callback();
          })
          .catch(function () {
            console.error("changeThreadColor", modernErr);
            return callback(modernErr);
          });
      });

    return returnPromise;
  };
};
