module.exports = function({ api, models, Users, Threads, Currencies }) {
    const stringSimilarity = require('string-similarity'),
      escapeRegex = (str) => str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
      logger = require("../../utility/logs.js");
    const axios = require('axios')
    const moment = require("moment-timezone");
      const premiumUtil = require("../../utility/premium.js");
    const runCommand = async function({ event }) {
      const dateNow = Date.now()
      const time = moment.tz("Asia/Manila").format("HH:MM:ss DD/MM/YYYY");
    //  const { allowinbox, adminonly, keyAdminOnly } = global.ryuko;
      const { allowinbox, adminonly, developermode, operators, approval, approvedgroups } = global.config;
      const bots = require("../../../bots.json");
      const userId = await api.getCurrentUserID();
      var prefix;
      var admins;
      var botname;
      var botMaintenance;
      try {
          prefix = bots.find(item => item.uid === userId).prefix;
          admins = bots.find(item => item.uid === userId).admins;
          botname = bots.find(item => item.uid === userId).botname;
          botMaintenance = bots.find(item => item.uid === userId).maintenance || {};
      } catch (error) {
          return api.logout();
      }
      const { userBanned, threadBanned, threadInfo, threadData, commandBanned } = global.data;
      const { commands, cooldowns } = global.client;
      var { body, senderID, threadID, messageID } = event;
      var senderID = String(senderID),
        threadID = String(threadID);
      const threadSetting = threadData.get(threadID) || {}
      const args = (body || '').trim().split(/ +/);
      const commandName = args.shift()?.toLowerCase();
      var command = commands.get(commandName);
      const send = global.send;
      const replyAD = 'mode - only bot admin can use bot';
      const globalMaintenance = global.config.maintenance || {};
      // per-bot maintenance (set from the bot panel) takes priority over the global one
      const maintenance = botMaintenance.status === true ? botMaintenance : globalMaintenance;
      const notApproved = `this box is not approved.\nuse "${prefix}request" to send a approval request from bot operators`;
      // this must match the "request" command only. it used to match any body
      // starting with "<prefix>request", so "<prefix>requestpremium" was
      // swallowed here and the real command never ran
      const isApprovalRequest = typeof body === "string"
        && new RegExp(`^${escapeRegex(prefix)}request(?:\\s|$)`, "i").test(body.trim());
      if (isApprovalRequest && approval) {
        if (approvedgroups.includes(threadID)) {
          return api.sendMessage('this box is already approved', threadID, messageID)
        }
        let ryukodev;
        let request;
          // a missing thread info used to throw here and take down the whole
          // handler, leaving the bot silent for every following command
          var groupname = (threadInfo.get(threadID) || {}).threadName
            || (threadData.get(threadID) || {}).threadName
            || "name does not exist";
          ryukodev = `group name : ${groupname}\ngroup id : ${threadID}`;
          request = `${groupname} group is requesting for approval`
        try {
          operators.forEach(i => {
              api.sendMessage(request + '\n\n' + ryukodev, i);
          })

          // store the request in the pending list so admins/operators can review it later
          try {
            const fsExtra = global.nodemodule["fs-extra"];
            const path = require("path");
            const cfgPath = path.join(__dirname, "../../../config.json");
            delete require.cache[require.resolve("../../../config.json")];
            const cfg = require("../../../config.json");
            cfg.pendingrequests = cfg.pendingrequests || [];
            cfg.approvedgroups = cfg.approvedgroups || [];
            const alreadyPending = cfg.pendingrequests.some(r => String(r.threadID) === String(threadID));
            const alreadyApproved = cfg.approvedgroups.map(String).includes(String(threadID));
            if (!alreadyPending && !alreadyApproved) {
              cfg.pendingrequests.push({
                threadID: String(threadID),
                name: groupname,
                senderID: String(senderID),
                time
              });
              fsExtra.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), "utf8");
              global.config.pendingrequests = cfg.pendingrequests;
            }
          } catch (e) {
            logger(e, "error");
          }

          return api.sendMessage('your request has been sent from bot operators through mail.', threadID, messageID);
        } catch (error) {
          logger(error, "error");
        }
        return;
      }
      if (command && (command.config.name.toLowerCase() === commandName.toLowerCase()) &&(!approvedgroups.includes(threadID) && !operators.includes(senderID) && !admins.includes(senderID) && approval)) {
        return api.sendMessage(notApproved, threadID, async (err, info) => {
              await new Promise(resolve => setTimeout(resolve, 5 * 1000));
              return api.unsendMessage(info.messageID);
            });
      }
      if (typeof body === 'string' && body.startsWith(prefix) && (!approvedgroups.includes(threadID) && !operators.includes(senderID) && !admins.includes(senderID) && approval)) {
        return api.sendMessage(notApproved, threadID, async (err, info) => {
              await new Promise(resolve => setTimeout(resolve, 5 * 1000));
              return api.unsendMessage(info.messageID);
            });
      }
      if (command && (command.config.name.toLowerCase() === commandName.toLowerCase()) && (!admins.includes(senderID) && !operators.includes(senderID) && adminonly && senderID !== api.getCurrentUserID())) {
        return api.sendMessage(replyAD, threadID, messageID);
      }
      if (typeof body === 'string' && body.startsWith(prefix) && (!operators.includes(senderID) && adminonly && senderID !== api.getCurrentUserID())) {
        return api.sendMessage(replyAD, threadID, messageID);
      }

      // maintenance mode - only bot admins and operators can use the bot while it is on
      if (maintenance.status === true && !admins.includes(senderID) && !operators.includes(senderID) && senderID !== userId) {
        const usedCommand = (command && commandName && command.config.name.toLowerCase() === commandName.toLowerCase())
          || (typeof body === 'string' && body.startsWith(prefix));
        if (usedCommand) {
          const reason = maintenance.reason || 'the bot is currently under maintenance, please try again later.';
          const since = maintenance.since ? `\nsince : ${maintenance.since}` : '';
          return api.sendMessage(`🔧 maintenance mode\n\n${reason}${since}`, threadID, async (err, info) => {
            if (err || !info) return;
            await new Promise(resolve => setTimeout(resolve, 5 * 1000));
            return api.unsendMessage(info.messageID);
          }, messageID);
        }
        return;
      }
  
  
      if (userBanned.has(senderID) || threadBanned.has(threadID) || allowinbox == ![] && senderID == threadID) {
        if (!admins.includes(senderID.toString()) && !operators.includes(senderID.toString()))
        {
          if (command && (command.config.name.toLowerCase() === commandName.toLowerCase()) && userBanned.has(senderID)) {
            const { reason, dateAdded } = userBanned.get(senderID) || {};
            return api.sendMessage(`you're unable to use bot\nreason : ${reason}\ndate banned : ${dateAdded}`, threadID, async (err, info) => {
              await new Promise(resolve => setTimeout(resolve, 5 * 1000));
              return api.unsendMessage(info.messageID);
            }, messageID);
          } else {
            if (command && (command.config.name.toLowerCase() === commandName.toLowerCase()) && threadBanned.has(threadID)) {
              const { reason, dateAdded } = threadBanned.get(threadID) || {};
              return api.sendMessage(global.getText("handleCommand", "threadBanned", reason, dateAdded), threadID, async (err, info) => {
                await new Promise(resolve => setTimeout(resolve, 5 * 1000));
                return api.unsendMessage(info.messageID);
              }, messageID);
            }
          } 
          if (typeof body === 'string' && body.startsWith(prefix) && userBanned.has(senderID)) {
            const { reason, dateAdded } = userBanned.get(senderID) || {};
            return api.sendMessage(`you're unable to use bot\nreason : ${reason}\ndate banned : ${dateAdded}`, threadID, async (err, info) => {
              await new Promise(resolve => setTimeout(resolve, 5 * 1000));
              return api.unsendMessage(info.messageID);
            }, messageID);
          } else {
            if (typeof body === 'string' && body.startsWith(prefix) && threadBanned.has(threadID)) {
              const { reason, dateAdded } = threadBanned.get(threadID) || {};
              return api.sendMessage(global.getText("handleCommand", "threadBanned", reason, dateAdded), threadID, async (err, info) => {
                await new Promise(resolve => setTimeout(resolve, 5 * 1000));
                return api.unsendMessage(info.messageID);
              }, messageID);
            }
          }
  
        }
      }
  
      if (typeof commandName === 'string' && typeof prefix === 'string' && prefix.length > 0 && commandName.startsWith(prefix)) {
        if (!command) {
          const allCommandName = Array.from(commands.keys());
          const checker = stringSimilarity.findBestMatch(commandName, allCommandName);
          if (checker.bestMatch.rating >= 0.5) {
            command = commands.get(checker.bestMatch.target);
          } else {
            return api.sendMessage(global.getText("handleCommand", "commandNotExist", checker.bestMatch.target), threadID, messageID);
          }
        }
      }
      // "command" is undefined for ordinary chat messages, reading
      // command.config.name here used to throw and stop the whole handler
      if (command && command.config && (commandBanned.get(threadID) || commandBanned.get(senderID))) {
        if (!admins.includes(senderID) && !operators.includes(senderID)) {
          const banThreads = commandBanned.get(threadID) || [],
            banUsers = commandBanned.get(senderID) || [];
          if (banThreads.includes(command.config.name))
            return api.sendMessage(global.getText("handleCommand", "commandThreadBanned", command.config.name), threadID, async (err, info) => {
              await new Promise(resolve => setTimeout(resolve, 5 * 1000))
              return api.unsendMessage(info.messageID);
            }, messageID);
          if (banUsers.includes(command.config.name))
            return api.sendMessage(global.getText("handleCommand", "commandUserBanned", command.config.name), threadID, async (err, info) => {
              await new Promise(resolve => setTimeout(resolve, 5 * 1000));
              return api.unsendMessage(info.messageID);
            }, messageID);
        }
      }
      const premium = global.config.premium;
      if (premium) {
        if (command && command.config && command.config.premium) {
          // expired users lose access on their own, staff never needs premium
          premiumUtil.sweepExpired();
          const bypass = admins.includes(senderID) || operators.includes(senderID);
          if (!bypass && !premiumUtil.isPremium(senderID)) {
            return api.sendMessage(`the command you used is only for premium users. If you want to use it, you can contact the admins and operators of the bot or you can type ${prefix}requestpremium.`, event.threadID, async (err, eventt) => {
              if (err) {
                return;
              }
                await new Promise(resolve => setTimeout(resolve, 5 * 1000))
                return api.unsendMessage(eventt.messageID);
            }, event.messageID);
          }
        }
      }
  
      if (command && command.config) {
        // prefix-less commands (premium, requestpremium, redeem ...) are also
        // accepted with the prefix, otherwise a user copying "redeem <code>"
        // from a help text gets no answer at all
        if (command.config.prefix === false) {
          const typed = commandName.toLowerCase();
          const plain = command.config.name.toLowerCase();
          const withPrefix = `${prefix}${plain}`.toLowerCase();
          if (typed !== plain && typed !== withPrefix) {
            api.sendMessage(global.getText("handleCommand", "notMatched", command.config.name), event.threadID, event.messageID);
            return;
          }
        }
        if (command.config.prefix === true && !body.startsWith(prefix)) {
          return;
        }
      }
      if (command && command.config) {
        if (typeof command.config.prefix === 'undefined') {
          api.sendMessage(global.getText("handleCommand", "noPrefix", command.config.name), event.threadID, event.messageID);
          return;
        }
      }
  
  
      if (command && command.config && command.config.category && command.config.category.toLowerCase() === 'nsfw' && !global.data.threadAllowNSFW.includes(threadID) && !admins.includes(senderID))
        return api.sendMessage(global.getText("handleCommand", "threadNotAllowNSFW"), threadID, async (err, info) => {
          await new Promise(resolve => setTimeout(resolve, 5 * 1000))
          return api.unsendMessage(info.messageID);
        }, messageID);
      var threadInfo2;
      if (event.isGroup == !![])
        try {
          threadInfo2 = (threadInfo.get(threadID) || await Threads.getInfo(threadID))
          if (Object.keys(threadInfo2).length == 0) throw new Error();
        } catch (err) {
          logger(global.getText("handleCommand", "cantGetInfoThread", "error"));
        }
      var permssion = 0;
      // a missing / empty thread info used to throw here and kill the whole
      // handler, which made the bot go silent on every command in that group
      var threadInfoo = threadInfo.get(threadID);
      if (!threadInfoo || Object.keys(threadInfoo).length === 0) {
        try {
          threadInfoo = await Threads.getInfo(threadID);
        } catch (err) {
          threadInfoo = {};
        }
      }
      const groupAdmins = Array.isArray(threadInfoo?.adminIDs) ? threadInfoo.adminIDs : [];
      const Find = groupAdmins.find(el => String(el?.id ?? el) == senderID);
      const ryuko = '!operators.includes(senderID)';
      if (operators.includes(senderID.toString())) permssion = 3;
      else if (admins.includes(senderID.toString())) permssion = 2;
      else if (!admins.includes(senderID) && ryuko && Find) permssion = 1;
      if (command && command.config && command.config.permission && command.config.permission > permssion) {
        return api.sendMessage(global.getText("handleCommand", "permissionNotEnough", command.config.name), event.threadID, event.messageID);
      }
  
      if (command && command.config && !client.cooldowns.has(command.config.name)) {
        client.cooldowns.set(command.config.name, new Map());
      }
  
      const timestamps = command && command.config ? client.cooldowns.get(command.config.name) : undefined;
  
      const expirationTime = (command && command.config && command.config.cooldowns || 1) * 1000;
  
      if (timestamps && timestamps instanceof Map && timestamps.has(senderID) && dateNow < timestamps.get(senderID) + expirationTime)
  
        return api.setMessageReaction('🕚', event.messageID, err => (err) ? logger('An error occurred while executing setMessageReaction' + 2, "error") : '', !![]);
      var getText2;
      if (command && command.languages && typeof command.languages === 'object' && command.languages.hasOwnProperty(global.config.language))
  
        getText2 = (...values) => {
          var lang = command.languages[global.config.language][values[0]] || '';
          for (var i = values.length; i > 0x2533 + 0x1105 + -0x3638; i--) {
            const expReg = RegExp('%' + i, 'g');
            lang = lang.replace(expReg, values[i]);
          }
          return lang;
        };
      else getText2 = () => { };
      
      try {
        const Obj = {
          api: api,
          event: event,
          args: args,
          models: models,
          Users: Users,
          prefix: prefix,
          botname: botname,
          admin: admins,
          Threads: Threads,
          Currencies: Currencies,
          permssion: permssion,
          getText: getText2,
          botid: userId
        };
  
        if (command && typeof command.run === 'function') {
          // the web control panel can disable a command, gate it behind its
          // whitelist / blacklist or apply its own cooldown before anything runs
          const panel = global.panel;
          if (panel) {
            const denied = panel.gate({
              botId: userId,
              command,
              senderID,
              threadID,
              isAdmin: admins.includes(senderID) || operators.includes(senderID) || senderID === userId
            });
            if (denied) {
              return api.sendMessage(denied, threadID, async (err, info) => {
                if (err || !info) return;
                await new Promise(resolve => setTimeout(resolve, 8 * 1000));
                return api.unsendMessage(info.messageID);
              }, messageID);
            }
          }

          // without await, a rejected async command failed silently and the
          // user got no reply at all
          await command.run(Obj);
          if (timestamps && typeof timestamps.set === 'function') timestamps.set(senderID, dateNow);

          // feeds the dashboard counters, the usage chart and the console log
          if (panel) panel.recordCommand(userId, command.config.name, senderID, Date.now() - dateNow);

          if (developermode == !![]) {
            logger(global.getText("handleCommand", "executeCommand", time, commandName, senderID, threadID, args.join(" "), (Date.now()) - dateNow) + '\n', "cmd");
          }
  
          return;
        }
      } catch (e) {
        if (global.panel && command && command.config) {
          global.panel.recordError(userId, command.config.name, (e && e.message) || e, senderID);
        }
        return api.sendMessage(global.getText("handleCommand", "commandError", commandName, e), threadID);
      }
    };

    // an unhandled throw in here used to leave the bot completely silent, now
    // the error is logged so the next message is still processed normally
    return async function({ event }) {
      try {
        return await runCommand({ event });
      } catch (error) {
        logger(`handleCommand error : ${(error && error.stack) || error}`, "error");
      }
    };
  };
