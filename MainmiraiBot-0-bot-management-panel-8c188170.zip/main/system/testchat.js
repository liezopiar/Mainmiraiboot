/**
 * test chat sandbox
 *
 * runs real command modules from script/commands and captures whatever the command tried to
 * send back, instead of delivering it to facebook. this powers the "Test Bot" chat panels.
 *
 * two modes :
 *   demo  - no bot session. every api call is faked, the database controllers are stubbed and
 *           only permission 0 commands are allowed. safe for anonymous visitors on the home page.
 *   live  - an authenticated bot panel. read only api calls hit the real account so commands that
 *           need user or thread info still work, but nothing is ever sent to a real chat.
 */

const DEMO_THREAD_ID = "100000000000001";
const DEMO_SENDER_ID = "100000000000002";
const DEMO_BOT_ID = "100000000000003";

// commands that must never run from the web tester, they restart, log out or mass message
const BLOCKED = [
  "logout", "restart", "shutdown", "stop", "eval", "exec", "shell", "cmd",
  "notify", "notification", "broadcast", "sendall", "spam", "autopost", "post",
  "leave", "leavegroup", "kick", "adduser", "add", "join", "accept", "approve",
];

/**
 * the fake facebook api handed to the command. read only helpers fall through to the real api
 * when we have one, everything that would write to facebook is captured instead.
 */
function createMockApi({ realApi, botId, collect, threadID }) {
  const noop = () => {};

  // sendMessage has a few shapes in this codebase :
  //   sendMessage(msg, threadID)
  //   sendMessage(msg, threadID, messageID)
  //   sendMessage(msg, threadID, callback)
  //   sendMessage(msg, threadID, callback, messageID)
  const sendMessage = (msg, tid, third, fourth) => {
    const callback = typeof third === "function" ? third : null;
    collect(msg);
    const info = {
      messageID: "test-" + Math.random().toString(36).slice(2, 10),
      threadID: String(tid || threadID),
      timestamp: Date.now(),
    };
    if (callback) {
      // commands often register a reply handler or unsend inside this callback, so keep it async
      setTimeout(() => {
        try { callback(null, info); } catch (e) {}
      }, 0);
    }
    return Promise.resolve(info);
  };

  const api = {
    sendMessage,
    sendMessageMqtt: sendMessage,
    // reactions, typing and unsend are meaningless in the sandbox
    setMessageReaction: noop,
    sendTypingIndicator: noop,
    markAsRead: noop,
    markAsReadAll: noop,
    unsendMessage: noop,
    setOptions: noop,
    getCurrentUserID: () => String(botId),
    getAppState: () => [],
    // writes to facebook are swallowed so a tester can never mutate a real account
    changeNickname: noop,
    changeThreadColor: noop,
    changeThreadEmoji: noop,
    changeAdminStatus: noop,
    changeGroupImage: noop,
    setTitle: noop,
    addUserToGroup: noop,
    removeUserFromGroup: noop,
    createPost: noop,
    createCommentPost: noop,
    handleMessageRequest: noop,
    muteThread: noop,
    deleteThread: noop,
    logout: noop,
  };

  // read only helpers, use the real account when available so commands like "info" still work
  const passthrough = [
    "getUserInfo", "getThreadInfo", "getThreadList", "getUserID",
    "getThreadPictures", "getThreadHistory", "resolvePhotoUrl",
    "httpGet", "httpPost", "httpPostFormData", "getFriendsList", "getRegion",
  ];
  for (const name of passthrough) {
    if (realApi && typeof realApi[name] === "function") {
      api[name] = realApi[name].bind(realApi);
    }
  }

  // fallbacks for demo mode, plus anything the real api does not expose
  if (typeof api.getUserInfo !== "function") {
    api.getUserInfo = async (id) => {
      const ids = Array.isArray(id) ? id : [id];
      const out = {};
      for (const i of ids) {
        out[String(i)] = {
          name: String(i) === String(botId) ? "OP AutoBot" : "Test User",
          firstName: "Test",
          vanity: "",
          profileUrl: "https://facebook.com",
          gender: 1,
          type: "user",
          isFriend: false,
          thumbSrc: "/placeholder.svg?height=80&width=80",
        };
      }
      return out;
    };
  }
  if (typeof api.getThreadInfo !== "function") {
    api.getThreadInfo = async () => ({
      threadID: String(threadID),
      threadName: "Test Sandbox",
      participantIDs: [String(DEMO_SENDER_ID), String(botId)],
      userInfo: [],
      adminIDs: [{ id: String(DEMO_SENDER_ID) }],
      isGroup: true,
      messageCount: 1,
      emoji: null,
    });
  }
  if (typeof api.getThreadList !== "function") api.getThreadList = async () => [];
  if (typeof api.getUserID !== "function") api.getUserID = async () => [];

  // anything else a command might reach for should fail quietly rather than crash the request
  return new Proxy(api, {
    get(target, prop) {
      if (prop in target) return target[prop];
      return () => {};
    },
  });
}

/** in demo mode the database is stubbed so a visitor cannot write to it */
function createStubControllers() {
  const empty = async () => [];
  const nul = async () => null;
  const stub = {
    getAll: empty,
    getData: nul,
    setData: async () => true,
    delData: async () => true,
    createData: async () => true,
    getInfo: async () => ({}),
    getNameUser: async () => "Test User",
    getMoney: async () => 0,
    increaseMoney: async () => true,
    decreaseMoney: async () => true,
    setMoney: async () => true,
  };
  return new Proxy(stub, {
    get(t, p) {
      if (p in t) return t[p];
      return async () => null;
    },
  });
}

/** turn whatever a command passed to sendMessage into plain text for the chat bubble */
function normalize(msg) {
  if (msg === null || msg === undefined) return null;
  if (typeof msg === "string" || typeof msg === "number") return String(msg);

  if (typeof msg === "object") {
    const parts = [];
    if (msg.body) parts.push(String(msg.body));

    const att = msg.attachment;
    if (att) {
      const count = Array.isArray(att) ? att.length : 1;
      parts.push(count > 1 ? `[${count} attachments]` : "[attachment]");
    }
    if (msg.location) parts.push("[location]");
    if (Array.isArray(msg.mentions) && msg.mentions.length) {
      parts.push(`[${msg.mentions.length} mention(s)]`);
    }
    if (!parts.length) {
      try { return JSON.stringify(msg); } catch (e) { return "[unsupported message]"; }
    }
    return parts.join("\n");
  }
  return String(msg);
}

/**
 * run one line of text through the bot's command set.
 * returns { replies: string[], command, note } - it never throws.
 */
async function runTestMessage({ body, prefix = "!", realApi = null, botId, botname = "OP AutoBot", models = null, demo = true, permission = 0 }) {
  const text = String(body || "").trim();
  if (!text) return { replies: [], command: null, note: "empty message" };

  const threadID = DEMO_THREAD_ID;
  const senderID = DEMO_SENDER_ID;
  const resolvedBotId = String(botId || DEMO_BOT_ID);

  const commands = global.client && global.client.commands;
  if (!commands || !commands.size) {
    return { replies: ["The command list is not loaded yet. Please try again in a moment."], command: null };
  }

  // resolve the command name, tolerating a missing prefix so beginners can just type "help"
  const args = text.split(/ +/);
  let raw = args.shift().toLowerCase();
  let usedPrefix = false;
  if (prefix && raw.startsWith(prefix)) {
    raw = raw.slice(prefix.length);
    usedPrefix = true;
  }
  if (!raw) return { replies: [`Type a command after the prefix, for example ${prefix}help`], command: null };

  let command = commands.get(raw);

  // suggest the closest match when the name is slightly wrong
  if (!command) {
    let best = null;
    try {
      const stringSimilarity = require("string-similarity");
      const match = stringSimilarity.findBestMatch(raw, Array.from(commands.keys()));
      if (match.bestMatch.rating >= 0.6) best = match.bestMatch.target;
    } catch (e) {}
    if (best) {
      return {
        replies: [`"${raw}" is not a command. Did you mean ${prefix}${best} ?`],
        command: null,
        suggestion: best,
      };
    }
    return {
      replies: [`"${raw}" is not a command. Type ${prefix}help to see everything available.`],
      command: null,
    };
  }

  const config = command.config || {};
  const name = String(config.name || raw).toLowerCase();

  if (BLOCKED.includes(name)) {
    return { replies: [`${prefix}${name} is disabled in the test sandbox because it affects the live bot session.`], command: name, blocked: true };
  }

  const needed = Number(config.permission || 0);
  if (needed > permission) {
    const roles = ["everyone", "group admins", "bot admins", "operators"];
    return { replies: [`${prefix}${name} is restricted to ${roles[needed] || "operators"}, so it cannot run here.`], command: name, blocked: true };
  }

  // a command declared prefix:true expects the prefix, tell the tester instead of silently doing nothing
  if (config.prefix === true && !usedPrefix) {
    return { replies: [`${name} needs the prefix. Try ${prefix}${name}`], command: name };
  }

  const replies = [];
  const collect = (msg) => {
    const t = normalize(msg);
    if (t !== null && t !== "") replies.push(t);
  };

  const api = createMockApi({ realApi, botId: resolvedBotId, collect, threadID });

  const event = {
    type: "message",
    body: (usedPrefix ? prefix : "") + raw + (args.length ? " " + args.join(" ") : ""),
    senderID,
    threadID,
    messageID: "test-" + Date.now(),
    isGroup: true,
    participantIDs: [senderID, resolvedBotId],
    attachments: [],
    mentions: {},
    timestamp: String(Date.now()),
    args,
  };

  // language helper, mirrors handleCommand
  let getText = () => "";
  if (command.languages && typeof command.languages === "object" && command.languages[global.config?.language]) {
    getText = (...values) => {
      let lang = command.languages[global.config.language][values[0]] || "";
      for (let i = values.length; i > 0; i--) {
        lang = lang.replace(new RegExp("%" + i, "g"), values[i]);
      }
      return lang;
    };
  }

  let Users, Threads, Currencies, modelRef;
  if (demo || !models) {
    Users = createStubControllers();
    Threads = createStubControllers();
    Currencies = createStubControllers();
    modelRef = null;
  } else {
    try {
      Users = require("./controllers/users")({ models, api: realApi || api });
      Threads = require("./controllers/threads")({ models, api: realApi || api });
      Currencies = require("./controllers/currencies")({ models });
      modelRef = models;
    } catch (e) {
      Users = createStubControllers();
      Threads = createStubControllers();
      Currencies = createStubControllers();
      modelRef = null;
    }
  }

  try {
    await Promise.race([
      Promise.resolve(
        command.run({
          api,
          event,
          args,
          models: modelRef,
          Users,
          prefix,
          botname,
          admin: [],
          Threads,
          Currencies,
          permssion: permission,
          getText,
          botid: resolvedBotId,
        })
      ),
      new Promise((resolve) => setTimeout(resolve, 20000)),
    ]);
  } catch (err) {
    return {
      replies: replies.length ? replies : [`${prefix}${name} threw an error: ${err.message || err}`],
      command: name,
      error: err.message || String(err),
    };
  }

  // some commands answer inside a callback or a floating promise, give them a short grace period
  if (!replies.length) {
    for (let i = 0; i < 40 && !replies.length; i++) {
      await new Promise((r) => setTimeout(r, 250));
    }
  }

  if (!replies.length) {
    const hint = config.usage ? `\nUsage: ${prefix}${config.usage}` : "";
    return {
      replies: [`${prefix}${name} ran but produced no reply here. It probably needs a real group chat, a reply, or an attachment.${hint}`],
      command: name,
      empty: true,
    };
  }

  return { replies, command: name };
}

module.exports = { runTestMessage, BLOCKED };
