'use strict';

// devlog.js
// the developer side ledger behind the /opiar panel.
//
//   * every deploy attempt, panel sign in and panel mutation is appended here
//   * one roster row per person who owns a bot on this host, with their counters
//   * developer authentication for the /opiar routes
//
// nothing in the panel is invented. if the developer panel shows a row, a real
// request wrote it through record() or touch() below.

const fs = require('fs-extra');
const path = require('path');
const jwt = require('jsonwebtoken');

const DATA_DIR = path.join(process.cwd(), 'botdata');
const LOG_FILE = path.join(DATA_DIR, 'devlog.json');
const CONFIG_FILE = path.join(process.cwd(), 'config.json');
const BOTS_FILE = path.join(process.cwd(), 'bots.json');
const STATES_DIR = path.join(process.cwd(), 'states');

const EVENT_LIMIT = 1500;      // ring buffer of audited events on disk
const USER_LIMIT = 500;        // roster rows we keep
const DEVICE_LIMIT = 6;        // phone / computer models remembered per owner
const SESSION_IDLE = 15 * 60 * 1000;   // a new panel session after this much silence
const LOGIN_WINDOW = 10 * 60 * 1000;
const LOGIN_TRIES = 8;

// ---------------------------------------------------------------------------
// event catalogue - the panel filters and colours come from here
// ---------------------------------------------------------------------------
const EVENT_TYPES = [
    { type: 'deploy.start', label: 'Deploy started', icon: 'fa-rocket', level: 'info', group: 'Deploy' },
    { type: 'deploy.success', label: 'Deploy finished', icon: 'fa-circle-check', level: 'success', group: 'Deploy' },
    { type: 'deploy.failed', label: 'Deploy failed', icon: 'fa-circle-exclamation', level: 'error', group: 'Deploy' },
    { type: 'panel.login', label: 'Panel sign in', icon: 'fa-right-to-bracket', level: 'success', group: 'Access' },
    { type: 'panel.login.failed', label: 'Wrong panel password', icon: 'fa-key', level: 'warning', group: 'Access' },
    { type: 'panel.session', label: 'Panel session opened', icon: 'fa-desktop', level: 'info', group: 'Access' },
    { type: 'panel.signout', label: 'Panel sign out', icon: 'fa-right-from-bracket', level: 'info', group: 'Access' },
    { type: 'bot.removed', label: 'Bot deleted', icon: 'fa-trash-can', level: 'warning', group: 'Access' },
    { type: 'config.change', label: 'Settings changed', icon: 'fa-sliders', level: 'info', group: 'Panel use' },
    { type: 'feature.toggle', label: 'Feature toggled', icon: 'fa-toggle-on', level: 'info', group: 'Panel use' },
    { type: 'command.toggle', label: 'Command changed', icon: 'fa-terminal', level: 'info', group: 'Panel use' },
    { type: 'schedule.change', label: 'Schedule changed', icon: 'fa-clock', level: 'info', group: 'Panel use' },
    { type: 'action.run', label: 'Bot action fired', icon: 'fa-bolt', level: 'info', group: 'Panel use' },
    { type: 'access.change', label: 'Access list changed', icon: 'fa-user-lock', level: 'info', group: 'Panel use' },
    { type: 'power.change', label: 'Session power action', icon: 'fa-power-off', level: 'warning', group: 'Panel use' },
    { type: 'dev.login', label: 'Developer sign in', icon: 'fa-user-shield', level: 'success', group: 'Developer' },
    { type: 'dev.login.failed', label: 'Developer sign in failed', icon: 'fa-shield-halved', level: 'error', group: 'Developer' },
    { type: 'dev.action', label: 'Developer action', icon: 'fa-screwdriver-wrench', level: 'warning', group: 'Developer' }
];

const TYPE_MAP = EVENT_TYPES.reduce((acc, t) => { acc[t.type] = t; return acc; }, {});

// ---------------------------------------------------------------------------
// store
// ---------------------------------------------------------------------------
let store = null;

function blank() {
    return { events: [], users: {}, seq: 0, since: new Date().toISOString() };
}

function read() {
    if (store) return store;
    try {
        const raw = JSON.parse(fs.readFileSync(LOG_FILE, 'utf-8'));
        store = {
            events: Array.isArray(raw.events) ? raw.events : [],
            users: raw.users && typeof raw.users === 'object' ? raw.users : {},
            seq: Number(raw.seq) || 0,
            since: raw.since || new Date().toISOString()
        };
    } catch (err) {
        store = blank();
    }
    return store;
}

// disk writes are debounced, a busy panel can fire many touches per second
let flushTimer = null;
function save() {
    if (flushTimer) return;
    flushTimer = setTimeout(() => {
        flushTimer = null;
        try {
            fs.ensureDirSync(DATA_DIR);
            fs.writeFileSync(LOG_FILE, JSON.stringify(read(), null, 2));
        } catch (err) {}
    }, 400);
}

function readConfig() {
    try {
        return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
    } catch (err) {
        return {};
    }
}

function readBots() {
    try {
        return JSON.parse(fs.readFileSync(BOTS_FILE, 'utf-8'));
    } catch (err) {
        return [];
    }
}

// ---------------------------------------------------------------------------
// developer authentication
// ---------------------------------------------------------------------------
// the credentials live in config.json under "devpanel" and can be overridden by
// the DEVPANEL_USER / DEVPANEL_PASS environment variables, so a deployed host
// never has to keep the real password in the repository.
function devConfig() {
    const cfg = readConfig();
    const dev = cfg.devpanel && typeof cfg.devpanel === 'object' ? cfg.devpanel : {};
    return {
        username: String(process.env.DEVPANEL_USER || dev.username || 'opiar'),
        password: String(process.env.DEVPANEL_PASS || dev.password || 'opiar'),
        title: dev.title || 'Developer Panel'
    };
}

function secret() {
    const dev = devConfig();
    return `opiar-dev:${dev.username}:${dev.password}`;
}

const loginTries = new Map();

function loginAllowed(ip) {
    const now = Date.now();
    const tries = (loginTries.get(ip) || []).filter(t => now - t < LOGIN_WINDOW);
    loginTries.set(ip, tries);
    return tries.length < LOGIN_TRIES;
}

function loginFailed(ip) {
    const tries = loginTries.get(ip) || [];
    tries.push(Date.now());
    loginTries.set(ip, tries);
}

function signIn(username, password, ip) {
    if (!loginAllowed(ip)) {
        return { error: 'too many attempts, wait a few minutes and try again.' };
    }
    const dev = devConfig();
    const ok = String(username || '') === dev.username && String(password || '') === dev.password;
    if (!ok) {
        loginFailed(ip);
        record({
            type: 'dev.login.failed',
            message: `a wrong developer password was tried for "${String(username || '').slice(0, 40) || 'no username'}"`,
            actor: String(username || '').slice(0, 40) || 'unknown',
            ip
        });
        return { error: 'wrong developer username or password.' };
    }
    loginTries.delete(ip);
    record({
        type: 'dev.login',
        message: `${dev.username} opened the developer panel`,
        actor: dev.username,
        ip
    });
    return { token: jwt.sign({ dev: dev.username }, secret(), { expiresIn: '6h' }), username: dev.username };
}

function verifyDev(token) {
    if (!token) return null;
    try {
        return jwt.verify(String(token), secret());
    } catch (err) {
        return null;
    }
}

// ---------------------------------------------------------------------------
// recording
// ---------------------------------------------------------------------------
function clientIp(req) {
    if (!req) return 'unknown';
    const fwd = req.headers && req.headers['x-forwarded-for'];
    const raw = (Array.isArray(fwd) ? fwd[0] : fwd) || (req.socket && req.socket.remoteAddress) || 'unknown';
    return String(raw).split(',')[0].trim().replace(/^::ffff:/, '') || 'unknown';
}

// android puts the build model straight into the platform bracket, but it is a
// code like "SM-G991B". a small brand prefix makes the row readable without
// pretending we know the marketing name.
function brandOf(model) {
    const m = String(model || '').trim();
    if (!m) return '';
    if (/^SM-/i.test(m)) return `Samsung ${m}`;
    if (/^(GT-|SCH-|SPH-)/i.test(m)) return `Samsung ${m}`;
    if (/^Pixel/i.test(m)) return `Google ${m}`;
    if (/^(Redmi|POCO|Mi\s|M2\d|22\d{4}|23\d{4})/i.test(m)) return `Xiaomi ${m}`;
    if (/^(CPH|OPPO)/i.test(m)) return `OPPO ${m}`;
    if (/^(V\d{4}|vivo)/i.test(m)) return `vivo ${m}`;
    if (/^(RMX|realme)/i.test(m)) return `realme ${m}`;
    if (/^(moto|XT\d{4})/i.test(m)) return `Motorola ${m}`;
    if (/^(LM-|LG-)/i.test(m)) return `LG ${m}`;
    if (/^(ANE|ELS|VOG|LYA|MAR|JNY|STK|NEN)-/i.test(m)) return `Huawei ${m}`;
    if (/^(Infinix|TECNO|itel)/i.test(m)) return m;
    if (/^(Nokia)/i.test(m)) return m;
    return m;
}

// the phone model behind a request, as exact as the user agent allows. this is
// what the panel shows instead of an address : "Samsung SM-G991B (Android 13)".
function deviceOf(ua) {
    const s = String(ua || '');
    if (!s) return 'unknown device';

    if (/postman|curl|axios|python-requests|okhttp|got\/|node-fetch/i.test(s)) return 'api client';

    // ios never exposes the exact model, only the family and the os version
    if (/\biPhone\b/i.test(s)) {
        const v = s.match(/(?:CPU )?iPhone OS (\d+)[_.](\d+)/i);
        return v ? `iPhone (iOS ${v[1]}.${v[2]})` : 'iPhone';
    }
    if (/\biPad\b/i.test(s)) {
        const v = s.match(/CPU OS (\d+)[_.](\d+)/i);
        return v ? `iPad (iPadOS ${v[1]}.${v[2]})` : 'iPad';
    }

    // (Linux; Android 13; SM-G991B Build/TP1A.220624.014) -> SM-G991B
    if (/\bAndroid\b/i.test(s)) {
        const release = s.match(/Android\s+([\d.]+)/i);
        const bracket = s.match(/\(([^)]*Android[^)]*)\)/i);
        let model = '';
        if (bracket) {
            model = bracket[1]
                .split(';')
                .map(part => part.replace(/\s*Build\/.*$/i, '').trim())
                // drop the platform noise so only the model token is left
                .filter(part => part && !/^(linux|android\b.*|wv|u|x11)$/i.test(part))
                .map(part => part.slice(0, 40))[0] || '';
        }
        model = brandOf(model);
        if (model && release) return `${model} (Android ${release[1]})`;
        if (model) return model;
        return release ? `Android ${release[1]}` : 'Android phone';
    }

    if (/\bCrOS\b/i.test(s)) return 'Chromebook';
    if (/Windows Phone/i.test(s)) return 'Windows Phone';
    if (/Windows NT 10/i.test(s)) return 'Windows PC';
    if (/Windows NT/i.test(s)) return 'Windows PC (older)';
    if (/Macintosh|Mac OS X/i.test(s)) return 'Mac';
    if (/\bLinux\b/i.test(s)) return 'Linux PC';
    if (/\bMobile\b/i.test(s)) return 'mobile browser';
    return 'unknown device';
}

function agentOf(req) {
    return deviceOf(req && req.headers && req.headers['user-agent']);
}

function trimUser(users) {
    const keys = Object.keys(users);
    if (keys.length <= USER_LIMIT) return;
    keys
        .sort((a, b) => new Date(users[a].lastSeen || 0) - new Date(users[b].lastSeen || 0))
        .slice(0, keys.length - USER_LIMIT)
        .forEach(k => { delete users[k]; });
}

// the roster row for one bot owner. created the first time we see them, whether
// that is a deploy, a panel sign in or a single panel request.
function ownerRow(botId, patch) {
    const id = String(botId || '').trim();
    if (!id) return null;
    const s = read();
    if (!s.users[id]) {
        s.users[id] = {
            uid: id,
            owner: '',
            name: '',
            botname: '',
            firstSeen: new Date().toISOString(),
            lastSeen: new Date().toISOString(),
            deploys: 0,
            failedDeploys: 0,
            sessions: 0,
            requests: 0,
            changes: 0,
            devices: [],
            device: '',
            lastAction: ''
        };
        trimUser(s.users);
    }
    const row = s.users[id];
    row.lastSeen = new Date().toISOString();
    if (patch) Object.assign(row, patch);
    return row;
}

function record(entry) {
    const s = read();
    const type = TYPE_MAP[entry && entry.type] ? entry.type : 'panel.session';
    const meta = TYPE_MAP[type];
    const event = {
        id: ++s.seq,
        at: new Date().toISOString(),
        type,
        level: entry.level || meta.level,
        icon: meta.icon,
        label: meta.label,
        group: meta.group,
        message: String(entry.message == null ? meta.label : entry.message).slice(0, 400),
        botId: entry.botId ? String(entry.botId) : null,
        botName: entry.botName ? String(entry.botName).slice(0, 60) : null,
        owner: entry.owner ? String(entry.owner).slice(0, 40) : null,
        actor: entry.actor ? String(entry.actor).slice(0, 60) : null,
        ip: entry.ip || null,
        detail: entry.detail && typeof entry.detail === 'object' ? entry.detail : null
    };
    s.events.unshift(event);
    if (s.events.length > EVENT_LIMIT) s.events.length = EVENT_LIMIT;

    if (event.botId) {
        const row = ownerRow(event.botId, {});
        if (row) {
            if (event.owner) row.owner = event.owner;
            if (event.botName) row.botname = event.botName;
            const seenDevice = event.detail && event.detail.device ? String(event.detail.device) : '';
            if (!Array.isArray(row.devices)) row.devices = [];
            if (seenDevice && seenDevice !== 'unknown device' && !row.devices.includes(seenDevice)) {
                row.devices.unshift(seenDevice);
                if (row.devices.length > DEVICE_LIMIT) row.devices.length = DEVICE_LIMIT;
            }
            if (type === 'deploy.success') row.deploys++;
            if (type === 'deploy.failed') row.failedDeploys++;
            if (type === 'panel.login' || type === 'panel.session') row.sessions++;
            if (event.group === 'Panel use') row.changes++;
            row.lastAction = event.message;
        }
    }
    save();
    return event;
}

// called by every /panel/* request. counts the hit on the owner row and only
// writes an event when a new browser session starts, so the feed stays readable.
const lastTouch = new Map();

function touch(bot, req, route) {
    const id = String((bot && bot.uid) || '');
    if (!id) return;
    const ip = clientIp(req);
    const device = agentOf(req);
    const row = ownerRow(id, {
        owner: bot.username || '',
        name: bot.name || '',
        botname: bot.botname || '',
        device
    });
    if (!row) return;
    row.requests++;
    if (!Array.isArray(row.devices)) row.devices = [];
    if (device && device !== 'unknown device' && !row.devices.includes(device)) {
        row.devices.unshift(device);
        if (row.devices.length > DEVICE_LIMIT) row.devices.length = DEVICE_LIMIT;
    }

    const key = `${id}:${ip}`;
    const now = Date.now();
    const seen = lastTouch.get(key) || 0;
    lastTouch.set(key, now);
    if (now - seen > SESSION_IDLE) {
        record({
            type: 'panel.session',
            message: `${bot.username || bot.name || id} opened the bot panel from a ${device}`,
            botId: id,
            botName: bot.botname || bot.name || '',
            owner: bot.username || '',
            actor: bot.name || bot.username || id,
            ip,
            detail: { route: route || '', device }
        });
        return;
    }
    save();
}

// ---------------------------------------------------------------------------
// reporting
// ---------------------------------------------------------------------------
function deployedAt(uid) {
    try {
        return fs.statSync(path.join(STATES_DIR, `${uid}.json`)).mtime.toISOString();
    } catch (err) {
        const row = read().users[String(uid)];
        return row ? row.firstSeen : null;
    }
}

function botRows() {
    const s = read();
    const panel = global.panel;
    return readBots().map(bot => {
        const id = String(bot.uid);
        const row = s.users[id] || {};
        const online = !!(global.client && global.client.apis && global.client.apis.get(id));
        const account = global.client && global.client.accounts ? global.client.accounts.get(id) : null;
        const stats = panel && typeof panel.state === 'function' ? panel.state(id) : null;
        const settings = panel && typeof panel.settingsOf === 'function' ? panel.settingsOf(bot) : null;
        const features = settings ? settings.features : {};
        return {
            uid: id,
            name: bot.name || 'Unknown',
            botname: bot.botname || 'OP AutoBot',
            owner: bot.username || row.owner || '',
            prefix: bot.prefix || '-',
            thumbSrc: bot.thumbSrc || '/images/op-autobot-logo.svg',
            profileUrl: bot.profileUrl || '',
            online,
            signedIn: !!bot.token,
            uptime: account && Number(account.time) ? Number(account.time) : 0,
            deployedAt: deployedAt(id),
            hasSession: fs.existsSync(path.join(STATES_DIR, `${id}.json`)),
            admins: Array.isArray(bot.admins) ? bot.admins.length : 0,
            featuresOn: Object.keys(features).filter(k => features[k]).length,
            schedules: settings ? settings.schedules.length : 0,
            maintenance: !!(settings && settings.maintenance && settings.maintenance.status),
            commands: stats ? stats.commands : 0,
            messages: stats ? stats.messages : 0,
            errors: stats ? stats.errors : 0,
            people: stats ? stats.people.size : 0,
            lastSeen: row.lastSeen || null,
            requests: row.requests || 0,
            changes: row.changes || 0,
            sessions: row.sessions || 0,
            deploys: row.deploys || 0,
            failedDeploys: row.failedDeploys || 0,
            device: row.device || '',
            ips: Array.isArray(row.ips) ? row.ips : [],
            lastAction: row.lastAction || ''
        };
    });
}

// owners who no longer have a bot record still count as panel users, they are
// listed here as "left" so a deleted deploy does not quietly disappear
function orphanRows() {
    const s = read();
    const live = new Set(readBots().map(b => String(b.uid)));
    return Object.values(s.users)
        .filter(row => !live.has(String(row.uid)))
        .map(row => ({
            uid: row.uid,
            name: row.name || 'Unknown',
            botname: row.botname || '',
            owner: row.owner || '',
            online: false,
            signedIn: false,
            gone: true,
            deployedAt: row.firstSeen,
            lastSeen: row.lastSeen,
            requests: row.requests || 0,
            changes: row.changes || 0,
            sessions: row.sessions || 0,
            deploys: row.deploys || 0,
            failedDeploys: row.failedDeploys || 0,
            device: row.device || '',
            ips: Array.isArray(row.ips) ? row.ips : [],
            lastAction: row.lastAction || ''
        }));
}

function events(filter) {
    const opts = filter || {};
    const query = String(opts.q || '').trim().toLowerCase();
    const group = String(opts.group || '');
    const type = String(opts.type || '');
    const botId = opts.botId ? String(opts.botId) : '';
    const limit = Math.min(Math.max(Number(opts.limit) || 120, 1), 400);

    return read().events.filter(e => {
        if (group && e.group !== group) return false;
        if (type && e.type !== type) return false;
        if (botId && String(e.botId) !== botId) return false;
        if (query) {
            const hay = `${e.message} ${e.owner || ''} ${e.botName || ''} ${e.actor || ''} ${e.botId || ''} ${e.ip || ''}`.toLowerCase();
            if (!hay.includes(query)) return false;
        }
        return true;
    }).slice(0, limit);
}

function since(hours) {
    const cutoff = Date.now() - hours * 60 * 60 * 1000;
    return read().events.filter(e => new Date(e.at).getTime() >= cutoff);
}

function summary() {
    const bots = botRows();
    const day = since(24);
    const counts = day.reduce((acc, e) => {
        acc[e.type] = (acc[e.type] || 0) + 1;
        return acc;
    }, {});
    const s = read();
    return {
        bots: bots.length,
        online: bots.filter(b => b.online).length,
        panelUsers: Object.keys(s.users).length,
        deploys24: counts['deploy.success'] || 0,
        failedDeploys24: counts['deploy.failed'] || 0,
        signIns24: counts['panel.login'] || 0,
        rejected24: (counts['panel.login.failed'] || 0) + (counts['dev.login.failed'] || 0),
        changes24: day.filter(e => e.group === 'Panel use').length,
        events: s.events.length,
        commands: bots.reduce((sum, b) => sum + b.commands, 0),
        errors: bots.reduce((sum, b) => sum + b.errors, 0),
        people: bots.reduce((sum, b) => sum + b.people, 0),
        liveSessions: liveSessions(),
        deployLock: deployLock(),
        since: s.since,
        host: {
            uptime: Math.floor(process.uptime()),
            memory: Math.round(process.memoryUsage().rss / 1024 / 1024),
            node: process.version,
            commandModules: global.client && global.client.commands ? global.client.commands.size : 0
        }
    };
}

// a 24 hour bar series of everything audited, one column per two hours
function timeline() {
    const bucket = 2 * 60 * 60 * 1000;
    const now = Math.floor(Date.now() / bucket) * bucket;
    const day = since(26);
    const series = [];
    for (let i = 11; i >= 0; i--) {
        const at = now - i * bucket;
        series.push({
            at,
            label: new Date(at).toLocaleTimeString([], { hour: '2-digit' }),
            count: day.filter(e => {
                const t = new Date(e.at).getTime();
                return t >= at && t < at + bucket;
            }).length
        });
    }
    return series;
}

// ---------------------------------------------------------------------------
// rollups
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// appstates
// ---------------------------------------------------------------------------
// an appstate is a facebook session : whoever holds the cookie values holds the
// account. so the panel shows the shape of every saved state by default and only
// returns the values when a developer explicitly asks, which is audited.
const SAFE_KEYS = ['key', 'domain', 'path', 'hostOnly', 'creation', 'lastAccessed', 'expires', 'secure', 'httpOnly'];

function maskValue(value) {
    const v = String(value == null ? '' : value);
    if (!v) return '';
    if (v.length <= 6) return '•'.repeat(v.length);
    return `${v.slice(0, 3)}${'•'.repeat(Math.min(24, Math.max(4, v.length - 6)))}${v.slice(-3)}`;
}

function readState(uid) {
    const file = path.join(STATES_DIR, `${String(uid)}.json`);
    if (!fs.existsSync(file)) return { file, exists: false };
    const stat = fs.statSync(file);
    let parsed = null;
    let error = '';
    try {
        parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (err) {
        error = 'the file on disk is not valid json';
    }
    return {
        file,
        exists: true,
        bytes: stat.size,
        savedAt: stat.mtime.toISOString(),
        cookies: Array.isArray(parsed) ? parsed : null,
        error
    };
}

// one row per saved appstate, with the shape only : no cookie values leave here
function appstateRows() {
    const s = read();
    const rows = readBots().map(bot => {
        const id = String(bot.uid);
        const state = readState(id);
        const cookies = state.cookies || [];
        const row = s.users[id] || {};
        return {
            uid: id,
            owner: bot.username || row.owner || '',
            name: bot.name || 'Unknown',
            botname: bot.botname || 'OP AutoBot',
            thumbSrc: bot.thumbSrc || '/images/op-autobot-logo.svg',
            online: !!(global.client && global.client.apis && global.client.apis.get(id)),
            exists: state.exists,
            error: state.error || '',
            bytes: state.bytes || 0,
            savedAt: state.savedAt || null,
            count: cookies.length,
            keys: cookies.map(c => String((c && (c.key || c.name)) || '?')).slice(0, 24),
            domains: Array.from(new Set(cookies
                .map(c => String((c && c.domain) || ''))
                .filter(Boolean))).slice(0, 6),
            expires: cookies
                .map(c => c && c.expires ? new Date(c.expires).getTime() : 0)
                .filter(t => t > 0)
                .sort((a, b) => a - b)
                .map(t => new Date(t).toISOString())[0] || null
        };
    });
    return rows.sort((a, b) => Number(b.exists) - Number(a.exists) || a.owner.localeCompare(b.owner));
}

// the cookies of one saved appstate. masked unless reveal is true, and either
// way the developer's look is written to the ledger.
function appstateOf(uid, reveal, actor, ip) {
    const id = String(uid || '');
    const bot = readBots().find(b => String(b.uid) === id);
    const state = readState(id);
    if (!state.exists) return { error: 'this bot has no saved appstate on disk.' };
    if (state.error) return { error: state.error };

    const cookies = (state.cookies || []).map(cookie => {
        const out = {};
        for (const key of SAFE_KEYS) {
            if (cookie && cookie[key] !== undefined) out[key] = cookie[key];
        }
        out.key = String((cookie && (cookie.key || cookie.name)) || '?');
        const raw = String((cookie && cookie.value) || '');
        out.length = raw.length;
        out.value = reveal ? raw : maskValue(raw);
        return out;
    });

    record({
        type: 'dev.action',
        message: `${actor || 'the developer'} ${reveal ? 'revealed' : 'opened'} the saved appstate of ${(bot && (bot.username || bot.name)) || id}`,
        botId: id,
        botName: (bot && bot.botname) || '',
        owner: (bot && bot.username) || '',
        actor: actor || 'developer',
        ip,
        detail: { revealed: !!reveal, cookies: cookies.length }
    });

    return {
        uid: id,
        owner: (bot && bot.username) || '',
        botname: (bot && bot.botname) || '',
        savedAt: state.savedAt,
        bytes: state.bytes,
        revealed: !!reveal,
        cookies
    };
}

// the whole appstate file, byte for byte, for the download button
function appstateRaw(uid, actor, ip) {
    const id = String(uid || '');
    const state = readState(id);
    if (!state.exists) return { error: 'this bot has no saved appstate on disk.' };
    const bot = readBots().find(b => String(b.uid) === id);
    record({
        type: 'dev.action',
        message: `${actor || 'the developer'} downloaded the appstate of ${(bot && (bot.username || bot.name)) || id}`,
        botId: id,
        actor: actor || 'developer',
        ip,
        detail: { bytes: state.bytes }
    });
    return {
        file: `appstate-${id}.json`,
        savedAt: state.savedAt,
        appstate: state.cookies || []
    };
}

// what people are actually running, added up across every bot on the host.
// the counters live in panel's memory, so this resets with the process.
function hostCommands() {
    const panel = global.panel;
    if (!panel || typeof panel.commandUse !== 'function') return [];
    const totals = new Map();
    for (const bot of readBots()) {
        const owner = bot.username || '';
        for (const entry of panel.commandUse(bot.uid)) {
            if (!totals.has(entry.name)) totals.set(entry.name, { name: entry.name, count: 0, owners: [] });
            const row = totals.get(entry.name);
            row.count += entry.count;
            if (owner && !row.owners.includes(owner)) row.owners.push(owner);
        }
    }
    return Array.from(totals.values()).sort((a, b) => b.count - a.count);
}

function clear(actor, ip) {
    const s = read();
    s.events.length = 0;
    save();
    record({ type: 'dev.action', message: 'the developer cleared the audit trail', actor: actor || 'developer', ip });
    return true;
}

// the whole ledger, for the "download" button on the audit page. the developer
// gets the same json that sits on disk, nothing summarised away.
function dump() {
    const s = read();
    return {
        exportedAt: new Date().toISOString(),
        since: s.since,
        host: { node: process.version, uptime: Math.floor(process.uptime()) },
        users: s.users,
        events: s.events
    };
}

// ---------------------------------------------------------------------------
// deploy lock
// ---------------------------------------------------------------------------
// a host wide gate on /create. it lives in config.json so it survives a restart
// and is visible to anyone reading the file, not just to this process.
function deployLock() {
    const cfg = readConfig();
    const lock = cfg.deploylock && typeof cfg.deploylock === 'object' ? cfg.deploylock : {};
    return {
        status: !!lock.status,
        reason: String(lock.reason || 'new deployments are closed by the developer right now, please try again later.'),
        since: lock.since || null
    };
}

function setDeployLock(status, reason, actor, ip) {
    const cfg = readConfig();
    const current = deployLock();
    const next = {
        status: !!status,
        reason: String(reason || current.reason).slice(0, 200),
        since: status ? new Date().toISOString() : null
    };
    cfg.deploylock = next;
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
    try { delete require.cache[require.resolve(CONFIG_FILE)]; } catch (err) {}
    try { if (global.config) global.config.deploylock = next; } catch (err) {}

    record({
        type: 'dev.action',
        message: `${actor || 'the developer'} ${next.status ? 'closed' : 'reopened'} new deployments on this host`,
        actor: actor || 'developer',
        ip,
        detail: next
    });
    return next;
}

// how many owners touched a bot panel inside the idle window. this is the same
// window touch() uses to decide a new session, so the number always agrees with
// the "Panel session opened" lines in the feed.
function liveSessions() {
    const cutoff = Date.now() - SESSION_IDLE;
    return Object.values(read().users)
        .filter(row => new Date(row.lastSeen || 0).getTime() >= cutoff)
        .length;
}

module.exports = {
    EVENT_TYPES,
    devConfig,
    signIn,
    verifyDev,
    clientIp,
    agentOf,
    record,
    touch,
    events,
    summary,
    timeline,
    botRows,
    orphanRows,
    addresses,
    hostCommands,
    liveSessions,
    deployLock,
    setDeployLock,
    dump,
    clear
};
