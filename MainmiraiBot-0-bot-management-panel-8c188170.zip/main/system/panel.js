'use strict';

// panel.js
// the single source of truth shared by the web control panel and the live bot.
//
//   * persistence  - every toggle, rule, schedule and access list lives in bots.json
//   * telemetry    - counters, latency, the usage chart series, activity feed and console logs
//   * enforcement  - the runtime hooks that actually act on the flags the panel writes
//
// nothing here is decorative. if the dashboard shows a number, it was recorded below.

const fs = require('fs-extra');
const path = require('path');
const jwt = require('jsonwebtoken');
const cron = require('node-cron');
const moment = require('moment-timezone');

// the 19 one-shot facebook operations the Bot Actions page fires
const actions = require('./actions.js');

const BOTS_FILE = path.join(process.cwd(), 'bots.json');
const CONFIG_FILE = path.join(process.cwd(), 'config.json');

const PEOPLE_LIMIT = 400;     // how many bot users we keep in the roster

const LOG_LIMIT = 400;        // console log ring buffer per bot
const ACTIVITY_LIMIT = 40;    // dashboard activity feed
const BUCKET_MS = 5 * 60 * 1000;
const BUCKETS = 12;           // 12 x 5 min = the last hour on the usage chart
const LATENCY_SAMPLES = 20;

// ---------------------------------------------------------------------------
// feature catalogue
// ---------------------------------------------------------------------------
// `enforced` tells the panel whether the runtime currently acts on the flag.
// anything false renders with an honest "needs session access" badge instead of
// pretending to work, so a switch never lies about what it does.
const FEATURES = [
    {
        key: 'autoReply', label: 'Auto Reply', icon: 'fa-reply', group: 'Messaging',
        desc: 'Answer automatically when an incoming message matches one of your keyword rules.',
        default: false, enforced: true
    },
    {
        key: 'autoReact', label: 'Auto React', icon: 'fa-heart', group: 'Messaging',
        desc: 'Drop a reaction on every message the bot receives.',
        default: false, enforced: true
    },
    {
        key: 'autoSeen', label: 'Auto Seen', icon: 'fa-eye', group: 'Messaging',
        desc: 'Mark threads as read the moment a message arrives.',
        default: false, enforced: true
    },
    {
        key: 'aiChat', label: 'AI Chat Mode', icon: 'fa-wand-magic-sparkles', group: 'Messaging',
        desc: 'Route plain conversation in direct messages to the AI assistant command.',
        default: false, enforced: true
    },
    {
        key: 'autoGreet', label: 'Auto Greet', icon: 'fa-hand-sparkles', group: 'Groups',
        desc: 'Welcome members who join and say goodbye to members who leave.',
        default: true, enforced: true
    },
    {
        key: 'antiOut', label: 'Anti-Out / Anti-Kick', icon: 'fa-shield-halved', group: 'Groups',
        desc: 'Immediately add a member back when they leave or are removed from a group.',
        default: false, enforced: true
    },
    {
        key: 'groupTools', label: 'Group Admin Tools', icon: 'fa-users-gear', group: 'Groups',
        desc: 'Allow the group management commands: kick, ban, mute, promote and lock group name.',
        default: true, enforced: true
    },
    {
        key: 'spamFilter', label: 'Spam & Link Filter', icon: 'fa-filter-circle-xmark', group: 'Protection',
        desc: 'Warn members who flood a thread or post links. Three warnings are logged for review.',
        default: true, enforced: true
    },
    {
        key: 'accessControl', label: 'Whitelist / Blacklist', icon: 'fa-user-lock', group: 'Protection',
        desc: 'Enforce the access lists from the Users page before any command runs.',
        default: false, enforced: true
    },
    {
        key: 'perCommandCooldown', label: 'Per-command Cooldown', icon: 'fa-hourglass-half', group: 'Protection',
        desc: 'Apply the cooldown you set on each command instead of the command author default.',
        default: false, enforced: true
    },
    {
        key: 'schedules', label: 'Scheduled Tasks', icon: 'fa-clock', group: 'Automation',
        desc: 'Run your saved cron schedules. Turn this off to pause every task at once.',
        default: false, enforced: true
    },
    {
        key: 'autoPost', label: 'Auto Post & Share', icon: 'fa-share-nodes', group: 'Automation',
        desc: 'Let post and share type schedules publish on their interval.',
        default: false, enforced: true
    },
    {
        key: 'autoAcceptFriend', label: 'Auto Accept Friend Request', icon: 'fa-user-plus', group: 'Automation',
        desc: 'Accept incoming friend requests automatically.',
        default: false, enforced: false,
        note: 'Facebook does not expose pending requests to this session type, so the bot cannot poll them yet.'
    }
];

const FEATURE_DEFAULTS = FEATURES.reduce((acc, f) => {
    acc[f.key] = !!f.default;
    return acc;
}, {});

const NOTIFY_DEFAULTS = { commandErrors: true, featureChanges: true, newMembers: false, schedules: true };

// ---------------------------------------------------------------------------
// bots.json access
// ---------------------------------------------------------------------------
function readBots() {
    try {
        return JSON.parse(fs.readFileSync(BOTS_FILE, 'utf-8'));
    } catch (err) {
        return [];
    }
}

function writeBots(bots) {
    fs.writeFileSync(BOTS_FILE, JSON.stringify(bots, null, 2));
    try { delete require.cache[require.resolve(BOTS_FILE)]; } catch (err) {}
}

function findBot(botId) {
    return readBots().find(b => String(b.uid) === String(botId)) || null;
}

// read, mutate and persist in one shot so two panel requests can't clobber each other
function updateBot(botId, mutate) {
    const bots = readBots();
    const bot = bots.find(b => String(b.uid) === String(botId));
    if (!bot) return null;
    mutate(bot);
    writeBots(bots);
    return bot;
}

// fills in every default so the panel and the handlers always read a complete shape
function settingsOf(bot) {
    if (!bot) return null;
    return {
        botname: bot.botname || 'OP AutoBot',
        prefix: typeof bot.prefix === 'string' && bot.prefix.length ? bot.prefix : '-',
        admins: (Array.isArray(bot.admins) ? bot.admins : []).map(String),
        features: Object.assign({}, FEATURE_DEFAULTS, bot.features || {}),
        autoReplyRules: Array.isArray(bot.autoReplyRules) ? bot.autoReplyRules : [],
        reactEmoji: bot.reactEmoji || '\uD83D\uDC4D',
        greetJoin: bot.greetJoin || 'Welcome {name} to {thread}!',
        greetLeave: bot.greetLeave || 'Goodbye {name}, we will miss you.',
        schedules: Array.isArray(bot.schedules) ? bot.schedules : [],
        whitelist: (Array.isArray(bot.whitelist) ? bot.whitelist : []).map(String),
        blacklist: (Array.isArray(bot.blacklist) ? bot.blacklist : []).map(String),
        groupBans: (Array.isArray(bot.groupBans) ? bot.groupBans : [])
            .filter(entry => entry && entry.threadID)
            .map(entry => ({
                threadID: String(entry.threadID),
                name: entry.name || '',
                reason: entry.reason || '',
                at: entry.at || ''
            })),
        commandState: bot.commandState && typeof bot.commandState === 'object' ? bot.commandState : {},
        defaultCooldown: Number(bot.defaultCooldown) || 0,
        timezone: bot.timezone || 'Asia/Manila',
        notify: Object.assign({}, NOTIFY_DEFAULTS, bot.notify || {}),
        maintenance: bot.maintenance || { status: false, reason: '', since: null }
    };
}

// ---------------------------------------------------------------------------
// config.json access - the approval lists live here, shared with the chat
// commands (request / approve), so the panel and the bot always agree
// ---------------------------------------------------------------------------
function readConfigFile() {
    try {
        const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
        if (!Array.isArray(cfg.approvedgroups)) cfg.approvedgroups = [];
        if (!Array.isArray(cfg.pendingrequests)) cfg.pendingrequests = [];
        return cfg;
    } catch (err) {
        return { approvedgroups: [], pendingrequests: [] };
    }
}

// handleCommand destructures approvedgroups once per message from global.config,
// so the live array has to be mutated in place, never replaced, or the running
// bot keeps reading a stale list until the process restarts
function syncApprovalGlobals(cfg) {
    try {
        if (!global.config) return;
        if (Array.isArray(global.config.approvedgroups)) {
            global.config.approvedgroups.length = 0;
            cfg.approvedgroups.forEach(id => global.config.approvedgroups.push(String(id)));
        } else {
            global.config.approvedgroups = cfg.approvedgroups.map(String);
        }
        global.config.pendingrequests = cfg.pendingrequests;
    } catch (err) {}
}

function writeConfigFile(cfg) {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf8');
    try { delete require.cache[require.resolve(CONFIG_FILE)]; } catch (err) {}
    syncApprovalGlobals(cfg);
}

// ---------------------------------------------------------------------------
// auth - the panel proves ownership with the same jwt the login route issued
// ---------------------------------------------------------------------------
function verify(botId, token) {
    return new Promise(resolve => {
        if (!botId || !token) return resolve(null);
        const bot = findBot(botId);
        if (!bot || !bot.token || bot.token !== token) return resolve(null);
        jwt.verify(token, String(botId), err => resolve(err ? null : bot));
    });
}

// ---------------------------------------------------------------------------
// per bot runtime state, in memory only
// ---------------------------------------------------------------------------
const runtime = new Map();

function state(botId) {
    const id = String(botId);
    if (!runtime.has(id)) {
        runtime.set(id, {
            startedAt: Date.now(),
            commands: 0,
            messages: 0,
            events: 0,
            errors: 0,
            blocked: 0,
            users: new Set(),
            people: new Map(),
            threads: new Set(),
            latency: 0,
            latencies: [],
            logs: [],
            activity: [],
            buckets: new Map(),
            commandUse: new Map(),
            spam: new Map(),
            warns: new Map(),
            cooldowns: new Map(),
            tasks: new Map(),
            seq: 0
        });
    }
    return runtime.get(id);
}

function bucketStart(at) {
    return Math.floor((at || Date.now()) / BUCKET_MS) * BUCKET_MS;
}

// ---------------------------------------------------------------------------
// who did it
// ---------------------------------------------------------------------------
// the listener keeps global.data.userName warm for everyone it has seen, so a
// name lookup is a cheap map read. when the name is not cached yet we still
// return the id so the console and the activity feed never show a blank actor.
function userLabel(id) {
    const key = String(id == null ? '' : id).trim();
    if (!key) return null;

    let name = '';
    try {
        const map = global.data && global.data.userName;
        if (map && typeof map.get === 'function') name = map.get(key) || '';
    } catch (err) {}

    // the bot's own uid is never in the member cache, but bots.json knows it
    if (!name) {
        const own = findBot(key);
        if (own) name = own.name || own.botname || '';
    }

    return { id: key, name: String(name).slice(0, 60) || `User ${key}` };
}

function whoIs(id) {
    const user = userLabel(id);
    return user ? user.name : 'Someone';
}

// profile pictures, shared by every bot in this process. graph.facebook.com is
// only the fallback, the real fbcdn thumbnail comes from getUserInfo.
const avatars = new Map();

function avatarOf(id) {
    const key = String(id || '').trim();
    return avatars.get(key) || `https://graph.facebook.com/${key}/picture?width=120&height=120`;
}

// the roster of everyone who has actually used this bot. one entry per person,
// updated on every message and command so the Users page can show real numbers.
function person(botId, id) {
    const key = String(id == null ? '' : id).trim();
    if (!key) return null;
    const s = state(botId);
    let entry = s.people.get(key);
    if (!entry) {
        // never let a busy bot grow this map without a bound: drop the least
        // recently active person once we are over the cap
        if (s.people.size >= PEOPLE_LIMIT) {
            let oldestKey = null;
            let oldest = Infinity;
            for (const [k, v] of s.people) {
                const at = new Date(v.lastAt || 0).getTime() || 0;
                if (at < oldest) { oldest = at; oldestKey = k; }
            }
            if (oldestKey) s.people.delete(oldestKey);
        }
        entry = {
            id: key,
            commands: 0,
            messages: 0,
            firstAt: new Date().toISOString(),
            lastAt: new Date().toISOString(),
            lastCommand: null,
            threads: new Set()
        };
        s.people.set(key, entry);
    }
    entry.lastAt = new Date().toISOString();
    return entry;
}

// fills the shared name cache in the background the first time we see someone,
// so their next command shows a real name instead of a raw id. the avatar is
// picked up in the same round trip.
function cacheName(api, id) {
    const key = String(id == null ? '' : id).trim();
    if (!key || !api || typeof api.getUserInfo !== 'function') return;
    try {
        const map = global.data && global.data.userName;
        if (!map || typeof map.get !== 'function') return;
        if (map.get(key) && avatars.has(key)) return;
        Promise.resolve(api.getUserInfo(key))
            .then(info => {
                const found = info && info[key];
                if (!found) return;
                if (found.name) map.set(key, found.name);
                if (found.thumbSrc) avatars.set(key, found.thumbSrc);
            })
            .catch(() => {});
    } catch (err) {}
}

// ---------------------------------------------------------------------------
// console logs + activity feed
// ---------------------------------------------------------------------------
// `senderID` is optional. when it is given the line carries the display name of
// the person responsible, so the Console page can show who ran what.
function log(botId, level, message, senderID) {
    const s = state(botId);
    const user = userLabel(senderID);
    const entry = {
        id: ++s.seq,
        at: new Date().toISOString(),
        level: ['info', 'success', 'warning', 'error'].includes(level) ? level : 'info',
        message: String(message == null ? '' : message).slice(0, 600),
        user: user ? user.name : null,
        userId: user ? user.id : null
    };
    s.logs.push(entry);
    if (s.logs.length > LOG_LIMIT) s.logs.splice(0, s.logs.length - LOG_LIMIT);
    if (entry.level === 'error') s.errors++;
    return entry;
}

function activity(botId, icon, text, senderID) {
    const s = state(botId);
    const user = userLabel(senderID);
    s.activity.unshift({
        at: new Date().toISOString(),
        icon: icon || 'fa-circle-dot',
        text: String(text).slice(0, 200),
        user: user ? user.name : null,
        userId: user ? user.id : null
    });
    if (s.activity.length > ACTIVITY_LIMIT) s.activity.length = ACTIVITY_LIMIT;
}

function clearLogs(botId) {
    state(botId).logs.length = 0;
    log(botId, 'info', 'console cleared from the panel');
}

// ---------------------------------------------------------------------------
// telemetry recording
// ---------------------------------------------------------------------------
function recordCommand(botId, name, senderID, ms) {
    const s = state(botId);
    s.commands++;
    if (senderID) {
        s.users.add(String(senderID));
        const who = person(botId, senderID);
        if (who) {
            who.commands++;
            who.lastCommand = String(name || '');
        }
    }

    // host wide "what are people actually running" counter, read by /opiar
    const command = String(name || '').trim().toLowerCase();
    if (command) s.commandUse.set(command, (s.commandUse.get(command) || 0) + 1);

    const key = bucketStart();
    s.buckets.set(key, (s.buckets.get(key) || 0) + 1);
    // keep a little more than the chart window so old buckets can't grow forever
    const cutoff = key - BUCKET_MS * (BUCKETS + 4);
    for (const k of s.buckets.keys()) if (k < cutoff) s.buckets.delete(k);

    if (typeof ms === 'number' && ms >= 0) {
        s.latencies.push(ms);
        if (s.latencies.length > LATENCY_SAMPLES) s.latencies.shift();
        s.latency = Math.round(s.latencies.reduce((a, b) => a + b, 0) / s.latencies.length);
    }

    const actor = whoIs(senderID);
    log(botId, 'success', `${actor} ran "${name}" in ${Math.round(ms || 0)}ms`, senderID);
    activity(botId, 'fa-terminal', `${actor} used ${name}`, senderID);
}

function recordError(botId, name, message, senderID) {
    const actor = whoIs(senderID);
    log(botId, 'error', `"${name}" failed for ${actor} : ${message}`, senderID);
    activity(botId, 'fa-triangle-exclamation', `${name} threw an error for ${actor}`, senderID);
}

// every command this bot has run since the process started, most used first
function commandUse(botId) {
    const s = state(botId);
    return Array.from(s.commandUse.entries())
        .map(([name, count]) => ({ name, count }))
        .sort((a, b) => b.count - a.count);
}

function usageSeries(botId) {
    const s = state(botId);
    const now = bucketStart();
    const series = [];
    for (let i = BUCKETS - 1; i >= 0; i--) {
        const at = now - i * BUCKET_MS;
        series.push({
            at,
            label: new Date(at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            count: s.buckets.get(at) || 0
        });
    }
    return series;
}

// ---------------------------------------------------------------------------
// dashboard payload
// ---------------------------------------------------------------------------
function stats(botId) {
    const id = String(botId);
    const bot = findBot(id);
    const cfg = settingsOf(bot) || {};
    const s = state(id);
    const account = global.client && global.client.accounts ? global.client.accounts.get(id) : null;
    const online = !!(global.client && global.client.apis && global.client.apis.get(id));

    // the login flow keeps account.time ticking, fall back to this process's own clock
    const uptime = account && Number(account.time)
        ? Number(account.time)
        : Math.floor((Date.now() - s.startedAt) / 1000);

    return {
        online,
        uptime,
        prefix: cfg.prefix,
        botname: cfg.botname,
        commands: s.commands,
        messages: s.messages,
        events: s.events,
        errors: s.errors,
        blocked: s.blocked,
        activeUsers: s.users.size,
        threads: s.threads.size,
        latency: s.latency,
        admins: cfg.admins.length,
        maintenance: cfg.maintenance,
        usage: usageSeries(id),
        activity: s.activity.slice(0, 12),
        totalCommandModules: global.client && global.client.commands ? global.client.commands.size : 0
    };
}

// ---------------------------------------------------------------------------
// scheduled tasks - real node-cron jobs bound to the live session
// ---------------------------------------------------------------------------
function stopSchedules(botId) {
    const s = state(botId);
    for (const task of s.tasks.values()) {
        try { task.stop(); } catch (err) {}
    }
    s.tasks.clear();
}

function syncSchedules(botId) {
    const id = String(botId);
    stopSchedules(id);

    const bot = findBot(id);
    if (!bot) return;
    const cfg = settingsOf(bot);
    if (!cfg.features.schedules) return;

    const s = state(id);
    for (const task of cfg.schedules) {
        if (!task || task.enabled === false) continue;
        if (!cron.validate(String(task.cron || ''))) {
            log(id, 'warning', `schedule "${task.label}" has an invalid cron expression, skipped`);
            continue;
        }
        // post and share tasks stay parked until the Auto Post feature is on
        if ((task.action === 'post' || task.action === 'share') && !cfg.features.autoPost) continue;

        try {
            const job = cron.schedule(String(task.cron), () => runSchedule(id, task), { timezone: cfg.timezone });
            s.tasks.set(String(task.id), job);
        } catch (err) {
            log(id, 'error', `could not start schedule "${task.label}" : ${err.message || err}`);
        }
    }
    if (s.tasks.size) log(id, 'info', `${s.tasks.size} scheduled task${s.tasks.size === 1 ? '' : 's'} armed`);
}

async function runSchedule(botId, task) {
    const api = global.client && global.client.apis ? global.client.apis.get(String(botId)) : null;
    if (!api) {
        log(botId, 'warning', `schedule "${task.label}" skipped, the bot session is offline`);
        return;
    }
    try {
        if (task.action === 'post' && typeof api.createPost === 'function') {
            await api.createPost({ message: task.message });
            log(botId, 'success', `schedule "${task.label}" published a post`);
        } else if (task.action === 'share' && typeof api.shareLink === 'function' && task.target) {
            await api.shareLink(task.message || '', task.target, task.thread);
            log(botId, 'success', `schedule "${task.label}" shared a link`);
        } else if (task.target) {
            await new Promise((resolve, reject) => {
                api.sendMessage(String(task.message || ''), String(task.target), err => (err ? reject(err) : resolve()));
            });
            log(botId, 'success', `schedule "${task.label}" sent a message to ${task.target}`);
        } else {
            log(botId, 'warning', `schedule "${task.label}" has no target thread, nothing was sent`);
            return;
        }
        activity(botId, 'fa-clock', `Schedule ${task.label} ran`);
    } catch (err) {
        log(botId, 'error', `schedule "${task.label}" failed : ${(err && err.message) || err}`);
    }
}

// ---------------------------------------------------------------------------
// command gate - runs inside handleCommand before a command executes
// returns null to allow, or a reason string to block
// ---------------------------------------------------------------------------
function gate({ botId, command, senderID, threadID, isAdmin }) {
    const bot = findBot(botId);
    if (!bot || !command || !command.config) return null;
    const cfg = settingsOf(bot);
    const s = state(botId);
    const name = command.config.name;
    const sender = String(senderID);

    const block = reason => {
        s.blocked++;
        const actor = whoIs(sender);
        log(botId, 'warning', `blocked "${name}" for ${actor} (${sender}) : ${reason}`, sender);
        activity(botId, 'fa-ban', `${actor} was blocked from ${name}`, sender);
        return reason;
    };

    // a banned group is refused for everyone in it, admins included, otherwise
    // the ban would only be half a ban
    const groupBan = isGroupBanned(cfg, threadID);
    if (groupBan) {
        return block(`this group is banned from using the bot (${groupBan.reason || 'no reason given'}).`);
    }

    if (cfg.features.accessControl && !isAdmin) {
        if (cfg.blacklist.includes(sender)) {
            return block('you are on this bot\'s blacklist.');
        }
        if (cfg.whitelist.length && !cfg.whitelist.includes(sender)) {
            return block('this bot is limited to whitelisted users right now.');
        }
    }

    const entry = cfg.commandState[name];
    if (entry && entry.enabled === false) {
        return block(`the "${name}" command is turned off in the bot panel.`);
    }

    if (cfg.features.perCommandCooldown && !isAdmin) {
        const seconds = Number(entry && entry.cooldown != null ? entry.cooldown : cfg.defaultCooldown) || 0;
        if (seconds > 0) {
            const key = `${name}:${sender}`;
            const last = s.cooldowns.get(key) || 0;
            const left = Math.ceil((last + seconds * 1000 - Date.now()) / 1000);
            if (left > 0) return block(`please wait ${left}s before using "${name}" again.`);
            s.cooldowns.set(key, Date.now());
        }
    }

    const category = String(command.config.category || '').toLowerCase();
    if (!cfg.features.groupTools && category === 'group') {
        return block('group admin tools are turned off in the bot panel.');
    }

    return null;
}

// ---------------------------------------------------------------------------
// runtime hook - called for every event from listen.js
// may return { rewrite: '<body>' } to ask the listener to re-dispatch the message
// ---------------------------------------------------------------------------
async function onEvent({ api, event }) {
    if (!api || !event) return null;

    let botId;
    try {
        botId = String(await api.getCurrentUserID());
    } catch (err) {
        return null;
    }

    const bot = findBot(botId);
    if (!bot) return null;

    const cfg = settingsOf(bot);
    const f = cfg.features;
    const s = state(botId);
    const admins = cfg.admins.concat(String(botId));
    const sender = event.senderID ? String(event.senderID) : '';
    const isAdmin = admins.includes(sender) || (global.config.operators || []).map(String).includes(sender);

    if (event.threadID) s.threads.add(String(event.threadID));

    // a banned group gets nothing: no auto reply, no reaction, no seen receipt,
    // no greeting and no anti-out. handleCommand refuses it separately in gate().
    if (isGroupBanned(cfg, event.threadID)) {
        s.blocked++;
        return null;
    }

    if (event.type === 'message' || event.type === 'message_reply') {
        s.messages++;
        if (sender) {
            s.users.add(sender);
            cacheName(api, sender);
            const who = person(botId, sender);
            if (who) {
                who.messages++;
                if (event.threadID) who.threads.add(String(event.threadID));
            }
        }

        const body = typeof event.body === 'string' ? event.body : '';
        const isCommand = !!cfg.prefix && body.startsWith(cfg.prefix);

        if (f.autoSeen && typeof api.markAsRead === 'function') {
            try { api.markAsRead(event.threadID, () => {}); } catch (err) {}
        }

        if (f.autoReact && typeof api.setMessageReaction === 'function' && event.messageID) {
            try { api.setMessageReaction(cfg.reactEmoji, event.messageID, () => {}, true); } catch (err) {}
        }

        if (f.spamFilter && sender && !isAdmin) {
            const hit = spamCheck(botId, event, body, api);
            if (hit) return null;
        }

        if (!isCommand && body.trim()) {
            if (f.autoReply) {
                const rule = cfg.autoReplyRules.find(r => matches(r, body));
                if (rule) {
                    try {
                        api.sendMessage(String(rule.reply), event.threadID, () => {}, event.messageID);
                        log(botId, 'info', `auto reply matched "${rule.keyword}" from ${whoIs(sender)}`, sender);
                        activity(botId, 'fa-reply', `Auto replied to ${whoIs(sender)} on "${rule.keyword}"`, sender);
                    } catch (err) {}
                    return null;
                }
            }
            // ai chat mode reuses the real assistant command instead of a second code path,
            // so the listener re-dispatches the message as "<prefix>aij <text>"
            if (f.aiChat && !event.isGroup && global.client.commands.has('aij')) {
                log(botId, 'info', `ai chat mode handled a direct message from ${whoIs(sender)}`, sender);
                return { rewrite: `${cfg.prefix}aij ${body.trim()}` };
            }
        }
        return null;
    }

    if (event.type === 'event') {
        s.events++;
        const kind = event.logMessageType;

        if (kind === 'log:subscribe') {
            const added = (event.logMessageData && event.logMessageData.addedParticipants) || [];
            const joined = added[0] || {};
            const joinedId = joined.userFbId ? String(joined.userFbId) : '';
            const joinedName = joined.fullName || (joinedId ? whoIs(joinedId) : 'A member');
            activity(botId, 'fa-user-plus', `${joinedName} joined a group`, joinedId);
        }

        if (kind === 'log:unsubscribe') {
            const left = event.logMessageData && event.logMessageData.leftParticipantFbId;
            const leftId = left ? String(left) : '';
            const leftName = leftId ? whoIs(leftId) : 'A member';
            activity(botId, 'fa-user-minus', `${leftName} left a group`, leftId);
            if (f.antiOut && leftId && leftId !== botId && typeof api.addUserToGroup === 'function') {
                try {
                    api.addUserToGroup(leftId, event.threadID, err => {
                        if (err) log(botId, 'warning', `anti-out could not add ${leftName} back`, leftId);
                        else log(botId, 'success', `anti-out added ${leftName} back to the group`, leftId);
                    });
                } catch (err) {}
            }
        }
    }
    return null;
}

function matches(rule, body) {
    if (!rule || !rule.keyword) return false;
    const keyword = String(rule.keyword).toLowerCase();
    const text = body.toLowerCase();
    return rule.exact ? text.trim() === keyword : text.includes(keyword);
}

// flood + link guard. warns rather than removing, and every warning is logged
// so the owner can review it on the Console page.
function spamCheck(botId, event, body, api) {
    const s = state(botId);
    const sender = String(event.senderID);
    const now = Date.now();

    const stamps = (s.spam.get(sender) || []).filter(t => now - t < 10000);
    stamps.push(now);
    s.spam.set(sender, stamps);

    const flooding = stamps.length > 6;
    const linking = /https?:\/\/\S+/i.test(body);
    if (!flooding && !linking) return false;

    const warns = (s.warns.get(sender) || 0) + 1;
    s.warns.set(sender, warns);
    const reason = flooding ? 'sending messages too quickly' : 'posting a link';
    const actor = whoIs(sender);
    log(botId, 'warning', `spam filter warned ${actor} (${sender}) for ${reason} (warning ${warns}/3)`, sender);
    activity(botId, 'fa-filter-circle-xmark', `Spam warning for ${actor}`, sender);

    if (flooding) {
        try {
            api.sendMessage(`Please slow down. Warning ${warns} of 3.`, event.threadID, () => {}, event.messageID);
        } catch (err) {}
        return true;
    }
    return false;
}

// ---------------------------------------------------------------------------
// bot users - who actually used this bot, with ban control
// ---------------------------------------------------------------------------
function stamp(botId) {
    const cfg = settingsOf(findBot(botId)) || {};
    return moment.tz(cfg.timezone || 'Asia/Manila').format('HH:mm:ss DD/MM/YYYY');
}

function banRecord(id) {
    try {
        const map = global.data && global.data.userBanned;
        if (!map || typeof map.get !== 'function') return null;
        return map.get(String(id)) || null;
    } catch (err) {
        return null;
    }
}

// the roster the Users page renders. sorted by who was active most recently.
function people(botId) {
    const id = String(botId);
    const s = state(id);
    const cfg = settingsOf(findBot(id)) || { admins: [], whitelist: [], blacklist: [] };
    const operators = ((global.config && global.config.operators) || []).map(String);

    return Array.from(s.people.values())
        .sort((a, b) => new Date(b.lastAt || 0) - new Date(a.lastAt || 0))
        .map(entry => {
            const record = banRecord(entry.id);
            const label = userLabel(entry.id);
            return {
                id: entry.id,
                name: label ? label.name : `User ${entry.id}`,
                avatar: avatarOf(entry.id),
                profileUrl: `https://www.facebook.com/profile.php?id=${entry.id}`,
                commands: entry.commands,
                messages: entry.messages,
                threads: entry.threads.size,
                firstSeen: entry.firstAt,
                lastSeen: entry.lastAt,
                lastCommand: entry.lastCommand,
                banned: !!record,
                banReason: record ? record.reason || '' : '',
                bannedAt: record ? record.dateAdded || '' : '',
                isAdmin: cfg.admins.includes(entry.id),
                isOperator: operators.includes(entry.id),
                isBot: entry.id === id,
                blacklisted: (cfg.blacklist || []).includes(entry.id)
            };
        });
}

// ban / unban write to the same two places the chat command does: the in memory
// map every handler checks, and the Users table so it survives a restart
async function setBanned(botId, id, banned, reason) {
    const key = String(id || '').trim();
    if (!/^\d{5,}$/.test(key)) throw new Error('user id must be numbers only.');
    if (key === String(botId)) throw new Error("you can't ban the bot itself.");

    const operators = ((global.config && global.config.operators) || []).map(String);
    if (banned && operators.includes(key)) throw new Error('bot operators cannot be banned.');

    const map = global.data && global.data.userBanned;
    const dateAdded = stamp(botId);
    const why = String(reason || '').trim().slice(0, 200) || 'banned from the bot panel';

    if (banned) {
        if (map && typeof map.set === 'function') map.set(key, { reason: why, dateAdded });
    } else if (map && typeof map.delete === 'function') {
        map.delete(key);
    }

    // persistence is best effort: the database controller only exists once a bot
    // session has booted, but the in memory ban above is already enforced
    const Users = global.controllers && global.controllers.Users;
    if (Users) {
        try {
            const existing = await Users.getData(key);
            const data = (existing && existing.data) || {};
            data.banned = !!banned;
            data.reason = banned ? why : null;
            data.dateAdded = banned ? dateAdded : null;
            await Users.setData(key, { data });
        } catch (err) {
            log(botId, 'warning', `could not save the ban state of ${key} to the database`, botId);
        }
    }

    const who = userLabel(key);
    const name = who ? who.name : key;
    const message = banned ? `${name} (${key}) was banned from the panel` : `${name} (${key}) was unbanned from the panel`;
    log(botId, banned ? 'warning' : 'success', message, botId);
    activity(botId, banned ? 'fa-user-slash' : 'fa-user-check', message, botId);

    return { data: banned ? `${name} is banned.` : `${name} can use the bot again.`, users: people(botId) };
}

// ---------------------------------------------------------------------------
// group access - shared by the approval queue and the group ban list
// ---------------------------------------------------------------------------
function threadLabel(id) {
    const key = String(id || '');
    try {
        const info = global.data && global.data.threadInfo ? global.data.threadInfo.get(key) : null;
        const data = global.data && global.data.threadData ? global.data.threadData.get(key) : null;
        return {
            name: (info && info.threadName) || (data && data.threadName) || '',
            image: (info && (info.imageSrc || info.thumbSrc)) || ''
        };
    } catch (err) {
        return { name: '', image: '' };
    }
}

// ---------------------------------------------------------------------------
// group bans - a thread level block, enforced before any command or event
// ---------------------------------------------------------------------------
// approval says "this chat may use the bot". a ban is the harder statement: the
// bot ignores the thread completely, even if it is still on the approved list.
function isGroupBanned(cfg, threadID) {
    const id = String(threadID || '');
    if (!id) return null;
    return (cfg.groupBans || []).find(entry => entry.threadID === id) || null;
}

// the list the Users page renders, enriched with whatever the thread cache knows
function groupBans(botId) {
    const cfg = settingsOf(findBot(botId)) || { groupBans: [] };
    const approved = readConfigFile().approvedgroups.map(String);
    return (cfg.groupBans || []).map(entry => {
        const group = threadLabel(entry.threadID);
        return {
            threadID: entry.threadID,
            name: entry.name || group.name || 'Unknown chat',
            image: group.image || '',
            reason: entry.reason || '',
            at: entry.at || '',
            approved: approved.includes(entry.threadID)
        };
    });
}

function setGroupBanned(botId, threadID, banned, reason) {
    const id = String(threadID || '').trim();
    if (!/^\d{5,}$/.test(id)) throw new Error('the thread id must be numbers only.');

    const existing = settingsOf(findBot(botId));
    if (!existing) throw new Error('bot not found.');

    if (banned && isGroupBanned(existing, id)) throw new Error('that group is already banned.');
    if (!banned && !isGroupBanned(existing, id)) throw new Error('that group is not on the ban list.');

    const name = threadLabel(id).name || '';
    const why = String(reason || '').trim().slice(0, 200) || 'banned from the bot panel';

    const updated = updateBot(botId, b => {
        const list = (Array.isArray(b.groupBans) ? b.groupBans : []).filter(e => e && String(e.threadID) !== id);
        if (banned) list.push({ threadID: id, name, reason: why, at: stamp(botId) });
        b.groupBans = list;
    });
    if (!updated) throw new Error('bot not found.');

    const label = name || id;
    const message = banned
        ? `group "${label}" (${id}) was banned from the panel`
        : `group "${label}" (${id}) was unbanned from the panel`;
    log(botId, banned ? 'warning' : 'success', message, botId);
    activity(botId, banned ? 'fa-users-slash' : 'fa-users', message, botId);

    // tell the room why the bot went quiet, but only on the way in
    if (banned) notifyThread(botId, id, 'this group has been banned by the bot owner, the bot will stop responding here.');

    return {
        data: banned ? `${label} is banned.` : `${label} can use the bot again.`,
        groupBans: groupBans(botId)
    };
}

// ---------------------------------------------------------------------------
// group approval - the queue the "request" command fills from chat
// ---------------------------------------------------------------------------
function approvals(botId) {
    const cfg = readConfigFile();
    const approved = cfg.approvedgroups.map(String);

    const pending = cfg.pendingrequests
        .filter(r => r && r.threadID)
        .map(r => {
            const requester = userLabel(r.senderID);
            const group = threadLabel(r.threadID);
            return {
                threadID: String(r.threadID),
                name: r.name || group.name || 'Unnamed chat',
                image: group.image || '',
                at: r.time || '',
                requesterId: requester ? requester.id : '',
                requesterName: requester ? requester.name : 'Unknown',
                requesterAvatar: requester ? avatarOf(requester.id) : ''
            };
        })
        .filter(r => !approved.includes(r.threadID));

    return {
        enabled: cfg.approval !== false,
        pending,
        approved: approved.map(id => {
            const group = threadLabel(id);
            return { threadID: id, name: group.name || 'Approved chat', image: group.image || '' };
        })
    };
}

function notifyThread(botId, threadID, message) {
    try {
        const api = global.client && global.client.apis ? global.client.apis.get(String(botId)) : null;
        if (api && typeof api.sendMessage === 'function') api.sendMessage(message, String(threadID), () => {});
    } catch (err) {}
}

function approveGroup(botId, threadID) {
    const id = String(threadID || '').trim();
    if (!/^\d{5,}$/.test(id)) throw new Error('that thread id does not look right.');

    const cfg = readConfigFile();
    if (cfg.approvedgroups.map(String).includes(id)) throw new Error('that chat is already approved.');

    const request = cfg.pendingrequests.find(r => String(r.threadID) === id);
    const name = (request && request.name) || threadLabel(id).name || id;

    cfg.approvedgroups.push(id);
    cfg.pendingrequests = cfg.pendingrequests.filter(r => String(r.threadID) !== id);
    writeConfigFile(cfg);

    notifyThread(botId, id, 'this box has been approved, you can now use the bot');
    log(botId, 'success', `approved "${name}" (${id}) from the panel`, botId);
    activity(botId, 'fa-circle-check', `${name} was approved`, request ? request.senderID : botId);

    return { data: `${name} is approved.`, approvals: approvals(botId) };
}

function declineRequest(botId, threadID) {
    const id = String(threadID || '').trim();
    const cfg = readConfigFile();
    const request = cfg.pendingrequests.find(r => String(r.threadID) === id);
    if (!request) throw new Error('that request is no longer pending.');

    const name = request.name || threadLabel(id).name || id;
    cfg.pendingrequests = cfg.pendingrequests.filter(r => String(r.threadID) !== id);
    writeConfigFile(cfg);

    notifyThread(botId, id, 'your approval request was declined by the bot owner.');
    log(botId, 'warning', `declined the approval request from "${name}" (${id})`, botId);
    activity(botId, 'fa-circle-xmark', `${name} was declined`, request.senderID);

    return { data: `${name} was declined.`, approvals: approvals(botId) };
}

function revokeGroup(botId, threadID) {
    const id = String(threadID || '').trim();
    const cfg = readConfigFile();
    if (!cfg.approvedgroups.map(String).includes(id)) throw new Error('that chat is not on the approved list.');

    const name = threadLabel(id).name || id;
    cfg.approvedgroups = cfg.approvedgroups.filter(t => String(t) !== id);
    writeConfigFile(cfg);

    log(botId, 'warning', `removed "${name}" (${id}) from the approved list`, botId);
    activity(botId, 'fa-ban', `${name} lost bot access`, botId);

    return { data: `${name} can no longer use the bot.`, approvals: approvals(botId) };
}

// ---------------------------------------------------------------------------
// exports
// ---------------------------------------------------------------------------
module.exports = {
    FEATURES,
    FEATURE_DEFAULTS,
    readBots,
    writeBots,
    findBot,
    updateBot,
    settingsOf,
    verify,
    state,
    log,
    activity,
    userLabel,
    clearLogs,
    recordCommand,
    recordError,
    commandUse,
    usageSeries,
    stats,
    people,
    setBanned,
    approvals,
    approveGroup,
    declineRequest,
    revokeGroup,
    groupBans,
    setGroupBanned,
    actionCatalogue: actions.catalogue,
    runAction: actions.runAction,
    syncSchedules,
    stopSchedules,
    gate,
    onEvent
};
