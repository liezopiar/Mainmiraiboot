'use strict';

// actions.js
// the 19 one-shot operations the control panel can fire at the live facebook
// session. every entry below maps to a real ws3-fca method, so the panel never
// renders a button that has nothing behind it.
//
//   * CATALOGUE - what the panel draws: fields, help text and the method it needs
//   * runAction - resolves the live session, validates the payload, calls facebook
//
// three entries have no first-party ws3-fca method (delete post, delete a user's
// post and sending a friend request). those go through api.httpPost against the
// graphql endpoint and are flagged `unverified`, which the panel renders as an
// honest warning rather than pretending the call is guaranteed to land.

const ID = /^\d{5,}$/;

// facebook's post ids are numeric, but a full permalink is what people actually
// have on their clipboard, so accept either and pull the id out
function postId(raw) {
    const value = String(raw == null ? '' : raw).trim();
    if (!value) return '';
    if (/^\d{5,}$/.test(value)) return value;
    const patterns = [
        /(?:posts|videos|photos|permalink|story_fbid=|fbid=)\/?(\d{5,})/i,
        /(\d{10,})/
    ];
    for (const pattern of patterns) {
        const found = value.match(pattern);
        if (found) return found[1];
    }
    return '';
}

// ---------------------------------------------------------------------------
// catalogue
// ---------------------------------------------------------------------------
// field types the panel knows how to draw: text, id, textarea, url, toggle, select
const CATALOGUE = [
    {
        no: 1, key: 'bio', label: 'Edit bot bio', icon: 'fa-quote-left', group: 'Identity',
        method: 'changeBio', verb: 'Save bio',
        desc: "Rewrite the bio on the bot's own Facebook profile.",
        fields: [
            { name: 'bio', type: 'textarea', label: 'Bio text', placeholder: 'Up to 101 characters', max: 101 },
            { name: 'publish', type: 'toggle', label: 'Publish to timeline', value: false }
        ]
    },
    {
        no: 2, key: 'nickname', label: 'Edit bot nicknames', icon: 'fa-signature', group: 'Identity',
        method: 'changeNickname', verb: 'Set nickname',
        desc: 'Change a nickname inside one group chat. Leave the member blank to rename the bot itself.',
        fields: [
            { name: 'threadID', type: 'id', label: 'Group thread ID', placeholder: '1000000000000' },
            { name: 'participantID', type: 'id', label: 'Member ID', placeholder: 'blank = the bot', optional: true },
            { name: 'nickname', type: 'text', label: 'Nickname', placeholder: 'Leave empty to clear it', max: 100, optional: true }
        ]
    },
    {
        no: 3, key: 'pending', label: 'View pending messages', icon: 'fa-envelope-circle-check', group: 'Inbox',
        method: 'getThreadList', verb: 'Load pending', reads: true,
        desc: 'Message requests waiting for the bot to accept them.',
        fields: [{ name: 'limit', type: 'select', label: 'How many', value: '20', options: ['10', '20', '50'] }]
    },
    {
        no: 4, key: 'unread', label: 'View unread messages', icon: 'fa-envelope', group: 'Inbox',
        method: 'getThreadList', verb: 'Load unread', reads: true,
        desc: 'Threads in the inbox the bot has not read yet.',
        fields: [{ name: 'limit', type: 'select', label: 'How many', value: '20', options: ['10', '20', '50'] }]
    },
    {
        no: 5, key: 'spam', label: 'View spam messages', icon: 'fa-triangle-exclamation', group: 'Inbox',
        method: 'getThreadList', verb: 'Load spam', reads: true,
        desc: "Everything Facebook filed under Spam and Other for this account.",
        fields: [{ name: 'limit', type: 'select', label: 'How many', value: '20', options: ['10', '20', '50'] }]
    },
    {
        no: 6, key: 'avatar', label: 'Change bot profile picture', icon: 'fa-image-portrait', group: 'Identity',
        method: 'changeAvatarV2', verb: 'Upload picture',
        desc: 'Point at a direct image URL and Facebook will set it as the profile picture.',
        fields: [
            { name: 'url', type: 'url', label: 'Image URL', placeholder: 'https://example.com/photo.jpg' },
            { name: 'caption', type: 'text', label: 'Caption', placeholder: 'Optional', max: 200, optional: true }
        ]
    },
    {
        no: 7, key: 'shield', label: 'Bot avatar shield', icon: 'fa-shield-halved', group: 'Identity',
        method: 'setProfileGuard', verb: 'Apply shield',
        desc: "Turn Facebook's profile picture guard on or off for the bot account.",
        fields: [{ name: 'state', type: 'toggle', label: 'Shield on', value: true }]
    },
    {
        no: 8, key: 'block', label: 'Block user (Messenger)', icon: 'fa-user-slash', group: 'Blocking',
        method: 'changeBlockedStatus', verb: 'Block',
        desc: 'Block someone on Messenger so they can no longer reach the bot account at all.',
        fields: [{ name: 'userID', type: 'id', label: 'Facebook user ID', placeholder: '1000000000000' }]
    },
    {
        no: 9, key: 'unblock', label: 'Unblock user (Messenger)', icon: 'fa-user-check', group: 'Blocking',
        method: 'changeBlockedStatus', verb: 'Unblock',
        desc: 'Lift a Messenger block so the person can message the bot again.',
        fields: [{ name: 'userID', type: 'id', label: 'Facebook user ID', placeholder: '1000000000000' }]
    },
    {
        no: 10, key: 'post', label: 'Create post', icon: 'fa-pen-to-square', group: 'Posts',
        method: 'createPost', verb: 'Publish',
        desc: "Publish a text post to the bot's own timeline.",
        fields: [{ name: 'message', type: 'textarea', label: 'Post text', placeholder: 'What should the bot post?', max: 2000 }]
    },
    {
        no: 11, key: 'deletePost', label: 'Delete post', icon: 'fa-trash', group: 'Posts',
        method: 'httpPost', verb: 'Delete', unverified: true, danger: true,
        desc: "Remove one of the bot's own posts by id or permalink.",
        fields: [{ name: 'postID', type: 'text', label: 'Post ID or link', placeholder: '1234567890 or a permalink' }]
    },
    {
        no: 12, key: 'deleteUserPost', label: 'Delete post (user)', icon: 'fa-user-xmark', group: 'Posts',
        method: 'httpPost', verb: 'Delete', unverified: true, danger: true,
        desc: "Delete a post that belongs to someone else. Only works where the bot is an admin of the group the post sits in.",
        fields: [
            { name: 'postID', type: 'text', label: 'Post ID or link', placeholder: '1234567890 or a permalink' },
            { name: 'actorID', type: 'id', label: 'Post owner ID', placeholder: '1000000000000' }
        ]
    },
    {
        no: 13, key: 'comment', label: 'Comment the post (group)', icon: 'fa-comment-dots', group: 'Posts',
        method: 'createCommentPost', verb: 'Comment',
        desc: 'Leave a comment on any post the bot can see, or reply to an existing comment.',
        fields: [
            { name: 'postID', type: 'text', label: 'Post ID or link', placeholder: '1234567890 or a permalink' },
            { name: 'message', type: 'textarea', label: 'Comment', placeholder: 'What should the bot say?', max: 1000 },
            { name: 'replyCommentID', type: 'text', label: 'Reply to comment ID', placeholder: 'Optional', optional: true }
        ]
    },
    {
        no: 14, key: 'postReaction', label: 'Drop post feelings', icon: 'fa-face-smile', group: 'Posts',
        method: 'setPostReaction', verb: 'React',
        desc: 'React to a post with any of the six Facebook feelings.',
        fields: [
            { name: 'postID', type: 'text', label: 'Post ID or link', placeholder: '1234567890 or a permalink' },
            {
                name: 'type', type: 'select', label: 'Feeling', value: 'like',
                options: ['like', 'love', 'care', 'haha', 'wow', 'sad', 'angry', 'none']
            }
        ]
    },
    {
        no: 15, key: 'addFriend', label: 'Make friends by ID', icon: 'fa-user-plus', group: 'Friends',
        method: 'httpPost', verb: 'Send request', unverified: true,
        desc: 'Send a friend request to a Facebook ID.',
        fields: [{ name: 'userID', type: 'id', label: 'Facebook user ID', placeholder: '1000000000000' }]
    },
    {
        no: 16, key: 'acceptFriend', label: 'Accept friend request by ID', icon: 'fa-user-check', group: 'Friends',
        method: 'handleFriendRequest', verb: 'Accept',
        desc: 'Accept an incoming friend request from a specific ID.',
        fields: [{ name: 'userID', type: 'id', label: 'Facebook user ID', placeholder: '1000000000000' }]
    },
    {
        no: 17, key: 'declineFriend', label: 'Decline friend request by ID', icon: 'fa-user-xmark', group: 'Friends',
        method: 'handleFriendRequest', verb: 'Decline',
        desc: 'Reject an incoming friend request from a specific ID.',
        fields: [{ name: 'userID', type: 'id', label: 'Facebook user ID', placeholder: '1000000000000' }]
    },
    {
        no: 18, key: 'unfriend', label: 'Delete friend by ID', icon: 'fa-user-minus', group: 'Friends',
        method: 'unfriend', verb: 'Unfriend', danger: true,
        desc: 'Remove someone from the bot account\u2019s friend list.',
        fields: [{ name: 'userID', type: 'id', label: 'Facebook user ID', placeholder: '1000000000000' }]
    },
    {
        no: 19, key: 'sendMessage', label: 'Send a message by ID', icon: 'fa-paper-plane', group: 'Messaging',
        method: 'sendMessage', verb: 'Send',
        desc: 'Send a message straight to any user or group thread ID.',
        fields: [
            { name: 'threadID', type: 'id', label: 'User or thread ID', placeholder: '1000000000000' },
            { name: 'message', type: 'textarea', label: 'Message', placeholder: 'What should the bot send?', max: 2000 }
        ]
    }
];

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
function session(botId) {
    const api = global.client && global.client.apis ? global.client.apis.get(String(botId)) : null;
    if (!api) throw new Error('the bot session is offline, start it from Settings first.');
    return api;
}

// most ws3-fca methods are callback style and a few also return a promise.
// this wraps either shape into one await, and never resolves twice.
function call(api, method, args) {
    return new Promise((resolve, reject) => {
        let settled = false;
        const done = (err, value) => {
            if (settled) return;
            settled = true;
            if (err) return reject(new Error(readError(err)));
            resolve(value);
        };
        let returned;
        try {
            returned = api[method].apply(api, args.concat([(err, value) => done(err, value)]));
        } catch (err) {
            return done(err);
        }
        if (returned && typeof returned.then === 'function') {
            returned.then(value => done(null, value), err => done(err));
        }
    });
}

// facebook throws plain objects as often as it throws Errors
function readError(err) {
    if (!err) return 'facebook rejected that request.';
    if (typeof err === 'string') return err;
    return err.errorSummary || err.errorDescription || err.message || err.error || err.err ||
        'facebook rejected that request.';
}

function requireId(value, label) {
    const id = String(value == null ? '' : value).trim();
    if (!ID.test(id)) throw new Error(`${label} must be numbers only.`);
    return id;
}

function requireText(value, label, max) {
    const text = String(value == null ? '' : value).trim();
    if (!text) throw new Error(`please fill in the ${label}.`);
    return max ? text.slice(0, max) : text;
}

function truthy(value) {
    return value === true || value === 'true' || value === 1 || value === '1';
}

// graphql through the authenticated session. api.httpPost signs the form with the
// session's fb_dtsg for us, so this is the same path the built-in methods take.
async function graphql(api, friendlyName, docId, variables) {
    const uid = String(await api.getCurrentUserID());
    const body = await call(api, 'httpPost', ['https://www.facebook.com/api/graphql', {
        av: uid,
        fb_api_req_friendly_name: friendlyName,
        fb_api_caller_class: 'RelayModern',
        doc_id: docId,
        variables: JSON.stringify(variables(uid))
    }]);

    let parsed = body;
    if (typeof body === 'string') {
        try { parsed = JSON.parse(body.replace(/^for ?\(;;\);/, '')); } catch (err) { parsed = null; }
    }
    if (parsed && parsed.errors && parsed.errors.length) {
        throw new Error(readError(parsed.errors[0]));
    }
    if (!parsed) throw new Error('facebook returned a response this panel could not read.');
    return parsed;
}

// the shape the panel's result table renders for the three inbox viewers
function threadRows(list) {
    return (Array.isArray(list) ? list : []).map(thread => ({
        id: String(thread.threadID || ''),
        name: thread.name || thread.threadName || 'Unnamed chat',
        image: thread.imageSrc || thread.thumbSrc || '',
        group: !!thread.isGroup,
        unread: Number(thread.unreadCount) || 0,
        snippet: String(thread.snippet || '').slice(0, 140),
        at: thread.timestamp ? new Date(Number(thread.timestamp)).toISOString() : null
    }));
}

async function threads(api, tags, limit) {
    const size = Math.min(Math.max(Number(limit) || 20, 1), 50);
    const list = await call(api, 'getThreadList', [size, null, tags]);
    return threadRows(list);
}

// ---------------------------------------------------------------------------
// the handlers
// ---------------------------------------------------------------------------
const HANDLERS = {
    async bio(api, input) {
        const bio = String(input.bio == null ? '' : input.bio).trim().slice(0, 101);
        await call(api, 'changeBio', [bio, truthy(input.publish)]);
        return { message: bio ? 'the bot bio was updated.' : 'the bot bio was cleared.' };
    },

    async nickname(api, input) {
        const threadID = requireId(input.threadID, 'the group thread ID');
        const participantID = String(input.participantID || '').trim() ||
            String(await api.getCurrentUserID());
        if (!ID.test(participantID)) throw new Error('the member ID must be numbers only.');
        const nickname = String(input.nickname == null ? '' : input.nickname).slice(0, 100);
        await call(api, 'changeNickname', [nickname, threadID, participantID]);
        return { message: nickname ? `nickname set to "${nickname}".` : 'that nickname was cleared.' };
    },

    async pending(api, input) {
        const rows = await threads(api, ['PENDING'], input.limit);
        return { message: `${rows.length} pending thread${rows.length === 1 ? '' : 's'}.`, rows, kind: 'threads' };
    },

    async unread(api, input) {
        const rows = (await threads(api, ['INBOX'], input.limit)).filter(t => t.unread > 0);
        return { message: `${rows.length} unread thread${rows.length === 1 ? '' : 's'}.`, rows, kind: 'threads' };
    },

    async spam(api, input) {
        const rows = await threads(api, ['OTHER'], input.limit);
        return { message: `${rows.length} filtered thread${rows.length === 1 ? '' : 's'}.`, rows, kind: 'threads' };
    },

    async avatar(api, input) {
        const url = requireText(input.url, 'image URL');
        if (!/^https?:\/\//i.test(url)) throw new Error('the image URL has to start with http or https.');
        await call(api, 'changeAvatarV2', [url, String(input.caption || '').slice(0, 200)]);
        return { message: 'the profile picture was uploaded.' };
    },

    async shield(api, input) {
        const on = truthy(input.state);
        await call(api, 'setProfileGuard', [on]);
        return { message: `the avatar shield is now ${on ? 'on' : 'off'}.` };
    },

    async block(api, input) {
        const userID = requireId(input.userID, 'the user ID');
        await call(api, 'changeBlockedStatus', [userID, true]);
        return { message: `${userID} is blocked on Messenger.` };
    },

    async unblock(api, input) {
        const userID = requireId(input.userID, 'the user ID');
        await call(api, 'changeBlockedStatus', [userID, false]);
        return { message: `${userID} is unblocked on Messenger.` };
    },

    async post(api, input) {
        const message = requireText(input.message, 'post text', 2000);
        await call(api, 'createPost', [message]);
        return { message: 'the post was published.' };
    },

    async deletePost(api, input) {
        const id = postId(input.postID);
        if (!id) throw new Error('that post ID or link does not contain a usable post id.');
        await graphql(api, 'CometFeedStoryDeletePostMutation', '5075815825832681', uid => ({
            input: { story_id: id, actor_id: uid, client_mutation_id: '1' },
            scale: 1
        }));
        return { message: `post ${id} was deleted.` };
    },

    async deleteUserPost(api, input) {
        const id = postId(input.postID);
        if (!id) throw new Error('that post ID or link does not contain a usable post id.');
        const actorID = requireId(input.actorID, 'the post owner ID');
        await graphql(api, 'CometFeedStoryDeletePostMutation', '5075815825832681', () => ({
            input: { story_id: id, actor_id: actorID, client_mutation_id: '1' },
            scale: 1
        }));
        return { message: `post ${id} by ${actorID} was deleted.` };
    },

    async comment(api, input) {
        const id = postId(input.postID);
        if (!id) throw new Error('that post ID or link does not contain a usable post id.');
        const message = requireText(input.message, 'comment', 1000);
        const reply = String(input.replyCommentID || '').trim();
        await call(api, 'createCommentPost', reply ? [message, id, reply] : [message, id]);
        return { message: reply ? 'the reply was posted.' : 'the comment was posted.' };
    },

    async postReaction(api, input) {
        const id = postId(input.postID);
        if (!id) throw new Error('that post ID or link does not contain a usable post id.');
        const type = String(input.type || 'like').toLowerCase();
        await call(api, 'setPostReaction', [id, type]);
        return { message: type === 'none' ? `the reaction on ${id} was removed.` : `reacted ${type} to ${id}.` };
    },

    async addFriend(api, input) {
        const userID = requireId(input.userID, 'the user ID');
        await graphql(api, 'FriendingCometFriendRequestSendMutation', '5333055050107221', uid => ({
            input: {
                friend_requestee_ids: [userID],
                friending_channel: 'PROFILE_BUTTON',
                warn_ack_for_ids: [],
                actor_id: uid,
                client_mutation_id: '1'
            },
            scale: 1
        }));
        return { message: `a friend request was sent to ${userID}.` };
    },

    async acceptFriend(api, input) {
        const userID = requireId(input.userID, 'the user ID');
        await call(api, 'handleFriendRequest', [userID, true]);
        return { message: `the friend request from ${userID} was accepted.` };
    },

    async declineFriend(api, input) {
        const userID = requireId(input.userID, 'the user ID');
        await call(api, 'handleFriendRequest', [userID, false]);
        return { message: `the friend request from ${userID} was declined.` };
    },

    async unfriend(api, input) {
        const userID = requireId(input.userID, 'the user ID');
        await call(api, 'unfriend', [userID]);
        return { message: `${userID} was removed from the friend list.` };
    },

    async sendMessage(api, input) {
        const threadID = requireId(input.threadID, 'the user or thread ID');
        const message = requireText(input.message, 'message', 2000);
        await call(api, 'sendMessage', [message, threadID]);
        return { message: `the message was sent to ${threadID}.` };
    }
};

// what the panel gets on first paint. `available` is computed against the live
// session so an action whose method is missing renders disabled instead of failing.
function catalogue(botId) {
    const api = global.client && global.client.apis ? global.client.apis.get(String(botId)) : null;
    return {
        online: !!api,
        actions: CATALOGUE.map(action => ({
            no: action.no,
            key: action.key,
            label: action.label,
            icon: action.icon,
            group: action.group,
            desc: action.desc,
            verb: action.verb,
            fields: action.fields,
            reads: !!action.reads,
            danger: !!action.danger,
            unverified: !!action.unverified,
            available: !api ? false : typeof api[action.method] === 'function'
        }))
    };
}

async function runAction(botId, key, input) {
    const action = CATALOGUE.find(a => a.key === key);
    if (!action) throw new Error('unknown action.');

    const api = session(botId);
    if (typeof api[action.method] !== 'function') {
        throw new Error(`this session does not expose ${action.method}, so "${action.label}" cannot run.`);
    }

    const result = await HANDLERS[key](api, input || {});
    return Object.assign({ key, label: action.label }, result);
}

module.exports = { CATALOGUE, catalogue, runAction };
