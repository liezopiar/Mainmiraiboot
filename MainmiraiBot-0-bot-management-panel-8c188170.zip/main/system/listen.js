module.exports = function({ api, models }) {

const Users = require("./controllers/users")({ models, api }),
Threads = require("./controllers/threads")({ models, api }),
Currencies = require("./controllers/currencies")({ models });
const logger = require("../utility/logs.js");
const chalk = require("chalk");
const fs = require("fs-extra");

// the web panel needs the database controllers to persist a ban or unban it made
// from the Users page. the tables are shared by every session, so the last bot to
// boot owning this reference is fine.
global.controllers = { Users, Threads, Currencies };
	
(async function () {
		try {
            const botID = await api.getCurrentUserID();
			const [threads, users] = await Promise.all([Threads.getAll(), Users.getAll(['userID', 'name', 'data'])]);
            
                
			threads.forEach(async (data) => {
				const idThread = String(data.threadID);
                global.data.allThreadID.get(botID).push(String(data.threadID));
                global.client.onlines.push(botID);
				global.data.threadData.set(idThread, data.data || {});
				global.data.threadInfo.set(idThread, data.threadInfo || {});
				if (data.data && data.data.banned) {
					global.data.threadBanned.set(idThread, {
						'reason': data.data.reason || '',
						'dateAdded': data.data.dateAdded || ''
					});
				}
				if (data.data && data.data.commandBanned && data.data.commandBanned.length !== 0) {
					global.data.commandBanned.set(idThread, data.data.commandBanned);
				}
				if (data.data && data.data.NSFW) {
					global.data.threadAllowNSFW.push(idThread);
				}
			});
			users.forEach(dataU => {
				const idUsers = String(dataU.userID);
				global.data.allUserID.push(idUsers);
				if (dataU.name && dataU.name.length !== 0) {
					global.data.userName.set(idUsers, dataU.name);
				}
				if (dataU.data && dataU.data.banned) {
					global.data.userBanned.set(idUsers, {
						'reason': dataU.data.reason || '',
						'dateAdded': dataU.data.dateAdded || ''
					});
				}
				if (dataU.data && dataU.data.commandBanned && dataU.data.commandBanned.length !== 0) {
					global.data.commandBanned.set(idUsers, dataU.data.commandBanned);
				}
			});
			
			} catch (error) {
			logger(`can't load environment variable, error : ${error}`, 'error');
		}
	})();	



// revoke premium access the moment the subscription runs out,
// even if the user never sends another message. : revoke access the moment the subscription runs out,
// even if the user never sends another message.
const premiumUtil = require("../utility/premium.js");
if (!global.client.premiumSweeper) {
	try { premiumUtil.migrate(); } catch (error) { logger(`premium migrate error : ${error}`, "error"); }
	global.client.premiumSweeper = setInterval(() => {
		try {
			const expired = premiumUtil.sweepExpired();
			if (expired.length) logger(`premium expired for : ${expired.join(", ")}`, "[ premium ]");
		} catch (error) {
			logger(`premium sweeper error : ${error}`, "error");
		}
	}, 60 * 1000);
}

const handleCommand = require("./handle/handleCommand.js")({ api, Users, Threads, Currencies, models });
const handleCommandEvent = require("./handle/handleCommandEvent.js")({ api, Users, Threads, Currencies, models });
const handleReply = require("./handle/handleReply.js")({ api, Users, Threads, Currencies, models });
const handleReaction = require("./handle/handleReaction.js")({ api, Users, Threads, Currencies, models });
const handleEvent = require("./handle/handleEvent.js")({ api,  Users, Threads, Currencies, models });
const handleCreateDatabase = require("./handle/handleCreateDatabase.js")({  api, Threads, Users, Currencies, models });
    const handleRefresh = require("./handle/handleRefresh")({ api, Users, Threads, Currencies });


	
// one handler throwing must never stop the others from running, otherwise a
// single bad event makes the bot look dead
const safe = (name, fn, payload) => {
	try {
		const result = fn(payload);
		if (result && typeof result.catch === "function") {
			result.catch(error => logger(`${name} error : ${(error && error.stack) || error}`, "error"));
		}
	} catch (error) {
		logger(`${name} error : ${(error && error.stack) || error}`, "error");
	}
};

// the control panel records telemetry and enforces its own feature flags here.
// when ai chat mode answers a plain message it asks for a rewrite, and the message is
// re-dispatched as a real command so there is only ever one command code path.
const panel = require("./panel.js");
const panelHook = (event) => {
	panel.onEvent({ api, event })
		.then(result => {
			if (result && result.rewrite) {
				safe("handleCommand", handleCommand, { event: { ...event, body: result.rewrite } });
			}
		})
		.catch(error => logger(`panel hook error : ${(error && error.stack) || error}`, "error"));
};

return (event) => {
		switch (event.type) {
			case "message":
			case "message_reply":
			case "message_unsend":
				panelHook(event);
				safe("handleCommand", handleCommand, { event });
				safe("handleReply", handleReply, { event });
				safe("handleCreateDatabase", handleCreateDatabase, { event });
				safe("handleCommandEvent", handleCommandEvent, { event });
				break;
			case "change_thread_image":
				// the api reports group photo changes as their own type, normalize it
				// into a regular log event so events can listen on "log:thread-image"
				safe("handleEvent", handleEvent, {
					event: {
						...event,
						type: "event",
						senderID: event.author,
						logMessageType: "log:thread-image",
						logMessageData: event.image || {}
					}
				});
				break;
			case "event":
				panelHook(event);
				safe("handleEvent", handleEvent, { event });
				safe("handleRefresh", handleRefresh, { event });
				break;
			case "message_reaction":
				safe("handleReaction", handleReaction, { event });
				// reactions aren't log events, normalize them into one so events
				// can listen on "log:message-reaction"
				safe("handleEvent", handleEvent, {
					event: {
						...event,
						type: "event",
						logMessageType: "log:message-reaction",
						logMessageData: { reaction: event.reaction || "" }
					}
				});
				break;
			default:
				break;
		}
	};
};
