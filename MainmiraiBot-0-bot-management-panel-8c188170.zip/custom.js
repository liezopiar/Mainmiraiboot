module.exports = async ({ api, event }) => {
  const logger = require('./main/utility/logs.js');
  
  const configCustom = {
    autosetbio: {
      status: false,
      bio: `prefix : ${global.config.PREFIX}`,
      note: 'automatically change the bot bio.'
    },
    greetings: {
      status: true,
      morning: [
        `good morning everyone! start your day with a positive mindset and a grateful heart.`,
        `good morning! may today bring you fresh energy and new opportunities.`,
        `rise and shine! wishing you a productive and happy morning.`,
        `good morning everyone! take a deep breath and make today count.`,
        `a brand new day is here! good morning and stay motivated.`,
        `good morning! believe in yourself and everything will fall into place.`,
        `top of the morning to you all! keep smiling and stay positive.`,
        `good morning! let go of yesterday and focus on today's blessings.`,
        `wishing you a bright and beautiful morning, everyone!`,
        `good morning! start strong and finish even stronger today.`,
        `hello sunshine! good morning and have an amazing day ahead.`,
        `good morning everyone! small progress is still progress, keep going.`,
        `good morning! may your coffee be strong and your day be productive.`,
        `new day, new chances. good morning and make the most of it!`,
        `good morning! surround yourself with good vibes and great energy.`,
        `good morning everyone! today is a fresh page, write a good story.`,
        `wake up with determination! good morning and go get it.`,
        `good morning! grateful for another day to grow and improve.`,
        `good morning everyone! stay humble, stay hungry, stay kind.`,
        `good morning! may this day be filled with peace and purpose.`
      ],
      afternoon: [
        `good afternoon everyone! take a short break, recharge, and keep doing your best.`,
        `good afternoon! stay focused and keep pushing toward your goals.`,
        `hope your day is going well! good afternoon everyone.`,
        `good afternoon! remember to hydrate and stretch a little.`,
        `good afternoon everyone! you're halfway through, keep it up.`,
        `good afternoon! a little rest now fuels a stronger finish.`,
        `good afternoon everyone! stay productive but don't forget to breathe.`,
        `good afternoon! keep that positive energy flowing.`,
        `good afternoon everyone! you're doing great, keep going.`,
        `good afternoon! take a moment to appreciate how far you've come.`,
        `good afternoon everyone! stay sharp and stay motivated.`,
        `good afternoon! a quick break can boost your whole day.`,
        `good afternoon everyone! keep smiling and stay strong.`,
        `good afternoon! finish your tasks with focus and calm.`,
        `good afternoon everyone! the day is still full of possibilities.`,
        `good afternoon! stay consistent and the results will come.`,
        `good afternoon everyone! recharge and get back stronger.`,
        `good afternoon! keep your head up and your energy high.`,
        `good afternoon everyone! progress over perfection, always.`,
        `good afternoon! wishing you a peaceful and productive rest of the day.`
      ],
      evening: [
        `good evening everyone! thank you for making it through another productive day.`,
        `good evening! take some time to relax and unwind.`,
        `good evening everyone! be proud of everything you accomplished today.`,
        `good evening! wishing you a calm and cozy night ahead.`,
        `good evening everyone! reflect on the good moments of your day.`,
        `good evening! you did your best today, and that's enough.`,
        `good evening everyone! slow down and enjoy the little things.`,
        `good evening! may your night be filled with peace and comfort.`,
        `good evening everyone! rest your mind and recharge your soul.`,
        `good evening! grateful for another day well spent.`,
        `good evening everyone! let go of the stress and just breathe.`,
        `good evening! surround yourself with warmth and good company.`,
        `good evening everyone! tomorrow is another chance to shine.`,
        `good evening! enjoy your dinner and a well-deserved rest.`,
        `good evening everyone! you made it through, be proud.`,
        `good evening! may your evening be as bright as your smile.`,
        `good evening everyone! take it easy and treat yourself kindly.`,
        `good evening! close the day with gratitude and peace.`,
        `good evening everyone! relax, reset, and recharge.`,
        `good evening! wishing you a restful and happy night.`
      ],
      sleep: [
        `good night everyone! rest well and get ready for a brighter tomorrow.`,
        `good night! may your dreams be sweet and your sleep be deep.`,
        `good night everyone! recharge for another amazing day ahead.`,
        `sleep tight everyone! tomorrow is full of new possibilities.`,
        `good night! let go of today's worries and rest your mind.`,
        `good night everyone! you deserve a peaceful and restful sleep.`,
        `good night! close your eyes and dream something wonderful.`,
        `good night everyone! thank you for today, see you tomorrow.`,
        `good night! may you wake up refreshed and ready to shine.`,
        `sweet dreams everyone! rest and recharge for tomorrow.`,
        `good night! a good sleep is the best gift for yourself.`,
        `good night everyone! be proud of what you did today.`,
        `good night! wishing you calm nights and bright mornings.`,
        `good night everyone! let your body and mind rest fully.`,
        `good night! tomorrow is a fresh start, so sleep well.`,
        `good night everyone! may peace fill your dreams tonight.`,
        `good night! rest easy, you've earned it.`,
        `good night everyone! recharge those batteries for tomorrow.`,
        `good night! end the day with a grateful heart.`,
        `good night everyone! sweet dreams and take care.`
      ],
      newMessage: [
        `hello everyone! wishing you peace, progress, and good vibes today.`,
        `hi everyone! hope you're having a wonderful day.`,
        `hello! sending positive energy to everyone here.`,
        `hey everyone! stay awesome and keep shining.`,
        `hello everyone! wishing you a day full of blessings.`,
        `hi there! may your day be productive and joyful.`,
        `hello everyone! keep your head up and stay positive.`,
        `hey! wishing you strength and happiness today.`,
        `hello everyone! may good things come your way.`,
        `hi everyone! stay kind, stay humble, stay strong.`,
        `hello! hope your day is going amazingly well.`,
        `hey everyone! here's a little reminder that you matter.`,
        `hello everyone! believe in yourself and keep moving forward.`,
        `hi! wishing you calm, focus, and good energy today.`,
        `hello everyone! spread positivity wherever you go.`,
        `hey there! may your day be light and your heart full.`,
        `hello everyone! grateful to share this day with you.`,
        `hi everyone! keep smiling, the world needs it.`,
        `hello! wishing you a peaceful and meaningful day.`,
        `hey everyone! stay blessed and take good care of yourself.`
      ],
      note: 'greetings every morning, afternoon and evening. the timezone is located in Asia/Manila'
    },
    randomQuotes: {
      status: true,
      interval: 20, // 20 minutes
      quotes: [
        `believe you can and you're halfway there.`,
        `small steps every day lead to big results.`,
        `your only limit is your mind.`,
        `keep going, you are closer than you think.`
      ],
      note: 'sends a random quote to all threads every 20 minutes.'
    },
    accpetPending: {
      status: false,
      time: 10, // 10 minutes
      note: 'approve waiting messages after a certain time, set the status to false if you want to disable auto accept message request.'
    }
  }

  function autosetbio(config) {
    if (config.status) {
      try {
        api.changeBio(config.bio, (err) => {
          if (err) {
            logger(`having some unexpected error : ${err}`, 'setbio')
          }; return logger(`changed the bot bio into : ${config.bio}`, 'setbio')
        })
      } catch (error) {
        logger(`having some unexpected error in auto set bio : ${error}`, 'error')
      }
    }
  }
  async function greetings(config) {
    if (config.status) {
      try {
      const asArray = v => Array.isArray(v) ? v : [v];
      const nam = [
        {
          timer: '12:00:00 PM',
          message: asArray(config.newMessage)
        },
        {
          timer: '5:00:00 AM',
          message: asArray(config.morning)
        },
        {
          timer: '11:00:00 AM',
          message: asArray(config.afternoon)
        },
        {
          timer: '6:00:00 PM',
          message: asArray(config.evening)
        },
        {
          timer: '10:00:00 PM',
          message: asArray(config.sleep)
        }
      ];
      const userID = await api.getCurrentUserID();
        setInterval(() => {
const r = a => a[Math.floor(Math.random()*a.length)];
if (á = nam.find(i => i.timer == new Date(Date.now()+25200000).toLocaleString().split(/,/).pop().trim())) {
    const allThread = global.data.allThreadID.get(userID);
    allThread.forEach(i => {
        api.sendMessage(r(á.message), i);
       });
      }
}, 1000);
      } catch (error) {
        logger(`having some unexpected error in greetings : ${error}`, 'error')
      }
    }
  }

  async function randomQuotes(config) {
    if (config.status) {
      try {
        const userID = await api.getCurrentUserID();
        const pickRandom = (items) => items[Math.floor(Math.random() * items.length)];
        const getQuote = async () => {
          try {
            const response = await fetch('https://zenquotes.io/api/random', {
              headers: { accept: 'application/json' }
            });
            if (!response.ok) throw new Error(`quote API returned ${response.status}`);
            const [quote] = await response.json();
            if (!quote?.q || !quote?.a) throw new Error('invalid quote response');
            return `“${quote.q}” — ${quote.a}\nSource: ZenQuotes.io`;
          } catch (error) {
            logger(`quote API unavailable, using fallback quote : ${error}`, 'warning');
            return pickRandom(config.quotes);
          }
        };

        const sendQuote = async () => {
          const allThread = global.data.allThreadID.get(userID);
          if (!allThread) return;

          const quote = await getQuote();
          allThread.forEach(threadID => api.sendMessage(quote, threadID));
        };

        setInterval(sendQuote, config.interval * 60 * 1000);
      } catch (error) {
        logger(`having some unexpected error in random quotes : ${error}`, 'error');
      }
    }
  }

  function accpetPending(config) {
    if(config.status) {
      setInterval(async () => {
          const list = [
              ...(await api.getThreadList(1, null, ['PENDING'])),
              ...(await api.getThreadList(1, null, ['OTHER']))
          ];
          if (list[0]) {
              api.sendMessage('this thread is automatically approved by our system.', list[0].threadID);
          }
      }, config.time * 60 * 1000)
    }
  }

autosetbio(configCustom.autosetbio)
greetings(configCustom.greetings)
randomQuotes(configCustom.randomQuotes)
accpetPending(configCustom.accpetPending)
};
