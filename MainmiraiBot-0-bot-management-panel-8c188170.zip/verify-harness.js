/* TEMPORARY verification harness - deleted after browser verification.
   Boots the REAL panel module and the REAL /panel/* + /profile route source
   sliced verbatim out of main.js, so the browser exercises production code
   without needing a live Facebook login. */

const fs = require('fs-extra');
const path = require('path');
const express = require('express');
const jwt = require('jsonwebtoken');

const ROOT = __dirname;

// ---- minimal globals the route code expects -------------------------------
global.client = {
    commands: new Map(),
    accounts: new Map(),
    apis: new Map(),
    configPath: path.join(ROOT, 'config.json')
};
global.data = {
    allThreadID: new Map(),
    userName: new Map(),
    allUserID: [],
    userBanned: new Map(),
    threadInfo: new Map(),
    threadData: new Map()
};
global.config = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
global.config.PREFIX = '-';

// fake commands so the Commands table has rows to render
const NAMES = ['help','ping','uptime','profile','weather','song','video','meme','quote','trivia',
               'ban','kick','unban','warn','prefix','balance','daily','shop','rank','leaderboard',
               'translate','define','wiki','qrcode'];
const CATS = ['utility','media','fun','admin','economy'];
NAMES.forEach((name, i) => {
    global.client.commands.set(name, {
        config: {
            name,
            category: ['ban','kick','unban','warn'].includes(name) ? 'admin' : CATS[i % CATS.length],
            description: `Runs the ${name} command.`,
            permission: ['ban','kick','unban','warn'].includes(name) ? 1 : 0,
            usePrefix: true,
            cooldown: 5
        }
    });
});

const panel = require(path.join(ROOT, 'main/system/panel.js'));
global.panel = panel;

// the developer ledger behind /opiar, exercised by the same route source
const devlog = require(path.join(ROOT, 'main/system/devlog.js'));
global.devlog = devlog;

// the /opiar/control power actions call these three from main.js scope
globalThis.startLogin = () => Promise.reject(new Error('no facebook login in the harness'));
globalThis.rmStates = () => Promise.resolve();
globalThis.deleteUser = () => Promise.resolve();

// ---- seed a signed test bot into bots.json --------------------------------
const UID = '100072511403089';
// deterministic (no iat/exp jitter) so the panel URL stays stable across restarts
const TOKEN = jwt.sign({ uid: UID, username: 'demo' }, UID, { noTimestamp: true });
fs.writeFileSync(path.join(ROOT, 'bots.json'), JSON.stringify([{
    uid: UID,
    name: 'OP AutoBot Demo',
    username: 'demo',
    password: 'demo',
    token: TOKEN,
    thumbSrc: '/images/op-autobot-logo.svg',
    profileUrl: 'https://facebook.com/' + UID,
    time: Date.now()
}], null, 2));

// a few named members so the console and the activity feed can show who acted
const PEOPLE = [
    ['100001111111111', 'Ana Reyes'],
    ['100002222222222', 'Miguel Santos'],
    ['100003333333333', 'Joy Dela Cruz']
];
PEOPLE.forEach(([id, name]) => global.data.userName.set(id, name));

// pending approval requests + one banned user, written to config.json the same
// way the "request" command does, so the Users page has something to render
const cfgPath = path.join(ROOT, 'config.json');
const seeded = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
seeded.pendingrequests = [
    { threadID: '9876543210001', name: 'Barkada Chat', senderID: PEOPLE[0][0], time: '21:14:02 17/08/2026' },
    { threadID: '9876543210002', name: 'Study Group 2026', senderID: PEOPLE[1][0], time: '09:02:41 17/08/2026' }
];
seeded.approvedgroups = ['9876543210003'];
fs.writeFileSync(cfgPath, JSON.stringify(seeded, null, 2));
global.config.pendingrequests = seeded.pendingrequests;
global.config.approvedgroups = seeded.approvedgroups;
global.data.threadInfo.set('9876543210003', { threadName: 'Family Group' });
global.data.userBanned.set(PEOPLE[2][0], { reason: 'spamming the group', dateAdded: '18:30:00 16/08/2026' });

// telemetry + console history to render
panel.log(UID, 'success', 'panel verification harness started', UID);
['help','ping','weather','song','help','meme','help','balance'].forEach((c, i) => {
    panel.recordCommand(UID, c, PEOPLE[i % PEOPLE.length][0], 40 + i * 7);
});
panel.activity(UID, 'fa-plug-circle-check', 'Session connected to Facebook', UID);
panel.activity(UID, 'fa-reply', 'Auto replied to Ana Reyes on "good morning"', PEOPLE[0][0]);
panel.log(UID, 'info', 'listening for events on mqtt');
panel.log(UID, 'info', 'thread list synced (12 threads)');
panel.log(UID, 'warning', 'rate limit warning on /weather', PEOPLE[1][0]);
panel.recordError(UID, 'quote', 'quote API unavailable, using fallback', PEOPLE[2][0]);

// developer ledger history, written through the real record() so the /opiar
// tables render exactly what a real deploy and a real panel session produce
devlog.record({
    type: 'deploy.start',
    message: 'demo started a deploy for "OP AutoBot Demo" from a desktop browser',
    owner: 'demo', actor: 'demo', ip: '203.0.113.14',
    detail: { username: 'demo', botname: 'OP AutoBot Demo', prefix: '-', admin: PEOPLE[0][0], cookies: 9, device: 'desktop browser' }
});
devlog.record({
    type: 'deploy.success',
    message: 'demo deployed "OP AutoBot Demo" with the prefix "-"',
    botId: UID, botName: 'OP AutoBot Demo', owner: 'demo', actor: 'demo', ip: '203.0.113.14',
    detail: { username: 'demo', botname: 'OP AutoBot Demo', prefix: '-', admin: PEOPLE[0][0], cookies: 9, device: 'desktop browser', tookMs: 4310 }
});
devlog.record({
    type: 'deploy.failed',
    message: 'jaycee failed to deploy : the provided appstate is wrong format.',
    owner: 'jaycee', actor: 'jaycee', ip: '198.51.100.7',
    detail: { username: 'jaycee', botname: 'Test Bot', prefix: '!', admin: '', cookies: 0, device: 'mobile browser', tookMs: 820, reason: 'the provided appstate is wrong format.' }
});
devlog.record({
    type: 'panel.login',
    message: 'demo signed in to the OP AutoBot Demo panel',
    botId: UID, botName: 'OP AutoBot Demo', owner: 'demo', actor: 'demo', ip: '203.0.113.14',
    detail: { device: 'desktop browser' }
});
devlog.record({
    type: 'feature.toggle',
    message: 'demo turned Auto Reply on',
    botId: UID, botName: 'OP AutoBot Demo', owner: 'demo', actor: 'demo', ip: '203.0.113.14',
    detail: { feature: 'autoReply', value: true }
});
devlog.record({
    type: 'panel.login.failed',
    message: 'a wrong password was tried for "demo"',
    botId: UID, owner: 'demo', actor: 'demo', ip: '198.51.100.7'
});

// ---- app ------------------------------------------------------------------
const app = express();
app.use(express.json());
app.use(express.static(path.join(ROOT, 'public/main')));
app.use('/images', express.static(path.join(ROOT, 'public/images')));

// public routes that live outside the panel slice in main.js
app.get('/commands', (req, res) => {
    res.json(Array.from(global.client.commands.values()));
});
app.get('/info', (req, res) => {
    // same shape as main.js: a bare array of live sessions
    res.json([{
        name: 'OP AutoBot Demo',
        profileUrl: 'https://facebook.com/' + UID,
        thumbSrc: '/images/op-autobot-logo.svg',
        time: Date.now() - 1000 * 60 * 42
    }]);
});

// slice the real route definitions (panel api + /profile) out of main.js
const src = fs.readFileSync(path.join(ROOT, 'main.js'), 'utf8').split('\n');
const start = src.findIndex(l => l.includes('async function panelBot'));
const end = src.findIndex(l => l.includes("app.post('/login'"));
const routeSrc = src.slice(start, end).join('\n');
new Function('app', 'panel', 'devlog', 'jwt', 'path', 'fs', '__dirname', 'require', routeSrc)(
    app, panel, devlog, jwt, path, fs, ROOT, require
);

app.get('/', (req, res) => res.redirect(`/profile?botid=${UID}&token=${TOKEN}`));
app.use((req, res) => res.status(404).sendFile(path.join(ROOT, 'public/notFound.html')));

const PORT = process.env.DEV_PORT || 3000;
app.listen(PORT, () => {
    console.log(`[verify] listening on ${PORT}`);
    console.log(`[verify] PANEL_PATH=/profile?botid=${UID}&token=${TOKEN}`);
});
