const express = require('express');
const { addUser, rmStates, createUser, deleteUser } = require('./main/system/editconfig.js');
const log = require("./main/utility/logs.js");
const logger = require("./main/utility/logs.js");
const axios = require("axios");
const chalk = require('chalk');
const { readdirSync, readFileSync, writeFileSync } = require("fs-extra");
const { join, resolve } = require('path')
const { execSync, exec } = require('child_process');
const configLog = require('./main/utility/config.json');
const login = require("./main/system/ws3-fca/index.js");
const fancyfont = require("./main/utility/fancyfont.js");
const listPackage = JSON.parse(readFileSync('package.json')).dependencies;
const packages = JSON.parse(readFileSync('package.json'));
const fs = require("fs-extra")
const process = require('process');
const moment = require("moment-timezone");
const app = express();
const port = Number(process.env.PORT || process.env.DEV_PORT) || 8099;
const cron = require('node-cron');
const path = require('path');
const jwt = require('jsonwebtoken');

global.client = new Object({
    commands: new Map(),
    events: new Map(),
    accounts: new Map(),
    cooldowns: new Map(),
    mainPath: process.cwd(),
    eventRegistered: new Map(),
    configPath: new String(),
    envConfigPath: new String(),
    handleSchedule: new Array(),
    handleReaction: new Map(),
    handleReply: new Map(),
    // the live ws3-fca api instance for every logged in bot, keyed by uid.
    // used by the test chat so it can run commands against the right session.
    apis: new Map(),
    onlines: new Array()
});

// exposed so commands can opt out of styling with fancyfont.raw("...")
// or convert a single string on demand
global.fancyfont = fancyfont;

global.data = new Object({
    threadInfo: new Map(),
    threadData: new Map(),
    userName: new Map(),
    userBanned: new Map(),
    threadBanned: new Map(),
    commandBanned: new Map(),
    threadAllowNSFW: new Array(),
    allUserID: new Array(),
    allCurrenciesID: new Array(),
    allThreadID: new Map()
});

global.config = new Object();
global.envConfig = new Object();
global.accounts = new Array();
global.nodemodule = new Object();
global.configModule = new Object();
global.moduleData = new Array();
global.language = new Object();
global.utils = require('./main/utility/utils.js');
global.send = require("./main/utility/send.js");
global.editBots = require("./main/system/editconfig.js");
// telemetry, feature flags and access control shared by the web panel and the live bot
global.panel = require("./main/system/panel.js");
// the developer ledger behind /opiar : deploys, panel sign ins and every panel mutation
global.devlog = require("./main/system/devlog.js");


console.clear();
console.log(chalk.blue('LOADING MAIN SYSTEM'));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public/main')));
// shared assets (logos, favicon, setup screenshots) live in public/images and are
// referenced as /images/* by both index.html and profile.html. Mounted on the
// /images prefix so the html files in public/ stay unreachable directly and
// profile.html is only ever served by the token checked /profile route.
app.use('/images', express.static(path.join(__dirname, 'public/images')));
async function logOut(res, botId) {
    try {
        delete require.cache[require.resolve('./bots.json')];
        try {
            delete require.cache[require.resolve('./states/' + botId + '.json')];
        } catch (e) {}
        await global.client.accounts.delete(botId);
        global.client.apis.delete(botId);
        await rmStates(botId);
        await deleteUser(botId);
        var data = `logged out ${botId} successfully`;
        return res.send({ data, redirect: '/' });
    } catch (err) {
        var error = `can't logged out bot ${botId}, maybe the bot is not logged in.`;
        return res.status(400).send({ error });
    }
}

app.get('/commands', (req, res) => {
    const commands = global.client.commands;
    const command = Array.from(commands.values());
    res.json(command);
})
// simple in memory rate limit so the sandbox can't be used to hammer the command modules
const testChatHits = new Map();
function testChatAllowed(key) {
    const now = Date.now();
    const window = 60 * 1000;
    const limit = 20;
    const hits = (testChatHits.get(key) || []).filter(t => now - t < window);
    if (hits.length >= limit) {
        testChatHits.set(key, hits);
        return false;
    }
    hits.push(now);
    testChatHits.set(key, hits);
    return true;
}

// run a message through the real command modules without touching facebook.
// with a valid botid + token the bot's own prefix and session are used, otherwise it
// falls back to an anonymous demo sandbox that only allows permission 0 commands.
app.post('/testchat', async (req, res) => {
    const { botid, token, message } = req.body || {};

    if (typeof message !== 'string' || !message.trim()) {
        return res.status(400).send({ error: 'please type a message.' });
    }
    if (message.length > 1000) {
        return res.status(400).send({ error: 'that message is too long.' });
    }

    const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    if (!testChatAllowed(String(botid || ip))) {
        return res.status(429).send({ error: 'too many test messages, please slow down.' });
    }

    let prefix = global.config.prefix || '!';
    let botname = 'OP AutoBot';
    let realApi = null;
    let demo = true;
    let permission = 0;
    let resolvedBotId = null;

    // an authenticated bot panel gets the live session and bot admin level access
    if (botid && token) {
        try {
            delete require.cache[require.resolve('./bots.json')];
            const bot = require('./bots.json').find(i => String(i.uid) === String(botid));
            if (bot && bot.token && bot.token === token) {
                const valid = await new Promise(resolve => {
                    jwt.verify(token, String(botid), err => resolve(!err));
                });
                if (valid) {
                    prefix = bot.prefix || prefix;
                    botname = bot.botname || botname;
                    realApi = global.client.apis.get(String(botid)) || null;
                    resolvedBotId = String(botid);
                    demo = false;
                    permission = 2;
                }
            }
        } catch (err) {
            // fall through to the demo sandbox
        }
    }

    try {
        const { runTestMessage } = require('./main/system/testchat.js');
        const result = await runTestMessage({
            body: message,
            prefix,
            realApi,
            botId: resolvedBotId,
            botname,
            models: demo ? null : models,
            demo,
            permission
        });
        return res.send({ ...result, prefix, botname, demo });
    } catch (err) {
        return res.status(500).send({ error: `the sandbox failed to run that command : ${err.message || err}` });
    }
});

app.post('/profile', async (req, res) => {
    try {
        delete require.cache[require.resolve('./bots.json')];
        const { botid } = req.body;
        const botPath = require('./bots.json');
        const data = botPath.find(data => data.uid === botid);
        const name = data.name || 'Unknown';
        const uid = botid;
        const thumbSrc = data.thumbSrc;
        const profileUrl = data.profileUrl;
        const botname = data.botname;
        const botprefix = data.prefix;
        const adminList = Array.isArray(data.admins) ? data.admins : [];
        const admins = adminList.length;
        const maintenance = data.maintenance || { status: false, reason: '', since: null };
        return res.send({name, uid, thumbSrc, profileUrl, botname, botprefix, admins, adminList, maintenance});
    } catch (err) {
        // the bot no longer exists, tell the panel to go back to the home page
        return res.status(401).send({ error: 'this bot is no longer available.', redirect: '/' });
    }
})

app.post('/logout', async (req, res) => {
    const { botid } = req.body;
    try {
        const bot = global.panel.findBot(botid) || {};
        global.devlog.record({
            type: 'bot.removed',
            message: `${bot.username || bot.name || botid} deleted their bot and its saved session`,
            botId: botid,
            botName: bot.botname || bot.name || '',
            owner: bot.username || '',
            actor: bot.name || bot.username || String(botid || ''),
            ip: global.devlog.clientIp(req)
        });
    } catch (err) {}
    return await logOut(res, botid);
});

app.post('/configure', async (req, res) => {
    const { botId, content, type } = req.body;

    // the quick edits on the profile page are audited too, so the developer feed
    // shows the same change history the owner sees
    const answer = res.send.bind(res);
    res.send = payload => {
        try {
            if (res.statusCode < 400) {
                const bot = global.panel.findBot(botId) || {};
                const who = bot.username || bot.name || String(botId || '');
                const said = type === 'logout'
                    ? `${who} signed out of the bot panel`
                    : `${who} changed ${type} from the profile page`;
                global.devlog.record({
                    type: type === 'logout' ? 'panel.signout' : 'config.change',
                    message: said,
                    botId,
                    botName: bot.botname || bot.name || '',
                    owner: bot.username || '',
                    actor: bot.name || bot.username || String(botId || ''),
                    ip: global.devlog.clientIp(req),
                    detail: { field: type, value: typeof content === 'object' ? content : String(content || '').slice(0, 80) }
                });
            }
        } catch (err) {}
        return answer(payload);
    };

    const botPath = "bots.json";
    const botChanges = JSON.parse(fs.readFileSync(botPath, 'utf-8'));
    const pointDirect = botChanges.find(i => i.uid == botId);
    if (!pointDirect) {
        return res.status(404).send({ error: 'bot not found, it may already be deleted.' });
    }
    async function saveChanges() {
        await fs.writeFileSync(botPath, JSON.stringify(botChanges, null, 2));
        delete require.cache[require.resolve('./bots.json')];
    }
    async function editDetails(where, value) {
        pointDirect[where] = value;
        try {
            await saveChanges();
            var data = `edited ${where} successfully.`;
            return res.send({data})
        } catch (err) {
            var error = `failed to edit ${where}`;
            return res.status(400).send({error});
        }
    }
    async function addAdmin(value) {
        const adminId = String(value || '').trim();
        if (!/^\d{5,}$/.test(adminId)) {
            return res.status(400).send({ error: 'invalid user id, it must be numbers only.' });
        }
        if (!Array.isArray(pointDirect.admins)) pointDirect.admins = [];
        const admins = pointDirect.admins.map(String);
        if (admins.includes(adminId)) {
            return res.status(400).send({ error: `${adminId} is already an admin.` });
        }
        if (adminId === String(botId)) {
            return res.status(400).send({ error: `you can't grant admin to the bot itself.` });
        }
        pointDirect.admins = [...admins, adminId];
        try {
            await saveChanges();
            var data = `added admin ${adminId} successfully.`;
            return res.send({ data, admins: pointDirect.admins });
        } catch (err) {
            var error = `failed to add admin.`;
            return res.status(400).send({error});
        }
    }
    async function setMaintenance(value) {
        const payload = typeof value === 'object' && value !== null ? value : { status: !!value };
        const status = payload.status === true || payload.status === 'true';
        const reason = String(payload.reason || '').trim() || 'the bot is currently under maintenance, please try again later.';
        pointDirect.maintenance = {
            status,
            reason,
            since: status ? new Date().toISOString() : null
        };
        try {
            await saveChanges();
            var data = status ? 'maintenance mode is now enabled.' : 'maintenance mode is now disabled.';
            return res.send({ data, maintenance: pointDirect.maintenance });
        } catch (err) {
            return res.status(400).send({ error: 'failed to update maintenance mode.' });
        }
    }
    async function logoutSession() {
        pointDirect.token = '';
        try {
            await saveChanges();
            return res.send({ data: 'logged out successfully.', redirect: '/' });
        } catch (err) {
            return res.status(400).send({ error: 'failed to log out.' });
        }
    }
    switch (type) {
        case 'prefix':
            return await editDetails('prefix', content);
        case 'botname':
            return await editDetails('botname', content);
        case 'admin':
            return await addAdmin(content);
        case 'maintenance':
            return await setMaintenance(content);
        case 'logout':
            return await logoutSession();
        default:
            return res.status(400).send({ error: 'unknown configuration type.' });
    }
})
        
/* ---------------------------------------------------------------------------
   panel api
   every route below is owned by the logged in bot. the panel proves ownership with
   the same jwt the login route issued, so one bot can never read or write another.
--------------------------------------------------------------------------- */
const panel = global.panel;
const devlog = global.devlog;

// resolves the caller's bot or answers 401 and returns null
async function panelBot(req, res) {
    const { botid, token } = req.body || {};
    const bot = await panel.verify(botid, token);
    if (!bot) {
        res.status(401).send({ error: 'this session is no longer valid.', redirect: '/' });
        return null;
    }
    // every authenticated panel request counts towards the owner's roster row on
    // the developer panel, and opens a session entry when the browser is new
    try { devlog.touch(bot, req, req.path); } catch (err) {}
    return bot;
}

/* ---------------------------------------------------------------------------
   developer audit trail
   one description per mutating panel route. the middleware below only writes an
   entry when the route actually answered with a success, so the developer feed
   can never claim a change that was rejected.
--------------------------------------------------------------------------- */
const PANEL_AUDIT = {
    '/panel/feature': body => {
        const known = panel.FEATURES.find(f => f.key === body.key);
        if (!known) return null;
        const on = body.value === true || body.value === 'true';
        return { type: 'feature.toggle', message: `turned ${known.label} ${on ? 'on' : 'off'}`, detail: { key: body.key, enabled: on } };
    },
    '/panel/command': body => ({
        type: 'command.toggle',
        message: `changed the "${body.name}" command`,
        detail: { command: body.name, enabled: body.enabled, cooldown: body.cooldown }
    }),
    '/panel/settings': body => {
        const keys = Object.keys((body && body.patch) || {});
        if (!keys.length) return null;
        return { type: 'config.change', message: `saved settings : ${keys.join(', ')}`, detail: (body && body.patch) || {} };
    },
    '/panel/schedules': body => {
        if (!body.action) return null;
        const label = (body.task && body.task.label) || (body.task && body.task.id) || 'a task';
        return { type: 'schedule.change', message: `${body.action}d the schedule "${label}"`, detail: body.task || {} };
    },
    '/panel/actions': body => {
        if (!body.key) return null;
        return { type: 'action.run', message: `fired the bot action "${body.key}"`, detail: { key: body.key } };
    },
    '/panel/users': body => {
        if (!body.action) return null;
        return { type: 'access.change', message: `${body.action === 'add' ? 'added' : 'removed'} ${body.id} ${body.action === 'add' ? 'to' : 'from'} ${body.list}`, detail: body };
    },
    '/panel/people': body => {
        if (!body.action) return null;
        return { type: 'access.change', message: `${body.action}ned the user ${body.id}`, detail: body };
    },
    '/panel/groupbans': body => {
        if (!body.action) return null;
        return { type: 'access.change', message: `${body.action}ned the group ${body.threadID}`, detail: body };
    },
    '/panel/approvals': body => {
        if (!body.action) return null;
        return { type: 'access.change', message: `${body.action}d the group ${body.threadID}`, detail: body };
    },
    '/panel/logs/clear': () => ({ type: 'config.change', message: 'cleared their bot console' }),
    '/panel/power': body => {
        if (!body.action) return null;
        return { type: 'power.change', message: `${body.action === 'stop' ? 'stopped' : 'restarted'} the bot session`, detail: { action: body.action } };
    }
};

app.use((req, res, next) => {
    if (req.method !== 'POST') return next();
    const describe = PANEL_AUDIT[req.path];
    if (!describe) return next();

    const send = res.send.bind(res);
    res.send = payload => {
        try {
            if (res.statusCode < 400) {
                const body = req.body || {};
                const info = describe(body);
                if (info) {
                    const bot = panel.findBot(body.botid) || {};
                    devlog.record({
                        type: info.type,
                        message: `${bot.username || bot.name || body.botid} ${info.message}`,
                        botId: body.botid,
                        botName: bot.botname || bot.name || '',
                        owner: bot.username || '',
                        actor: bot.name || bot.username || String(body.botid || ''),
                        ip: devlog.clientIp(req),
                        detail: Object.assign({ route: req.path }, info.detail || {})
                    });
                }
            }
        } catch (err) {}
        return send(payload);
    };
    next();
});

// everything the dashboard needs for its first paint
app.post('/panel/overview', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const settings = panel.settingsOf(bot);
    return res.send({
        profile: {
            name: bot.name || 'Unknown',
            uid: String(bot.uid),
            thumbSrc: bot.thumbSrc,
            profileUrl: bot.profileUrl
        },
        settings,
        catalogue: panel.FEATURES,
        stats: panel.stats(bot.uid)
    });
});

// polled by the dashboard for the live cards, chart and activity feed
app.post('/panel/stats', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    return res.send(panel.stats(bot.uid));
});

app.post('/panel/feature', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { key, value } = req.body || {};
    const known = panel.FEATURES.find(f => f.key === key);
    if (!known) return res.status(400).send({ error: 'unknown feature.' });

    const enabled = value === true || value === 'true';
    const updated = panel.updateBot(bot.uid, b => {
        b.features = Object.assign({}, panel.FEATURE_DEFAULTS, b.features || {});
        b.features[key] = enabled;
    });
    if (!updated) return res.status(404).send({ error: 'bot not found.' });

    panel.log(bot.uid, 'info', `${known.label} was turned ${enabled ? 'on' : 'off'} from the panel`, bot.uid);
    panel.activity(bot.uid, known.icon, `${known.label} ${enabled ? 'enabled' : 'disabled'} from the panel`, bot.uid);
    // schedule related flags change which cron jobs should be armed
    if (key === 'schedules' || key === 'autoPost') panel.syncSchedules(bot.uid);

    return res.send({ data: `${known.label} ${enabled ? 'enabled' : 'disabled'}.`, features: panel.settingsOf(updated).features });
});

// the command table, with each command merged with this bot's saved state
app.post('/panel/commands', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const settings = panel.settingsOf(bot);
    const roles = ['User', 'Admin', 'Owner'];
    const commands = Array.from(global.client.commands.values())
        .filter(c => c && c.config && c.config.name)
        .map(c => {
            const saved = settings.commandState[c.config.name] || {};
            const authored = Number(c.config.cooldowns) || 0;
            return {
                name: c.config.name,
                description: c.config.description || 'No description provided.',
                category: c.config.category || 'other',
                permission: Number(c.config.permission) || 0,
                role: roles[Number(c.config.permission) || 0] || 'User',
                usage: c.config.usage || c.config.usages || '',
                usesPrefix: c.config.prefix !== false,
                authoredCooldown: authored,
                cooldown: saved.cooldown != null ? Number(saved.cooldown) : authored,
                enabled: saved.enabled !== false,
                premium: !!c.config.premium,
                credits: c.config.credits || ''
            };
        })
        .sort((a, b) => a.name.localeCompare(b.name));
    return res.send({ commands, prefix: settings.prefix, cooldownEnforced: settings.features.perCommandCooldown });
});

app.post('/panel/command', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { name, enabled, cooldown } = req.body || {};
    if (!global.client.commands.has(String(name))) {
        return res.status(400).send({ error: 'unknown command.' });
    }
    const cd = cooldown === undefined || cooldown === null || cooldown === '' ? null : Number(cooldown);
    if (cd !== null && (!Number.isFinite(cd) || cd < 0 || cd > 3600)) {
        return res.status(400).send({ error: 'cooldown must be between 0 and 3600 seconds.' });
    }

    const updated = panel.updateBot(bot.uid, b => {
        if (!b.commandState || typeof b.commandState !== 'object') b.commandState = {};
        const entry = b.commandState[name] || {};
        if (enabled !== undefined) entry.enabled = enabled === true || enabled === 'true';
        if (cd !== null) entry.cooldown = cd;
        b.commandState[name] = entry;
    });
    if (!updated) return res.status(404).send({ error: 'bot not found.' });

    panel.log(bot.uid, 'info', `command "${name}" updated from the panel`, bot.uid);
    return res.send({ data: `${name} updated.`, commandState: panel.settingsOf(updated).commandState });
});

app.post('/panel/logs', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const since = Number(req.body && req.body.since) || 0;
    const all = panel.state(bot.uid).logs;
    return res.send({ logs: since ? all.filter(l => l.id > since) : all });
});

app.post('/panel/logs/clear', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    panel.clearLogs(bot.uid);
    return res.send({ data: 'console cleared.' });
});

// whitelist, blacklist and the admin roster all live here
app.post('/panel/users', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { action, list, id } = req.body || {};
    const lists = ['whitelist', 'blacklist', 'admins'];
    const settings = panel.settingsOf(bot);

    if (!action) {
        return res.send({ whitelist: settings.whitelist, blacklist: settings.blacklist, admins: settings.admins });
    }
    if (!lists.includes(list)) return res.status(400).send({ error: 'unknown list.' });

    const userId = String(id || '').trim();
    if (!/^\d{5,}$/.test(userId)) return res.status(400).send({ error: 'user id must be numbers only.' });
    if (list === 'admins' && userId === String(bot.uid)) {
        return res.status(400).send({ error: "you can't grant admin to the bot itself." });
    }

    let message = '';
    const updated = panel.updateBot(bot.uid, b => {
        const current = (Array.isArray(b[list]) ? b[list] : []).map(String);
        if (action === 'add') {
            if (!current.includes(userId)) current.push(userId);
            message = `${userId} added to ${list}.`;
        } else {
            const index = current.indexOf(userId);
            if (index !== -1) current.splice(index, 1);
            message = `${userId} removed from ${list}.`;
        }
        b[list] = current;
    });
    if (!updated) return res.status(404).send({ error: 'bot not found.' });

    panel.log(bot.uid, 'info', message, bot.uid);
    panel.activity(bot.uid, 'fa-user-lock', message, bot.uid);
    const next = panel.settingsOf(updated);
    return res.send({ data: message, whitelist: next.whitelist, blacklist: next.blacklist, admins: next.admins });
});

// the people who actually used this bot, with ban control
app.post('/panel/people', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { action, id, reason } = req.body || {};

    if (!action) return res.send({ users: panel.people(bot.uid) });
    if (action !== 'ban' && action !== 'unban') return res.status(400).send({ error: 'unknown action.' });

    try {
        const result = await panel.setBanned(bot.uid, id, action === 'ban', reason);
        return res.send(result);
    } catch (err) {
        return res.status(400).send({ error: (err && err.message) || 'that request failed.' });
    }
});

// the group approval queue the "request" command fills from chat
app.post('/panel/approvals', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { action, threadID } = req.body || {};

    if (!action) return res.send(panel.approvals(bot.uid));

    try {
        if (action === 'approve') return res.send(panel.approveGroup(bot.uid, threadID));
        if (action === 'decline') return res.send(panel.declineRequest(bot.uid, threadID));
        if (action === 'revoke') return res.send(panel.revokeGroup(bot.uid, threadID));
        return res.status(400).send({ error: 'unknown action.' });
    } catch (err) {
        return res.status(400).send({ error: (err && err.message) || 'that request failed.' });
    }
});

// the group ban list. a ban outranks approval: the bot ignores the thread entirely.
app.post('/panel/groupbans', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { action, threadID, reason } = req.body || {};

    if (!action) return res.send({ groupBans: panel.groupBans(bot.uid) });
    if (action !== 'ban' && action !== 'unban') return res.status(400).send({ error: 'unknown action.' });

    try {
        return res.send(panel.setGroupBanned(bot.uid, threadID, action === 'ban', reason));
    } catch (err) {
        return res.status(400).send({ error: (err && err.message) || 'that request failed.' });
    }
});

// the 19 one-shot operations fired straight at the live facebook session
app.post('/panel/actions', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { key, input } = req.body || {};

    if (!key) return res.send(panel.actionCatalogue(bot.uid));

    try {
        const result = await panel.runAction(bot.uid, String(key), input || {});
        panel.log(bot.uid, 'success', `panel action "${result.label}" : ${result.message}`, bot.uid);
        panel.activity(bot.uid, 'fa-bolt', result.label, bot.uid);
        return res.send({ data: result.message, rows: result.rows || null, kind: result.kind || null });
    } catch (err) {
        const message = (err && err.message) || 'that action failed.';
        panel.log(bot.uid, 'error', `panel action "${key}" failed : ${message}`, bot.uid);
        return res.status(400).send({ error: message });
    }
});

// bot name, prefix, cooldown default, timezone, notifications, auto reply rules and greetings
app.post('/panel/settings', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const patch = (req.body && req.body.patch) || {};

    if (patch.prefix !== undefined) {
        const prefix = String(patch.prefix).trim();
        if (!prefix || prefix.length > 5) return res.status(400).send({ error: 'prefix must be 1 to 5 characters.' });
    }
    if (patch.botname !== undefined && !String(patch.botname).trim()) {
        return res.status(400).send({ error: 'please enter a bot name.' });
    }
    if (patch.defaultCooldown !== undefined) {
        const cd = Number(patch.defaultCooldown);
        if (!Number.isFinite(cd) || cd < 0 || cd > 3600) {
            return res.status(400).send({ error: 'default cooldown must be between 0 and 3600 seconds.' });
        }
    }
    if (patch.timezone !== undefined && !moment.tz.zone(String(patch.timezone))) {
        return res.status(400).send({ error: 'that timezone is not recognised.' });
    }

    const updated = panel.updateBot(bot.uid, b => {
        if (patch.botname !== undefined) b.botname = String(patch.botname).trim();
        if (patch.prefix !== undefined) b.prefix = String(patch.prefix).trim();
        if (patch.defaultCooldown !== undefined) b.defaultCooldown = Number(patch.defaultCooldown);
        if (patch.timezone !== undefined) b.timezone = String(patch.timezone);
        if (patch.reactEmoji !== undefined) b.reactEmoji = String(patch.reactEmoji).slice(0, 8);
        if (patch.greetJoin !== undefined) b.greetJoin = String(patch.greetJoin).slice(0, 400);
        if (patch.greetLeave !== undefined) b.greetLeave = String(patch.greetLeave).slice(0, 400);
        if (patch.notify !== undefined && typeof patch.notify === 'object') {
            b.notify = Object.assign({}, b.notify || {}, patch.notify);
        }
        if (Array.isArray(patch.autoReplyRules)) {
            b.autoReplyRules = patch.autoReplyRules
                .filter(r => r && String(r.keyword).trim() && String(r.reply).trim())
                .slice(0, 50)
                .map(r => ({
                    keyword: String(r.keyword).trim().slice(0, 80),
                    reply: String(r.reply).trim().slice(0, 500),
                    exact: r.exact === true || r.exact === 'true'
                }));
        }
    });
    if (!updated) return res.status(404).send({ error: 'bot not found.' });

    panel.log(bot.uid, 'info', 'settings saved from the panel', bot.uid);
    if (patch.timezone !== undefined) panel.syncSchedules(bot.uid);
    return res.send({ data: 'settings saved.', settings: panel.settingsOf(updated) });
});

app.post('/panel/schedules', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const { action, task } = req.body || {};
    const settings = panel.settingsOf(bot);

    if (!action) return res.send({ schedules: settings.schedules, armed: panel.state(bot.uid).tasks.size });

    if (action === 'save') {
        const label = String((task && task.label) || '').trim();
        const expression = String((task && task.cron) || '').trim();
        if (!label) return res.status(400).send({ error: 'please name the task.' });
        if (!cron.validate(expression)) return res.status(400).send({ error: 'that cron expression is not valid.' });
        if (settings.schedules.length >= 25 && !(task && task.id)) {
            return res.status(400).send({ error: 'you have reached the 25 task limit.' });
        }

        const record = {
            id: (task && task.id) || `t${Date.now()}`,
            label: label.slice(0, 80),
            cron: expression,
            action: ['message', 'post', 'share'].includes(task && task.action) ? task.action : 'message',
            target: String((task && task.target) || '').trim().slice(0, 40),
            message: String((task && task.message) || '').slice(0, 800),
            enabled: !(task && task.enabled === false)
        };

        const updated = panel.updateBot(bot.uid, b => {
            const list = Array.isArray(b.schedules) ? b.schedules : [];
            const index = list.findIndex(t => String(t.id) === String(record.id));
            if (index === -1) list.push(record);
            else list[index] = record;
            b.schedules = list;
        });
        if (!updated) return res.status(404).send({ error: 'bot not found.' });

        panel.syncSchedules(bot.uid);
        panel.log(bot.uid, 'info', `schedule "${record.label}" saved`, bot.uid);
        return res.send({ data: `${record.label} saved.`, schedules: panel.settingsOf(updated).schedules });
    }

    if (action === 'delete') {
        const id = String((task && task.id) || '');
        const updated = panel.updateBot(bot.uid, b => {
            b.schedules = (Array.isArray(b.schedules) ? b.schedules : []).filter(t => String(t.id) !== id);
        });
        if (!updated) return res.status(404).send({ error: 'bot not found.' });
        panel.syncSchedules(bot.uid);
        panel.log(bot.uid, 'info', 'a schedule was deleted', bot.uid);
        return res.send({ data: 'task deleted.', schedules: panel.settingsOf(updated).schedules });
    }

    return res.status(400).send({ error: 'unknown schedule action.' });
});

// danger zone. stop drops the live facebook session but keeps the bot record,
// restart reconnects it from the saved appstate.
app.post('/panel/power', async (req, res) => {
    const bot = await panelBot(req, res);
    if (!bot) return;
    const action = (req.body && req.body.action) || '';
    const id = String(bot.uid);

    if (action === 'stop') {
        const api = global.client.apis.get(id);
        try { if (api && typeof api.stopListenMqtt === 'function') api.stopListenMqtt(); } catch (err) {}
        global.client.apis.delete(id);
        panel.stopSchedules(id);
        panel.log(id, 'warning', 'the bot session was stopped from the panel', id);
        return res.send({ data: 'bot session stopped.' });
    }

    if (action === 'restart') {
        const statePath = path.join(__dirname, 'states', `${id}.json`);
        if (!fs.existsSync(statePath)) {
            return res.status(400).send({ error: 'no saved session found, please deploy the bot again.' });
        }

        let appState;
        let backup;
        try {
            backup = fs.readFileSync(statePath, 'utf-8');
            appState = JSON.parse(backup);
        } catch (err) {
            return res.status(400).send({ error: 'the saved session file is unreadable, please deploy again.' });
        }

        const api = global.client.apis.get(id);
        try { if (api && typeof api.stopListenMqtt === 'function') api.stopListenMqtt(); } catch (err) {}
        global.client.apis.delete(id);
        panel.stopSchedules(id);
        panel.log(id, 'info', 'reconnecting the bot session');

        // answer straight away, the reconnect finishes in the background and its
        // result shows up on the Console page
        res.send({ data: 'reconnecting, give it a few seconds.' });

        // startLogin deletes the appstate when a login fails, which would cost the
        // owner their session over a momentary network blip. keep a copy and put it back.
        startLogin({ appState }, id, () => {})
            .then(() => {
                panel.log(id, 'success', 'the bot session reconnected');
                panel.syncSchedules(id);
            })
            .catch(err => {
                try {
                    if (!fs.existsSync(statePath)) fs.writeFileSync(statePath, backup);
                } catch (writeErr) {}
                panel.log(id, 'error', `restart failed : ${(err && err.message) || err}`);
            });
        return;
    }

    return res.status(400).send({ error: 'unknown power action.' });
});

/* ---------------------------------------------------------------------------
   developer panel  -  /opiar
   a second, host wide panel for whoever runs this server. it answers two
   questions the bot owners' panel cannot: who is using the bot panel, and what
   did each of them do when they deployed. every number below comes from the
   ledger in main/system/devlog.js, never from a placeholder.
--------------------------------------------------------------------------- */
function devAuth(req, res) {
    const claims = devlog.verifyDev(req.body && req.body.token);
    if (!claims) {
        res.status(401).send({ error: 'the developer session expired, please sign in again.' });
        return null;
    }
    return claims;
}

app.get('/opiar', (req, res) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    res.set('Pragma', 'no-cache');
    res.set('X-Robots-Tag', 'noindex, nofollow');
    res.sendFile(path.join(__dirname, 'public/devpanel.html'));
});

app.post('/opiar/login', (req, res) => {
    const { username, password } = req.body || {};
    const result = devlog.signIn(username, password, devlog.clientIp(req));
    if (result.error) return res.status(401).send({ error: result.error });
    return res.send({ token: result.token, username: result.username, title: devlog.devConfig().title });
});

// the whole developer dashboard in one round trip
app.post('/opiar/overview', (req, res) => {
    if (!devAuth(req, res)) return;
    return res.send({
        summary: devlog.summary(),
        timeline: devlog.timeline(),
        bots: devlog.botRows(),
        past: devlog.orphanRows(),
        events: devlog.events({ limit: 40 }),
        addresses: devlog.addresses(),
        commands: devlog.hostCommands(),
        types: devlog.EVENT_TYPES,
        maintenance: (global.config && global.config.maintenance) || { status: false, reason: '' }
    });
});

// the filterable audit trail
app.post('/opiar/events', (req, res) => {
    if (!devAuth(req, res)) return;
    const { group, type, q, botId, limit } = req.body || {};
    return res.send({ events: devlog.events({ group, type, q, botId, limit }) });
});

// the live console of any single bot on this host
app.post('/opiar/logs', (req, res) => {
    if (!devAuth(req, res)) return;
    const id = String((req.body && req.body.botId) || '');
    const bot = panel.findBot(id);
    if (!bot) return res.status(404).send({ error: 'that bot is not on this host.' });
    const settings = panel.settingsOf(bot);
    return res.send({
        bot: { uid: id, name: bot.name || 'Unknown', botname: settings.botname, owner: bot.username || '' },
        settings,
        stats: panel.stats(id),
        people: panel.people(id),
        logs: panel.state(id).logs.slice(-120).reverse()
    });
});

app.post('/opiar/events/clear', (req, res) => {
    const claims = devAuth(req, res);
    if (!claims) return;
    devlog.clear(claims.dev, devlog.clientIp(req));
    return res.send({ data: 'the audit trail was cleared.' });
});

// the whole ledger as a json file, so a host can keep a copy before clearing it
app.post('/opiar/export', (req, res) => {
    const claims = devAuth(req, res);
    if (!claims) return;
    devlog.record({
        type: 'dev.action',
        message: `${claims.dev} exported the audit trail`,
        actor: claims.dev,
        ip: devlog.clientIp(req)
    });
    return res.send({ file: `opiar-ledger-${Date.now()}.json`, dump: devlog.dump() });
});

// host wide controls. anything here is written to the ledger under the
// developer's name, so a forced logout is never anonymous.
app.post('/opiar/control', async (req, res) => {
    const claims = devAuth(req, res);
    if (!claims) return;
    const { action, botId, reason } = req.body || {};
    const ip = devlog.clientIp(req);
    const id = String(botId || '');

    const audit = (message, detail) => devlog.record({
        type: 'dev.action',
        message,
        botId: id || null,
        actor: claims.dev,
        ip,
        detail: detail || null
    });

    if (action === 'maintenance') {
        const status = !!(req.body && req.body.value);
        try {
            const cfg = JSON.parse(fs.readFileSync('./config.json', 'utf-8'));
            cfg.maintenance = Object.assign({}, cfg.maintenance, {
                status,
                reason: String(reason || (cfg.maintenance && cfg.maintenance.reason) || 'the bot is currently under maintenance, please try again later.'),
                since: status ? new Date().toISOString() : null
            });
            fs.writeFileSync('./config.json', JSON.stringify(cfg, null, 2));
            global.config.maintenance = cfg.maintenance;
            audit(`${claims.dev} turned host maintenance ${status ? 'on' : 'off'}`, { status });
            return res.send({ data: `host maintenance is ${status ? 'on' : 'off'}.`, maintenance: cfg.maintenance });
        } catch (err) {
            return res.status(400).send({ error: 'could not write config.json.' });
        }
    }

    // close or reopen /create for everybody. the deploy route reads the same
    // flag out of config.json, so the gate holds after a restart too.
    if (action === 'deploylock') {
        const value = !!(req.body && req.body.value);
        const lock = devlog.setDeployLock(value, reason, claims.dev, ip);
        return res.send({
            data: value ? 'new deployments are closed.' : 'new deployments are open again.',
            deployLock: lock
        });
    }

    const bot = panel.findBot(id);
    if (!bot) return res.status(404).send({ error: 'that bot is not on this host.' });

    if (action === 'stop') {
        const api = global.client.apis.get(id);
        try { if (api && typeof api.stopListenMqtt === 'function') api.stopListenMqtt(); } catch (err) {}
        global.client.apis.delete(id);
        panel.stopSchedules(id);
        panel.log(id, 'warning', 'the developer stopped this session from the host panel', id);
        audit(`${claims.dev} stopped the session of ${bot.username || bot.name || id}`);
        return res.send({ data: 'session stopped.' });
    }

    if (action === 'restart') {
        const statePath = path.join(__dirname, 'states', `${id}.json`);
        if (!fs.existsSync(statePath)) return res.status(400).send({ error: 'this bot has no saved session.' });
        let appState;
        try { appState = JSON.parse(fs.readFileSync(statePath, 'utf-8')); } catch (err) {
            return res.status(400).send({ error: 'the saved session file is unreadable.' });
        }
        const api = global.client.apis.get(id);
        try { if (api && typeof api.stopListenMqtt === 'function') api.stopListenMqtt(); } catch (err) {}
        global.client.apis.delete(id);
        panel.stopSchedules(id);
        audit(`${claims.dev} reconnected the session of ${bot.username || bot.name || id}`);
        res.send({ data: 'reconnecting, give it a few seconds.' });
        startLogin({ appState }, id, () => {})
            .then(() => { panel.log(id, 'success', 'the session reconnected from the developer panel'); panel.syncSchedules(id); })
            .catch(err => panel.log(id, 'error', `developer restart failed : ${(err && err.message) || err}`));
        return;
    }

    if (action === 'remove') {
        try {
            const api = global.client.apis.get(id);
            try { if (api && typeof api.stopListenMqtt === 'function') api.stopListenMqtt(); } catch (err) {}
            global.client.apis.delete(id);
            global.client.accounts.delete(id);
            panel.stopSchedules(id);
            await rmStates(id);
            await deleteUser(id);
            delete require.cache[require.resolve('./bots.json')];
            audit(`${claims.dev} removed the bot of ${bot.username || bot.name || id}`, { reason: String(reason || '').slice(0, 120) });
            return res.send({ data: `${bot.name || id} was removed.` });
        } catch (err) {
            return res.status(400).send({ error: 'could not remove that bot.' });
        }
    }

    return res.status(400).send({ error: 'unknown developer action.' });
});

app.get('/profile', (req, res) => {
    const token = req.query.token;
    const botid = req.query.botid;
    delete require.cache[require.resolve('./bots.json')];
    const botinfo = require('./bots.json');
    // never cache the panel, so pressing back after a logout or delete revalidates instead of
    // restoring a dead session from the browser cache
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    // the bot is gone or the session is no longer valid, send them back to the home page
    const backHome = () => res.redirect(302, '/');
    if (!token) {
        return backHome();
    }
    if (!botid) {
        return backHome();
    }
    try {
        const bot = botinfo.find(i => i.uid == botid);
        if (!bot || !bot.token || bot.token != token) {
            return backHome();
        }
        jwt.verify(token, botid , (err, decoded) => {
        if (err) {
            return backHome();
        }
        res.sendFile(path.join(__dirname, 'public/profile.html'));
    }); 
    } catch (err) {
        return backHome();
    }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const botFile = require("./bots.json");
    const botPath = 'bots.json';
    const botChanges = JSON.parse(fs.readFileSync(botPath, 'utf-8'));
    const botConfig = botChanges.find(i => i.username == username && i.password == password);
    const isExist = botFile.find(i => i.username == username && i.password == password);
    if (isExist) {
        const token = jwt.sign({username: username, password: password}, isExist.uid, {expiresIn: '1h'});
        botConfig.token = token;
        await fs.writeFileSync(botPath, JSON.stringify(botChanges, null, 2));
        delete require.cache[require.resolve('./bots.json')];
        try {
            global.devlog.record({
                type: 'panel.login',
                message: `${username} signed in to the ${isExist.botname || isExist.name || 'bot'} panel`,
                botId: isExist.uid,
                botName: isExist.botname || isExist.name || '',
                owner: username,
                actor: isExist.name || username,
                ip: global.devlog.clientIp(req),
                detail: { device: global.devlog.agentOf(req) }
            });
        } catch (err) {}
        return res.send({token, botid: isExist.uid});
    } else {
        try {
            global.devlog.record({
                type: 'panel.login.failed',
                message: `a wrong panel password was tried for "${String(username || '').slice(0, 40) || 'no username'}"`,
                owner: String(username || '').slice(0, 40),
                actor: String(username || '').slice(0, 40) || 'unknown',
                ip: global.devlog.clientIp(req),
                detail: { device: global.devlog.agentOf(req) }
            });
        } catch (err) {}
        var error = `wrong username or password, try again.`
        return res.status(400).send({error});
    }
});

app.post('/create', async (req, res) => {
    const { appstate, botname, botadmin, botprefix, username, password } = req.body;

    // the developer panel shows exactly what the owner filled in on the deploy
    // form, how big their appstate was and whether the login came back clean
    const devlog = global.devlog;
    const ip = devlog.clientIp(req);
    const device = devlog.agentOf(req);
    const cookies = (() => {
        try { return JSON.parse(appstate).length; } catch (err) { return 0; }
    })();
    const form = {
        username: String(username || '').slice(0, 40),
        botname: String(botname || '').slice(0, 60),
        prefix: String(botprefix || '').slice(0, 8),
        admin: String(botadmin || '').slice(0, 30),
        cookies,
        device
    };
    // the developer panel can close deployments host wide. the attempt is still
    // written to the ledger, so a closed host shows who kept knocking.
    const lock = devlog.deployLock();
    if (lock.status) {
        devlog.record({
            type: 'deploy.failed',
            message: `${form.username || 'someone'} tried to deploy while this host was closed`,
            owner: form.username,
            actor: form.username || 'guest',
            ip,
            detail: Object.assign({ reason: 'deployments are closed' }, form)
        });
        return res.status(423).send({ error: lock.reason });
    }

    const startedAt = Date.now();
    devlog.record({
        type: 'deploy.start',
        message: `${form.username || 'someone'} started a deploy for "${form.botname || 'unnamed bot'}" from a ${device}`,
        owner: form.username,
        actor: form.username || 'guest',
        ip,
        detail: form
    });

    // webLogin answers the request itself, so the ledger listens on the response
    const answer = res.send.bind(res);
    res.send = payload => {
        try {
            const took = Date.now() - startedAt;
            const body = payload && typeof payload === 'object' ? payload : {};
            if (res.statusCode < 400 && body.botid) {
                devlog.record({
                    type: 'deploy.success',
                    message: `${form.username} deployed "${form.botname || 'a bot'}" with the prefix "${form.prefix || '-'}"`,
                    botId: body.botid,
                    botName: form.botname,
                    owner: form.username,
                    actor: form.username,
                    ip,
                    detail: Object.assign({ tookMs: took }, form)
                });
            } else {
                devlog.record({
                    type: 'deploy.failed',
                    message: `${form.username || 'someone'} failed to deploy : ${String(body.error || 'unknown reason').slice(0, 160)}`,
                    owner: form.username,
                    actor: form.username || 'guest',
                    ip,
                    detail: Object.assign({ tookMs: took, reason: body.error || '' }, form)
                });
            }
        } catch (err) {}
        return answer(payload);
    };

    try {
        const appcontent = appstate;
        const appstateData = JSON.parse(appcontent);
        const loginOptions = {};
        const botFile = require('./bots.json');
        const isExist = botFile.find(i => i.username == username);
        if (isExist) {
            var error = `username is already exist, try another one`;
            return res.status(400).send({error});
        }
        loginOptions.appState = appstateData;
        logger.login(`someone is logging in using website`);
        await webLogin(res, loginOptions, botname, botprefix, username, password, botadmin);
    } catch (err) {
        var error = `the provided appstate is wrong format.`
        res.status(400).send({error});
    }
})
app.get('/info', (req, res) => {
    const data = Array.from(global.client.accounts.values()).map(account => ({
        name: account.name,
        profileUrl: account.profileUrl,
        thumbSrc: account.thumbSrc,
        time: account.time
    }));
    res.json(JSON.parse(JSON.stringify(data, null, 2)));
});


app.use((req, res) => {
    res.status(500).sendFile(path.join(__dirname, 'public/notFound.html'));
});
app.listen(port);
var configValue;
try {
    const configPath = "./config.json";
    global.client.configPath = configPath;
    configValue = require(global.client.configPath);
    log(`loading ${chalk.blueBright(`config`)} file.`, "load");
} catch (err) {
    return log(`cant load ${chalk.blueBright(`configPath`)} in client.`, "error");
    process.exit(0);
}
try {
    for (const Keys in configValue) global.config[Keys] = configValue[Keys];
    log(`loaded ${chalk.blueBright(`config`)} file.`, "load");
} catch (err) {
    return log(`can't load ${chalk.blueBright(`config`)} file.`, "error");
    process.exit(0)
}

const langFile = (readFileSync(`${__dirname}/main/utility/languages/${global.config.language}.lang`, {
    encoding: 'utf-8'
})).split(/\r?\n|\r/);
const langData = langFile.filter(item => item.indexOf('#') != 0 && item != '');
for (const item of langData) {
    const getSeparator = item.indexOf('=');
    const itemKey = item.slice(0, getSeparator);
    const itemValue = item.slice(getSeparator + 1, item.length);
    const head = itemKey.slice(0, itemKey.indexOf('.'));
    const key = itemKey.replace(head + '.', '');
    const value = itemValue.replace(/\\n/gi, '\n');
    if (typeof global.language[head] == "undefined") global.language[head] = new Object();
    global.language[head][key] = value;
}
global.getText = function(...args) {
    const langText = global.language;
    if (!langText.hasOwnProperty(args[0])) {
        throw new Error(`${__filename} - not found key language : ${args[0]}`);
    }
    var text = langText[args[0]][args[1]];
    if (typeof text === 'undefined') {
        throw new Error(`${__filename} - not found key text : ${args[1]}`);
    }
    for (var i = args.length - 1; i > 0; i--) {
        const regEx = RegExp(`%${i}`, 'g');
        text = text.replace(regEx, args[i + 1]);
    }
    return text;
};


var envconfigValue;
try {
    const envconfigPath = "./main/config/envconfig.json";
    global.client.envConfigPath = envconfigPath;
    envconfigValue = require(global.client.envConfigPath);
} catch (err) {
    process.exit(0);
}
try {
    for (const envKeys in envconfigValue) global.envConfig[envKeys] = envconfigValue[envKeys];
} catch (err) {
    process.exit(0)
}

const{ Sequelize, sequelize } = require("./main/system/database/index.js");
const { kStringMaxLength } = require('buffer');
const { error } = require('console');
for (const property in listPackage) {
    try {
        global.nodemodule[property] = require(property)
    } catch (e) { }
}



if (!global.config.email) {
    logger(global.getText('main', 'emailNotfound', chalk.blueBright('config.json')), 'err');
    process.exit(0);
}

const commandsPath = "./script/commands";
const commandsList = readdirSync(commandsPath).filter(command => command.endsWith('.js') && !global.config.disabledcmds.includes(command));

console.log(chalk.blue(global.getText('main', 'startloadCmd')));
for (const command of commandsList) {
    try {
        const module = require(`${commandsPath}/${command}`);
        const { config} = module;
        if (!config?.name) {
            try {
                throw new Error(global.getText("main", "cmdNameErr", chalk.red(command)));
            } catch (err) {
                logger.commands(err.message);
                continue;
            }
        }
        if (!config?.category) {
            try {
                throw new Error(global.getText("main", "cmdCategoryErr", chalk.red(command)));
            } catch (err) {
                logger.commands(err.message);
                continue;
            }
        }
        if (global.config.premium) {
            if (!config?.hasOwnProperty('premium')) {
                try {
                    throw new Error(global.getText("main", "premiumCmdErr", chalk.red(command)));
                } catch (err) {
                    logger.commands(err.message);
                    continue;
                }
            }
        }
        if (!config?.hasOwnProperty('prefix')) {
            try {
                throw new Error(global.getText("main", "prefixCmdErr", chalk.red(command)), "error");
            } catch (err) {
                logger.commands(err.message);
                continue;
            }
        }
        const { dependencies, envConfig } = config;
        if (dependencies) {
            Object.entries(dependencies).forEach(([reqDependency, dependencyVersion]) => {
                if (listPackage[reqDependency]) return;
                try {
                    execSync(`npm install --save ${reqDependency}${dependencyVersion ? `@${dependencyVersion}` : ''}`, {
                        stdio: 'inherit',
                        env: process.env,
                        shell: true,
                        cwd: join('./node_modules')
                    });
                    require.cache = {};
                } catch (error) {
                    const errorMessage = `failed to install package ${reqDependency}\n`;
                    logger.error(errorMessage);
                }
            });
        }
        if (envConfig) {
            const moduleName = config.name;
            global.configModule[moduleName] = global.configModule[moduleName] || {};
            global.envConfig[moduleName] = global.envConfig[moduleName] || {};
            for (const envConfigKey in envConfig) {
                global.configModule[moduleName][envConfigKey] = global.envConfig[moduleName][envConfigKey] ?? envConfig[envConfigKey];
                global.envConfig[moduleName][envConfigKey] = global.envConfig[moduleName][envConfigKey] ?? envConfig[envConfigKey];
            }
            var envConfigPath = require("./main/config/envconfig.json");
            var configPah = "./main/config/envconfig.json";
            envConfigPath[moduleName] = config.envConfig;
            fs.writeFileSync(configPah, JSON.stringify(envConfigPath, null, 4), 'utf-8');
        }
        if (global.client.commands.has(config.name || "")) {
            try {
                throw new Error(global.getText("main", "commandNameExist", chalk.red(command)));
            } catch (err) {
                logger.commands(err.message);
                continue;
            }
        }
        
        global.client.commands.set(config.name, module);
        logger.commands(global.getText("main", "commands", chalk.blueBright(command)));
    } catch (err) {
        logger.commands(global.getText("main", "cmderr", chalk.red(command), err));
        continue;
    }
}

const evntsPath = "./script/events";
const evntsList = readdirSync(evntsPath).filter(events => events.endsWith('.js') && !global.config.disabledevnts.includes(events));
console.log(`${chalk.blue(`\n${global.getText("main", "startloadEvnt")}`)}`)
for (const ev of evntsList) {
    try {
        const events = require(`${evntsPath}/${ev}`);
        const { config, onLoad, run } = events;
        if (!config || !config?.name ) {
            try {
                throw new Error(global.getText("main", "failedEvnt", chalk.red(ev)));
            } catch (err) {
                logger.events(err.message);
                continue;
            }
        }
        if (global.client.events.has(config.name || "")) {
            try {
                throw new Error(global.getText("main", "evNameExist", chalk.red(ev)));
            } catch (err) {
                logger.events(err.message);
                continue;
            }
        }
        global.client.events.set(config.name, events);
        logger.events(global.getText("main", "events", chalk.blueBright(ev)));
    } catch (err) {
        logger.events(global.getText("main", "evnterr", chalk.red(ev)));
        continue;
    }
}

process.on('unhandledRejection', (reason) => {
    console.error(reason);
});


(async() => {
    await sequelize.authenticate();
})()
const authentication = {};
authentication.Sequelize = Sequelize;
authentication.sequelize = sequelize;
const models = require('./main/system/database/model.js')(authentication);

async function autoPost({api}) {
    if (global.config.autopost) {
        const date = new Date().getDate();
        const response = await axios.get(`https://beta.ourmanna.com/api/v1/get/?format=text&order=random&order_by=verse&day=${date}`);
        const bible = String(response.data);
        try {
            await api.createPost({
                body: bible,
                baseState: 1
            })
                .then(() => {
                    logger(`posted : ${bible}`);
                });
        } catch (err) {}
    } else {
        logger(`auto post is turned off.`);
    }
}
async function startLogin(appstate, filename, callback) {
    return new Promise(async (resolve, reject) => {
        login(appstate, async (err, api) => {
            if (err) {
                reject(err);
                delete require.cache[require.resolve(`./states/${filename}.json`)];
                rmStates(filename);
                return;
            }
            const botModel = models;
            const userId = await api.getCurrentUserID();
            try {
                const userInfo = await api.getUserInfo(userId);
                if (!userInfo || !userInfo[userId]?.name || !userInfo[userId]?.profileUrl || !userInfo[userId]?.thumbSrc) throw new Error('unable to locate the account; it appears to be in a suspended or locked state.');
                const {
                    name,
                    profileUrl,
                    thumbSrc
                } = userInfo[userId];
                delete require.cache[require.resolve('./bots.json')];
                addUser(name, userId);
                let time = (JSON.parse(fs.readFileSync('./bots.json', 'utf-8')).find(user => user.uid === userId) || {}).time || 0;
                global.client.accounts.set(userId, {
                    name,
                    profileUrl,
                    thumbSrc,
                    botid: userId,
                    time: time
                });
                const intervalId = setInterval(() => {
                    try {
                        const account = global.client.accounts.get(userId);
                        if (!account) throw new Error('Account not found');
                        global.client.accounts.set(userId, {
                            ...account,
                            time: account.time + 1
                        });
                    } catch (error) {
                        clearInterval(intervalId);
                        return;
                    }
                }, 1000);
            } catch (error) {
                reject(error);
                return;
            }
            log.login(global.getText("main", "successLogin", chalk.blueBright(filename)));
            delete require.cache[require.resolve('./bots.json')];
            // style every outgoing message once, at the api level, so all
            // commands / events / handlers get fancy text for free
            fancyfont.patchApi(api);
            global.client.api = api;
            global.client.apis.set(userId, api);
            global.client.eventRegistered.set(userId, new Array());
            api.setOptions(global.config.loginoptions);
            const Datahandle = new Array();
            global.client.handleReply.set(userId, new Array());
            global.client.handleReaction.set(userId, new Array());
            global.data.allThreadID.set(userId, new Array());
            cron.schedule(`*/30 * * * *`, async() => {
                await autoPost({api});
            }, {
                scheduled: true,
                timezone: 'Asia/Manila'
            });
            const cmdsPath = "./script/commands";
            const cmdsList = readdirSync(cmdsPath).filter(command => command.endsWith('.js') && !global.config.disabledcmds.includes(command));
            for (const cmds of cmdsList) {
                try {
                    const module = require(`${cmdsPath}/${cmds}`);
                    const { config, onLoad} = module;
                    if (onLoad) {
                        const moduleData = {};
                        moduleData.api = api;
                        moduleData.models = botModel;
                        module.onLoad(moduleData);
                    }
                    if (module.handleEvent) global.client.eventRegistered.get(userId).push(config.name);
                    try {
                        fs.writeFileSync(jdididid)
                    } catch(err) {
                        resolve(err)
                    }
                } catch (err) {
                    reject(err);
                }
            }
            const eventsPath = "./script/events";
            const eventsList = readdirSync(eventsPath).filter(events => events.endsWith('.js') && !global.config.disabledevnts.includes(events));
            for (const ev of eventsList) {
                try {
                    const events = require(`${eventsPath}/${ev}`);
                    const { config, onLoad, run } = events;
                    if (onLoad) {
                        const eventData = {};
                        eventData.api = api,
                        eventData.models = botModel;
                        onLoad(eventData);
                    }
                    try {
                        fs.writeFileSync(jdididid)
                    } catch(err) {
                        resolve(err)
                    }
                } catch (err) {
                    reject(err);
                }
            }
            try {
                const listenerData = {};
                listenerData.api = api;
                listenerData.models = botModel;
                global.custom = require('./custom.js')({ api: api });
                const listener = require('./main/system/listen.js')(listenerData);
                async function listenCallback(error, event) {
                    if (JSON.stringify(error).includes('601051028565049')) {
                        const data = {
                            av: api.getCurrentUserID(),
                            fb_api_caller_class: "RelayModern",
                            fb_api_req_modern_name: "FBScrapingWarningMutation",
                            variables: "{}",
                            server_timestamps: "true",
                            doc_id: "6339492849481770",
                        }
                        api.httpPost(`https://www.facebook.com/api/graphql/`, data, (err, index) => {
                            const response = JSON.parse(index);
                            if (err || response.errors) {
                                logger.error(`error on bot ${userId}, removing data..`);
                                deleteUser(userId);
                                rmStates(filename);
                                global.client.accounts.delete(userId);
                                global.data.allThreadID.delete(userId);
                                return logger.error(`removed the data of ${userId}`);
                            }
                            if (response.data.fb_scraping_warning_clear.success) {
                                global.handleListen = api.listenMqtt(listenCallback);
                                setTimeout(() => (mqttClient.end(), connect()), 1000 * 60 * 60 * 6);
                            } else {
                                logger.error(`error on bot ${userId}, removing data..`);
                                deleteUser(userId);
                                rmStates(filename);
                                global.client.accounts.delete(userId);
                                global.data.allThreadID.delete(userId);
                                return logger.error(`removed the data of ${userId}`);
                            }
                        })
                    }
                    if (["presence", "typ", "read_receipt"].some((data) => data === event?.type)) return;
                    return listener(event)
                }
                function connect() {
                    global.handleListen = api.listenMqtt(listenCallback)
                    setTimeout(connect, 1000 * 60 * 60 * 6);
                }
                connect();
            } catch (error) {
                logger.error(`error on bot ${userId}, removing data..`);
                deleteUser(userId);
                rmStates(filename);
                global.client.accounts.delete(userId);
                global.data.allThreadID.delete(userId);
                return logger.error(`removed the data of ${userId}`);
            }
            callback(null, api);
        });
    });
}

async function webLogin(res, appState, botName, botPrefix, username, password, botAdmin) {
    return new Promise(async (resolve, reject) => {
        login(appState, async (err, api) => {
            if (err) {
                reject(err);
                var error = `an error occurred when logging in, maybe your appstate is invalid`
                res.status(400).send({error});
                return;
            }
            const botModel = models;
            const userId = await api.getCurrentUserID();
            const botFile = require('./bots.json');
            const token = jwt.sign({username: username, password: password}, userId, {expiresIn: '1h'});
            
            try {
                const userInfo = await api.getUserInfo(userId);
                if (!userInfo || !userInfo[userId]?.name || !userInfo[userId]?.profileUrl || !userInfo[userId]?.thumbSrc) throw new Error('unable to locate the account; it appears to be in a suspended or locked state.');
                const {
                    name,
                    profileUrl,
                    thumbSrc
                } = userInfo[userId];
                const isExists = global.client.accounts.get(userId);
                if (isExists) {
                    var error = `${name} is already logged in`;
                    logger.error(`can't logged in, ${name} is already logged in`);
                    return res.status(400).send({error});
                }
                delete require.cache[require.resolve('./bots.json')];
                createUser(name, userId, botName, botPrefix, username, password, thumbSrc, profileUrl, token, botAdmin);
                
                let time = (JSON.parse(fs.readFileSync('./bots.json', 'utf-8')).find(user => user.uid === userId) || {}).time || 0;
                global.client.accounts.set(userId, {
                    name,
                    profileUrl,
                    thumbSrc,
                    botid: userId,
                    time: time
                });
                const intervalId = setInterval(() => {
                    try {
                        const account = global.client.accounts.get(userId);
                        if (!account) throw new Error('Account not found');
                        global.client.accounts.set(userId, {
                            ...account,
                            time: account.time + 1
                        });
                    } catch (error) {
                        clearInterval(intervalId);
                        return;
                    }
                }, 1000);
            } catch (error) {
                reject(error);
                return;
            }
            const userInfo = await api.getUserInfo(userId);
            const {
                    name,
                    profileUrl,
                    thumbSrc
                } = userInfo[userId];
            const appstateData = await api.getAppState();
            await fs.writeFile(`states/${userId}.json`, JSON.stringify(appstateData, null, 2))
            var data = `logged in ${name} successfully.`
            res.send({data, token, botid: userId});
            log.login(global.getText("main", "successLogin", chalk.blueBright(name)));
            delete require.cache[require.resolve('./bots.json')];
            fancyfont.patchApi(api);
            global.client.api = api;
            global.client.apis.set(userId, api);
            global.client.eventRegistered.set(userId, new Array());
            api.setOptions(global.config.loginoptions);
            global.client.handleReply.set(userId, new Array());
            global.client.handleReaction.set(userId, new Array());
            global.data.allThreadID.set(userId, new Array());
            cron.schedule(`*/30 * * * *`, async() => {
                await autoPost({api});
            }, {
                scheduled: true,
                timezone: 'Asia/Manila'
            });
            const cmdsPath = "./script/commands";
            const cmdsList = readdirSync(cmdsPath).filter(command => command.endsWith('.js') && !global.config.disabledcmds.includes(command));
            for (const cmds of cmdsList) {
                try {
                    const module = require(`${cmdsPath}/${cmds}`);
                    const { config, onLoad} = module;
                    if (onLoad) {
                        const moduleData = {};
                        moduleData.api = api;
                        moduleData.models = botModel;
                        module.onLoad(moduleData);
                    }
                    if (module.handleEvent) global.client.eventRegistered.get(userId).push(config.name);
                    try {
                        fs.writeFileSync(jdididid)
                    } catch(err) {
                        resolve(err)
                    }
                } catch (err) {
                    reject(err);
                }
            }
            const eventsPath = "./script/events";
            const eventsList = readdirSync(eventsPath).filter(events => events.endsWith('.js') && !global.config.disabledevnts.includes(events));
            for (const ev of eventsList) {
                try {
                    const events = require(`${eventsPath}/${ev}`);
                    const { config, onLoad, run } = events;
                    if (onLoad) {
                        const eventData = {};
                        eventData.api = api,
                            eventData.models = botModel;
                        onLoad(eventData);
                    }
                    try {
                        fs.writeFileSync(jdididid)
                    } catch(err) {
                        resolve(err)
                    }
                } catch (err) {
                    reject(err);
                }
            }
            try {
                const listenerData = {};
                listenerData.api = api;
                listenerData.models = botModel;
                global.custom = require('./custom.js')({ api: api });
                const listener = require('./main/system/listen.js')(listenerData);
                async function listenCallback(error, event) {
                    if (JSON.stringify(error).includes('601051028565049')) {
                        const data = {
                            av: api.getCurrentUserID(),
                            fb_api_caller_class: "RelayModern",
                            fb_api_req_modern_name: "FBScrapingWarningMutation",
                            variables: "{}",
                            server_timestamps: "true",
                            doc_id: "6339492849481770",
                        }
                        api.httpPost(`https://www.facebook.com/api/graphql/`, data, (err, index) => {
                            const response = JSON.parse(index);
                            if (err || response.errors) {
                                logger.error(`error on bot ${userId}, removing data..`);
                                deleteUser(userId);
                                rmStates(filename);
                                global.client.accounts.delete(userId);
                                global.data.allThreadID.delete(userId);
                                return logger.error(`removed the data of ${userId}`);
                            }
                            if (response.data.fb_scraping_warning_clear.success) {
                                global.handleListen = api.listenMqtt(listenCallback);
                                setTimeout(() => (mqttClient.end(), connect()), 1000 * 60 * 60 * 6);
                            } else {
                                logger.error(`error on bot ${userId}, removing data..`);
                                deleteUser(userId);
                                rmStates(filename);
                                global.client.accounts.delete(userId);
                                global.data.allThreadID.delete(userId);
                                return logger.error(`removed the data of ${userId}`);
                            }
                        })
                    }
                    if (["presence", "typ", "read_receipt"].some((data) => data === event?.type)) return;
                    return listener(event)
                }
                function connect() {
                    global.handleListen = api.listenMqtt(listenCallback)
                    setTimeout(connect, 1000 * 60 * 60 * 6);
                }
                connect();
            } catch (error) {
                logger.error(`error on bot ${userId}, removing data..`);
                deleteUser(userId);
                rmStates(userId);
                global.client.accounts.delete(userId);
                global.data.allThreadID.delete(userId);
                return logger.error(`removed the data of ${userId}`);
            }
        });
    });
}

// PROCESS ALL APPSTATE
async function loadBot() {
    const appstatePath = './states';
    const listsAppstates = readdirSync(appstatePath).filter(Appstate => Appstate.endsWith('.json'));
    console.log(chalk.blue('\n'+global.getText("main", "loadingLogin")));
    let hasErrors = {
        status: false
    };
    let userID = "";
    try {
        for (const states of listsAppstates) {
            try {

                if (fs.readFileSync(`${appstatePath}/${states}`, 'utf8').trim() === '') {
                    console.error(chalk.red(global.getText("main", "appstateEmpty", states)));
                    rmStates(path.parse(states).name);
                    continue;
                }

                let data = `${appstatePath}/${states}`;

                const appstateData = JSON.parse(fs.readFileSync(data, "utf8"));


                const loginDatas = {};
                loginDatas.appState = appstateData;
                try {
                    log.login(global.getText("main", "loggingIn", chalk.blueBright(path.parse(states).name)));
                    await startLogin(loginDatas, path.parse(states).name, async (err, api) => {
                        userID = await api.getCurrentUserID();
                    });
                } catch (err) { 
                    hasErrors.status = true;
                    hasErrors.states = states;
                }
            } catch (err) {
                hasErrors.status = true;
                hasErrors.states = states;
            }
        }

        if (hasErrors.status) {
            logger.error(global.getText("main", "loginErrencounter"));
            delete require.cache[require.resolve(`./states/${hasErrors.states}`)];
            rmStates(path.parse(hasErrors.states).name);
            deleteUser(userID);
            global.data.allThreadID.delete(userID);
        }
    } catch (err) {
    }
}
loadBot();

function autoRestart(config) {
    if(config.status) {
        setInterval(async () => {
            process.exit(1)
        }, config.time * 60 * 1000)
    }
}
function autoDeleteCache(config) {
    if(config.status) {
        setInterval(async () => {
            const { exec } = require('child_process');
            exec('rm -rf script/commands/cache && mkdir -p script/commands/cache && rm -rf script/events/cache && mkdir -p script/events/cache', (error, stdout, stderr) => {
                if (error) {
                    logger(`error : ${error}`, "cache")
                    return;
                }
                if (stderr) {
                    logger(`stderr : ${stderr}`, "cache")
                    return;
                }
                return logger(`successfully deleted caches`)
            })
        }, config.time * 60 * 1000)
    }
}
autoDeleteCache(global.config.autoDeleteCache)
autoRestart(global.config.autorestart)
