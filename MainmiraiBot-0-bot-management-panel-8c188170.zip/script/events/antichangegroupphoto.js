const fs = require("fs-extra");

module.exports.config = {
  name: "antichangegroupphoto",
  eventType: ["log:thread-image"],
  version: "1.0.0",
  credits: "mainmirai",
  description: "revert the group photo when antichangegroupphoto is enabled",
  dependencies: {}
};

module.exports.run = async function ({ api, event, Threads, Users }) {
  try {
    const { threadID } = event;
    const botID = String(await api.getCurrentUserID());
    const author = String(event.author || "");

    // ignore our own revert so we don't loop
    if (author === botID) return;

    let data = global.data.threadData.get(String(threadID));
    if (!data) {
      const record = await Threads.getData(threadID);
      data = (record && record.data) || {};
      global.data.threadData.set(String(threadID), data);
    }

    const setting = data.antichangegroupphoto || {};
    if (!setting.enabled || !setting.file) return;
    if (!(await fs.pathExists(setting.file))) return;

    try {
      await api.changeGroupImage(fs.createReadStream(setting.file), threadID);
    } catch (e) {
      return api.sendMessage(
        "someone changed the group photo but i can't change it back, make me an admin first",
        threadID
      );
    }

    let name = global.data.userName.get(author);
    if (!name) {
      try { name = await Users.getNameUser(author); } catch (e) {}
    }

    return api.sendMessage(
      `${name || "someone"} tried to change the group photo, i put the old one back`,
      threadID
    );
  } catch (error) {
    return console.log("[antichangegroupphoto]", error.message || error);
  }
};
