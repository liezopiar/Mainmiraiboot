module.exports.config = {
  name: "antichangegroupname",
  eventType: ["log:thread-name"],
  version: "1.0.1",
  credits: "mainmirai",
  description: "revert the group name when antichangegroupname is enabled",
  dependencies: {}
};

module.exports.run = async function ({ api, event, Threads, Users }) {
  try {
    const { threadID } = event;
    const botID = String(await api.getCurrentUserID());
    const author = String(event.author || "");

    // ignore our own revert so we don't loop
    if (author === botID) return;

    let data = global.data.threadData.get(String(threadID));
    if (!data) {
      const record = await Threads.getData(threadID);
      data = (record && record.data) || {};
      global.data.threadData.set(String(threadID), data);
    }

    const setting = data.antichangegroupname || {};
    if (!setting.enabled || !setting.name) return;

    const newName = event.logMessageData?.name || "";
    if (newName === setting.name) return;

    try {
      await api.setTitle(setting.name, threadID);
    } catch (e) {
      return api.sendMessage(
        "someone changed the group name but i can't change it back, make me an admin first",
        threadID
      );
    }

    let name = global.data.userName.get(author);
    if (!name) {
      try { name = await Users.getNameUser(author); } catch (e) {}
    }

    return api.sendMessage(
      `${name || "someone"} tried to change the group name, i put it back to "${setting.name}"`,
      threadID
    );
  } catch (error) {
    return console.log("[antichangegroupname]", error.message || error);
  }
};
