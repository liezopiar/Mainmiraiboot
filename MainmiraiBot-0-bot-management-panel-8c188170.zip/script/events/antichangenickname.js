module.exports.config = {
  name: "antichangenickname",
  eventType: ["log:user-nickname"],
  version: "1.0.0",
  credits: "mainmirai",
  description: "revert member nicknames when antichangenickname is enabled",
  dependencies: {}
};

module.exports.run = async function ({ api, event, Threads, Users }) {
  try {
    const { threadID } = event;
    const botID = String(await api.getCurrentUserID());
    const author = String(event.author || "");

    // ignore our own revert so we don't loop
    if (author === botID) return;

    let data = global.data.threadData.get(String(threadID));
    if (!data) {
      const record = await Threads.getData(threadID);
      data = (record && record.data) || {};
      global.data.threadData.set(String(threadID), data);
    }

    const setting = data.antichangenickname || {};
    if (!setting.enabled || !setting.nicknames) return;

    const targetID = String(event.logMessageData?.participant_id || "");
    if (!targetID) return;

    const newNickname = event.logMessageData?.nickname || "";
    const locked = setting.nicknames[targetID];

    // someone who joined after the lock was set, remember their nickname instead of reverting
    if (locked === undefined) {
      setting.nicknames[targetID] = newNickname;
      data.antichangenickname = setting;
      global.data.threadData.set(String(threadID), data);
      await Threads.setData(threadID, { data });
      return;
    }

    if (newNickname === locked) return;

    try {
      await api.changeNickname(locked, threadID, targetID);
    } catch (e) {
      return api.sendMessage(
        "someone changed a nickname but i can't change it back, make me an admin first",
        threadID
      );
    }

    let name = global.data.userName.get(author);
    if (!name) {
      try { name = await Users.getNameUser(author); } catch (e) {}
    }

    let targetName = global.data.userName.get(targetID);
    if (!targetName) {
      try { targetName = await Users.getNameUser(targetID); } catch (e) {}
    }

    return api.sendMessage(
      `${name || "someone"} tried to change ${targetName || "a member"}'s nickname, i put it back to ` +
        (locked ? `"${locked}"` : "empty"),
      threadID
    );
  } catch (error) {
    return console.log("[antichangenickname]", error.message || error);
  }
};
