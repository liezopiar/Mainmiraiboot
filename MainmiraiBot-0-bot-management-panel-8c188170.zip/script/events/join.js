module.exports.config = {
	name: "join",
	eventType: ["log:subscribe"],
	version: "1.0.2",
	credits: "ryuko",
	description: "join and welcome notification",
	dependencies: {
		"fs-extra": ""
	}
};

module.exports.run = async function({ api, event, Threads, botname, prefix }) {
	try {
		const { threadID } = event;
		const botID = String(await api.getCurrentUserID());
		const added = event.logMessageData?.addedParticipants || [];
		if (!added.length) return;

		// getData returns false when the thread is not in the database yet
		let threadDB = {};
		try {
			const record = await Threads.getData(threadID);
			threadDB = (record && record.data) || global.data.threadData.get(String(threadID)) || {};
		} catch (e) {
			threadDB = global.data.threadData.get(String(threadID)) || {};
		}
		if (Array.isArray(threadDB.banOut) && threadDB.banOut.includes("join")) return;

		// bot itself was added to the group
		if (added.some(i => String(i.userFbId) === botID)) {
			try { await api.changeNickname(`${botname} ai`, threadID, botID); } catch (e) {}
			return api.sendMessage(`bot connected successfully\n\nabout me?\nbot name : ${botname}\nbot prefix : ${prefix}\n\nbot data?\nusers : ${global.data.allUserID.length}\ngroups : ${global.data.allThreadID.get(botID)?.length ?? 0}\n\nhow to use?\n${prefix}help (command list)\nai (question) - no prefix\ntalk (text) - no prefix\n\nryuko botpack v5`, threadID);
		}

		// new members were added by someone
		const newMembers = added.filter(i => String(i.userFbId) !== botID);
		if (!newMembers.length) return;

		// the Auto Greet switch in the web control panel silences the welcome message.
		// the bot's own "connected" notice above is deliberately never suppressed.
		let panelGreeting = null;
		if (global.panel) {
			const settings = global.panel.settingsOf(global.panel.findBot(botID));
			if (settings) {
				if (settings.features.autoGreet === false) return;
				panelGreeting = settings.greetJoin || null;
			}
		}

		let threadName = "this group";
		let memberCount = 0;
		try {
			const info = await api.getThreadInfo(threadID);
			threadName = info.threadName || threadName;
			memberCount = (info.participantIDs || []).length;
		} catch (e) {}

		let body = "";
		const mentions = [];
		const names = [];

		for (const member of newMembers) {
			const name = member.fullName || "facebook user";
			names.push(name);
			mentions.push({ tag: name, id: String(member.userFbId) });
		}

		const template = (typeof threadDB.customJoin === "undefined")
			? "welcome {name} to {threadName}!\n\nyou are member #{memberCount} here. enjoy your stay and type {prefix}help to see what i can do."
			: threadDB.customJoin;

		body = template
			.replace(/\{name}/g, names.join(", "))
			.replace(/\{type}/g, newMembers.length > 1 ? "friends" : "you")
			.replace(/\{memberCount}/g, memberCount)
			.replace(/\{soThanhVien}/g, memberCount)
			.replace(/\{threadName}/g, threadName)
			.replace(/\{prefix}/g, prefix);

		// build proper mention offsets by using the tags present in the body
		const validMentions = mentions.filter(m => body.includes(m.tag));

		return api.sendMessage({ body, mentions: validMentions }, threadID);
	} catch (error) {
		return console.log(error);
	}
}
