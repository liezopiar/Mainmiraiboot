module.exports.config = {
	name: "leave",
	eventType: ["log:unsubscribe"],
	version: "1.0.1",
	credits: "ryuko",
	description: "notify when a member leaves or gets kicked",
};

module.exports.run = async function({ api, event, Users, Threads }) {
	try {
		const { threadID } = event;
		const botID = String(await api.getCurrentUserID());
		const leftID = String(event.logMessageData?.leftParticipantFbId || "");
		if (!leftID || leftID === botID) return;

		// getData returns false when the thread is not in the database yet
		let threadDB = {};
		try {
			const record = await Threads.getData(threadID);
			threadDB = (record && record.data) || global.data.threadData.get(String(threadID)) || {};
		} catch (e) {
			threadDB = global.data.threadData.get(String(threadID)) || {};
		}
		if (Array.isArray(threadDB.banOut) && threadDB.banOut.includes("leave")) return;

		let name = global.data.userName.get(leftID);
		if (!name) {
			try { name = await Users.getNameUser(leftID); } catch (e) {}
		}
		if (!name) name = "facebook user";
		const selfLeft = String(event.author) === leftID;

		let threadName = "this group";
		let memberCount = 0;
		try {
			const info = await api.getThreadInfo(threadID);
			threadName = info.threadName || threadName;
			memberCount = info.participantIDs.length;
		} catch (e) {}

		let template;
		if (selfLeft) {
			template = (typeof threadDB.customLeave === "undefined")
				? "goodbye {name}, thanks for the memories in {threadName}. take care out there!\n\nmembers left : {memberCount}"
				: threadDB.customLeave;
		} else {
			template = (typeof threadDB.customKick === "undefined")
				? "{name} has been removed from {threadName} by an admin.\n\nmembers left : {memberCount}"
				: threadDB.customKick;
		}

		const body = template
			.replace(/\{name}/g, name)
			.replace(/\{type}/g, selfLeft ? "left the group" : "was kicked")
			.replace(/\{threadName}/g, threadName)
			.replace(/\{memberCount}/g, memberCount);

		return api.sendMessage({ body }, threadID);
	} catch (error) {
		return console.log(error);
	}
}
