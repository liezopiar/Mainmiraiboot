/**
 * bannerMaker.js
 * Shared helper used by the "banner" and "aibanner" commands.
 * Draws Facebook-ready cover banners with Jimp (no native deps needed).
 */

const Jimp = require("jimp");
const fs = require("fs");
const path = require("path");

// Facebook recommended hi-res canvas sizes
const SIZES = {
  cover:   { width: 1640, height: 624,  label: "Facebook profile cover" },
  page:    { width: 1640, height: 856,  label: "Facebook page cover" },
  group:   { width: 1640, height: 856,  label: "Facebook group cover" },
  event:   { width: 1920, height: 1005, label: "Facebook event cover" },
  square:  { width: 1080, height: 1080, label: "Square post" },
  story:   { width: 1080, height: 1920, label: "Story / reels" }
};

// from -> to = background gradient, accent = underline bar, dark = use white text
const THEMES = {
  midnight:  { from: "#050816", to: "#1b2a6b", accent: "#4cc9f0", dark: true },
  sunset:    { from: "#3d1043", to: "#f2653a", accent: "#ffd166", dark: true },
  forest:    { from: "#04150f", to: "#1c6b4a", accent: "#a7f3d0", dark: true },
  neon:      { from: "#0a0014", to: "#6d28d9", accent: "#f0abfc", dark: true },
  ocean:     { from: "#021c33", to: "#0e7490", accent: "#7dd3fc", dark: true },
  mono:      { from: "#0d0d0d", to: "#3f3f3f", accent: "#fafafa", dark: true },
  cherry:    { from: "#2b0212", to: "#be123c", accent: "#fecdd3", dark: true },
  gold:      { from: "#161003", to: "#a16207", accent: "#fde68a", dark: true },
  paper:     { from: "#f7f3ea", to: "#ded6c3", accent: "#1c1917", dark: false },
  mint:      { from: "#eafaf3", to: "#a5e4c9", accent: "#064e3b", dark: false }
};

const CACHE_DIR = path.join(__dirname, "..", "commands", "cache");

function hexToRgb(hex) {
  const clean = hex.replace("#", "");
  return {
    r: parseInt(clean.slice(0, 2), 16),
    g: parseInt(clean.slice(2, 4), 16),
    b: parseInt(clean.slice(4, 6), 16)
  };
}

/** Diagonal two-colour gradient background. */
async function gradient(width, height, from, to) {
  const a = hexToRgb(from);
  const b = hexToRgb(to);
  const image = new Jimp(width, height, 0x000000ff);

  image.scan(0, 0, width, height, function (x, y, idx) {
    const t = (x / width) * 0.65 + (y / height) * 0.35;
    this.bitmap.data[idx + 0] = Math.round(a.r + (b.r - a.r) * t);
    this.bitmap.data[idx + 1] = Math.round(a.g + (b.g - a.g) * t);
    this.bitmap.data[idx + 2] = Math.round(a.b + (b.b - a.b) * t);
    this.bitmap.data[idx + 3] = 255;
  });

  return image;
}

/** Soft dark edges so the text always stays readable. */
function vignette(image, strength = 0.45) {
  const { width, height } = image.bitmap;
  const cx = width / 2;
  const cy = height / 2;
  const max = Math.sqrt(cx * cx + cy * cy);

  image.scan(0, 0, width, height, function (x, y, idx) {
    const d = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / max;
    const f = 1 - Math.pow(d, 2.2) * strength;
    this.bitmap.data[idx + 0] *= f;
    this.bitmap.data[idx + 1] *= f;
    this.bitmap.data[idx + 2] *= f;
  });

  return image;
}

function bar(image, x, y, w, h, hex, alpha = 1) {
  const c = hexToRgb(hex);
  const { width, height } = image.bitmap;
  const x2 = Math.min(width, x + w);
  const y2 = Math.min(height, y + h);
  if (x >= x2 || y >= y2) return image;

  image.scan(Math.max(0, x), Math.max(0, y), x2 - Math.max(0, x), y2 - Math.max(0, y), function (px, py, idx) {
    this.bitmap.data[idx + 0] = Math.round(this.bitmap.data[idx + 0] * (1 - alpha) + c.r * alpha);
    this.bitmap.data[idx + 1] = Math.round(this.bitmap.data[idx + 1] * (1 - alpha) + c.g * alpha);
    this.bitmap.data[idx + 2] = Math.round(this.bitmap.data[idx + 2] * (1 - alpha) + c.b * alpha);
  });

  return image;
}

/** Pick the biggest bitmap font that still fits the given width. */
async function fitFont(text, maxWidth, dark, candidates) {
  const suffix = dark ? "WHITE" : "BLACK";
  for (const size of candidates) {
    const font = await Jimp.loadFont(Jimp[`FONT_SANS_${size}_${suffix}`]);
    if (Jimp.measureText(font, text) <= maxWidth) return { font, size };
  }
  const size = candidates[candidates.length - 1];
  return { font: await Jimp.loadFont(Jimp[`FONT_SANS_${size}_${suffix}`]), size };
}

async function printCentered(image, text, y, maxWidth, dark, candidates) {
  const { font, size } = await fitFont(text, maxWidth, dark, candidates);
  const x = Math.round((image.bitmap.width - maxWidth) / 2);
  const shadowFont = await Jimp.loadFont(Jimp[`FONT_SANS_${size}_${dark ? "BLACK" : "WHITE"}`]);
  const offset = Math.max(2, Math.round(size / 24));

  const opts = { text, alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER, alignmentY: Jimp.VERTICAL_ALIGN_TOP };
  image.print(shadowFont, x + offset, y + offset, opts, maxWidth);
  image.print(font, x, y, opts, maxWidth);

  const lines = Math.max(1, Math.ceil(Jimp.measureText(font, text) / maxWidth));
  return y + Jimp.measureTextHeight(font, text, maxWidth) + (lines > 1 ? 0 : 0);
}

/**
 * Build a banner and return the saved file path.
 * @param {object} opts
 * @param {string} opts.title
 * @param {string} [opts.subtitle]
 * @param {string} [opts.footer]     small text at the bottom
 * @param {string} [opts.theme]      key of THEMES
 * @param {string} [opts.size]       key of SIZES
 * @param {string} [opts.background] image URL used instead of the gradient
 */
async function createBanner(opts = {}) {
  const size = SIZES[opts.size] || SIZES.cover;
  const theme = THEMES[opts.theme] || THEMES.midnight;
  const title = (opts.title || "Your Title").trim();
  const subtitle = (opts.subtitle || "").trim();
  const footer = (opts.footer || "").trim();

  let image;
  if (opts.background) {
    image = await Jimp.read(opts.background);
    image.cover(size.width, size.height);
    image.brightness(-0.42).blur(2);
  } else {
    image = await gradient(size.width, size.height, theme.from, theme.to);
  }

  vignette(image, opts.background ? 0.35 : 0.5);

  const dark = opts.background ? true : theme.dark;
  const maxWidth = Math.round(size.width * 0.82);

  // vertical rhythm: title block sits slightly above the middle
  const titleTop = Math.round(size.height * (subtitle ? 0.3 : 0.38));
  const afterTitle = await printCentered(
    image,
    title,
    titleTop,
    maxWidth,
    dark,
    [128, 64, 32, 16]
  );

  // accent underline
  const barWidth = Math.round(size.width * 0.14);
  bar(
    image,
    Math.round((size.width - barWidth) / 2),
    afterTitle + Math.round(size.height * 0.03),
    barWidth,
    Math.max(4, Math.round(size.height * 0.012)),
    theme.accent,
    0.95
  );

  if (subtitle) {
    await printCentered(
      image,
      subtitle,
      afterTitle + Math.round(size.height * 0.08),
      maxWidth,
      dark,
      [64, 32, 16]
    );
  }

  if (footer) {
    const { font } = await fitFont(footer, maxWidth, dark, [32, 16]);
    image.print(
      font,
      Math.round((size.width - maxWidth) / 2),
      size.height - Math.round(size.height * 0.12),
      { text: footer, alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER, alignmentY: Jimp.VERTICAL_ALIGN_TOP },
      maxWidth
    );
  }

  if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });
  const filePath = path.join(CACHE_DIR, `banner_${Date.now()}.png`);
  await image.writeAsync(filePath);
  return filePath;
}

module.exports = { createBanner, THEMES, SIZES };
