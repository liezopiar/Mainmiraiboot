/**
 * imageTools.js
 * Shared helpers for the "imgedit" and "collage" commands.
 * Pure Jimp — no native dependencies required.
 */

const Jimp = require("jimp");
const fs = require("fs");
const path = require("path");

const CACHE_DIR = path.join(__dirname, "..", "commands", "cache");

const PHOTO_TYPES = ["photo", "image", "animated_image", "sticker"];

/**
 * Collect every photo in the message (replied message first, then own attachments).
 * @returns {string[]} list of URLs
 */
function collectPhotos(event, max = 9) {
  const buckets = [event?.messageReply?.attachments, event?.attachments];
  const urls = [];

  for (const bucket of buckets) {
    if (!Array.isArray(bucket)) continue;
    for (const item of bucket) {
      const url = item?.url || item?.previewUrl || item?.largePreviewUrl;
      if (!url) continue;
      if (item.type && !PHOTO_TYPES.includes(item.type)) continue;
      if (!urls.includes(url)) urls.push(url);
      if (urls.length >= max) return urls;
    }
  }

  return urls;
}

function hexToInt(hex, fallback = 0x0f0f12ff) {
  const clean = String(hex || "").replace("#", "").trim();
  if (!/^[0-9a-fA-F]{6}$/.test(clean)) return fallback;
  return parseInt(clean + "ff", 16);
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function humanSize(bytes) {
  if (!bytes) return "0 KB";
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

/** Save the Jimp image into the cache folder and return its path. */
async function saveImage(image, prefix = "img") {
  if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });
  const filePath = path.join(CACHE_DIR, `${prefix}_${Date.now()}.png`);
  await image.writeAsync(filePath);
  return filePath;
}

/** Delete the temp file after it has been sent. */
function scheduleCleanup(filePath, delay = 15000) {
  if (!filePath) return;
  setTimeout(() => fs.unlink(filePath, () => {}), delay);
}

/** Hard cap so oversized photos do not cause out-of-memory errors. */
function limitSize(image, maxSide = 2000) {
  const { width, height } = image.bitmap;
  if (Math.max(width, height) > maxSide) {
    if (width >= height) image.resize(maxSide, Jimp.AUTO);
    else image.resize(Jimp.AUTO, maxSide);
  }
  return image;
}

/* ── text helpers (shared by the premium image commands) ───────────────────── */

// Jimp only ships these bitmap sizes, so every text helper snaps to one of them
const FONT_SIZES = [8, 16, 32, 64, 128];

/**
 * Jimp's bundled fonts are ASCII-only bitmaps, so anything outside that range
 * is drawn as "?". Map the punctuation people actually paste, then drop the rest.
 */
function sanitize(text) {
  return String(text ?? "")
    .replace(/[\u2018\u2019\u201A\u201B\u2032]/g, "'")
    .replace(/[\u201C\u201D\u201E\u201F\u2033]/g, '"')
    .replace(/[\u2013\u2014\u2015]/g, "-")
    .replace(/[\u2026]/g, "...")
    .replace(/[\u00A0\u2007\u202F]/g, " ")
    .replace(/[^\x20-\x7E\n]/g, "")
    .replace(/[ \t]+/g, " ")
    .trim();
}

/**
 * Load a bundled Jimp font.
 * @param {number} size any number, snapped down to the nearest bundled size
 * @param {"white"|"black"} color
 */
function loadFont(size = 32, color = "white") {
  const snapped = [...FONT_SIZES].reverse().find((s) => s <= size) || 8;
  const key = `FONT_SANS_${snapped}_${color.toUpperCase() === "BLACK" ? "BLACK" : "WHITE"}`;
  return Jimp.loadFont(Jimp[key]);
}

/**
 * Pick the biggest bundled font whose wrapped text still fits the given box.
 * @returns {Promise<{font: object, size: number, height: number}>}
 */
async function fitFont(rawText, maxWidth, maxHeight, color = "white", startSize = 128) {
  const text = sanitize(rawText);
  let last = null;
  for (const size of [...FONT_SIZES].reverse()) {
    if (size > startSize) continue;
    const font = await loadFont(size, color);
    const height = Jimp.measureTextHeight(font, text, maxWidth);
    last = { font, size, height };
    if (height <= maxHeight) return last;
  }
  return last;
}

/**
 * Print text with a cheap faux outline by stamping the dark copy around it.
 * Keeps captions readable on both bright and dark photos.
 */
async function printOutlined(image, text, { x, y, maxWidth, size = 64, thickness = 3, align = "center" }) {
  const alignmentX = {
    left: Jimp.HORIZONTAL_ALIGN_LEFT,
    center: Jimp.HORIZONTAL_ALIGN_CENTER,
    right: Jimp.HORIZONTAL_ALIGN_RIGHT
  }[align] || Jimp.HORIZONTAL_ALIGN_CENTER;

  const white = await loadFont(size, "white");
  const black = await loadFont(size, "black");
  const options = { text, alignmentX, alignmentY: Jimp.VERTICAL_ALIGN_TOP };

  for (let dx = -thickness; dx <= thickness; dx++) {
    for (let dy = -thickness; dy <= thickness; dy++) {
      if (!dx && !dy) continue;
      image.print(black, x + dx, y + dy, options, maxWidth);
    }
  }
  image.print(white, x, y, options, maxWidth);
  return Jimp.measureTextHeight(white, text, maxWidth);
}

/** Darken the whole image so overlaid text stands out. */
function dim(image, amount = 0.35) {
  const overlay = new Jimp(image.bitmap.width, image.bitmap.height, 0x000000ff);
  overlay.opacity(clamp(amount, 0, 1));
  return image.composite(overlay, 0, 0);
}

/** Read the first photo of a message into a size-capped Jimp image. */
async function readPhoto(event, maxSide = 2000) {
  const [url] = collectPhotos(event, 1);
  if (!url) return null;
  const image = await Jimp.read(url);
  return limitSize(image, maxSide);
}

module.exports = {
  Jimp,
  CACHE_DIR,
  FONT_SIZES,
  collectPhotos,
  hexToInt,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup,
  limitSize,
  loadFont,
  fitFont,
  printOutlined,
  dim,
  readPhoto
};
