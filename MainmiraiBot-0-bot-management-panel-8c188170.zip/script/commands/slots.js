module.exports.config = {
  name: "slots",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Spin the slot machine and win big!",
  category: "economy",
  usages: "[amount]",
  cooldowns: 5
};

module.exports.languages = {
  "english": {
    "noAmount":     "❗ Enter a bet amount!\nUsage: slots [amount]",
    "invalidAmt":   "❗ Bet amount must be a positive number.",
    "minBet":       "❗ Minimum bet is $%1.",
    "noBalance":    "💸 You don't have enough balance! You have $%1.",
    "jackpot":      "🎰 %1 | %2 | %3\n\n🌟 JACKPOT! You won $%4! (10× payout)\n💵 Balance: $%5",
    "win":          "🎰 %1 | %2 | %3\n\n✅ Two in a row! You won $%4! (2× payout)\n💵 Balance: $%5",
    "lose":         "🎰 %1 | %2 | %3\n\n❌ No match. You lost $%4.\n💵 Balance: $%5"
  }
};

const SYMBOLS  = ["🍒", "🍋", "🍊", "🍇", "⭐", "💎", "7️⃣"];
const MIN_BET  = 100;

function spin() {
  return SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
}

module.exports.run = async function({ api, event, args, Currencies, getText }) {
  const { threadID, messageID, senderID } = event;

  // Validate bet
  if (!args[0]) return api.sendMessage(getText("noAmount"), threadID, messageID);

  const bet = parseInt(args[0].replace(/,/g, ""));
  if (isNaN(bet) || bet <= 0) return api.sendMessage(getText("invalidAmt"), threadID, messageID);
  if (bet < MIN_BET)          return api.sendMessage(getText("minBet", MIN_BET.toLocaleString()), threadID, messageID);

  const userData = await Currencies.getData(senderID);
  const balance  = userData.money || 0;

  if (bet > balance) {
    return api.sendMessage(getText("noBalance", balance.toLocaleString()), threadID, messageID);
  }

  // Spin reels
  const [r1, r2, r3] = [spin(), spin(), spin()];

  if (r1 === r2 && r2 === r3) {
    // Jackpot — 10× payout
    const prize  = bet * 10;
    await Currencies.increaseMoney(senderID, prize);
    const newBal = balance + prize;
    return api.sendMessage(getText("jackpot", r1, r2, r3, prize.toLocaleString(), newBal.toLocaleString()), threadID, messageID);

  } else if (r1 === r2 || r2 === r3 || r1 === r3) {
    // Two match — 2× payout
    const prize  = bet * 2;
    await Currencies.increaseMoney(senderID, prize);
    const newBal = balance + prize;
    return api.sendMessage(getText("win", r1, r2, r3, prize.toLocaleString(), newBal.toLocaleString()), threadID, messageID);

  } else {
    // No match — lose bet
    await Currencies.decreaseMoney(senderID, bet);
    const newBal = balance - bet;
    return api.sendMessage(getText("lose", r1, r2, r3, bet.toLocaleString(), newBal.toLocaleString()), threadID, messageID);
  }
};
