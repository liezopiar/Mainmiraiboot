const premiumUtil = require("../../main/utility/premium.js");

/**
 * resolve the gift receiver from a reply, a tag or a raw id, and pull the
 * duration out of whatever is left. the tagged name words are stripped first so
 * a shortened facebook name can never be read as the duration.
 */
function resolveTarget(args = [], event = {}, { minIDLength = 5 } = {}) {
	const tokens = (Array.isArray(args) ? args : []).map(a => String(a == null ? "" : a)).filter(Boolean);
	const mentions = event.mentions || {};
	const mentionedUsers = Object.keys(mentions);

	let uid = null;

	if (event.type === "message_reply" && event.messageReply) {
		// If the message is a reply, use the sender's ID of the replied message
		uid = String(event.messageReply.senderID);
	} else if (tokens.join(" ").indexOf("@") !== -1 || mentionedUsers.length) {
		// If the message contains mentions, check if there is more than one mention
		if (mentionedUsers.length > 1) {
			uid = String(mentionedUsers[0]);
		} else if (mentionedUsers.length === 1) {
			uid = String(mentionedUsers[0]);
		}
	}

	const labels = Object.values(mentions).map(n => String(n || "").replace(/^@/, "").trim()).filter(Boolean);
	let rest = tokens.filter(t => t.charAt(0) !== "@");
	for (const label of labels) {
		for (const word of label.split(/\s+/).filter(Boolean)) {
			const at = rest.findIndex(t => t.replace(/^@/, "") === word);
			if (at !== -1) rest.splice(at, 1);
		}
	}

	if (!uid) {
		const idIndex = rest.findIndex(t => new RegExp(`^\\d{${minIDLength},}$`).test(t));
		if (idIndex !== -1) uid = String(rest.splice(idIndex, 1)[0]);
	}

	const { duration } = premiumUtil.extractDuration(rest);
	return { uid, duration };
}

module.exports.config = {
  name: "premiumgift",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: true,
  premium: true,
  category: "premium",
  cooldowns: 15,
  aliases: ["giftpremium", "premiumshare"],
  description: "Gift a slice of your own premium time to another member",
  usages: "premiumgift <@mention | userID> <duration>",
};

module.exports.run = async function ({ api, event, args, Users, prefix }) {
  const { threadID, messageID, senderID } = event;

  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const getName = async (id) => {
    try { return await Users.getNameUser(id); } catch { return "Facebook User"; }
  };

  // the duration is detected by shape, not by subtracting the mention label out
  // of the body. a tagged name that facebook shortened used to survive the
  // subtraction and get read as the duration, so "premiumgift @tag 3d" failed.
  const resolved = resolveTarget(args, event);
  const targetID = resolved.uid;
  const duration = resolved.duration;

  const help =
    `🎁 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗚𝗜𝗙𝗧\n` +
    `━━━━━━━━━━━━━━━\n` +
    `${prefix}premiumgift <@mention | userID> <duration>\n\n` +
    `📌 examples :\n` +
    `${prefix}premiumgift @friend 3m\n` +
    `${prefix}premiumgift @friend 1d\n` +
    `${prefix}premiumgift @friend 2d\n` +
    `${prefix}premiumgift 100012345678 5d\n` +
    `${prefix}premiumgift @friend 1 months\n` +
    `━━━━━━━━━━━━━━━\n` +
    `the time is taken from your own balance, so you must keep some left.\n` +
    `permanent members can gift without losing anything.`;

  if (!targetID || !duration) return api.sendMessage(help, threadID, messageID);

  const mine = premiumUtil.find(senderID);
  if (!mine) {
    return api.sendMessage("⛔ Only premium members can gift premium time.", threadID, messageID);
  }

  const result = premiumUtil.giftPremium(senderID, targetID, duration);

  if (!result.ok) {
    switch (result.reason) {
      case "self":
        return api.sendMessage("❗ You cannot gift premium time to yourself.", threadID, messageID);
      case "duration":
        return api.sendMessage(
          `❗ Invalid duration "${duration}".\nUse a real amount of time like 3m, 1d, 2d, 5d or 1 months (permanent cannot be gifted).`,
          threadID, messageID
        );
      case "nopremium":
        return api.sendMessage("⛔ Your premium already ran out, so there is nothing to gift.", threadID, messageID);
      case "notenough":
        return api.sendMessage(
          `❗ Not enough time left.\n⏳ you only have ${premiumUtil.formatDuration(result.left)} and you must keep some for yourself.`,
          threadID, messageID
        );
      default:
        return api.sendMessage("❗ The gift could not be sent.", threadID, messageID);
    }
  }

  const [fromName, toName] = await Promise.all([getName(senderID), getName(targetID)]);
  const gifted = premiumUtil.formatDuration(result.ms);
  const yours = result.permanentGiver ? "permanent" : premiumUtil.formatRemaining(result.giverLeft);
  const theirs = premiumUtil.formatRemaining(result.entry.expiresAt);

  api.sendMessage(
    `🎁 ${fromName} gifted you premium time !\n` +
    `⏳ received : ${gifted}\n` +
    `⭐ your premium now : ${theirs}\n` +
    `type ${prefix}premiumperks to see what you unlocked.`,
    targetID
  );

  return api.sendMessage(
    `🎁 𝗚𝗜𝗙𝗧 𝗦𝗘𝗡𝗧\n` +
    `━━━━━━━━━━━━━━━\n` +
    `📤 from : ${fromName}\n` +
    `📥 to : ${toName} (${targetID})\n` +
    `⏳ gifted : ${gifted}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `⭐ your time left : ${yours}\n` +
    `⭐ their time left : ${theirs}`,
    threadID, messageID
  );
};
