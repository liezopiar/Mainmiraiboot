module.exports.config = {
    name: "dice",
    version: "1.0.0",
    permission: 0,
    credits: "YourName",
    prefix: false,
    premium: false,
    description: "Dice game - predict the number (1-6)",
    category: "gambling",
    usages: "dice [number 1-6] [amount]",
    cooldowns: 5
};

module.exports.languages = {
    "english": {
        "missingInput": "Please specify a number (1-6) and bet amount!",
        "invalidNumber": "Invalid number! Choose between 1 and 6.",
        "invalidAmount": "Bet amount must be a positive number!",
        "minBet": "Minimum bet is 50!",
        "insufficientBalance": "Insufficient balance for this bet!",
        "win": "🎲 The dice rolled %1! You won %2$ (5x payout)!",
        "lose": "🎲 The dice rolled %1! You lost %2$!"
    }
};

module.exports.run = async function({ api, event, args, Currencies, getText }) {
    const { threadID, senderID } = event;
    const { getData, increaseMoney, decreaseMoney } = Currencies;
    const userData = await getData(senderID);
    const balance = userData.money;

    // Validate input
    if (args.length < 2) return api.sendMessage(getText("missingInput"), threadID);
    
    const numberGuess = parseInt(args[0]);
    const betAmount = parseInt(args[1]);
    
    if (isNaN(numberGuess) || numberGuess < 1 || numberGuess > 6) 
        return api.sendMessage(getText("invalidNumber"), threadID);
    
    if (isNaN(betAmount) || betAmount <= 0) 
        return api.sendMessage(getText("invalidAmount"), threadID);
    
    if (betAmount < 50) 
        return api.sendMessage(getText("minBet"), threadID);
    
    if (betAmount > balance) 
        return api.sendMessage(getText("insufficientBalance"), threadID);

    // Generate random dice roll (1-6)
    const diceResult = Math.floor(Math.random() * 6) + 1;
    const isWin = numberGuess === diceResult;

    // Calculate payout (5:1 ratio)
    const payout = betAmount * 5;

    // Update balance
    if (isWin) {
        await increaseMoney(senderID, payout);
    } else {
        await decreaseMoney(senderID, betAmount);
    }

    // Build result message
    const resultMessage = isWin 
        ? getText("win", diceResult, payout)
        : getText("lose", diceResult, betAmount);

    api.sendMessage(resultMessage, threadID);
};
