module.exports.config = {
  name: "solve",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Math calculator and equation solver (offline, no API)",
  prefix: true,
  premium: false,
  category: "education",
  usages: "[expression | equation]",
  cooldowns: 3
};

const LINE = "━━━━━━━━━━━━━━━━━━━━━━━";

const guide = (prefix) =>
  "🧮 𝗠𝗔𝗧𝗛 𝗦𝗢𝗟𝗩𝗘𝗥\n" +
  LINE +
  "\n" +
  `${prefix}solve 12 * (4 + 5) / 3\n` +
  `${prefix}solve sqrt(144) + 5^3\n` +
  `${prefix}solve 3x + 7 = 25          (linear)\n` +
  `${prefix}solve x^2 - 5x + 6 = 0     (quadratic)\n\n` +
  "Supported:\n" +
  "+ - * / % ^ ! ( ) , and implicit multiply (2x, 3(4+1))\n" +
  "sqrt cbrt abs round floor ceil exp\n" +
  "sin cos tan asin acos atan (radians)\n" +
  "sind cosd tand (degrees)\n" +
  "log log2 ln min max pow hypot\n" +
  "Constants: pi, e, tau";

// ─── tokenizer ─────────────────────────────────────────────────────────────

function tokenize(src) {
  const tokens = [];
  let i = 0;

  while (i < src.length) {
    const c = src[i];

    if (/\s/.test(c)) {
      i++;
      continue;
    }

    if (/[0-9.]/.test(c)) {
      let num = "";
      while (i < src.length && /[0-9.]/.test(src[i])) num += src[i++];
      if ((num.match(/\./g) || []).length > 1) throw new Error(`Invalid number: ${num}`);
      tokens.push({ type: "num", value: parseFloat(num) });
      continue;
    }

    if (/[a-zA-Z]/.test(c)) {
      let name = "";
      while (i < src.length && /[a-zA-Z0-9_]/.test(src[i])) name += src[i++];
      tokens.push({ type: "name", value: name.toLowerCase() });
      continue;
    }

    if ("+-*/%^!(),".includes(c)) {
      tokens.push({ type: c });
      i++;
      continue;
    }

    if (c === "×" || c === "·") {
      tokens.push({ type: "*" });
      i++;
      continue;
    }

    if (c === "÷" || c === ":") {
      tokens.push({ type: "/" });
      i++;
      continue;
    }

    throw new Error(`Unknown character: "${c}"`);
  }

  return tokens;
}

// ─── evaluator (recursive descent) ─────────────────────────────────────────

const CONSTANTS = {
  pi: Math.PI,
  e: Math.E,
  tau: Math.PI * 2
};

const toRad = (d) => (d * Math.PI) / 180;

const FUNCTIONS = {
  sqrt: [1, Math.sqrt],
  cbrt: [1, Math.cbrt],
  abs: [1, Math.abs],
  round: [1, Math.round],
  floor: [1, Math.floor],
  ceil: [1, Math.ceil],
  exp: [1, Math.exp],
  sin: [1, Math.sin],
  cos: [1, Math.cos],
  tan: [1, Math.tan],
  asin: [1, Math.asin],
  acos: [1, Math.acos],
  atan: [1, Math.atan],
  sind: [1, (x) => Math.sin(toRad(x))],
  cosd: [1, (x) => Math.cos(toRad(x))],
  tand: [1, (x) => Math.tan(toRad(x))],
  ln: [1, Math.log],
  log: [1, Math.log10],
  log2: [1, Math.log2],
  sign: [1, Math.sign],
  min: [-1, Math.min],
  max: [-1, Math.max],
  pow: [2, Math.pow],
  hypot: [-1, Math.hypot],
  root: [2, (x, n) => (x < 0 && n % 2 === 1 ? -Math.pow(-x, 1 / n) : Math.pow(x, 1 / n))]
};

function factorial(n) {
  if (n < 0 || !Number.isInteger(n)) throw new Error("Factorial only works on whole numbers.");
  if (n > 170) throw new Error("Factorial is too large (max 170).");
  let out = 1;
  for (let i = 2; i <= n; i++) out *= i;
  return out;
}

function createParser(tokens, variable, variables) {
  let pos = 0;
  const peek = () => tokens[pos];
  const next = () => tokens[pos++];

  function parseExpression() {
    let left = parseTerm();
    while (peek() && (peek().type === "+" || peek().type === "-")) {
      const op = next().type;
      const right = parseTerm();
      left = op === "+" ? left + right : left - right;
    }
    return left;
  }

  function startsPrimary(token) {
    return token && (token.type === "num" || token.type === "name" || token.type === "(");
  }

  function parseTerm() {
    let left = parseUnary();
    while (peek()) {
      const t = peek().type;
      if (t === "*" || t === "/" || t === "%") {
        next();
        const right = parseUnary();
        if ((t === "/" || t === "%") && right === 0) throw new Error("Division by zero is not allowed.");
        left = t === "*" ? left * right : t === "/" ? left / right : left % right;
      } else if (startsPrimary(peek())) {
        // implicit multiplication: 2x, 3(4+1), 2pi
        left *= parseUnary();
      } else {
        break;
      }
    }
    return left;
  }

  function parseUnary() {
    if (peek() && (peek().type === "+" || peek().type === "-")) {
      const op = next().type;
      const value = parseUnary();
      return op === "-" ? -value : value;
    }
    return parsePower();
  }

  function parsePower() {
    const base = parsePostfix();
    if (peek() && peek().type === "^") {
      next();
      return Math.pow(base, parseUnary()); // right associative
    }
    return base;
  }

  function parsePostfix() {
    let value = parsePrimary();
    while (peek() && peek().type === "!") {
      next();
      value = factorial(value);
    }
    return value;
  }

  function parseArgs() {
    if (!peek() || peek().type !== "(") throw new Error("Missing '(' after the function name.");
    next();
    const args = [parseExpression()];
    while (peek() && peek().type === ",") {
      next();
      args.push(parseExpression());
    }
    if (!peek() || peek().type !== ")") throw new Error("Missing closing ')'.");
    next();
    return args;
  }

  function parsePrimary() {
    const token = next();
    if (!token) throw new Error("Incomplete expression.");

    if (token.type === "num") return token.value;

    if (token.type === "(") {
      const value = parseExpression();
      if (!peek() || peek().type !== ")") throw new Error("Missing closing ')'.");
      next();
      return value;
    }

    if (token.type === "name") {
      const name = token.value;

      if (FUNCTIONS[name]) {
        const [arity, fn] = FUNCTIONS[name];
        const args = parseArgs();
        if (arity !== -1 && args.length !== arity) {
          throw new Error(`${name}() requires ${arity} argument(s).`);
        }
        return fn(...args);
      }

      if (Object.prototype.hasOwnProperty.call(CONSTANTS, name)) return CONSTANTS[name];
      if (variable && name === variable) return variables[variable];

      throw new Error(`Unknown symbol: "${name}"`);
    }

    throw new Error(`Unexpected "${token.type}"`);
  }

  return function parse() {
    const value = parseExpression();
    if (pos < tokens.length) throw new Error("There are extra characters in the expression.");
    return value;
  };
}

function evaluate(src, variable, value) {
  const tokens = tokenize(src);
  if (!tokens.length) throw new Error("No expression provided.");
  const parse = createParser(tokens, variable, { [variable || "_"]: value });
  const result = parse();
  if (!Number.isFinite(result)) throw new Error("The result is not a valid number (Infinity/NaN).");
  return result;
}

// ─── formatting ────────────────────────────────────────────────────────────

function fmt(value) {
  const n = Object.is(value, -0) ? 0 : value;
  if (Number.isInteger(n) && Math.abs(n) < 1e15) return n.toLocaleString("en-US");
  const rounded = parseFloat(n.toPrecision(12));
  if (Math.abs(rounded) >= 1e15 || (Math.abs(rounded) < 1e-6 && rounded !== 0)) return rounded.toExponential(6);
  return String(rounded);
}

const near = (a, b, tol = 1e-9) => Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));

// ─── equation solving ──────────────────────────────────────────────────────

function detectVariable(src) {
  const names = src.toLowerCase().match(/[a-z][a-z0-9_]*/g) || [];
  const found = names.find(
    (n) => !FUNCTIONS[n] && !Object.prototype.hasOwnProperty.call(CONSTANTS, n) && n.length === 1
  );
  return found || null;
}

function solveEquation(lhs, rhs, variable) {
  const f = (x) => evaluate(lhs, variable, x) - evaluate(rhs, variable, x);

  const f0 = f(0);
  const f1 = f(1);
  const fm1 = f(-1);
  const f2 = f(2);

  // linear check: constant slope
  const m = f1 - f0;
  if (near(f2 - f1, m) && near(f0 - fm1, m)) {
    if (near(m, 0)) {
      return near(f0, 0)
        ? { type: "identity", steps: ["Both sides are identical — infinite solutions."] }
        : { type: "none", steps: ["No solution — the sides are never equal."] };
    }
    const x = -f0 / m;
    return {
      type: "linear",
      roots: [x],
      steps: [
        `Standard form : ${m === 1 ? "" : fmt(m)}${variable} ${f0 >= 0 ? "+" : "-"} ${fmt(Math.abs(f0))} = 0`,
        `${variable} = ${fmt(-f0)} / ${fmt(m)}`
      ]
    };
  }

  // quadratic fit through -1, 0, 1 then verify at 2
  const a = (f1 + fm1) / 2 - f0;
  const b = (f1 - fm1) / 2;
  const c = f0;
  if (!near(a, 0) && near(a * 4 + b * 2 + c, f2, 1e-7)) {
    const disc = b * b - 4 * a * c;
    const steps = [
      `Standard form : ${fmt(a)}${variable}² ${b >= 0 ? "+" : "-"} ${fmt(Math.abs(b))}${variable} ${c >= 0 ? "+" : "-"} ${fmt(Math.abs(c))} = 0`,
      `Discriminant  : b² - 4ac = ${fmt(disc)}`
    ];
    if (disc < 0) {
      const re = -b / (2 * a);
      const im = Math.sqrt(-disc) / (2 * a);
      return {
        type: "complex",
        steps: [...steps, "The discriminant is negative → complex roots."],
        complex: [`${fmt(re)} + ${fmt(Math.abs(im))}i`, `${fmt(re)} - ${fmt(Math.abs(im))}i`]
      };
    }
    const r1 = (-b + Math.sqrt(disc)) / (2 * a);
    const r2 = (-b - Math.sqrt(disc)) / (2 * a);
    return {
      type: "quadratic",
      roots: near(r1, r2) ? [r1] : [r1, r2].sort((p, q) => p - q),
      steps: [...steps, `Quadratic formula: ${variable} = (-b ± √disc) / 2a`]
    };
  }

  // numeric root scan
  const roots = [];
  let prev = null;
  for (let x = -50; x <= 50.0001; x += 0.05) {
    let value;
    try {
      value = f(x);
    } catch (err) {
      prev = null;
      continue;
    }
    if (!Number.isFinite(value)) {
      prev = null;
      continue;
    }
    if (near(value, 0, 1e-12)) {
      if (!roots.some((r) => near(r, x, 1e-4))) roots.push(x);
    } else if (prev && prev.value * value < 0) {
      let lo = prev.x;
      let hi = x;
      for (let k = 0; k < 80; k++) {
        const mid = (lo + hi) / 2;
        if (f(lo) * f(mid) <= 0) hi = mid;
        else lo = mid;
      }
      const root = parseFloat(((lo + hi) / 2).toPrecision(10));
      if (!roots.some((r) => near(r, root, 1e-4))) roots.push(root);
    }
    prev = { x, value };
  }

  if (!roots.length) return { type: "none", steps: ["No real root found between -50 and 50."] };

  // show the roots closest to zero
  const nearest = roots.sort((p, q) => Math.abs(p) - Math.abs(q)).slice(0, 4);
  return {
    type: "numeric",
    roots: nearest.sort((p, q) => p - q),
    steps: [
      "Non-linear — used a numerical method (bisection) over -50 … 50.",
      roots.length > nearest.length
        ? `${roots.length} roots found; showing the ${nearest.length} closest to 0.`
        : null
    ].filter(Boolean)
  };
}

// ─── run ───────────────────────────────────────────────────────────────────

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID, messageReply } = event;

  let input = args.join(" ").trim();
  if (!input && messageReply && messageReply.body) input = messageReply.body.trim();
  if (!input || input.toLowerCase() === "help") return api.sendMessage(guide(prefix), threadID, messageID);

  if (input.length > 200) {
    return api.sendMessage("⚠️ Expression is too long (max 200 characters).", threadID, messageID);
  }

  try {
    if (input.includes("=")) {
      const sides = input.split("=");
      if (sides.length !== 2 || !sides[0].trim() || !sides[1].trim()) {
        throw new Error("Only one '=' is allowed, and both sides need an expression.");
      }

      const [lhs, rhs] = sides.map((s) => s.trim());
      const variable = detectVariable(input);
      if (!variable) throw new Error("No variable found (use a single letter, e.g. x).");

      const result = solveEquation(lhs, rhs, variable);
      const answer =
        result.type === "identity"
          ? `${variable} = any number`
          : result.type === "none"
            ? "no solution"
            : result.type === "complex"
              ? result.complex.map((r) => `${variable} = ${r}`).join("\n")
              : result.roots.map((r) => `${variable} = ${fmt(r)}`).join("\n");

      return api.sendMessage(
        [
          "🧮 𝗘𝗤𝗨𝗔𝗧𝗜𝗢𝗡",
          LINE,
          `Equation : ${lhs} = ${rhs}`,
          `Type     : ${result.type}`,
          "",
          result.steps.join("\n"),
          LINE,
          `✅ ${answer}`
        ].join("\n"),
        threadID,
        messageID
      );
    }

    const value = evaluate(input, null, 0);
    return api.sendMessage(
      [
        "🧮 𝗥𝗘𝗦𝗨𝗟𝗧",
        LINE,
        `Expression : ${input}`,
        `Answer     : ${fmt(value)}`,
        Number.isInteger(value) ? null : `Rounded    : ${value.toFixed(4)}`
      ]
        .filter(Boolean)
        .join("\n"),
      threadID,
      messageID
    );
  } catch (err) {
    return api.sendMessage(
      `❌ ${err.message}\n\nType ${prefix}solve help for the guide.`,
      threadID,
      messageID
    );
  }
};
