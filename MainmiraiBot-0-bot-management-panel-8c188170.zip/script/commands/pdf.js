const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");
const { Jimp, CACHE_DIR, collectPhotos, humanSize, scheduleCleanup } = require("../utils/imageTools");

module.exports.config = {
  name: "pdf",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Turn the photos you send or reply to into a single PDF file",
  prefix: true,
  premium: true,
  category: "premium",
  usages: "[reply to photos] (a4) (name)",
  cooldowns: 20
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const MAX_PAGES = 15;
const MAX_SIDE = 1700;
const A4 = { width: 595.28, height: 841.89 };
const MARGIN = 24;

/**
 * Minimal PDF writer. Each page holds one JPEG embedded with the DCTDecode
 * filter, so no native PDF dependency is needed.
 */
function buildPdf(pages) {
  const chunks = [];
  const offsets = [];
  let length = 0;

  const push = data => {
    const buffer = Buffer.isBuffer(data) ? data : Buffer.from(data, "binary");
    chunks.push(buffer);
    length += buffer.length;
  };

  const openObject = id => {
    offsets[id] = length;
    push(`${id} 0 obj\n`);
  };

  const closeObject = () => push("endobj\n");

  // 1 catalog, 2 pages tree, then 3 objects per page
  const pageIds = pages.map((_, index) => 3 + index * 3);
  const totalObjects = 2 + pages.length * 3;

  push("%PDF-1.4\n%\xff\xff\xff\xff\n");

  openObject(1);
  push("<< /Type /Catalog /Pages 2 0 R >>\n");
  closeObject();

  openObject(2);
  push(`<< /Type /Pages /Count ${pages.length} /Kids [${pageIds.map(id => `${id} 0 R`).join(" ")}] >>\n`);
  closeObject();

  pages.forEach((page, index) => {
    const pageId = pageIds[index];
    const contentId = pageId + 1;
    const imageId = pageId + 2;

    const content =
      `q\n${page.drawWidth.toFixed(2)} 0 0 ${page.drawHeight.toFixed(2)} ` +
      `${page.x.toFixed(2)} ${page.y.toFixed(2)} cm\n/Im0 Do\nQ\n`;

    openObject(pageId);
    push(
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${page.width.toFixed(2)} ${page.height.toFixed(2)}] ` +
        `/Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>\n`
    );
    closeObject();

    openObject(contentId);
    push(`<< /Length ${content.length} >>\nstream\n`);
    push(content);
    push("endstream\n");
    closeObject();

    openObject(imageId);
    push(
      `<< /Type /XObject /Subtype /Image /Width ${page.pixelWidth} /Height ${page.pixelHeight} ` +
        `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.jpeg.length} >>\nstream\n`
    );
    push(page.jpeg);
    push("\nendstream\n");
    closeObject();
  });

  const xrefOffset = length;
  push(`xref\n0 ${totalObjects + 1}\n`);
  push("0000000000 65535 f \n");
  for (let id = 1; id <= totalObjects; id++) {
    push(`${String(offsets[id]).padStart(10, "0")} 00000 n \n`);
  }
  push(`trailer\n<< /Size ${totalObjects + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`);

  return Buffer.concat(chunks);
}

async function toPage(url, fitA4) {
  const source = await axios.get(url, {
    responseType: "arraybuffer",
    headers: { "User-Agent": UA },
    timeout: 60000
  });

  const image = await Jimp.read(Buffer.from(source.data));
  if (Math.max(image.bitmap.width, image.bitmap.height) > MAX_SIDE) {
    if (image.bitmap.width >= image.bitmap.height) image.resize(MAX_SIDE, Jimp.AUTO);
    else image.resize(Jimp.AUTO, MAX_SIDE);
  }

  // flatten transparency so the PDF never shows black boxes
  const flat = new Jimp(image.bitmap.width, image.bitmap.height, 0xffffffff);
  flat.composite(image, 0, 0);
  flat.quality(88);

  const jpeg = await flat.getBufferAsync(Jimp.MIME_JPEG);
  const pixelWidth = flat.bitmap.width;
  const pixelHeight = flat.bitmap.height;

  if (!fitA4) {
    return {
      jpeg,
      pixelWidth,
      pixelHeight,
      width: pixelWidth,
      height: pixelHeight,
      drawWidth: pixelWidth,
      drawHeight: pixelHeight,
      x: 0,
      y: 0
    };
  }

  const usableWidth = A4.width - MARGIN * 2;
  const usableHeight = A4.height - MARGIN * 2;
  const ratio = Math.min(usableWidth / pixelWidth, usableHeight / pixelHeight);
  const drawWidth = pixelWidth * ratio;
  const drawHeight = pixelHeight * ratio;

  return {
    jpeg,
    pixelWidth,
    pixelHeight,
    width: A4.width,
    height: A4.height,
    drawWidth,
    drawHeight,
    x: (A4.width - drawWidth) / 2,
    y: (A4.height - drawHeight) / 2
  };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const urls = collectPhotos(event, MAX_PAGES);

  if (!urls.length) {
    return api.sendMessage(
      `⚠️ send or reply to photos then use ${prefix}pdf\n\n` +
        `options :\n• ${prefix}pdf a4        fit every page to A4\n` +
        `• ${prefix}pdf notes     name the file "notes.pdf"\n\n` +
        `up to ${MAX_PAGES} photos per file.`,
      threadID,
      messageID
    );
  }

  const flags = args.map(item => item.toLowerCase());
  const fitA4 = flags.includes("a4");
  const rawName = args.filter(item => item.toLowerCase() !== "a4").join("_");
  const name = (rawName.replace(/[^\w-]/g, "") || `document_${Date.now()}`).slice(0, 40);

  const loading = await api.sendMessage(
    `📄 building a pdf from ${urls.length} photo${urls.length > 1 ? "s" : ""}...`,
    threadID,
    messageID
  );

  try {
    const pages = [];
    const skipped = [];

    for (let i = 0; i < urls.length; i++) {
      try {
        pages.push(await toPage(urls[i], fitA4));
      } catch {
        skipped.push(i + 1);
      }
    }

    if (!pages.length) throw new Error("none of the photos could be read");

    await fs.ensureDir(CACHE_DIR);
    const file = path.join(CACHE_DIR, `${name}.pdf`);
    const pdf = buildPdf(pages);
    await fs.writeFile(file, pdf);

    api.unsendMessage(loading.messageID);

    return api.sendMessage(
      {
        body:
          "📄 𝗣𝗗𝗙 𝗥𝗘𝗔𝗗𝗬\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━\n" +
          `file  : ${name}.pdf\n` +
          `pages : ${pages.length}\n` +
          `size  : ${humanSize(pdf.length)}\n` +
          `layout: ${fitA4 ? "A4" : "original size"}` +
          (skipped.length ? `\nskipped: photo ${skipped.join(", ")}` : ""),
        attachment: fs.createReadStream(file)
      },
      threadID,
      () => scheduleCleanup(file, 10000),
      messageID
    );
  } catch (error) {
    api.unsendMessage(loading.messageID);
    return api.sendMessage(`❌ failed to build the pdf — ${error.message || "unknown error"}`, threadID, messageID);
  }
};
