module.exports.config = {
  name: "maintenance",
  version: "1.0.0",
  permission: 3,
  prefix: false,
  premium: false,
  credits: "ryuko",
  description: "put the bot on maintenance mode, only admins and operators can use the bot while it is on",
  category: "operator",
  usages: "maintenance [on/off/status] [reason]",
  cooldowns: 5
};

module.exports.languages = {
  "bangla": {},
  "english": {}
};

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const path = require("path");
  const moment = require("moment-timezone");
  const { writeFileSync } = global.nodemodule["fs-extra"];
  const configPath = path.join(__dirname, "../../config.json");

  delete require.cache[require.resolve("../../config.json")];
  const config = require("../../config.json");
  config.maintenance = config.maintenance || {
    status: false,
    reason: "the bot is currently under maintenance, please try again later.",
    since: null,
    note: "when the status is true, only bot admins and operators can use the bot. use the maintenance command to toggle it."
  };

  const saveConfig = () => {
    writeFileSync(configPath, JSON.stringify(config, null, 2), "utf8");
    global.config.maintenance = config.maintenance;
  };

  const action = (args[0] || "status").toLowerCase();
  const reason = args.slice(1).join(" ").trim();

  switch (action) {
    case "on":
    case "enable":
    case "true": {
      config.maintenance.status = true;
      if (reason) config.maintenance.reason = reason;
      config.maintenance.since = moment.tz("Asia/Manila").format("HH:mm:ss DD/MM/YYYY");
      saveConfig();
      return api.sendMessage(
        `🔧 maintenance mode is now on\n\nreason : ${config.maintenance.reason}\nsince : ${config.maintenance.since}\n\nonly bot admins and operators can use the bot.`,
        threadID, messageID
      );
    }

    case "off":
    case "disable":
    case "false": {
      config.maintenance.status = false;
      config.maintenance.since = null;
      saveConfig();
      return api.sendMessage(`✅ maintenance mode is now off, everyone can use the bot again.`, threadID, messageID);
    }

    case "reason":
    case "message": {
      if (!reason) return api.sendMessage(`please provide the reason.\nexample : maintenance reason updating the commands`, threadID, messageID);
      config.maintenance.reason = reason;
      saveConfig();
      return api.sendMessage(`maintenance reason updated to :\n${config.maintenance.reason}`, threadID, messageID);
    }

    case "status":
    case "info": {
      const { status, reason: why, since } = config.maintenance;
      return api.sendMessage(
        `maintenance mode : ${status ? "on" : "off"}\nreason : ${why || "none"}${since ? `\nsince : ${since}` : ""}`,
        threadID, messageID
      );
    }

    default:
      return api.sendMessage(
        `usage :\nmaintenance on [reason] - turn on maintenance mode\nmaintenance off - turn off maintenance mode\nmaintenance reason <text> - change the maintenance message\nmaintenance status - show the current state`,
        threadID, messageID
      );
  }
};
