const axios = require('axios');
const path = require('path');
const fs = require('fs-extra');

module.exports.config = {
    name: "fbdl",
    version: "1.0.0",
    permission: 0,
    description: "Download HD Facebook video using API",
    prefix: false,
    premium: false,
    credits: "Your Name",
    cooldowns: 15,
    category: "media"
};

module.exports.run = async function ({ api, event, args }) {
    try {
        const facebookUrl = args[0];
        if (!facebookUrl) return api.sendMessage("Please provide a Facebook video URL.", event.threadID, event.messageID);

        // Fetch video data from API
        const apiResponse = await axios.get(`https://gis-rest-api.onrender.com/facebookdl?url=${encodeURIComponent(facebookUrl)}`);
        const videoData = apiResponse.data;
        
        // Validate response structure
        if (!videoData.result?.hd) throw new Error('No HD video found in API response');
        
        // Download the HD video
        const fileName = `${event.messageID}.mp4`;
        const filePath = path.join(__dirname, fileName);
        
        const videoResponse = await axios({
            method: 'GET',
            url: videoData.result.hd,
            responseType: 'stream'
        });

        const writer = fs.createWriteStream(filePath);
        videoResponse.data.pipe(writer);

        writer.on('finish', () => {
            // Send video with additional metadata
            const messageBody = [
                videoData.title && `Title: ${videoData.title}`,
                videoData.duration && `Duration: ${videoData.duration}s`,
                videoData.views && `Views: ${videoData.views}`,
                videoData.description && `Description: ${videoData.description}`
            ].filter(Boolean).join('\n') || 'HD Facebook Video Downloaded';

            api.sendMessage({
                body: messageBody,
                attachment: fs.createReadStream(filePath)
            }, event.threadID, () => fs.unlinkSync(filePath), event.messageID);
        });

        writer.on('error', (error) => {
            console.error('Download error:', error);
            api.sendMessage('Error downloading video file.', event.threadID, event.messageID);
        });

    } catch (error) {
        console.error('Error in fbdl command:', error);
        api.sendMessage(`Failed to download video: ${error.message}`, event.threadID, event.messageID);
    }
};
