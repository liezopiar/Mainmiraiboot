const premiumUtil = require("../../main/utility/premium.js");

module.exports.config = {
  name: "premiumlist",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: true,
  premium: true,
  category: "premium",
  cooldowns: 10,
  description: "Show every premium member of the bot with the time left on their access",
  usages: "premiumlist [page]",
};

const PER_PAGE = 10;

module.exports.run = async function ({ api, event, args, Users }) {
  const { threadID, messageID, senderID } = event;

  // an expired member should never show up on the roster
  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const list = premiumUtil.getList();
  if (!list.length) {
    return api.sendMessage("📭 There are no premium members yet.", threadID, messageID);
  }

  // permanent members first, then the ones with the most time left
  const sorted = [...list].sort((a, b) => {
    if (!a.expiresAt && !b.expiresAt) return 0;
    if (!a.expiresAt) return -1;
    if (!b.expiresAt) return 1;
    return Number(b.expiresAt) - Number(a.expiresAt);
  });

  const pages = Math.max(1, Math.ceil(sorted.length / PER_PAGE));
  let page = parseInt(args[0], 10);
  if (isNaN(page) || page < 1) page = 1;
  if (page > pages) page = pages;

  const slice = sorted.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const lines = [];
  for (let i = 0; i < slice.length; i++) {
    const entry = slice[i];
    let name = "Facebook User";
    try { name = await Users.getNameUser(entry.userID); } catch {}
    const rank = (page - 1) * PER_PAGE + i + 1;
    const you = String(entry.userID) === String(senderID) ? " ← you" : "";
    const badge = entry.expiresAt ? "⏳" : "♾️";
    lines.push(`${rank}. ${name}${you}\n   ${badge} ${premiumUtil.formatRemaining(entry.expiresAt)}`);
  }

  const permanent = sorted.filter(entry => !entry.expiresAt).length;

  return api.sendMessage(
    `⭐ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗠𝗘𝗠𝗕𝗘𝗥𝗦\n` +
    `━━━━━━━━━━━━━━━\n` +
    `${lines.join("\n\n")}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `👥 total : ${sorted.length}  •  ♾️ permanent : ${permanent}\n` +
    `📄 page ${page}/${pages}${pages > 1 ? `  •  type "premiumlist ${page < pages ? page + 1 : 1}" for more` : ""}`,
    threadID, messageID
  );
};
