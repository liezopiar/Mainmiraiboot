const fs = require("fs");
const {
  Jimp,
  collectPhotos,
  hexToInt,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup,
  limitSize
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgedit",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Image editor: filter, resize, rotate, crop, border and more",
  prefix: true,
  premium: false,
  category: "tools",
  usages: "[reply to a photo] <ops...>  |  list",
  cooldowns: 10
};

/**
 * Each op has:
 *  arg  - "none" | "number" | "text"
 *  info - description shown in help
 *  apply(image, value)
 */
const OPS = {
  grayscale: { arg: "none", info: "black and white", apply: (img) => img.grayscale() },
  sepia: { arg: "none", info: "vintage brown tone", apply: (img) => img.sepia() },
  invert: { arg: "none", info: "invert the colors", apply: (img) => img.invert() },
  normalize: { arg: "none", info: "balance the contrast", apply: (img) => img.normalize() },
  autocrop: { arg: "none", info: "remove plain borders", apply: (img) => img.autocrop() },
  sharpen: {
    arg: "none",
    info: "sharpen the details",
    apply: (img) =>
      img.convolute([
        [0, -1, 0],
        [-1, 5, -1],
        [0, -1, 0]
      ])
  },
  blur: {
    arg: "number",
    info: "blur strength (1-20, default 6)",
    apply: (img, v) => img.blur(clamp(Math.round(v ?? 6), 1, 20))
  },
  pixelate: {
    arg: "number",
    info: "pixel block size (2-64, default 10)",
    apply: (img, v) => img.pixelate(clamp(Math.round(v ?? 10), 2, 64))
  },
  posterize: {
    arg: "number",
    info: "number of color levels (2-32, default 6)",
    apply: (img, v) => img.posterize(clamp(Math.round(v ?? 6), 2, 32))
  },
  brightness: {
    arg: "number",
    info: "-1 to 1 (default 0.2)",
    apply: (img, v) => img.brightness(clamp(v ?? 0.2, -1, 1))
  },
  contrast: {
    arg: "number",
    info: "-1 to 1 (default 0.3)",
    apply: (img, v) => img.contrast(clamp(v ?? 0.3, -1, 1))
  },
  fade: {
    arg: "number",
    info: "transparency 0-1 (default 0.4)",
    apply: (img, v) => img.fade(clamp(v ?? 0.4, 0, 1))
  },
  rotate: {
    arg: "number",
    info: "degrees, e.g. 90 / 180 / -45",
    apply: (img, v) => img.rotate(((v ?? 90) % 360 + 360) % 360)
  },
  flip: {
    arg: "text",
    info: "h (horizontal), v (vertical), hv (both)",
    apply: (img, v) => {
      const mode = String(v || "h").toLowerCase();
      return img.flip(mode.includes("h"), mode.includes("v"));
    }
  },
  resize: {
    arg: "text",
    info: "800 or 800x600 (max 2000)",
    apply: (img, v) => {
      const raw = String(v || "").toLowerCase();
      const [w, h] = raw.split(/[x*:]/).map((n) => parseInt(n, 10));
      if (!w || Number.isNaN(w)) throw new Error("Resize needs a width, e.g. resize:800");
      const width = clamp(w, 32, 2000);
      const height = h && !Number.isNaN(h) ? clamp(h, 32, 2000) : Jimp.AUTO;
      return img.resize(width, height);
    }
  },
  crop: {
    arg: "text",
    info: "circle, square, or 1:1 / 16:9 aspect",
    apply: (img, v) => cropShape(img, String(v || "square").toLowerCase())
  },
  border: {
    arg: "number",
    info: "frame thickness in pixels (default 24)",
    apply: (img, v, flags) => addBorder(img, clamp(Math.round(v ?? 24), 2, 200), flags.color)
  }
};

const ALIASES = {
  gray: "grayscale",
  greyscale: "grayscale",
  bw: "grayscale",
  bright: "brightness",
  rotate90: "rotate",
  mirror: "flip",
  frame: "border",
  size: "resize",
  pixel: "pixelate"
};

function cropShape(image, mode) {
  const { width, height } = image.bitmap;

  if (mode === "circle") {
    const side = Math.min(width, height);
    image.crop(Math.round((width - side) / 2), Math.round((height - side) / 2), side, side);
    return image.circle();
  }

  if (mode === "square" || mode === "1:1") {
    const side = Math.min(width, height);
    return image.crop(Math.round((width - side) / 2), Math.round((height - side) / 2), side, side);
  }

  const match = mode.match(/^(\d+)[:x](\d+)$/);
  if (!match) throw new Error(`Unknown crop "${mode}". Use: circle, square, or 16:9`);

  const ratio = Number(match[1]) / Number(match[2]);
  let w = width;
  let h = Math.round(width / ratio);
  if (h > height) {
    h = height;
    w = Math.round(height * ratio);
  }
  return image.crop(Math.round((width - w) / 2), Math.round((height - h) / 2), w, h);
}

function addBorder(image, thickness, colorHex) {
  const { width, height } = image.bitmap;
  const canvas = new Jimp(width + thickness * 2, height + thickness * 2, hexToInt(colorHex, 0xfafafaff));
  canvas.composite(image, thickness, thickness);
  return canvas;
}

function parseOps(args) {
  const flags = { color: null };
  const queue = [];
  const unknown = [];

  for (let i = 0; i < args.length; i++) {
    const token = args[i];
    const lower = token.toLowerCase();

    if ((lower === "-c" || lower === "--color") && args[i + 1]) {
      flags.color = args[++i];
      continue;
    }

    // split on the FIRST ":" or "=" only so aspect ratios like crop:16:9 still work
    const [, rawName, rawValue] = lower.match(/^([^:=]+)(?:[:=]([\s\S]*))?$/) || [];
    const name = ALIASES[rawName] || rawName;
    const op = OPS[name];

    if (!op) {
      unknown.push(token);
      continue;
    }

    let value = rawValue === "" ? undefined : rawValue;
    if (op.arg === "number") value = value === undefined ? undefined : Number(value);
    if (op.arg === "number" && value !== undefined && Number.isNaN(value)) {
      throw new Error(`"${name}" needs a number, e.g. ${name}:5`);
    }

    queue.push({ name, op, value });
  }

  return { queue, flags, unknown };
}

function guide(prefix) {
  const lines = Object.entries(OPS).map(([name, op]) => {
    const sample = op.arg === "none" ? name : `${name}:<${op.arg === "number" ? "n" : "val"}>`;
    return `• ${sample.padEnd(16)} ${op.info}`;
  });

  return (
    "🛠 𝗜𝗠𝗔𝗚𝗘 𝗘𝗗𝗜𝗧𝗢𝗥\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━\n" +
    `Reply to a photo then send:\n${prefix}imgedit <ops...>\n\n` +
    "Available ops:\n" +
    lines.join("\n") +
    "\n\nExtra: -c <hex> → border color\n" +
    "Ops are applied in order.\n\n" +
    "Examples:\n" +
    `${prefix}imgedit grayscale contrast:0.3 border:30 -c 111111\n` +
    `${prefix}imgedit crop:circle resize:512\n` +
    `${prefix}imgedit blur:8 brightness:-0.2 rotate:90`
  );
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;

  if (!args[0] || ["help", "list", "ops"].includes(args[0].toLowerCase())) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const photos = collectPhotos(event, 1);
  if (!photos.length) {
    return api.sendMessage(
      `⚠️ A photo is required.\nReply to a photo then type ${prefix}imgedit <ops...>`,
      threadID,
      messageID
    );
  }

  let parsed;
  try {
    parsed = parseOps(args);
  } catch (error) {
    return api.sendMessage(`⚠️ ${error.message}`, threadID, messageID);
  }

  const { queue, flags, unknown } = parsed;

  if (!queue.length) {
    return api.sendMessage(
      `⚠️ No valid ops${unknown.length ? `: ${unknown.join(", ")}` : ""}.\n\n${guide(prefix)}`,
      threadID,
      messageID
    );
  }

  api.setMessageReaction("🛠", messageID, () => {}, true);

  let filePath;
  try {
    let image = await Jimp.read(photos[0]);
    const before = `${image.bitmap.width}x${image.bitmap.height}`;
    limitSize(image, 2000);

    const applied = [];
    for (const item of queue) {
      const result = item.op.apply(image, item.value, flags);
      if (result && result.bitmap) image = result;
      applied.push(item.value === undefined ? item.name : `${item.name}:${item.value}`);
    }

    filePath = await saveImage(image, "imgedit");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "✅ 𝗘𝗗𝗜𝗧𝗘𝗗\n" +
          `🎛 ${applied.join(" → ")}\n` +
          `📐 ${before} → ${image.bitmap.width}x${image.bitmap.height}\n` +
          `💾 ${humanSize(stats.size)}` +
          (unknown.length ? `\n⚠️ Unknown ops: ${unknown.join(", ")}` : ""),
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to edit the image: ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
