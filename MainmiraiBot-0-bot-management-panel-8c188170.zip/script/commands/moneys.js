module.exports.config = {
  name: "moneys",
  version: "1.0.2",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "check the amount of yourself or the person tagged",
  category: "without prefix",
  usages: "[tag]",
  cooldowns: 5
};

module.exports.languages = {
  "bangla": {
    "sotienbanthan": "your current balance : %1$",
    "sotiennguoikhac": "%1's current balance : %2$."
  },
  "english": {
    "sotienbanthan": "your current balance : %1$",
    "sotiennguoikhac": "%1's current balance : %2$."
  }
};

module.exports.run = async function({ api, event, args, Currencies, getText }) {
  const { threadID, messageID, senderID, mentions } = event;

  // No arguments — show the sender's own balance
  if (!args[0]) {
    const money = (await Currencies.getData(senderID)).money;
    return api.sendMessage(getText("sotienbanthan", money), threadID, messageID);
  }

  // One person tagged — show that person's balance
  if (Object.keys(event.mentions).length === 1) {
    const mention = Object.keys(mentions)[0];
    let money = (await Currencies.getData(mention)).money;
    if (!money) money = 0;

    return api.sendMessage({
      body: getText("sotiennguoikhac", mentions[mention].replace(/\@/g, ""), money),
      mentions: [{
        tag: mentions[mention].replace(/\@/g, ""),
        id: mention
      }]
    }, threadID, messageID);
  }

  // Anything else — throw a usage error
  return global.utils.throwError(this.config.name, threadID, messageID);
};
