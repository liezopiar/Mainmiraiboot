module.exports.config = {
  name: "transfer",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Transfer money to a tagged user",
  category: "economy",
  usages: "[@tag | reply | userID] [amount]",
  cooldowns: 5
};

module.exports.languages = {
  "english": {
    "noTag":        "❗ Tag someone to transfer to!\nUsage: transfer @username [amount] (or reply to their message / pass their id)",
    "noSelf":       "🤦 You can't transfer to yourself!",
    "noAmount":     "❗ Enter an amount to transfer!\nUsage: transfer @username [amount]",
    "invalidAmt":   "❗ Amount must be a positive number.",
    "minTransfer":  "❗ Minimum transfer is $%1.",
    "noBalance":    "💸 Insufficient balance! You have $%1.",
    "success":      "✅ Transferred $%1 to %2!\n💵 Your balance: $%3\n💵 %2's balance: $%4",
    "tax":          "\n🏦 Transfer fee: $%1 (1%%)"
  }
};

const MIN_TRANSFER = 100;
const TAX_RATE     = 0.01; // 1 % fee

module.exports.run = async function({ api, event, args, Users, Currencies, getText }) {
  const { threadID, messageID, senderID, mentions } = event;

  // Resolve the receiver : reply first, then a tag, then a raw id
  let targetID = null;
  let targetName = null;
  let amountTokens = args.filter(a => a.charAt(0) !== "@");

  if (event.type === "message_reply" && event.messageReply) {
    // If the message is a reply, use the sender's ID of the replied message
    targetID = String(event.messageReply.senderID);
  } else if (args.join(" ").indexOf("@") !== -1 || Object.keys(mentions).length) {
    // If the message contains mentions, check if there is more than one mention
    const mentionedUsers = Object.keys(mentions);
    if (mentionedUsers.length > 1) {
      return api.sendMessage("❗ Transfer to only one person at a time.", threadID, messageID);
    }
    if (mentionedUsers.length === 1) {
      targetID   = String(mentionedUsers[0]);
      targetName = String(Object.values(mentions)[0]).replace(/@/g, "");
    }
  }

  // drop the tagged name words so they can't be read as the amount
  for (const label of Object.values(mentions)) {
    for (const word of String(label).replace(/^@/, "").trim().split(/\s+/).filter(Boolean)) {
      const at = amountTokens.findIndex(t => t.replace(/^@/, "") === word);
      if (at !== -1) amountTokens.splice(at, 1);
    }
  }

  if (!targetID) {
    const idIndex = amountTokens.findIndex(a => /^\d{10,}$/.test(a));
    if (idIndex !== -1) targetID = String(amountTokens.splice(idIndex, 1)[0]);
  }

  if (!targetID) {
    return api.sendMessage(getText("noTag"), threadID, messageID);
  }

  if (String(targetID) === String(senderID)) {
    return api.sendMessage(getText("noSelf"), threadID, messageID);
  }

  // Last remaining numeric token is the amount
  const amountArg = amountTokens.filter(a => !isNaN(a) && a !== "").pop();
  if (!amountArg) return api.sendMessage(getText("noAmount"), threadID, messageID);

  const amount = parseInt(amountArg);
  if (isNaN(amount) || amount <= 0) return api.sendMessage(getText("invalidAmt"), threadID, messageID);
  if (amount < MIN_TRANSFER)        return api.sendMessage(getText("minTransfer", MIN_TRANSFER.toLocaleString()), threadID, messageID);

  const senderData = await Currencies.getData(senderID);
  const senderBal  = senderData.money || 0;
  const tax        = Math.floor(amount * TAX_RATE);
  const total      = amount + tax;

  if (total > senderBal) {
    return api.sendMessage(getText("noBalance", senderBal.toLocaleString()), threadID, messageID);
  }

  // Execute transfer
  await Currencies.decreaseMoney(senderID, total);
  await Currencies.increaseMoney(targetID, amount);

  const targetData  = await Currencies.getData(targetID);
  const senderNew   = senderBal - total;
  const targetNew   = (targetData.money || 0);
  if (!targetName) {
    try { targetName = await Users.getNameUser(targetID); }
    catch { targetName = `user ${targetID}`; }
  }

  let msg = getText("success",
    amount.toLocaleString(),
    targetName,
    senderNew.toLocaleString(),
    targetNew.toLocaleString()
  );
  if (tax > 0) msg += getText("tax", tax.toLocaleString());

  return api.sendMessage(msg, threadID, messageID);
};
