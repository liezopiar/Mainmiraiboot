const fs = require("fs");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  name: "dictionary",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Definitions, pronunciation, examples and synonyms of a word",
  prefix: true,
  premium: false,
  category: "education",
  usages: "[word] (-a to include audio)",
  cooldowns: 5,
  dependency: {
    axios: ""
  }
};

const LINE = "━━━━━━━━━━━━━━━━━━━━━━━";
const API = "https://api.dictionaryapi.dev/api/v2/entries/en";
const MAX_POS = 3;
const MAX_DEF = 2;

const guide = (prefix) =>
  "📚 𝗗𝗜𝗖𝗧𝗜𝗢𝗡𝗔𝗥𝗬\n" +
  LINE +
  "\n" +
  `${prefix}dictionary <word>\n\n` +
  "Options:\n" +
  "-a  → include the pronunciation audio\n\n" +
  `Example: ${prefix}dictionary photosynthesis -a\n` +
  "Tip: you can also reply to a message containing the word.";

function cleanWord(input) {
  return input
    .replace(/[^a-zA-Z\s'-]/g, "")
    .trim()
    .split(/\s+/)[0] || "";
}

function pickAudio(entries) {
  for (const entry of entries) {
    for (const p of entry.phonetics || []) {
      if (p.audio) return p.audio;
    }
  }
  return null;
}

function pickPhonetic(entries) {
  for (const entry of entries) {
    if (entry.phonetic) return entry.phonetic;
    const withText = (entry.phonetics || []).find((p) => p.text);
    if (withText) return withText.text;
  }
  return null;
}

/** Merge every entry into one map: part of speech -> definitions. */
function collectMeanings(entries) {
  const map = new Map();
  for (const entry of entries) {
    for (const meaning of entry.meanings || []) {
      const pos = meaning.partOfSpeech || "other";
      if (!map.has(pos)) map.set(pos, { definitions: [], synonyms: new Set(), antonyms: new Set() });
      const bucket = map.get(pos);
      for (const def of meaning.definitions || []) {
        if (def.definition) bucket.definitions.push(def);
      }
      for (const s of meaning.synonyms || []) bucket.synonyms.add(s);
      for (const a of meaning.antonyms || []) bucket.antonyms.add(a);
    }
  }
  return map;
}

function buildMessage(word, entries) {
  const phonetic = pickPhonetic(entries);
  const meanings = collectMeanings(entries);

  const blocks = Array.from(meanings.entries())
    .slice(0, MAX_POS)
    .map(([pos, bucket]) => {
      const defs = bucket.definitions.slice(0, MAX_DEF).map((def, i) => {
        const lines = [`${i + 1}. ${def.definition}`];
        if (def.example) lines.push(`   ↳ "${def.example}"`);
        return lines.join("\n");
      });

      const extra = [];
      const syn = Array.from(bucket.synonyms).slice(0, 5);
      const ant = Array.from(bucket.antonyms).slice(0, 5);
      if (syn.length) extra.push(`   Synonyms: ${syn.join(", ")}`);
      if (ant.length) extra.push(`   Antonyms: ${ant.join(", ")}`);

      return [`❒ ${pos.toUpperCase()}`, ...defs, ...extra].join("\n");
    });

  return [
    `📚 ${word.toUpperCase()}${phonetic ? `  ${phonetic}` : ""}`,
    LINE,
    blocks.join("\n\n") || "No definitions found.",
    LINE,
    "Source: dictionaryapi.dev"
  ].join("\n");
}

async function downloadAudio(url) {
  const dir = path.join(__dirname, "cache");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `dict_${Date.now()}.mp3`);
  const res = await axios.get(url, { responseType: "arraybuffer", timeout: 20000 });
  fs.writeFileSync(file, Buffer.from(res.data));
  return file;
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID, messageReply } = event;

  const wantAudio = args.some((a) => a.toLowerCase() === "-a" || a.toLowerCase() === "--audio");
  const words = args.filter((a) => !a.startsWith("-"));
  const query = cleanWord(words.join(" ") || (messageReply ? messageReply.body || "" : ""));

  if (!query) return api.sendMessage(guide(prefix), threadID, messageID);

  let entries;
  try {
    const res = await axios.get(`${API}/${encodeURIComponent(query)}`, { timeout: 20000 });
    entries = Array.isArray(res.data) ? res.data : [];
  } catch (err) {
    if (err.response && err.response.status === 404) {
      return api.sendMessage(
        `❌ No definitions found for "${query}".\nDouble-check the spelling for typos.`,
        threadID,
        messageID
      );
    }
    return api.sendMessage("⚠️ Cannot reach the dictionary service. Please try again later.", threadID, messageID);
  }

  if (!entries.length) {
    return api.sendMessage(`❌ No definitions found for "${query}".`, threadID, messageID);
  }

  const body = buildMessage(query, entries);
  const audioUrl = wantAudio ? pickAudio(entries) : null;

  if (!audioUrl) return api.sendMessage(body, threadID, messageID);

  try {
    const file = await downloadAudio(audioUrl);
    return api.sendMessage(
      { body, attachment: fs.createReadStream(file) },
      threadID,
      () => fs.unlinkSync(file),
      messageID
    );
  } catch (err) {
    return api.sendMessage(`${body}\n\n⚠️ Failed to download the audio.`, threadID, messageID);
  }
};
