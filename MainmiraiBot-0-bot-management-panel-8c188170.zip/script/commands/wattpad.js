const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "wattpad",
  version: "2.0.0",
  prefix: false,
  premium: false,
  permission: 0,
  credits: "ryuko",
  description: "Search Wattpad stories, then reply with a number for the full details",
  category: "without prefix",
  usages: "[title or tag] | reply with a number",
  cooldowns: 5
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const CACHE_DIR = path.join(__dirname, "cache");
const RESULTS = 6;
const FIELDS =
  "stories(id,title,description,url,cover,voteCount,readCount,commentCount,numParts,completed,mature,language(name),user(name,fullname),tags,lastPublishedPart(createDate))";

function compact(number) {
  const value = Number(number) || 0;
  if (value >= 1e9) return `${(value / 1e9).toFixed(1)}B`;
  if (value >= 1e6) return `${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `${(value / 1e3).toFixed(1)}K`;
  return String(value);
}

function trim(text, max) {
  const clean = String(text || "").replace(/\s+/g, " ").trim();
  if (!clean) return "no description";
  return clean.length > max ? `${clean.slice(0, max - 1)}…` : clean;
}

/** Wattpad's own search API — same one the website calls. */
async function searchApi(query) {
  const { data } = await axios.get("https://www.wattpad.com/v4/search/stories", {
    params: { query, limit: RESULTS, mature: 1, fields: FIELDS },
    headers: { "User-Agent": UA, Accept: "application/json" },
    timeout: 25000
  });

  return (data?.stories || []).map(story => ({
    title: story.title,
    author: story.user?.fullname || story.user?.name || "unknown",
    username: story.user?.name || "",
    reads: compact(story.readCount),
    votes: compact(story.voteCount),
    comments: compact(story.commentCount),
    parts: story.numParts || 0,
    completed: !!story.completed,
    mature: !!story.mature,
    language: story.language?.name || "",
    tags: (story.tags || []).slice(0, 6),
    url: story.url || `https://www.wattpad.com/story/${story.id}`,
    cover: story.cover ? String(story.cover).replace(/-\d+-\d+(?=\.)/, "-512-k") : null,
    description: story.description || ""
  }));
}

/** Fallback for when the API is unreachable — scrapes the public search page. */
async function searchHtml(query) {
  const { data } = await axios.get(`https://www.wattpad.com/search/${encodeURIComponent(query)}`, {
    headers: { "User-Agent": UA },
    timeout: 25000
  });

  const $ = cheerio.load(data);
  const stories = [];

  $("div.story-card-data div.story-info").each((_, element) => {
    const card = $(element);
    const stats = card.find("span.stats-value");
    const href = card.closest("a").attr("href") || card.find("a").attr("href") || "";

    stories.push({
      title: card.find("div.title").text().trim(),
      author: card.find("div.author").text().replace(/^by\s*/i, "").trim() || "unknown",
      username: "",
      reads: $(stats[0]).text().trim() || "0",
      votes: $(stats[1]).text().trim() || "0",
      comments: "0",
      parts: parseInt($(stats[2]).text().trim(), 10) || 0,
      completed: false,
      mature: false,
      language: "",
      tags: [],
      url: href.startsWith("http") ? href : `https://www.wattpad.com${href}`,
      cover: card.closest("div.story-card-data").find("img").attr("src") || null,
      description: card.find("div.description").text().trim()
    });
  });

  return stories.slice(0, RESULTS);
}

async function coverStream(url, id) {
  if (!url) return null;

  try {
    const { data } = await axios.get(url, {
      responseType: "arraybuffer",
      headers: { "User-Agent": UA },
      timeout: 20000
    });

    await fs.ensureDir(CACHE_DIR);
    const file = path.join(CACHE_DIR, `wattpad_${id}.jpg`);
    await fs.writeFile(file, Buffer.from(data));
    return file;
  } catch {
    return null;
  }
}

function listMessage(query, stories) {
  const lines = stories.map((story, index) => {
    const flags = [story.completed ? "completed" : "ongoing", story.mature ? "mature" : null]
      .filter(Boolean)
      .join(" • ");

    return (
      `${index + 1}. ${story.title}\n` +
      `   by ${story.author}\n` +
      `   ${story.reads} reads • ${story.votes} votes • ${story.parts} parts\n` +
      `   ${flags}`
    );
  });

  return (
    `📚 𝗪𝗔𝗧𝗧𝗣𝗔𝗗 — "${query}"\n` +
    "━━━━━━━━━━━━━━━━━━━━━━━\n" +
    `${lines.join("\n\n")}\n\n` +
    "Reply with a number to see the full details."
  );
}

function detailMessage(story) {
  const parts = [
    `📖 ${story.title}`,
    "━━━━━━━━━━━━━━━━━━━━━━━",
    `author  : ${story.author}${story.username ? ` (@${story.username})` : ""}`,
    `reads   : ${story.reads}`,
    `votes   : ${story.votes}`,
    `parts   : ${story.parts}`,
    `status  : ${story.completed ? "completed" : "ongoing"}${story.mature ? " • mature" : ""}`
  ];

  if (story.comments && story.comments !== "0") parts.push(`comments: ${story.comments}`);
  if (story.language) parts.push(`language: ${story.language}`);
  if (story.tags.length) parts.push(`tags    : ${story.tags.join(", ")}`);

  parts.push("", trim(story.description, 700), "", `🔗 ${story.url}`);
  return parts.join("\n");
}

module.exports.run = async function ({ api, event, args, botid }) {
  const { threadID, messageID } = event;
  const query = args.join(" ").trim();

  if (!query) {
    return api.sendMessage(
      "⚠️ what story are you looking for?\n\nexample : wattpad tagalog romance",
      threadID,
      messageID
    );
  }

  const loading = await api.sendMessage(`🔎 searching wattpad for "${query}"...`, threadID);

  let stories = [];
  try {
    stories = await searchApi(query);
  } catch {
    try {
      stories = await searchHtml(query);
    } catch {
      stories = [];
    }
  }

  api.unsendMessage(loading.messageID);

  if (!stories.length) {
    return api.sendMessage(
      `❌ no stories found for "${query}". try another title or tag.`,
      threadID,
      messageID
    );
  }

  return api.sendMessage(listMessage(query, stories), threadID, (error, info) => {
    if (error) return;
    global.client.handleReply.get(botid).push({
      name: module.exports.config.name,
      type: "pick",
      author: event.senderID,
      messageID: info.messageID,
      stories
    });
  }, messageID);
};

module.exports.handleReply = async function ({ api, event, handleReply, botid }) {
  const { threadID, messageID, senderID, body } = event;
  if (handleReply.author !== senderID) return;

  const index = parseInt(String(body).trim(), 10);
  const story = handleReply.stories[index - 1];

  if (!story) {
    return api.sendMessage(
      `⚠️ reply with a number from 1 to ${handleReply.stories.length}.`,
      threadID,
      messageID
    );
  }

  const file = await coverStream(story.cover, `${Date.now()}_${index}`);
  const payload = { body: detailMessage(story) };
  if (file) payload.attachment = fs.createReadStream(file);

  api.sendMessage(payload, threadID, () => {
    if (file) fs.unlink(file, () => {});
  }, messageID);

  const replies = global.client.handleReply.get(botid);
  const position = replies.findIndex(item => item.messageID === handleReply.messageID);
  if (position > -1) replies.splice(position, 1);
};
