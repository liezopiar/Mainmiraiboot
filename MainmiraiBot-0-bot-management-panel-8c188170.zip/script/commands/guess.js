module.exports.config = {
  name: "guess",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Guess the secret number between 1 and 100 to win money",
  category: "game",
  usages: "guess",
  cooldowns: 10
};

module.exports.languages = {
  "english": {
    "start":      "🔢 NUMBER GUESS\n\nI picked a number between 1 and 100.\nYou have %1 tries.\n\n💬 Reply to this message with your guess.",
    "notYours":   "❗ This is not your game.",
    "invalid":    "⚠️ Send a whole number between 1 and 100.",
    "higher":     "⬆️ %1 is too low! Go higher.\n🎯 Tries left: %2\n\n💬 Reply with your next guess.",
    "lower":      "⬇️ %1 is too high! Go lower.\n🎯 Tries left: %2\n\n💬 Reply with your next guess.",
    "correct":    "🎉 Correct! The number was %1.\n💰 You earned $%2 with %3 tries left!\n💵 Balance: $%4",
    "outOfTries": "❌ Out of tries! The number was %1.\n💬 Type \"guess\" to play again.",
    "timeout":    "⌛ Time's up! The number was %1."
  }
};

const MAX_TRIES  = 6;
const MAX_NUMBER = 100;
const BASE_PRIZE = 2000;

/** Sends a message and registers the reply listener for the next guess. */
function ask({ api, event, botid, commandName, message, state, timeoutText }) {
  api.sendMessage(message, event.threadID, (err, info) => {
    if (err || !info) return;
    global.client.handleReply.get(botid).push({
      name: commandName,
      messageID: info.messageID,
      ...state,
      timeout: setTimeout(() => {
        api.unsendMessage(info.messageID);
        api.sendMessage(timeoutText, event.threadID);
      }, 60000)
    });
  });
}

module.exports.run = async function({ api, event, getText, botid }) {
  const secret = Math.floor(Math.random() * MAX_NUMBER) + 1;

  ask({
    api, event, botid,
    commandName: this.config.name,
    message: getText("start", MAX_TRIES),
    state: { author: event.senderID, secret, triesLeft: MAX_TRIES },
    timeoutText: getText("timeout", secret)
  });
};

module.exports.handleReply = async function({ api, event, handleReply, Currencies, getText, botid }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID !== handleReply.author) return api.sendMessage(getText("notYours"), threadID, messageID);

  const guess = parseInt(String(body || "").trim());
  if (isNaN(guess) || guess < 1 || guess > MAX_NUMBER) {
    return api.sendMessage(getText("invalid"), threadID, messageID);
  }

  clearTimeout(handleReply.timeout);
  api.unsendMessage(handleReply.messageID);

  const { secret } = handleReply;
  const triesLeft  = handleReply.triesLeft - 1;

  if (guess === secret) {
    // Fewer guesses used means a bigger reward
    const prize = BASE_PRIZE * (triesLeft + 1);
    await Currencies.increaseMoney(senderID, prize);
    const balance = (await Currencies.getData(senderID)).money || 0;
    return api.sendMessage(
      getText("correct", secret, prize.toLocaleString(), triesLeft, balance.toLocaleString()),
      threadID, messageID
    );
  }

  if (triesLeft <= 0) {
    return api.sendMessage(getText("outOfTries", secret), threadID, messageID);
  }

  ask({
    api, event, botid,
    commandName: module.exports.config.name,
    message: guess < secret ? getText("higher", guess, triesLeft) : getText("lower", guess, triesLeft),
    state: { author: senderID, secret, triesLeft },
    timeoutText: getText("timeout", secret)
  });
};
