module.exports.config = {
  name: "microsay",
  version: "1.0.0",
  permission: 0,
  credits: "mainmirai",
  prefix: true,
  description: "short text to speech in 10 languages",
  category: "with prefix",
  premium: false,
  usages: "microsay <language> <text>  |  microsay list",
  cooldowns: 5,
};

// the 10 supported languages, key is what the user types
const LANGUAGES = {
  en: { name: "English", code: "en" },
  tl: { name: "Filipino", code: "tl" },
  es: { name: "Spanish", code: "es" },
  ja: { name: "Japanese", code: "ja" },
  ko: { name: "Korean", code: "ko" },
  zh: { name: "Chinese", code: "zh-CN" },
  fr: { name: "French", code: "fr" },
  de: { name: "German", code: "de" },
  ru: { name: "Russian", code: "ru" },
  hi: { name: "Hindi", code: "hi" },
};

// google's tts endpoint rejects anything longer than this
const MAX_LENGTH = 200;

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID } = event;
  const { createReadStream, unlinkSync, existsSync } = global.nodemodule["fs-extra"];
  const { resolve } = global.nodemodule["path"];

  const listText =
    `microsay supported languages :\n\n` +
    Object.keys(LANGUAGES)
      .map((key) => `${key} - ${LANGUAGES[key].name}`)
      .join("\n") +
    `\n\nexample : microsay en hello`;

  const option = (args[0] || "").toLowerCase();

  if (!option || option === "list" || option === "help") {
    return api.sendMessage(listText, threadID, messageID);
  }

  if (!LANGUAGES[option]) {
    return api.sendMessage(
      `"${args[0]}" is not a supported language\n\n${listText}`,
      threadID,
      messageID
    );
  }

  const language = LANGUAGES[option];

  // take the text from the replied message when the user only gives a language
  let text = args.slice(1).join(" ").trim();
  if (!text && event.type === "message_reply") text = (event.messageReply.body || "").trim();

  if (!text) {
    return api.sendMessage(
      `please give me something to say\n\nexample : microsay ${option} hello`,
      threadID,
      messageID
    );
  }

  if (text.length > MAX_LENGTH) {
    return api.sendMessage(
      `microsay is for short text only, please keep it under ${MAX_LENGTH} characters (yours is ${text.length})`,
      threadID,
      messageID
    );
  }

  const path = resolve(__dirname, "cache", `microsay_${threadID}_${event.senderID}.mp3`);

  try {
    const url =
      `https://translate.google.com/translate_tts?ie=UTF-8` +
      `&q=${encodeURIComponent(text)}&tl=${language.code}&client=tw-ob`;
    await global.utils.downloadFile(url, path);

    return api.sendMessage(
      { body: `[ ${language.name} ] ${text}`, attachment: createReadStream(path) },
      threadID,
      () => {
        if (existsSync(path)) unlinkSync(path);
      },
      messageID
    );
  } catch (error) {
    if (existsSync(path)) unlinkSync(path);
    return api.sendMessage("i can't generate the voice message right now, please try again", threadID, messageID);
  }
};
