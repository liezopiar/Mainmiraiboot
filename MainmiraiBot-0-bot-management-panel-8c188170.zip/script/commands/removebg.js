const axios = require("axios");
const FormData = require("form-data");
const fs = require("fs-extra");
const path = require("path");
const { Jimp, CACHE_DIR, collectPhotos, humanSize, scheduleCleanup } = require("../utils/imageTools");

module.exports.config = {
  name: "removebg",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Remove the background of a photo and return a transparent PNG",
  prefix: true,
  premium: true,
  category: "premium",
  usages: "[reply to photo] (tolerance 1-100)",
  cooldowns: 15
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const MAX_SIDE = 1600;

/** remove.bg — best quality, used when the owner set REMOVE_BG_API_KEY. */
async function viaRemoveBg(buffer) {
  const key = process.env.REMOVE_BG_API_KEY;
  if (!key) return null;

  const form = new FormData();
  form.append("image_file", buffer, { filename: "input.jpg", contentType: "image/jpeg" });
  form.append("size", "auto");
  form.append("format", "png");

  const { data } = await axios.post("https://api.remove.bg/v1.0/removebg", form, {
    headers: { ...form.getHeaders(), "X-Api-Key": key },
    responseType: "arraybuffer",
    timeout: 90000
  });

  return { buffer: Buffer.from(data), engine: "remove.bg" };
}

/** Clipdrop — second cloud option, used when CLIPDROP_API_KEY exists. */
async function viaClipdrop(buffer) {
  const key = process.env.CLIPDROP_API_KEY;
  if (!key) return null;

  const form = new FormData();
  form.append("image_file", buffer, { filename: "input.jpg", contentType: "image/jpeg" });

  const { data } = await axios.post("https://clipdrop-api.co/remove-background/v1", form, {
    headers: { ...form.getHeaders(), "x-api-key": key },
    responseType: "arraybuffer",
    timeout: 90000
  });

  return { buffer: Buffer.from(data), engine: "clipdrop" };
}

function colorAt(bitmap, x, y) {
  const index = (bitmap.width * y + x) << 2;
  return [bitmap.data[index], bitmap.data[index + 1], bitmap.data[index + 2]];
}

function distance(a, b) {
  return Math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2);
}

/**
 * Offline fallback: flood fill inward from the four edges and clear every pixel
 * that stays close to the edge colour. Works well on plain or studio backgrounds.
 */
async function viaFloodFill(buffer, tolerance) {
  const image = await Jimp.read(buffer);

  if (Math.max(image.bitmap.width, image.bitmap.height) > MAX_SIDE) {
    if (image.bitmap.width >= image.bitmap.height) image.resize(MAX_SIDE, Jimp.AUTO);
    else image.resize(Jimp.AUTO, MAX_SIDE);
  }

  const bitmap = image.bitmap;
  const { width, height } = bitmap;
  const limit = (tolerance / 100) * 200; // colour distance threshold
  const visited = new Uint8Array(width * height);
  const stack = [];

  for (let x = 0; x < width; x++) {
    stack.push([x, 0], [x, height - 1]);
  }
  for (let y = 0; y < height; y++) {
    stack.push([0, y], [width - 1, y]);
  }

  // average the corners so a slight gradient does not break the match
  const seeds = [
    colorAt(bitmap, 0, 0),
    colorAt(bitmap, width - 1, 0),
    colorAt(bitmap, 0, height - 1),
    colorAt(bitmap, width - 1, height - 1)
  ];

  while (stack.length) {
    const [x, y] = stack.pop();
    if (x < 0 || y < 0 || x >= width || y >= height) continue;

    const flat = width * y + x;
    if (visited[flat]) continue;
    visited[flat] = 1;

    const pixel = colorAt(bitmap, x, y);
    if (!seeds.some(seed => distance(pixel, seed) <= limit)) continue;

    bitmap.data[(flat << 2) + 3] = 0;
    stack.push([x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]);
  }

  return { buffer: await image.getBufferAsync(Jimp.MIME_PNG), engine: "edge flood fill" };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const [url] = collectPhotos(event, 1);

  if (!url) {
    return api.sendMessage(
      `⚠️ reply to a photo then send ${prefix}removebg\n\n` +
        `you can pass a tolerance for plain backgrounds : ${prefix}removebg 25`,
      threadID,
      messageID
    );
  }

  const tolerance = Math.min(100, Math.max(1, parseInt(args[0], 10) || 18));
  const loading = await api.sendMessage("✂️ removing the background...", threadID, messageID);

  try {
    const source = await axios.get(url, {
      responseType: "arraybuffer",
      headers: { "User-Agent": UA },
      timeout: 60000
    });
    const input = Buffer.from(source.data);

    let result = null;
    for (const attempt of [viaRemoveBg, viaClipdrop]) {
      try {
        result = await attempt(input);
        if (result) break;
      } catch {
        result = null;
      }
    }

    if (!result) result = await viaFloodFill(input, tolerance);

    await fs.ensureDir(CACHE_DIR);
    const file = path.join(CACHE_DIR, `nobg_${Date.now()}.png`);
    await fs.writeFile(file, result.buffer);

    api.unsendMessage(loading.messageID);

    const note =
      result.engine === "edge flood fill"
        ? "\n\ntip : this offline mode works best on plain backgrounds. raise the tolerance if leftovers remain."
        : "";

    return api.sendMessage(
      {
        body:
          "✂️ 𝗕𝗔𝗖𝗞𝗚𝗥𝗢𝗨𝗡𝗗 𝗥𝗘𝗠𝗢𝗩𝗘𝗗\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━\n" +
          `engine : ${result.engine}\n` +
          `file   : ${humanSize(result.buffer.length)} png` +
          note,
        attachment: fs.createReadStream(file)
      },
      threadID,
      () => scheduleCleanup(file, 5000),
      messageID
    );
  } catch (error) {
    api.unsendMessage(loading.messageID);
    return api.sendMessage(
      `❌ failed to remove the background — ${error.message || "unknown error"}`,
      threadID,
      messageID
    );
  }
};
