const axios = require("axios");
const path = require("path");
const fs = require("fs-extra");

module.exports.config = {
  name: "clown",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Jonell Magallanes",
  description: "Generate a 4-step clown meme",
  premium: false,
  prefix: true,
  category: "media",
  usages: "[step1 | step2 | step3 | step4]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;

  try {
    const input = args.join(" ").trim();

    if (!input || !input.includes("|")) {
      return api.sendMessage(
        `please enter 4 steps separated by |.
example: ${prefix}clown The estimate is two days | I will start after lunch | I only need to change one file | It is now three weeks later`,
        threadID,
        messageID
      );
    }

    const steps = input.split("|").map(s => s.trim()).filter(Boolean);

    if (steps.length !== 4) {
      return api.sendMessage(
        `please enter exactly 4 steps.
example: ${prefix}clown step1 | step2 | step3 | step4`,
        threadID,
        messageID
      );
    }

    const [step1, step2, step3, step4] = steps;
    const lod = await api.sendMessage("please wait..", threadID, messageID);

    const apiUrl = `https://opiarnapi-v2-production.up.railway.app/api/meme-clown?step1=${encodeURIComponent(step1)}&step2=${encodeURIComponent(step2)}&step3=${encodeURIComponent(step3)}&step4=${encodeURIComponent(step4)}`;
    console.log(`Fetching clown meme from API: ${apiUrl}`);

    const imgResponse = await axios.get(apiUrl, {
      responseType: "arraybuffer",
      timeout: 30000,
      headers: {
        Accept: "image/png,image/*"
      }
    });

    const cacheDir = path.join(__dirname, "cache");
    await fs.ensureDir(cacheDir);

    const imgPath = path.join(cacheDir, `clown_${Date.now()}.png`);
    await fs.outputFile(imgPath, imgResponse.data);

    await api.sendMessage({
      body: `🤡 clown meme
1. ${step1}
2. ${step2}
3. ${step3}
4. ${step4}`,
      attachment: fs.createReadStream(imgPath)
    }, threadID, messageID);

    api.unsendMessage(lod.messageID);
    console.log(`clown meme successfully sent to thread ${threadID}`);

    await fs.remove(imgPath);
    console.log("clown cache file cleaned up.");

  } catch (error) {
    console.error("error fetching clown meme: ", error);
    return api.sendMessage(
      "An error occurred while generating the clown meme. Please try again later.",
      threadID,
      messageID
    );
  }
};
