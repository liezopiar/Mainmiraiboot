module.exports.config = {
	name: "addmoney",
	version: "1.0.0",
	permission: 2, // 0 = user, 1 = mod, 2 = admin
	credits: "ryuko",
	prefix: false,
	premium: false,
	description: "Add money to a user's balance (Admin only)",
	category: "without prefix",
	usages: "[@mention | reply | userID] [amount]",
	cooldowns: 5
};

module.exports.languages = {
	"english": {
		"invalidTarget": "❌ Tag a user, reply to their message, or provide a valid user ID.",
		"invalidAmount": "❌ Amount must be a positive number.\nUsage: addmoney @user [amount] (or reply to a message)",
		"success":       "✅ Added $%1 to %2's balance.\n💵 New balance: $%3"
	}
};

module.exports.run = async function({ api, event, args, Users, Currencies, getText }) {
	const { threadID, messageID, mentions } = event;

	// Resolve the target : reply first, then a tag, then a raw id
	let targetID;
	let targetName;
	let amountTokens = args.filter(a => a.charAt(0) !== "@");

	if (event.type === "message_reply" && event.messageReply) {
		// If the message is a reply, use the sender's ID of the replied message
		targetID = String(event.messageReply.senderID);
	} else if (args.join(" ").indexOf("@") !== -1 || Object.keys(mentions).length) {
		// If the message contains mentions, check if there is more than one mention
		const mentionedUsers = Object.keys(mentions);
		if (mentionedUsers.length > 1) {
			return api.sendMessage("❗ Tag only one user.", threadID, messageID);
		}
		if (mentionedUsers.length === 1) {
			targetID   = String(mentionedUsers[0]);
			targetName = String(Object.values(mentions)[0]).replace(/^@/, "");
		}
	}

	// remove the tagged name words so they can't be mistaken for the amount
	for (const label of Object.values(mentions)) {
		for (const word of String(label).replace(/^@/, "").trim().split(/\s+/).filter(Boolean)) {
			const at = amountTokens.findIndex(t => t.replace(/^@/, "") === word);
			if (at !== -1) amountTokens.splice(at, 1);
		}
	}

	if (!targetID) {
		const idIndex = amountTokens.findIndex(a => /^\d{10,}$/.test(a)); // FB IDs are long numbers
		if (idIndex === -1) return api.sendMessage(getText("invalidTarget"), threadID, messageID);
		targetID = String(amountTokens.splice(idIndex, 1)[0]);
	}

	if (!targetName) {
		try { targetName = await Users.getNameUser(targetID); }
		catch { targetName = `user ${targetID}`; }
	}

	// Find amount — first pure numeric token left after the target was removed
	const amount = parseInt(amountTokens.find(a => /^\d+$/.test(a)));
	if (isNaN(amount) || amount <= 0) {
		return api.sendMessage(getText("invalidAmount"), threadID, messageID);
	}

	// Add money and fetch new balance
	await Currencies.increaseMoney(targetID, amount);
	const updated    = await Currencies.getData(targetID);
	const newBalance = updated ? updated.money : amount;

	return api.sendMessage(
		getText("success", amount.toLocaleString(), targetName, newBalance.toLocaleString()),
		threadID,
		messageID
	);
};
