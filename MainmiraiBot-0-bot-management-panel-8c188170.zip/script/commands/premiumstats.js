const premiumUtil = require("../../main/utility/premium.js");

module.exports.config = {
  name: "premiumstats",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: true,
  premium: true,
  category: "premium",
  cooldowns: 10,
  aliases: ["premiuminfo", "premiumstatus"],
  description: "Overview of the whole premium system : members, expiring soon, codes and requests",
  usages: "premiumstats",
};

const DAY = 24 * 60 * 60 * 1000;

module.exports.run = async function ({ api, event, Users, permssion, prefix }) {
  const { threadID, messageID, senderID } = event;

  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const isStaff = permssion >= 2;
  const getName = async (id) => {
    try { return await Users.getNameUser(id); } catch { return "Facebook User"; }
  };

  const list = premiumUtil.getList();
  const permanent = list.filter(entry => !entry.expiresAt);
  const timed = list.filter(entry => entry.expiresAt);
  const expiringSoon = timed
    .filter(entry => Number(entry.expiresAt) - Date.now() <= 3 * DAY)
    .sort((a, b) => Number(a.expiresAt) - Number(b.expiresAt));
  const newestJoin = [...list].sort((a, b) => (b.addedAt || 0) - (a.addedAt || 0))[0] || null;

  const codes = premiumUtil.getCodes();
  const totalUses = codes.reduce((sum, code) => sum + (parseInt(code.uses, 10) || 0), 0);
  const requests = premiumUtil.getRequests();
  const denied = premiumUtil.getDenied();
  const onCooldown = denied.filter(record => premiumUtil.denyCooldown(record.userID).blocked).length;

  // premium-only commands taken straight off the live command list
  const commands = (global.client && global.client.commands) || new Map();
  const premiumCommands = new Set(
    [...commands.values()]
      .filter(cmd => cmd && cmd.config && cmd.config.premium && cmd.config.name)
      .map(cmd => cmd.config.name)
  );

  const mine = premiumUtil.find(senderID);
  const mineLabel = mine ? premiumUtil.formatRemaining(mine.expiresAt) : "staff access";

  const soonLines = [];
  for (const entry of expiringSoon.slice(0, 5)) {
    const name = await getName(entry.userID);
    const you = String(entry.userID) === String(senderID) ? " ← you" : "";
    soonLines.push(`• ${name}${you} — ${premiumUtil.formatRemaining(entry.expiresAt)}`);
  }

  let newestLabel = "—";
  if (newestJoin && newestJoin.addedAt) {
    const name = await getName(newestJoin.userID);
    newestLabel = `${name} (${new Date(newestJoin.addedAt).toLocaleDateString()})`;
  }

  return api.sendMessage(
    `📊 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗦𝗧𝗔𝗧𝗦\n` +
    `━━━━━━━━━━━━━━━\n` +
    `👥 members : ${list.length}\n` +
    `♾️ permanent : ${permanent.length}\n` +
    `⏳ timed : ${timed.length}\n` +
    `⚠️ expiring in 3 days : ${expiringSoon.length}\n` +
    `🆕 newest member : ${newestLabel}\n` +
    `🔓 premium commands : ${premiumCommands.size}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `⭐ your time left : ${mineLabel}\n` +
    (soonLines.length ? `━━━━━━━━━━━━━━━\n⚠️ 𝗘𝗫𝗣𝗜𝗥𝗜𝗡𝗚 𝗦𝗢𝗢𝗡\n${soonLines.join("\n")}\n` : "") +
    (isStaff
      ? `━━━━━━━━━━━━━━━\n` +
        `🛠️ 𝗦𝗧𝗔𝗙𝗙 𝗩𝗜𝗘𝗪\n` +
        `🎟️ active codes : ${codes.length} (${totalUses} uses left)\n` +
        `📩 pending requests : ${requests.length}\n` +
        `🚫 on deny cooldown : ${onCooldown}\n` +
        `use ${prefix}premium pending and ${prefix}redeem codes for details\n`
      : "") +
    `━━━━━━━━━━━━━━━\n` +
    `${prefix}premiumperks • ${prefix}premiumlist • ${prefix}premiumgift`,
    threadID, messageID
  );
};
