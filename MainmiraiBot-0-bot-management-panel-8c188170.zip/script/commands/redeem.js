const premiumUtil = require("../../main/utility/premium.js");
const fancyfont = require("../../main/utility/fancyfont.js");

module.exports.config = {
  name: "redeem",
  version: "2.0.0",
  permission: 0,
  credits: "ryuko",
  // works both as "redeem <code>" and "<prefix>redeem <code>"
  prefix: false,
  // left open on purpose : a non premium user has to be able to redeem a code
  premium: false,
  category: "premium",
  cooldowns: 10,
  description: "Redeem a premium code, or create and manage codes as an operator",
  usages: "redeem <code> | redeem create [duration] [uses] | redeem codes | redeem delete <code> | redeem examples",
};

// operator sub commands, everything else is treated as a code being redeemed
const ACTIONS = {
  create: ["create", "gen", "generate", "new", "make"],
  list: ["codes", "list", "code"],
  remove: ["delete", "remove", "rm", "del"],
  clear: ["clear", "purge", "cleanup"],
  examples: ["examples", "example", "durations", "duration", "help"],
};

const isAction = (group, value) => ACTIONS[group].includes(value);

// duration cheat sheet shown to operators (3m = 3 minutes, 1 months = 30 days)
const DURATION_EXAMPLES = [
  ["3m", "3 minutes (great for testing)"],
  ["1d", "1 day"],
  ["2d", "2 days"],
  ["3d", "3 days"],
  ["4d", "4 days"],
  ["5d", "5 days"],
  ["1 months", "1 month (30 days)"],
  ["perm", "never expires"],
];

function examplesText(prefix) {
  return (
    `🧾 𝗥𝗘𝗗𝗘𝗘𝗠 𝗖𝗥𝗘𝗔𝗧𝗘 𝗘𝗫𝗔𝗠𝗣𝗟𝗘𝗦\n` +
    `━━━━━━━━━━━━━━━\n` +
    `format : ${prefix}redeem create [duration] [uses]\n\n` +
    DURATION_EXAMPLES.map(([d, label]) => `• ${prefix}redeem create ${d} → ${label}`).join("\n") +
    `\n\nmulti use codes (add the use count last) :\n` +
    `• ${prefix}redeem create 1d 5 → 1 day, 5 people\n` +
    `• ${prefix}redeem create 1 months 10 → 1 month, 10 people\n` +
    `• ${prefix}redeem create 3m 3 → 3 minutes, 3 people\n\n` +
    `mixed units also work : 1d12h, 2d6h, 1w2d\n` +
    `note : m = minutes, h = hours, d = days, w = weeks, months = 30 days`
  );
}

function durationLabel(duration) {
  if (!duration) return "permanent";
  const parsed = premiumUtil.parseDuration(duration);
  return parsed ? parsed.label : String(duration);
}

module.exports.run = async function ({ api, event, args, Users, permssion, prefix }) {
  const { threadID, messageID, senderID } = event;

  if (!global.config.premium) {
    return api.sendMessage("⚠️ Premium system is not enabled on this bot.", threadID, messageID);
  }

  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const action = (args[0] || "").toLowerCase();
  const isOperator = permssion == 3;
  const denied = "⛔ Only bot operators can manage premium codes.";

  // ── operator : duration cheat sheet ─────────────────────────────────────────
  if (isAction("examples", action)) {
    if (!isOperator) return api.sendMessage(menuText(prefix, false), threadID, messageID);
    return api.sendMessage(examplesText(prefix), threadID, messageID);
  }

  // ── operator : create a code ────────────────────────────────────────────────
  if (isAction("create", action)) {
    if (!isOperator) return api.sendMessage(denied, threadID, messageID);

    const rest = args.slice(1);
    if (!rest.length) {
      return api.sendMessage(`❗ Please include a duration.\n\n${examplesText(prefix)}`, threadID, messageID);
    }

    // the trailing number is the use count, everything before it is the duration
    let uses = 1;
    if (rest.length > 1 && !isNaN(rest[rest.length - 1])) uses = parseInt(rest.pop(), 10);
    const duration = rest.join(" ").trim() || null;

    let record;
    try {
      record = premiumUtil.createCode({ duration, uses, createdBy: senderID });
    } catch (error) {
      return api.sendMessage(`❗ Invalid duration "${duration}".\n\n${examplesText(prefix)}`, threadID, messageID);
    }

    // fancyfont.raw keeps the code in plain ascii, a styled code cannot be
    // copied back into a working "redeem <code>" message
    return api.sendMessage(
      `🎟️ Premium code created\n` +
      `━━━━━━━━━━━━━━━\n` +
      `🔑 ${fancyfont.raw(record.code)}\n` +
      `⏳ grants : ${durationLabel(record.duration)}\n` +
      `🔁 uses : ${record.uses}\n` +
      `━━━━━━━━━━━━━━━\n` +
      `share it, then the user types :\n` +
      `${fancyfont.raw(`${prefix}redeem ${record.code}`)}`,
      threadID, messageID
    );
  }

  // ── operator : list codes ──────────────────────────────────────────────────
  if (isAction("list", action)) {
    if (!isOperator) return api.sendMessage(denied, threadID, messageID);

    const codes = premiumUtil.getCodes();
    if (!codes.length) {
      return api.sendMessage(
        `📭 There are no premium codes yet.\ncreate one with : ${prefix}redeem create 7d 1`,
        threadID, messageID
      );
    }

    const lines = codes.map(entry => {
      const left = parseInt(entry.uses, 10) || 0;
      const status = left > 0 ? `🔁 ${left} left` : `🚫 used up`;
      return `🔑 ${fancyfont.raw(entry.code)}\n   ⏳ ${durationLabel(entry.duration)}  •  ${status}  •  ✅ claimed ${(entry.usedBy || []).length}x`;
    });

    return api.sendMessage(
      `🎟️ Premium codes (${codes.length}) :\n\n${lines.join("\n\n")}\n\n` +
      `${prefix}redeem delete <code>\n${prefix}redeem clear - remove used up codes`,
      threadID, messageID
    );
  }

  // ── operator : delete a code ───────────────────────────────────────────────
  if (isAction("remove", action)) {
    if (!isOperator) return api.sendMessage(denied, threadID, messageID);

    const code = args.slice(1).join(" ").trim();
    if (!code) return api.sendMessage(`❗ Usage : ${prefix}redeem delete <code>`, threadID, messageID);
    const pretty = premiumUtil.formatCode(code) || code;
    return api.sendMessage(
      premiumUtil.removeCode(code)
        ? `🗑️ Deleted code ${fancyfont.raw(pretty)}.`
        : `⚠️ Code ${fancyfont.raw(pretty)} was not found.`,
      threadID, messageID
    );
  }

  // ── operator : purge spent codes ────────────────────────────────────────────
  if (isAction("clear", action)) {
    if (!isOperator) return api.sendMessage(denied, threadID, messageID);
    const purged = premiumUtil.clearUsedCodes();
    return api.sendMessage(
      purged ? `🧹 Removed ${purged} used up code(s).` : "📭 There are no used up codes to remove.",
      threadID, messageID
    );
  }

  // ── everyone : redeem a code ───────────────────────────────────────────────
  // the whole argument list is joined, so a pasted code with spaces or styled
  // unicode characters ("𝙿𝚁𝙴𝙼 𝙰7𝙺2 9𝚇𝚀4") still resolves to the real code
  const typed = args.join(" ").trim();
  if (!typed) return api.sendMessage(menuText(prefix, isOperator), threadID, messageID);

  if (!premiumUtil.looksLikeCode(typed)) {
    return api.sendMessage(
      `❓ "${typed}" is not a premium code or a known option.\n\n${menuText(prefix, isOperator)}`,
      threadID, messageID
    );
  }

  const result = premiumUtil.redeemCode(typed, senderID);

  if (!result.ok) {
    const pretty = premiumUtil.formatCode(typed) || typed;
    const reasons = {
      notfound:
        `❌ Code ${fancyfont.raw(pretty)} does not exist.\n` +
        `• check for missing or extra characters\n` +
        `• codes look like ${fancyfont.raw("PREM-A7K2-9XQ4")}\n` +
        `• ask the operator to resend it with ${prefix}redeem codes`,
      used: `⚠️ Code ${fancyfont.raw(pretty)} has already reached its use limit.`,
      already:
        `⚠️ You already redeemed this code.\n` +
        `check your remaining time with : ${prefix}premium check`,
      duration: `❌ That code was created with an unreadable duration, please ask the operator to make a new one.`,
    };
    return api.sendMessage(reasons[result.reason] || "❌ That code could not be redeemed.", threadID, messageID);
  }

  let name = "Facebook User";
  try { name = await Users.getNameUser(senderID); } catch {}

  // let the operators know a code was claimed
  for (const opID of global.config.operators || []) {
    api.sendMessage(`🎟️ ${name} (${senderID}) redeemed ${fancyfont.raw(result.code)} → ${result.label}`, opID);
  }

  return api.sendMessage(
    `⭐ Code redeemed. Premium ${result.extended ? "extended" : "activated"}.\n` +
    `⏳ time left : ${result.label}\n` +
    `type ${prefix}premiumperks to see what you unlocked.`,
    threadID, messageID
  );
};

function menuText(prefix, isOperator) {
  return (
    `🎟️ 𝗥𝗘𝗗𝗘𝗘𝗠\n` +
    `━━━━━━━━━━━━━━━\n` +
    `${prefix}redeem <code> - claim premium with a code\n` +
    `example : ${fancyfont.raw(`${prefix}redeem PREM-A7K2-9XQ4`)}\n` +
    (isOperator
      ? `━━━━━━━━━━━━━━━\n` +
        `${prefix}redeem create [duration] [uses] - make a code\n` +
        `${prefix}redeem codes - list every code\n` +
        `${prefix}redeem delete <code> - delete a code\n` +
        `${prefix}redeem clear - remove used up codes\n` +
        `${prefix}redeem examples - duration cheat sheet\n` +
        `━━━━━━━━━━━━━━━\n` +
        `📌 quick examples :\n` +
        `${prefix}redeem create 3m\n` +
        `${prefix}redeem create 1d\n` +
        `${prefix}redeem create 1 months\n` +
        `${prefix}redeem create 1d 5  (5 uses)\n`
      : "") +
    `━━━━━━━━━━━━━━━\n` +
    `no code yet ? type ${prefix}requestpremium`
  );
}
