module.exports.config = {
	name: "group",
	version: "0.1.0",
	permission: 2,
	credits: "ryuko",
	prefix: true,
  premium: false,
	description: "ban or unban a group",
	category: "admin",
	usages: "[ban/unban/search/list/info] [group id] [reason]",
	cooldowns: 5
};

const moment = require("moment-timezone");

// facebook pads mention labels with invisible characters, strip them so a
// pasted id or a typed reason compares cleanly
const clean = (text) => String(text == null ? "" : text).replace(/[\u200B-\u200D\u2063\uFEFF]/g, "").trim();

const now = () => moment.tz("Asia/Manila").format("HH:mm:ss DD/MM/YYYY");

const GUIDE = [
	"group - usage",
	"",
	"group ban raiding            (bans this group)",
	"group ban 100098765432 spam",
	"group ban 100098765432",
	"group unban 100098765432",
	"group list / group info 100098765432",
	"group search <name>",
	"",
	"bans are permanent until you unban the group"
].join("\n");

/**
 * pick the group id out of the args.
 * the id is optional, leaving it out targets the current thread, so
 * "group ban spam" and "group ban 100098765432 spam" both work.
 */
function resolveGroup(args, threadID) {
	let targetID = String(threadID);
	const leftover = [];

	for (const token of (args || [])) {
		// a bare long number is the group id
		if (targetID === String(threadID) && /^\d{5,}$/.test(clean(token))) {
			targetID = clean(token);
			continue;
		}
		leftover.push(token);
	}

	return { targetID, reason: clean(leftover.join(" ")) || null };
}

module.exports.handleReaction = async ({ event, api, Threads, handleReaction, botid }) => {
	if (parseInt(event.userID) !== parseInt(handleReaction.author)) return;

	const { type, target: targetID, reason, messageID } = handleReaction;
	// handleReaction is a Map keyed by bot id, the pending list lives inside it
	const pending = global.client.handleReaction.get(botid) || [];
	const index = pending.findIndex(item => item.messageID == messageID);
	if (index !== -1) pending.splice(index, 1);

	switch (type) {
		case "ban": {
			const data = (await Threads.getData(targetID)).data || {};
			data.banned = 1;
			data.reason = reason || "no reason given";
			data.dateAdded = now();
			await Threads.setData(targetID, { data });
			// the key has to be a string : handleCommand looks the ban up with the
			// raw event threadID, so the old parseInt key never matched and the ban
			// silently did nothing
			global.data.threadBanned.set(String(targetID), {
				reason: data.reason,
				dateAdded: data.dateAdded
			});
			api.sendMessage(`successfully banned group id ${targetID}\nreason : ${data.reason}`, event.threadID, () => api.unsendMessage(messageID));
			break;
		}
		case "unban": {
			const data = (await Threads.getData(targetID)).data || {};
			data.banned = 0;
			data.reason = null;
			data.dateAdded = null;
			await Threads.setData(targetID, { data });
			global.data.threadBanned.delete(String(targetID));
			// older commands stored the key as a number, clear that form too
			global.data.threadBanned.delete(parseInt(targetID));
			api.sendMessage(`successfully unbanned group id ${targetID}`, event.threadID, () => api.unsendMessage(messageID));
			break;
		}
		default:
			break;
	}
}

module.exports.run = async ({ event, api, args, Threads, botid }) => {
	const { threadID, messageID, senderID } = event;
	const sub = (args[0] || "").toLowerCase();
	const rest = args.slice(1);
	const reply = (msg) => api.sendMessage(msg, threadID, messageID);

	switch (sub) {
		case "ban": {
			const { targetID, reason } = resolveGroup(rest, threadID);

			const dataThread = await Threads.getData(targetID);
			if (!dataThread) return reply(`thread does not exist in database\ngroup id : ${targetID}`);

			const existing = global.data.threadBanned.get(String(targetID)) || global.data.threadBanned.get(parseInt(targetID));
			if (existing && typeof existing === "object") {
				return reply([
					`already banned group id ${targetID}`,
					`reason : ${existing.reason || "none"}`,
					`since : ${existing.dateAdded || "unknown"}`
				].join("\n"));
			}
			if (existing) return reply(`already banned group id ${targetID}`);

			let groupName = "unknown";
			try {
				groupName = (global.data.threadInfo.get(String(targetID)) || await Threads.getInfo(targetID)).threadName || "unknown";
			} catch (e) { /* the name is cosmetic */ }

			return api.sendMessage([
				`do you want to ban this group?`,
				`group : ${groupName} (${targetID})`,
				`reason : ${reason || "no reason given"}`,
				``,
				`react to this message to confirm`
			].join("\n"), threadID, (error, message) => {
				if (error || !message) return;
				global.client.handleReaction.get(botid).push({
					name: this.config.name,
					messageID: message.messageID,
					author: senderID,
					type: "ban",
					target: String(targetID),
					reason
				});
			}, messageID);
		}

		case "unban": {
			const { targetID } = resolveGroup(rest, threadID);

			const dataThread = await Threads.getData(targetID);
			if (!dataThread) return reply(`thread does not exist in the database\ngroup id : ${targetID}`);

			const banned = global.data.threadBanned.has(String(targetID)) || global.data.threadBanned.has(parseInt(targetID));
			if (!banned) return reply(`[${targetID}] not banned before`);

			return api.sendMessage(`do you want to unban group id ${targetID}?\n\nreact to this message to confirm`, threadID, (error, message) => {
				if (error || !message) return;
				global.client.handleReaction.get(botid).push({
					name: this.config.name,
					messageID: message.messageID,
					author: senderID,
					type: "unban",
					target: String(targetID)
				});
			}, messageID);
		}

		case "list": {
			if (global.data.threadBanned.size === 0) return reply("no groups are banned right now.");
			const lines = [];
			for (const [id, record] of global.data.threadBanned) {
				const info = (record && typeof record === "object") ? record : {};
				const name = (global.data.threadInfo.get(String(id)) || {}).threadName || "unknown";
				lines.push(`${lines.length + 1}. ${name} (${id})\n   reason : ${info.reason || "none"}`);
				if (lines.length >= 20) break;
			}
			return reply(`banned groups (${global.data.threadBanned.size})\n\n${lines.join("\n")}`);
		}

		case "info": {
			const { targetID } = resolveGroup(rest, threadID);
			const record = global.data.threadBanned.get(String(targetID)) || global.data.threadBanned.get(parseInt(targetID));
			if (!record) return reply(`group ${targetID} is not banned.`);
			const info = (record && typeof record === "object") ? record : {};
			const name = (global.data.threadInfo.get(String(targetID)) || {}).threadName || "unknown";
			return reply([
				`group : ${name} (${targetID})`,
				`banned : YES`,
				`reason : ${info.reason || "none"}`,
				`since : ${info.dateAdded || "unknown"}`
			].join("\n"));
		}

		case "search": {
			const contentJoin = rest.join(" ");
			const getThreads = (await Threads.getAll(['threadID', 'name'])).filter(item => !!item.name);
			const matchThreads = [];
			let a = '', b = 0;
			getThreads.forEach(i => {
				if (i.name.toLowerCase().includes(contentJoin.toLowerCase())) {
					matchThreads.push({ name: i.name, id: i.threadID });
				}
			});
			matchThreads.forEach(i => a += `\n${b += 1}. ${i.name} - ${i.id}`);
			return (matchThreads.length > 0) ? reply(`here's the match : \n${a}`) : reply("no results found based on your search");
		}

		default:
			return reply(GUIDE);
	}
}
