module.exports.config = {
  name: "leaderboard",
  version: "1.1.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Show top users (money) or top groups (activity)",
  category: "economy",
  usages: "[user | group]",
  cooldowns: 10
};

module.exports.languages = {
  "english": {
    "userHeader":  "🏆 TOP 10 RICHEST USERS 🏆\n━━━━━━━━━━━━━━━━━━━━\n",
    "userEntry":   "%1 %2. %3\n    💰 $%4\n",
    "userFooter":  "━━━━━━━━━━━━━━━━━━━━\n📊 Your rank: #%1 | 💵 $%2",
    "userEmpty":   "📭 No users with a balance found yet.",
    "groupHeader": "🏆 TOP 10 ACTIVE GROUPS 🏆\n━━━━━━━━━━━━━━━━━━━━\n",
    "groupEntry":  "%1 %2. %3\n    👥 %4 members | 💬 %5 messages\n",
    "groupFooter": "━━━━━━━━━━━━━━━━━━━━\n📊 This group's rank: #%1",
    "groupEmpty":  "📭 No group data found yet.",
    "norank":      "unranked"
  }
};

// Medals for top 3 — kept as a plain constant, NOT inside getText
const MEDALS = ["🥇", "🥈", "🥉"];

/** Top 10 richest users, plus the sender's own rank. */
async function userBoard({ api, event, Currencies, Users, getText }) {
  const { threadID, messageID, senderID } = event;

  const allUsers = await Currencies.getAll();

  const sorted = (allUsers || [])
    .filter(u => (u.money || 0) > 0)
    .sort((a, b) => (b.money || 0) - (a.money || 0));

  if (sorted.length === 0) {
    return api.sendMessage(getText("userEmpty"), threadID, messageID);
  }

  const top10 = sorted.slice(0, 10);

  // Fetch display names from Users table for the top 10
  const nameMap = {};
  await Promise.all(top10.map(async (u) => {
    try {
      const info = await Users.getData(String(u.userID));
      nameMap[String(u.userID)] = (info && info.name) ? info.name : `ID:${String(u.userID).slice(-6)}`;
    } catch (_) {
      nameMap[String(u.userID)] = `ID:${String(u.userID).slice(-6)}`;
    }
  }));

  let msg = getText("userHeader");

  top10.forEach((user, i) => {
    const medal = MEDALS[i] || `${i + 1}.`;
    const name  = (nameMap[String(user.userID)] || `ID:${String(user.userID).slice(-6)}`).slice(0, 20);
    msg += getText("userEntry", medal, i + 1, name, (user.money || 0).toLocaleString());
  });

  // Sender's own rank — compare as strings to avoid BigInt vs string mismatch
  const senderRank = sorted.findIndex(u => String(u.userID) === String(senderID)) + 1;
  const senderData = await Currencies.getData(senderID);
  const senderBal  = (senderData && senderData.money ? senderData.money : 0).toLocaleString();

  msg += getText("userFooter", senderRank > 0 ? senderRank : getText("norank"), senderBal);

  return api.sendMessage(msg, threadID, messageID);
}

/** Top 10 groups ranked by message count, with member count shown. */
async function groupBoard({ api, event, Threads, getText }) {
  const { threadID, messageID } = event;

  const allThreads = await Threads.getAll();

  const groups = (allThreads || [])
    .map(t => {
      const info = t.threadInfo || {};
      const members = Array.isArray(info.participantIDs)
        ? info.participantIDs.length
        : (info.memberCount || 0);
      return {
        threadID: String(t.threadID),
        name: (info.threadName || `ID:${String(t.threadID).slice(-6)}`).slice(0, 25),
        members,
        messages: info.messageCount || 0
      };
    })
    // only real groups with at least some data
    .filter(g => g.members > 0 || g.messages > 0)
    .sort((a, b) => (b.messages - a.messages) || (b.members - a.members));

  if (groups.length === 0) {
    return api.sendMessage(getText("groupEmpty"), threadID, messageID);
  }

  const top10 = groups.slice(0, 10);

  let msg = getText("groupHeader");

  top10.forEach((g, i) => {
    const medal = MEDALS[i] || `${i + 1}.`;
    msg += getText("groupEntry", medal, i + 1, g.name, g.members.toLocaleString(), g.messages.toLocaleString());
  });

  // Rank of the group the command was used in
  const thisRank = groups.findIndex(g => g.threadID === String(threadID)) + 1;
  msg += getText("groupFooter", thisRank > 0 ? thisRank : getText("norank"));

  return api.sendMessage(msg, threadID, messageID);
}

module.exports.run = async function(ctx) {
  const { args } = ctx;
  const mode = (args[0] || "user").toLowerCase();

  if (mode === "group" || mode === "groups") return groupBoard(ctx);
  return userBoard(ctx);
};
