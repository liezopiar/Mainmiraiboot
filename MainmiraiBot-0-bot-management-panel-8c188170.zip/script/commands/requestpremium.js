const premiumUtil = require("../../main/utility/premium.js");

module.exports.config = {
  name: "requestpremium",
  version: "2.1.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  category: "system",
  // a 100s cooldown also blocked "status" and "cancel", and the handler answers
  // a cooldown with a silent 🕚 reaction only, which looked like a dead command
  cooldowns: 10,
  description: "Send a premium access request to the bot operators",
  usages: "requestpremium [reason] | requestpremium status | requestpremium cancel",
};

const MIN_REASON = 5;

function menuText(prefix = "") {
  return (
    `📩 𝗥𝗘𝗤𝗨𝗘𝗦𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠\n` +
    `━━━━━━━━━━━━━━━\n` +
    `${prefix}requestpremium [reason] - ask the operators for access\n` +
    `${prefix}requestpremium status - check your request\n` +
    `${prefix}requestpremium cancel - take back your request\n` +
    `━━━━━━━━━━━━━━━\n` +
    `📌 examples :\n` +
    `${prefix}requestpremium gusto ko subukan ang ai commands\n` +
    `${prefix}requestpremium active daily user of the bot\n` +
    `━━━━━━━━━━━━━━━\n` +
    `already have a code ? use : ${prefix}redeem <code>`
  );
}

module.exports.run = async function ({ api, event, args, Users, prefix = "", admin }) {
  const { threadID, messageID, senderID } = event;

  if (!global.config.premium) {
    return api.sendMessage("⚠️ Premium system is not enabled on this bot.", threadID, messageID);
  }

  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const action = (args[0] || "").toLowerCase();

  // already premium ? no need to queue anything
  const current = premiumUtil.find(senderID);
  if (current && action !== "cancel") {
    return api.sendMessage(
      `⭐ You already have premium access.\n` +
      `⏳ time left : ${premiumUtil.formatRemaining(current.expiresAt)}\n` +
      `type ${prefix}premiumperks to see what you unlocked.`,
      threadID, messageID
    );
  }

  if (action === "cancel") {
    const removed = premiumUtil.removeRequest(senderID);
    return api.sendMessage(
      removed ? "🗑️ Your premium request has been cancelled." : "📭 You don't have a pending premium request.",
      threadID, messageID
    );
  }

  if (action === "status") {
    const request = premiumUtil.findRequest(senderID);
    if (!request) {
      const cooldown = premiumUtil.denyCooldown(senderID);
      if (cooldown.blocked) {
        return api.sendMessage(
          `⛔ Your last request was denied.\n` +
          (cooldown.record.reason ? `💬 reason : ${cooldown.record.reason}\n` : "") +
          `🕒 you can request again in ${premiumUtil.formatDuration(cooldown.msLeft)}`,
          threadID, messageID
        );
      }
      return api.sendMessage(`📭 You don't have a pending premium request.\n\n${menuText(prefix)}`, threadID, messageID);
    }

    const position = premiumUtil.requestPosition(senderID);
    return api.sendMessage(
      `⏳ Your request is still waiting for approval.\n` +
      `💬 reason : ${request.reason}\n` +
      `🔢 queue spot : ${position || "?"} of ${premiumUtil.getRequests().length}\n` +
      `🕒 sent : ${new Date(request.requestedAt).toLocaleString()}`,
      threadID, messageID
    );
  }

  // a denied user has to wait out the cooldown before asking again
  const cooldown = premiumUtil.denyCooldown(senderID);
  if (cooldown.blocked) {
    return api.sendMessage(
      `⛔ Your previous request was denied, so you can't send a new one yet.\n` +
      (cooldown.record.reason ? `💬 reason : ${cooldown.record.reason}\n` : "") +
      `🕒 try again in ${premiumUtil.formatDuration(cooldown.msLeft)}`,
      threadID, messageID
    );
  }

  const reason = args.join(" ").trim();
  if (!reason) return api.sendMessage(menuText(prefix), threadID, messageID);

  // a user pasting a redeem code in here should be pointed at the right command
  // instead of queueing a request nobody asked for
  if (premiumUtil.findCode(reason)) {
    return api.sendMessage(
      `🎟️ That looks like a premium code, redeem it instead :\n${prefix}redeem ${premiumUtil.formatCode(reason)}`,
      threadID, messageID
    );
  }

  if (reason.length < MIN_REASON) {
    return api.sendMessage(
      `❗ Please write a real reason (at least ${MIN_REASON} characters) so the operators can review it.\n\n${menuText(prefix)}`,
      threadID, messageID
    );
  }

  let username = "Facebook User";
  try { username = await Users.getNameUser(senderID); } catch {}

  try {
    const existing = premiumUtil.findRequest(senderID);
    premiumUtil.addRequest({ userID: senderID, name: username, reason, threadID });
    const position = premiumUtil.requestPosition(senderID);

    // notify operators and bot admins, and never let one failed dm abort the
    // request (a blocked / unreachable operator used to kill the whole reply)
    const staff = [...new Set([...(global.config.operators || []), ...(admin || [])].map(String))];
    for (const opID of staff) {
      try {
      api.sendMessage(
        `📩 Premium request${existing ? " (updated)" : ""}\n` +
        `━━━━━━━━━━━━━━━\n` +
        `👤 name : ${username}\n` +
        `🆔 user id : ${senderID}\n` +
        `💬 reason : ${reason}\n` +
        `🔢 queue spot : ${position || "?"}\n` +
        `🕒 sent : ${new Date().toLocaleString()}\n` +
        `━━━━━━━━━━━━━━━\n` +
        `${prefix}premium approve ${senderID} 7d\n` +
        `${prefix}premium deny ${senderID} [reason]\n` +
        `${prefix}premium pending - see the whole queue`,
        opID
      );
      } catch (e) { /* unreachable operator, keep going */ }
    }

    return api.sendMessage(
      (existing
        ? "✅ Your pending request has been updated and sent to the bot operators."
        : "✅ Your request has been sent to the bot operators.") +
      `\n🔢 queue spot : ${position || "?"}\n` +
      `check it anytime with : ${prefix}requestpremium status\n` +
      `cancel it with : ${prefix}requestpremium cancel\n` +
      `got a code from an operator ? use : ${prefix}redeem <code>`,
      threadID, messageID
    );
  } catch (error) {
    return api.sendMessage(`❌ Something went wrong while sending your request.\n${error.message}`, threadID, messageID);
  }
};
