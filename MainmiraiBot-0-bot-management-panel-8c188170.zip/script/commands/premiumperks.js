const premiumUtil = require("../../main/utility/premium.js");

module.exports.config = {
  name: "premiumperks",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: true,
  premium: true,
  category: "premium",
  cooldowns: 10,
  description: "Show your premium status and every perk plus premium-only command you unlocked",
  usages: "premiumperks",
};

module.exports.run = async function ({ api, event, Users, prefix }) {
  const { threadID, messageID, senderID } = event;

  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const entry = premiumUtil.find(senderID);
  let name = "Facebook User";
  try { name = await Users.getNameUser(senderID); } catch {}

  // staff reach this command through the gate bypass, so they may have no entry
  const since = entry && entry.addedAt ? new Date(entry.addedAt).toLocaleDateString() : "—";
  const left = entry ? premiumUtil.formatRemaining(entry.expiresAt) : "staff access";

  // read the premium commands straight off the loaded command list so this
  // never goes stale when a command is added or unmarked
  // the map also holds alias keys, so dedupe by the real command name
  const commands = (global.client && global.client.commands) || new Map();
  const premiumCommands = [...new Set(
    [...commands.values()]
      .filter(cmd => cmd && cmd.config && cmd.config.premium && cmd.config.name)
      .map(cmd => cmd.config.name)
  )].sort();

  const unlocked = premiumCommands.length
    ? premiumCommands.map(cmdName => `${prefix}${cmdName}`).join(", ")
    : "no premium-only commands are configured yet";

  const perks = [
    "🚀 access to every premium-only command",
    "⏱️ shorter waiting time between commands",
    "🎟️ redeem codes to extend your access anytime",
    "🔔 you get notified before your premium runs out",
    "🛠️ your reports and requests are looked at first",
    `🎁 you can gift your time to a friend with ${prefix}premiumgift`,
    `🎨 image studio : ${prefix}imgart ${prefix}imgtext ${prefix}imgmeme ${prefix}imgquote ${prefix}imgpfp ${prefix}imgposter`,
  ];

  return api.sendMessage(
    `⭐ 𝗬𝗢𝗨𝗥 𝗣𝗥𝗘𝗠𝗜𝗨𝗠\n` +
    `━━━━━━━━━━━━━━━\n` +
    `👤 ${name}\n` +
    `📅 member since : ${since}\n` +
    `⏳ time left : ${left}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `🎁 𝗣𝗘𝗥𝗞𝗦\n${perks.join("\n")}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `🔓 𝗨𝗡𝗟𝗢𝗖𝗞𝗘𝗗 (${premiumCommands.length})\n${unlocked}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `type ${prefix}redeem <code> to add more time.`,
    threadID, messageID
  );
};
