const fs = require("fs");
const { createBanner, THEMES, SIZES } = require("../utils/bannerMaker.js");

module.exports.config = {
  name: "banner",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Create a Facebook cover banner (gradient theme or a replied photo)",
  prefix: true,
  premium: false,
  category: "media",
  usages: "[title] | [subtitle] | [footer] -t <theme> -s <size>",
  cooldowns: 10
};

const guide = (prefix) =>
  "🎨 𝗕𝗔𝗡𝗡𝗘𝗥 𝗠𝗔𝗞𝗘𝗥\n" +
  "━━━━━━━━━━━━━━━━━━━━━━━\n" +
  `${prefix}banner Title | Subtitle | Footer\n\n` +
  "Options:\n" +
  "-t <theme>  → banner colors\n" +
  "-s <size>   → canvas size\n\n" +
  `Themes: ${Object.keys(THEMES).join(", ")}\n` +
  `Sizes: ${Object.keys(SIZES).join(", ")}\n\n` +
  "Tip: reply to a photo to use it as the background.\n" +
  `Example: ${prefix}banner Mainmirai Bot | 24/7 online -t neon`;

function parseArgs(args) {
  const flags = { theme: "midnight", size: "cover" };
  const words = [];

  for (let i = 0; i < args.length; i++) {
    const a = args[i].toLowerCase();
    if ((a === "-t" || a === "--theme") && args[i + 1]) {
      flags.theme = args[++i].toLowerCase();
    } else if ((a === "-s" || a === "--size") && args[i + 1]) {
      flags.size = args[++i].toLowerCase();
    } else {
      words.push(args[i]);
    }
  }

  const [title = "", subtitle = "", footer = ""] = words
    .join(" ")
    .split("|")
    .map((s) => s.trim());

  return { ...flags, title, subtitle, footer };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID, messageReply } = event;

  if (!args[0] || args[0].toLowerCase() === "help") {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const { title, subtitle, footer, theme, size } = parseArgs(args);

  if (!title) return api.sendMessage(guide(prefix), threadID, messageID);
  if (!THEMES[theme]) {
    return api.sendMessage(`⚠️ Unknown theme "${theme}".\nThemes: ${Object.keys(THEMES).join(", ")}`, threadID, messageID);
  }
  if (!SIZES[size]) {
    return api.sendMessage(`⚠️ Unknown size "${size}".\nSizes: ${Object.keys(SIZES).join(", ")}`, threadID, messageID);
  }

  const photo = messageReply?.attachments?.find((a) => a.type === "photo");

  api.setMessageReaction("🎨", messageID, () => {}, true);

  let filePath;
  try {
    filePath = await createBanner({
      title,
      subtitle,
      footer,
      theme,
      size,
      background: photo ? photo.url : null
    });

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          `✅ Banner ready!\n` +
          `📐 ${SIZES[size].label} • ${SIZES[size].width}x${SIZES[size].height}\n` +
          `🎨 ${photo ? "custom photo background" : `theme: ${theme}`}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to create the banner: ${error.message}`, threadID, messageID);
  } finally {
    if (filePath && fs.existsSync(filePath)) {
      setTimeout(() => fs.unlink(filePath, () => {}), 15000);
    }
  }
};
