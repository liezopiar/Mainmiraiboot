module.exports.config = {
  name: "allgroups",
  version: "2.0.0",
  permission: 2,
  credits: "ryuko",
  description: "all groups",
  prefix: true,
  premium: false,
  category: "admin",
  usages: "groups",
  cooldowns: 5,
};


module.exports.handleReply = async function({ api, event, args, Threads, handleReply }) {

  if (parseInt(event.senderID) !== parseInt(handleReply.author)) return;

  var arg = event.body.split(" ");
  var idgr = handleReply.groupid[arg[1] - 1];


  switch (handleReply.type) {

    case "reply":
      {
        if (arg[0] == "ban" || arg[0] == "Ban") {
          const data = (await Threads.getData(idgr)).data || {};
          data.banned = 1;
          data.reason = "banned from the group list";
          data.dateAdded = require("moment-timezone").tz("Asia/Manila").format("HH:mm:ss DD/MM/YYYY");
          await Threads.setData(idgr, { data });
          // string key : handleCommand looks the ban up with the raw event
          // threadID, so the old numeric key never matched and the ban did nothing
          global.data.threadBanned.set(String(idgr), {
            reason: data.reason,
            dateAdded: data.dateAdded
          });
          api.sendMessage(`successfully banned group id : ${idgr}`, event.threadID, event.messageID);
          break;
        }

        if (arg[0] == "out" || arg[0] == "Out") {
          api.removeUserFromGroup(`${api.getCurrentUserID()}`, idgr);
          api.sendMessage("out thread with id : " + idgr + "\n" + (await Threads.getData(idgr)).name, event.threadID, event.messageID);
          break;
        }

      }
  }
};


module.exports.run = async function({ api, event, client, botid }) {
  var inbox = await api.getThreadList(100, null, ['INBOX']);
  let list = [...inbox].filter(group => group.isSubscribed && group.isGroup);

  var listthread = [];

  //////////


  for (var groupInfo of list) {
    let data = (await api.getThreadInfo(groupInfo.threadID));

    listthread.push({
      id: groupInfo.threadID,
      name: groupInfo.name,
      sotv: data.userInfo.length,
    });

  } //for

  var listbox = listthread.sort((a, b) => {
    if (a.sotv > b.sotv) return -1;
    if (a.sotv < b.sotv) return 1;
  });

  let msg = '',
    i = 1;
  var groupid = [];
  for (var group of listbox) {
    msg += `${i++}. ${group.name}\ngroup id : ${group.id}\nmembers : ${group.sotv}\n\n`;
    groupid.push(group.id);
  }

  api.sendMessage(msg + 'reply "out" or "ban" the number of order to out or ban that thread!!', event.threadID, (e, data) =>
    global.client.handleReply.get(botid).push({
      name: this.config.name,
      author: event.senderID,
      messageID: data.messageID,
      groupid,
      type: 'reply'
    })
  );
};
