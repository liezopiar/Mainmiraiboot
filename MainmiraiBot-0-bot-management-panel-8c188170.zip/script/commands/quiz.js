module.exports.config = {
	name: "quiz",
	version: "1.1.0",
	permission: 0,
	credits: "Opiar",
	description: "❓ Random Quiz with Monetary Rewards",
	category: "without prefix",
	usages: "",
	cooldowns: 60
};

module.exports.languages = {
	"english": {
		"question": "📝 Question:\n%1\n\nA) %2\nB) %3\nC) %4\nD) %5\n\n💬 Reply to this message with your answer (a/b/c/d)",
		"correct": "🎉 Correct! You earned $%1!\n💰 New Balance: $%2",
		"incorrect": "❌ Wrong! Correct answer: %1\n💸 Better luck next time!",
		"cooldown": "⏳ Please wait %1 seconds before another quiz",
		"invalid": "⚠️ Invalid answer! Use a/b/c/d",
		"timeout": "⌛ Time's up! Answer was: %1",
		"error": "🔧 Error fetching question. Try again later."
	}
};

module.exports.run = async function({ api, event, Currencies, getText, botid }) {
	const { senderID, threadID, messageID } = event;
	const axios = require('axios');
	
	try {
		// Cooldown check (60 seconds) — stored in the JSON data column
		const userData = await Currencies.getData(senderID) || {};
		const store = userData.data || {};
		if (store.quizCooldown && Date.now() - store.quizCooldown < 60000) {
			const remaining = Math.ceil((60000 - (Date.now() - store.quizCooldown)) / 1000);
			return api.sendMessage(getText("cooldown", remaining), threadID, messageID);
		}

		// Fetch quiz question
		const { data } = await axios.get('https://gis-rest-api.onrender.com/quiz?tagalog=');
		const answers = [...data.wrongs, data.answer].sort(() => Math.random() - 0.5);
		
		// Prepare question
		const correctIndex = answers.indexOf(data.answer);
		const correctLetter = String.fromCharCode(97 + correctIndex);
		const questionMessage = getText(
			"question",
			data.question,
			...answers.map(a => a.trim())
		);

		// Send question
		const commandName = this.config.name;
		api.sendMessage(questionMessage, threadID, (err, info) => {
			if (err || !info) return;
			global.client.handleReply.get(botid).push({
				name: commandName,
				messageID: info.messageID,
				author: senderID,
				correct: correctLetter,
				startTime: Date.now(),
				timeout: setTimeout(async () => {
					api.unsendMessage(info.messageID);
					api.sendMessage(getText("timeout", data.answer), threadID);
					const fresh = (await Currencies.getData(senderID) || {}).data || {};
					await Currencies.setData(senderID, {
						data: { ...fresh, quizCooldown: Date.now() }
					});
				}, 30000) // 30-second timeout
			});
		});
	} catch (error) {
		console.error('Quiz Error:', error);
		api.sendMessage(getText("error"), threadID, messageID);
	}
};

module.exports.handleReply = async function({ api, event, handleReply, Currencies, getText }) {
	const { senderID, threadID, messageID } = event;
	const userAnswer = event.body.toLowerCase().trim();
	
	if (senderID !== handleReply.author) return;
	clearTimeout(handleReply.timeout);

	// Validate answer
	if (!['a', 'b', 'c', 'd'].includes(userAnswer)) {
		return api.sendMessage(getText("invalid"), threadID, messageID);
	}

	// Process answer
	api.unsendMessage(handleReply.messageID);
	const rewardPool = [10000, 9000, 8000, 7000];
	
	if (userAnswer === handleReply.correct) {
		const reward = rewardPool[Math.floor(Math.random() * rewardPool.length)];
		await Currencies.increaseMoney(senderID, reward);
		const balance = (await Currencies.getData(senderID)).money;
		
		api.sendMessage(
			getText("correct", reward.toLocaleString(), balance.toLocaleString()),
			threadID,
			messageID
		);
	} else {
		api.sendMessage(
			getText("incorrect", handleReply.correct.toUpperCase()),
			threadID,
			messageID
		);
	}

	// Update cooldown (stored in the JSON data column)
	const fresh = (await Currencies.getData(senderID) || {}).data || {};
	await Currencies.setData(senderID, {
		data: { ...fresh, quizCooldown: Date.now() }
	});
};
