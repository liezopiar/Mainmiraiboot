const axios = require("axios");
const fs = require("fs-extra");
const {
  Jimp,
  CACHE_DIR,
  collectPhotos,
  clamp,
  humanSize,
  scheduleCleanup
} = require("../utils/imageTools");
const path = require("path");

module.exports.config = {
  name: "hd",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Upscale and sharpen a photo up to 4x",
  prefix: true,
  premium: true,
  category: "premium",
  usages: "[reply to photo] (2 | 4)",
  cooldowns: 15
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const MAX_INPUT_SIDE = 1600;
const MAX_OUTPUT_SIDE = 4096;

const SHARPEN = [
  [0, -0.2, 0],
  [-0.2, 1.8, -0.2],
  [0, -0.2, 0]
];

/** Optional AI pass — only runs when the owner configured a Replicate token. */
async function aiUpscale(buffer, scale) {
  const token = process.env.REPLICATE_API_TOKEN;
  if (!token) return null;

  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
  const create = await axios.post(
    "https://api.replicate.com/v1/predictions",
    {
      version: "9283608cc6b7be6b65a8e44983db012355fde4132009bf99d976b2f0896856a3",
      input: { image: `data:image/jpeg;base64,${buffer.toString("base64")}`, scale }
    },
    { headers, timeout: 30000 }
  );

  let prediction = create.data;
  const deadline = Date.now() + 90000;

  while (["starting", "processing"].includes(prediction.status) && Date.now() < deadline) {
    await new Promise(resolve => setTimeout(resolve, 3000));
    const poll = await axios.get(prediction.urls.get, { headers, timeout: 20000 });
    prediction = poll.data;
  }

  if (prediction.status !== "succeeded" || !prediction.output) return null;

  const url = Array.isArray(prediction.output) ? prediction.output[0] : prediction.output;
  const image = await axios.get(url, { responseType: "arraybuffer", timeout: 60000 });
  return Buffer.from(image.data);
}

/** Local fallback: bicubic resize plus a light sharpen and contrast pass. */
async function localUpscale(buffer, scale) {
  const image = await Jimp.read(buffer);
  const { width, height } = image.bitmap;

  // shrink huge inputs first so the upscale does not blow past the output cap
  if (Math.max(width, height) > MAX_INPUT_SIDE) {
    if (width >= height) image.resize(MAX_INPUT_SIDE, Jimp.AUTO, Jimp.RESIZE_BICUBIC);
    else image.resize(Jimp.AUTO, MAX_INPUT_SIDE, Jimp.RESIZE_BICUBIC);
  }

  const base = image.bitmap;
  const targetSide = Math.max(base.width, base.height) * scale;
  const safeScale = targetSide > MAX_OUTPUT_SIDE ? MAX_OUTPUT_SIDE / Math.max(base.width, base.height) : scale;

  image
    .resize(Math.round(base.width * safeScale), Math.round(base.height * safeScale), Jimp.RESIZE_BICUBIC)
    .convolute(SHARPEN)
    .normalize()
    .contrast(0.05)
    .quality(95);

  return {
    buffer: await image.getBufferAsync(Jimp.MIME_JPEG),
    width: image.bitmap.width,
    height: image.bitmap.height
  };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const [url] = collectPhotos(event, 1);

  if (!url) {
    return api.sendMessage(
      `⚠️ reply to a photo then send ${prefix}hd\n\nexample : ${prefix}hd 4  (2x or 4x, default 2x)`,
      threadID,
      messageID
    );
  }

  const scale = clamp(parseInt(args[0], 10) || 2, 2, 4);
  const loading = await api.sendMessage(`✨ upscaling ${scale}x, please wait...`, threadID, messageID);

  try {
    const source = await axios.get(url, {
      responseType: "arraybuffer",
      headers: { "User-Agent": UA },
      timeout: 60000
    });
    const input = Buffer.from(source.data);

    let output;
    let engine = "ai upscaler";

    try {
      const ai = await aiUpscale(input, scale);
      if (ai) {
        const image = await Jimp.read(ai);
        output = { buffer: ai, width: image.bitmap.width, height: image.bitmap.height };
      }
    } catch {
      output = null;
    }

    if (!output) {
      engine = "local enhancer";
      output = await localUpscale(input, scale);
    }

    await fs.ensureDir(CACHE_DIR);
    const file = path.join(CACHE_DIR, `hd_${Date.now()}.jpg`);
    await fs.writeFile(file, output.buffer);

    api.unsendMessage(loading.messageID);

    return api.sendMessage(
      {
        body:
          "✨ 𝗨𝗣𝗦𝗖𝗔𝗟𝗘𝗗\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━\n" +
          `size   : ${output.width}x${output.height}\n` +
          `file   : ${humanSize(output.buffer.length)}\n` +
          `engine : ${engine}`,
        attachment: fs.createReadStream(file)
      },
      threadID,
      () => scheduleCleanup(file, 5000),
      messageID
    );
  } catch (error) {
    api.unsendMessage(loading.messageID);
    return api.sendMessage(`❌ failed to upscale — ${error.message || "unknown error"}`, threadID, messageID);
  }
};
