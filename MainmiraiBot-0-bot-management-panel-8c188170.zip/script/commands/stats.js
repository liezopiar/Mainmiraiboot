const os = require("os");

module.exports.config = {
  name: "stats",
  version: "2.0.0",
  permission: 0,
  credits: "Jonell Magallanes",
  description: "Detailed status panel of the bot and its host",
  prefix: false,
  premium: false,
  category: "System",
  usages: "stats",
  cooldowns: 9
};

function duration(seconds) {
  const total = Math.floor(seconds);
  const days = Math.floor(total / 86400);
  const hours = Math.floor((total % 86400) / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;

  const parts = [];
  if (days) parts.push(`${days}d`);
  if (days || hours) parts.push(`${hours}h`);
  if (days || hours || minutes) parts.push(`${minutes}m`);
  parts.push(`${secs}s`);
  return parts.join(" ");
}

function gb(bytes) {
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function mb(bytes) {
  return `${(bytes / 1024 / 1024).toFixed(0)} MB`;
}

/** Small text bar so the numbers are readable at a glance. */
function bar(percent, width = 12) {
  const filled = Math.max(0, Math.min(width, Math.round((percent / 100) * width)));
  return `[${"█".repeat(filled)}${"░".repeat(width - filled)}] ${percent.toFixed(0)}%`;
}

/** Sample the CPU counters twice so the load reflects right now, not since boot. */
function sampleCpu() {
  return os.cpus().reduce(
    (acc, cpu) => {
      const times = cpu.times;
      acc.idle += times.idle;
      acc.total += times.user + times.nice + times.sys + times.irq + times.idle;
      return acc;
    },
    { idle: 0, total: 0 }
  );
}

async function cpuUsage() {
  const first = sampleCpu();
  await new Promise(resolve => setTimeout(resolve, 300));
  const second = sampleCpu();

  const idle = second.idle - first.idle;
  const total = second.total - first.total;
  if (total <= 0) return 0;
  return Math.max(0, Math.min(100, (1 - idle / total) * 100));
}

function countCommands() {
  const commands = global.client?.commands;
  const list = commands ? [...commands.values()] : [];

  return {
    total: list.length,
    premium: list.filter(item => item?.config?.premium).length,
    noPrefix: list.filter(item => item?.config?.prefix === false).length,
    events: global.client?.events?.size || 0
  };
}

module.exports.run = async function ({ api, event, botname, prefix }) {
  const { threadID, messageID } = event;
  const started = Date.now();

  const loading = await api.sendMessage("📊 collecting stats...", threadID, messageID);
  const latency = Date.now() - started;

  const botID = await api.getCurrentUserID();
  const cpu = await cpuUsage();

  const totalMem = os.totalmem();
  const usedMem = totalMem - os.freemem();
  const heap = process.memoryUsage();
  const commands = countCommands();

  const users = global.data?.allUserID?.length || 0;
  const threads = global.data?.allThreadID?.get(botID)?.length || 0;
  const banned =
    (global.data?.userBanned?.size || 0) + (global.data?.threadBanned?.size || 0);
  // only count users whose premium has not expired yet
  let premiumUsers = 0;
  try {
    premiumUsers = require("../../main/utility/premium.js")
      .getList()
      .filter(entry => !entry.expiresAt || Number(entry.expiresAt) > Date.now()).length;
  } catch {
    premiumUsers = global.config?.haspremiumcmd?.length || 0;
  }

  const panel = [
    `📊 𝗕𝗢𝗧 𝗦𝗧𝗔𝗧𝗨𝗦${botname ? ` — ${botname}` : ""}`,
    "━━━━━━━━━━━━━━━━━━━━━━━",
    "‣ 𝗥𝗨𝗡𝗧𝗜𝗠𝗘",
    `  uptime   : ${duration(process.uptime())}`,
    `  latency  : ${latency}ms`,
    `  prefix   : ${prefix || global.config?.PREFIX || "none"}`,
    "",
    "‣ 𝗥𝗘𝗔𝗖𝗛",
    `  users    : ${users}`,
    `  threads  : ${threads}`,
    `  premium  : ${premiumUsers}`,
    `  banned   : ${banned}`,
    "",
    "‣ 𝗠𝗢𝗗𝗨𝗟𝗘𝗦",
    `  commands : ${commands.total} (${commands.premium} premium, ${commands.noPrefix} no-prefix)`,
    `  events   : ${commands.events}`,
    "",
    "‣ 𝗥𝗘𝗦𝗢𝗨𝗥𝗖𝗘𝗦",
    `  cpu  ${bar(cpu)}`,
    `  ram  ${bar((usedMem / totalMem) * 100)}`,
    `  ram used : ${gb(usedMem)} / ${gb(totalMem)}`,
    `  bot heap : ${mb(heap.heapUsed)} of ${mb(heap.rss)} rss`,
    "",
    "‣ 𝗛𝗢𝗦𝗧",
    `  cores    : ${os.cpus().length}x ${os.cpus()[0]?.model?.trim().slice(0, 28) || "unknown"}`,
    `  system   : ${os.type()} ${os.release()} (${os.arch()})`,
    `  node     : ${process.version}`,
    `  host up  : ${duration(os.uptime())}`
  ].join("\n");

  return api.editMessage(panel, loading.messageID, threadID);
};
