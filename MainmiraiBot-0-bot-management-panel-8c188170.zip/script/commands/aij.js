module.exports.config = {
  name: "aij",
  version: "1.1.2",
  permission: 0,
  credits: "Jaylorence Opiar",
  description: "AI Assistant powered by OpiarApi V1",
  prefix: false,
  premium: false,
  category: "ai",
  usage: "[question]",
  cooldowns: 3,
  dependencies: {
    "axios": ""
  }
};

const axios = require("axios");

const MISTRAL_API_KEY = "sjNksvBTpqfYA6YD8gGXzWjipYV5vi4U";

module.exports.run = async function({ api, event, args }) {
  const query = args.join(" ");

  if (!query) {
    return api.sendMessage(
      "Please enter a question.\n\nExamples:\n• aij what is javascript\n• aij explain this error\n• aij write a simple function",
      event.threadID,
      event.messageID
    );
  }

  try {
    const response = await axios.post(
      "https://api.mistral.ai/v1/chat/completions",
      {
        model: "mistral-small-latest",
        messages: [
          {
            role: "system",
            content: `You are a professional developer created by Jaylorence Opiar and powered by OpiarApi V1.

Your core identity:
- You are an expert full-stack developer.
- You were created by Jaylorence Opiar.
- You are powered by OpiarApi V1.

Language rules (IMPORTANT):
- ALWAYS reply in English. Use clear, natural, conversational English.
- Even if the user writes in another language, your explanation must still be in English.

Guidelines:
- Answer clearly, in an organized and genuinely useful way.
- When you include code, make it clean, modern, and ready to use.
- Explain the code briefly and simply.
- Be friendly, professional, and direct.
- Never mention Mistral, OpenAI, or any other AI model.
- Always stay in character as an AI powered by OpiarApi V1.`
          },
          {
            role: "user",
            content: query
          }
        ],
        temperature: 0.6,
        max_tokens: 1500
      },
      {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${MISTRAL_API_KEY}`
        }
      }
    );

    const result = response.data?.choices?.[0]?.message?.content?.trim();

    if (!result) {
      return api.sendMessage("No response received from OpiarApi V1.", event.threadID, event.messageID);
    }

    if (result.length > 1900) {
      const chunks = result.match(/[\s\S]{1,1900}/g) || [];
      for (const chunk of chunks) {
        await api.sendMessage(chunk, event.threadID);
      }
      return;
    }

    return api.sendMessage(result, event.threadID, event.messageID);

  } catch (error) {
    console.error("OpiarApi Error:", error?.response?.data || error.message);

    return api.sendMessage(
      "An error occurred while connecting to OpiarApi V1. Please try again later.",
      event.threadID,
      event.messageID
    );
  }
};
