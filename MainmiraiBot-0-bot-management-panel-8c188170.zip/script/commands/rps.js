module.exports.config = {
  name: "rps",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Rock paper scissors against the bot with a bet",
  category: "gambling",
  usages: "rps [rock/paper/scissors] [amount]",
  cooldowns: 5
};

module.exports.languages = {
  "english": {
    "missingInput": "❗ Choose rock, paper or scissors and a bet amount!\nUsage: rps [rock/paper/scissors] [amount]",
    "invalidChoice": "❗ Invalid choice! Pick rock, paper or scissors.",
    "invalidAmount": "❗ Bet amount must be a positive number.",
    "minBet": "❗ Minimum bet is $%1.",
    "noBalance": "💸 You don't have enough balance! You have $%1.",
    "win": "✂️ You: %1  vs  Bot: %2\n\n✅ You win $%3!\n💵 Balance: $%4",
    "lose": "✂️ You: %1  vs  Bot: %2\n\n❌ You lost $%3.\n💵 Balance: $%4",
    "draw": "✂️ You: %1  vs  Bot: %2\n\n➖ Draw! Your bet of $%3 is returned.\n💵 Balance: $%4"
  }
};

const MIN_BET = 50;
const MOVES   = { rock: "🪨 Rock", paper: "📄 Paper", scissors: "✂️ Scissors" };
const BEATS   = { rock: "scissors", paper: "rock", scissors: "paper" };
const ALIASES = { r: "rock", p: "paper", s: "scissors" };

module.exports.run = async function({ api, event, args, Currencies, getText }) {
  const { threadID, messageID, senderID } = event;

  if (args.length < 2) return api.sendMessage(getText("missingInput"), threadID, messageID);

  const raw    = String(args[0]).toLowerCase();
  const choice = ALIASES[raw] || raw;
  const bet    = parseInt(String(args[1]).replace(/,/g, ""));

  if (!MOVES[choice])         return api.sendMessage(getText("invalidChoice"), threadID, messageID);
  if (isNaN(bet) || bet <= 0) return api.sendMessage(getText("invalidAmount"), threadID, messageID);
  if (bet < MIN_BET)          return api.sendMessage(getText("minBet", MIN_BET.toLocaleString()), threadID, messageID);

  const balance = (await Currencies.getData(senderID)).money || 0;
  if (bet > balance) return api.sendMessage(getText("noBalance", balance.toLocaleString()), threadID, messageID);

  const keys    = Object.keys(MOVES);
  const botPick = keys[Math.floor(Math.random() * keys.length)];

  if (choice === botPick) {
    return api.sendMessage(
      getText("draw", MOVES[choice], MOVES[botPick], bet.toLocaleString(), balance.toLocaleString()),
      threadID, messageID
    );
  }

  if (BEATS[choice] === botPick) {
    await Currencies.increaseMoney(senderID, bet);
    return api.sendMessage(
      getText("win", MOVES[choice], MOVES[botPick], bet.toLocaleString(), (balance + bet).toLocaleString()),
      threadID, messageID
    );
  }

  await Currencies.decreaseMoney(senderID, bet);
  return api.sendMessage(
    getText("lose", MOVES[choice], MOVES[botPick], bet.toLocaleString(), (balance - bet).toLocaleString()),
    threadID, messageID
  );
};
