const fs = require("fs");
const {
  Jimp,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup,
  readPhoto,
  fitFont,
  printOutlined
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgtext",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Put custom text or a watermark on a photo",
  prefix: true,
  premium: true,
  category: "media",
  usages: "[reply to a photo] <text> [-p position] [-s size] [-c color] [-bg]",
  cooldowns: 12
};

const POSITIONS = {
  top: "top",
  center: "center",
  middle: "center",
  bottom: "bottom",
  topleft: "topleft",
  topright: "topright",
  bottomleft: "bottomleft",
  bottomright: "bottomright"
};

function guide(prefix) {
  return (
    "🖊 𝗜𝗠𝗔𝗚𝗘 𝗧𝗘𝗫𝗧 (premium)\n" +
    "━━━━━━━━━━━━━━━\n" +
    `reply to a photo then send :\n${prefix}imgtext <your text> [flags]\n\n` +
    "flags :\n" +
    "• -p <position>  top, center, bottom, topleft,\n" +
    "                 topright, bottomleft, bottomright\n" +
    "• -s <size>      8 / 16 / 32 / 64 / 128 (auto by default)\n" +
    "• -c <color>     white or black text\n" +
    "• -bg            put a dark bar behind the text\n\n" +
    "examples :\n" +
    `${prefix}imgtext hello world\n` +
    `${prefix}imgtext MAINMIRAI BOT -p bottomright -s 32\n` +
    `${prefix}imgtext top secret -p top -bg\n` +
    `${prefix}imgtext quote of the day -p center -c black`
  );
}

/** pull the flags out of the args and return the leftover words as the text */
function parseArgs(args) {
  const opts = { position: "bottom", size: null, color: "white", bg: false };
  const words = [];

  for (let i = 0; i < args.length; i++) {
    const token = args[i].toLowerCase();

    if ((token === "-p" || token === "--pos") && args[i + 1]) {
      opts.position = POSITIONS[args[++i].toLowerCase()] || "bottom";
      continue;
    }
    if ((token === "-s" || token === "--size") && args[i + 1]) {
      const n = parseInt(args[++i], 10);
      if (!Number.isNaN(n)) opts.size = clamp(n, 8, 128);
      continue;
    }
    if ((token === "-c" || token === "--color") && args[i + 1]) {
      opts.color = args[++i].toLowerCase() === "black" ? "black" : "white";
      continue;
    }
    if (token === "-bg" || token === "--bg") {
      opts.bg = true;
      continue;
    }
    words.push(args[i]);
  }

  return { opts, text: words.join(" ").trim() };
}

/** turn a position name into a top-left anchor for the text block */
function anchor(position, image, blockHeight, pad) {
  const { width, height } = image.bitmap;
  const boxWidth = position.includes("left") || position.includes("right") ? Math.round(width * 0.6) : width - pad * 2;

  let x = pad;
  let align = "center";
  if (position.includes("left")) align = "left";
  else if (position.includes("right")) {
    align = "right";
    x = width - pad - boxWidth;
  }

  let y = height - pad - blockHeight;
  if (position.startsWith("top")) y = pad;
  else if (position === "center") y = Math.round((height - blockHeight) / 2);

  return { x, y, boxWidth, align };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const first = (args[0] || "").toLowerCase();

  if (!args.length || ["help", "list"].includes(first)) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const { opts, text } = parseArgs(args);
  if (!text) {
    return api.sendMessage(`⚠️ Please include the text to write.\n\n${guide(prefix)}`, threadID, messageID);
  }

  api.setMessageReaction("🖊", messageID, () => {}, true);

  let filePath;
  try {
    const image = await readPhoto(event, 1600);
    if (!image) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage(
        `⚠️ A photo is required.\nReply to a photo then type ${prefix}imgtext ${text}`,
        threadID,
        messageID
      );
    }

    const pad = Math.round(Math.max(image.bitmap.width, image.bitmap.height) * 0.04) || 12;
    // auto sizing keeps long captions inside a third of the photo height
    const probeWidth = image.bitmap.width - pad * 2;
    const startSize = opts.size || clamp(Math.round(image.bitmap.width / 12), 16, 128);
    const fitted = await fitFont(text, probeWidth, Math.round(image.bitmap.height / 3), opts.color, startSize);

    const { x, y, boxWidth, align } = anchor(opts.position, image, fitted.height, pad);

    if (opts.bg) {
      const bar = new Jimp(image.bitmap.width, fitted.height + pad, 0x000000ff);
      bar.opacity(0.45);
      image.composite(bar, 0, clamp(y - pad / 2, 0, image.bitmap.height - bar.bitmap.height));
    }

    await printOutlined(image, text, {
      x,
      y,
      maxWidth: boxWidth,
      size: fitted.size,
      thickness: Math.max(1, Math.round(fitted.size / 24)),
      align
    });

    filePath = await saveImage(image, "imgtext");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "🖊 𝗧𝗘𝗫𝗧 𝗔𝗗𝗗𝗘𝗗\n" +
          `💬 "${text.length > 60 ? `${text.slice(0, 60)}…` : text}"\n` +
          `📍 ${opts.position} • ${fitted.size}px • ${opts.color}\n` +
          `💾 ${humanSize(stats.size)}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to add the text : ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
