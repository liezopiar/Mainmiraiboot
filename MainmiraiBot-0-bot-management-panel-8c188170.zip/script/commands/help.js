module.exports.config = {
  name: "help",
  version: "3.1.0",
  permission: 0,
  credits: "ryuko",
  description: "Command list, per-category list, and per-command info",
  prefix: true,
  premium: false,
  category: "guide",
  usages: "[page | category | command]",
  cooldowns: 5
};

module.exports.languages = {
  english: {
    user: "user",
    adminGroup: "[ADMIN]",
    adminBot: "[ADMIN]",
    vip: "[VIP]",
    noDescription: "No description available.",
    pageError: "⚠️ Invalid page. Choose between 1 and %1.",
    notFound: '⚠️ No command or category named "%1".'
  },
  bangla: {
    user: "user",
    adminGroup: "[ADMIN]",
    adminBot: "[ADMIN]",
    vip: "[VIP]",
    noDescription: "No description available.",
    pageError: "⚠️ Invalid page. Choose between 1 and %1.",
    notFound: '⚠️ No command or category named "%1".'
  }
};

// ─── style constants ───────────────────────────────────────────────────────

const LINE = "━━━━━━━━━━━━━━━━━━━━━━━";
const BULLET = "ꪊꪻ";
const PER_PAGE = 8;

// mga bagong command — may [NEW] tag sa listahan
const NEW_COMMANDS = [
  "premiumlist",
  "premiumperks",
  "redeem",
  "banner",
  "aibanner",
  "dictionary",
  "solve",
  "translate",
  "imgedit",
  "collage"
];

// mathematical sans-serif bold ranges (para sa header text)
const BOLD_UPPER = 0x1d5d4; // 𝗔
const BOLD_LOWER = 0x1d5ee; // 𝗮
const BOLD_DIGIT = 0x1d7ec; // 𝟬

/** Ginagawang bold-unicode ang normal na text para sa mga header. */
function bold(text) {
  return String(text).replace(/[A-Za-z0-9]/g, (ch) => {
    const code = ch.charCodeAt(0);
    if (ch >= "A" && ch <= "Z") return String.fromCodePoint(BOLD_UPPER + code - 65);
    if (ch >= "a" && ch <= "z") return String.fromCodePoint(BOLD_LOWER + code - 97);
    return String.fromCodePoint(BOLD_DIGIT + code - 48);
  });
}

// ─── helpers ───────────────────────────────────────────────────────────────

function newTag(cfg) {
  return NEW_COMMANDS.includes(cfg.name) ? " [NEW]" : "";
}

function permTag(cfg, getText) {
  if (cfg.premium) return ` ${getText("vip")}`;
  if (cfg.permission === 1) return ` ${getText("adminGroup")}`;
  if (cfg.permission >= 2) return ` ${getText("adminBot")}`;
  return "";
}

function permLabel(cfg, getText) {
  if (cfg.premium) return "vip";
  if (cfg.permission === 1) return "group admin";
  if (cfg.permission >= 2) return "bot admin";
  return getText("user") || "user";
}

function categoryOf(cmd) {
  return (cmd.config.category || "others").toLowerCase();
}

function usageOf(cmd, prefix) {
  const name = cmd.config.name;
  const head = `${cmd.config.prefix === false ? "" : prefix}${name}`;

  // may mga command na inuulit ang pangalan sa loob ng "usages" — alisin
  const args = String(cmd.config.usages || "")
    .trim()
    .replace(new RegExp(`^${prefix ? `\\${prefix}?` : ""}${name}\\b`, "i"), "")
    .trim();

  return `${head} ${args}`.trim();
}

/** Lahat ng command, alphabetical ayon sa pangalan. */
function sortedCommands() {
  return Array.from(global.client.commands.values()).sort((a, b) =>
    a.config.name.localeCompare(b.config.name)
  );
}

function groupByCategory(list) {
  const map = new Map();
  for (const cmd of list) {
    const key = categoryOf(cmd);
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(cmd);
  }
  return new Map(Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0])));
}

/** Isang entry sa listahan: bullet, tag, description, usage. */
function commandEntry(cmd, getText, prefix) {
  return [
    `${BULLET} ${cmd.config.name}${permTag(cmd.config, getText)}${newTag(cmd.config)}`,
    cmd.config.description || getText("noDescription"),
    `Usage: ${usageOf(cmd, prefix)}`
  ].join("\n");
}

// ─── views ─────────────────────────────────────────────────────────────────

function buildPage(pageItems, page, totalPages, total, getText, prefix) {
  const body = pageItems.map((cmd) => commandEntry(cmd, getText, prefix)).join("\n\n");

  const footer = [
    `🔍 For more info: ${prefix}help <command>`,
    `📂 By category: ${prefix}help <category>`,
    `✨ New commands: ${prefix}help new`,
    page < totalPages ? `📖 Next page: ${prefix}help ${page + 1}` : null,
    page > 1 ? `📖 Prev page: ${prefix}help ${page - 1}` : null,
    `📊 Total: ${total} commands`
  ].filter(Boolean);

  return [
    `📚 ${bold("Command List")} (${bold("Page")} ${page}/${totalPages})`,
    LINE,
    body,
    LINE,
    footer.join("\n")
  ].join("\n");
}

function buildCategory(category, cmds, getText, prefix) {
  const body = cmds.map((cmd) => commandEntry(cmd, getText, prefix)).join("\n\n");

  return [
    `📂 ${bold(category.toUpperCase())} (${cmds.length} ${cmds.length === 1 ? "command" : "commands"})`,
    LINE,
    body,
    LINE,
    `🔍 For more info: ${prefix}help <command>`,
    `📖 Full list: ${prefix}help`
  ].join("\n");
}

function buildNew(cmds, getText, prefix) {
  const body = cmds.map((cmd) => commandEntry(cmd, getText, prefix)).join("\n\n");

  return [
    `✨ ${bold("New Commands")} (${cmds.length})`,
    LINE,
    body,
    LINE,
    `🔍 For more info: ${prefix}help <command>`,
    `📖 Full list: ${prefix}help`
  ].join("\n");
}

function buildInfo(cmd, getText, prefix) {
  return [
    `📌 ${bold(cmd.config.name)}${permTag(cmd.config, getText)}${newTag(cmd.config)}`,
    LINE,
    cmd.config.description || getText("noDescription"),
    "",
    `Usage      : ${usageOf(cmd, prefix)}`,
    `Category   : ${categoryOf(cmd)}`,
    `Cooldown   : ${cmd.config.cooldowns || 0}s`,
    `Permission : ${permLabel(cmd.config, getText)}`,
    `Credits    : ${cmd.config.credits || "unknown"}`,
    LINE,
    `📂 By category: ${prefix}help ${categoryOf(cmd)}`
  ].join("\n");
}

function buildNotFound(query, categories, getText, prefix) {
  return [
    getText("notFound", query),
    LINE,
    `📂 Categories: ${categories.join(", ")}`,
    `📖 Full list: ${prefix}help`
  ].join("\n");
}

// ─── handleEvent – "help <command>" na walang prefix ───────────────────────

module.exports.handleEvent = function ({ api, event, getText, prefix }) {
  const { commands } = global.client;
  const { threadID, messageID, body } = event;

  if (!body || !body.toLowerCase().startsWith("help")) return;

  const parts = body.trim().split(/\s+/);
  if (parts.length < 2) return;

  const cmd = commands.get(parts[1].toLowerCase());
  if (!cmd) return;

  return api.sendMessage(buildInfo(cmd, getText, prefix), threadID, messageID);
};

// ─── run ───────────────────────────────────────────────────────────────────

module.exports.run = async function ({ api, event, args, getText, prefix }) {
  const { commands } = global.client;
  const { threadID, messageID } = event;

  const list = sortedCommands();
  const totalPages = Math.max(1, Math.ceil(list.length / PER_PAGE));
  const query = (args[0] || "").toLowerCase();

  // help <command>
  if (query && commands.has(query)) {
    return api.sendMessage(buildInfo(commands.get(query), getText, prefix), threadID, messageID);
  }

  // help new
  if (query === "new") {
    const fresh = list.filter((cmd) => NEW_COMMANDS.includes(cmd.config.name));
    if (fresh.length) {
      return api.sendMessage(buildNew(fresh, getText, prefix), threadID, messageID);
    }
  }

  // help <category>
  if (query && isNaN(parseInt(query))) {
    const groups = groupByCategory(list);
    const match = Array.from(groups.keys()).find((c) => c === query || c.startsWith(query));
    if (match) {
      return api.sendMessage(
        buildCategory(match, groups.get(match), getText, prefix),
        threadID,
        messageID
      );
    }
    return api.sendMessage(
      buildNotFound(query, Array.from(groups.keys()), getText, prefix),
      threadID,
      messageID
    );
  }

  // help [page]
  let page = 1;
  if (query) {
    const parsed = parseInt(query);
    if (isNaN(parsed) || parsed < 1 || parsed > totalPages) {
      return api.sendMessage(getText("pageError", totalPages), threadID, messageID);
    }
    page = parsed;
  }

  const start = (page - 1) * PER_PAGE;
  return api.sendMessage(
    buildPage(list.slice(start, start + PER_PAGE), page, totalPages, list.length, getText, prefix),
    threadID,
    messageID
  );
};
