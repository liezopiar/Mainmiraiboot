const axios = require("axios");

module.exports.config = {
  name: "translate",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Translate text into another language (Tagalog, English, and more)",
  prefix: true,
  premium: false,
  category: "education",
  usages: "[lang code] [text] | reply to a message",
  cooldowns: 5,
  dependency: {
    axios: ""
  }
};

const LINE = "━━━━━━━━━━━━━━━━━━━━━━━";
const ENDPOINT = "https://translate.googleapis.com/translate_a/single";
const MAX_LENGTH = 1800;

const LANGS = {
  tl: "Tagalog",
  fil: "Filipino",
  ceb: "Cebuano",
  ilo: "Ilocano",
  hil: "Hiligaynon",
  pam: "Kapampangan",
  war: "Waray",
  en: "English",
  es: "Spanish",
  ja: "Japanese",
  ko: "Korean",
  "zh-CN": "Chinese (Simplified)",
  zh: "Chinese",
  ar: "Arabic",
  hi: "Hindi",
  id: "Indonesian",
  ms: "Malay",
  th: "Thai",
  vi: "Vietnamese",
  fr: "French",
  de: "German",
  it: "Italian",
  pt: "Portuguese",
  ru: "Russian",
  bn: "Bengali",
  tr: "Turkish",
  nl: "Dutch"
};

const guide = (prefix) =>
  "🌐 𝗧𝗥𝗔𝗡𝗦𝗟𝗔𝗧𝗘\n" +
  LINE +
  "\n" +
  `${prefix}translate <lang> <text>\n` +
  `${prefix}translate <lang>   ← while replying to a message\n\n` +
  "Default target: tl (Tagalog)\n" +
  "The source language is auto-detected.\n\n" +
  `Codes: ${Object.keys(LANGS).join(", ")}\n\n` +
  `Examples:\n${prefix}translate tl Where are you going tomorrow?\n${prefix}translate ja How are you?`;

const langName = (code) => LANGS[code] || LANGS[code.toLowerCase()] || code;

function parseInput(args, messageReply) {
  let target = "tl";
  const rest = [...args];

  if (rest.length) {
    const first = rest[0].replace(/^-+/, "");
    const match = Object.keys(LANGS).find((c) => c.toLowerCase() === first.toLowerCase());
    if (match) {
      target = match;
      rest.shift();
    } else if (/^[a-z]{2}(-[a-zA-Z]{2,4})?$/.test(first) && rest.length > 1) {
      target = first;
      rest.shift();
    }
  }

  const typed = rest.join(" ").trim();
  const text = typed || (messageReply ? (messageReply.body || "").trim() : "");
  return { target, text };
}

/** Google's array response: [ [[translated, original, ...], ...], ..., detectedLang ] */
function parseResponse(data) {
  const chunks = Array.isArray(data[0]) ? data[0] : [];
  const translated = chunks
    .map((c) => (Array.isArray(c) ? c[0] : ""))
    .filter(Boolean)
    .join("")
    .trim();

  const alternatives = [];
  if (Array.isArray(data[1])) {
    for (const group of data[1]) {
      if (!Array.isArray(group)) continue;
      const pos = group[0];
      const terms = Array.isArray(group[1]) ? group[1].slice(0, 4) : [];
      if (pos && terms.length) alternatives.push(`${pos}: ${terms.join(", ")}`);
    }
  }

  return { translated, detected: data[2] || "auto", alternatives };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID, messageReply } = event;

  const { target, text } = parseInput(args, messageReply);

  if (!text) return api.sendMessage(guide(prefix), threadID, messageID);
  if (text.length > MAX_LENGTH) {
    return api.sendMessage(
      `⚠️ The text is too long (${text.length}/${MAX_LENGTH} characters).`,
      threadID,
      messageID
    );
  }

  const url =
    `${ENDPOINT}?client=gtx&sl=auto&tl=${encodeURIComponent(target)}` +
    `&dt=t&dt=bd&q=${encodeURIComponent(text)}`;

  try {
    const res = await axios.get(url, { timeout: 20000 });
    const { translated, detected, alternatives } = parseResponse(res.data);

    if (!translated) {
      return api.sendMessage(
        `⚠️ No translation returned. The language code "${target}" may be invalid.\nType ${prefix}translate for the list.`,
        threadID,
        messageID
      );
    }

    return api.sendMessage(
      [
        "🌐 𝗧𝗥𝗔𝗡𝗦𝗟𝗔𝗧𝗜𝗢𝗡",
        LINE,
        translated,
        LINE,
        `${langName(detected)} → ${langName(target)}`,
        alternatives.length ? `\nOther meanings:\n${alternatives.join("\n")}` : null
      ]
        .filter(Boolean)
        .join("\n"),
      threadID,
      messageID
    );
  } catch (err) {
    return api.sendMessage(
      "⚠️ Cannot reach the translation service right now. Please try again later.",
      threadID,
      messageID
    );
  }
};
