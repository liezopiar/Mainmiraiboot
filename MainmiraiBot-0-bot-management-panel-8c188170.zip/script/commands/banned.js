module.exports.config = {
	name: "banned",
	version: "1.1.0",
	permission: 2,
	credits: "NTKhang",
  prefix: false,
  premium: false,
  description: "show the ban list",
	category: "admin",
	usages: "[thread | user]",
	cooldowns: 5,
};

module.exports.run = async function({ api, args, Users, event, Threads }) {
	const sub = (args[0] || "").toLowerCase();

	if (sub == "user") {
		const list = global.data.userBanned || new Map();
		if (list.size === 0)
			return api.sendMessage("there are no banned users at the moment.", event.threadID, event.messageID);

		let msg = "";
		let i = 0;
		// read straight from the in-memory map, it already holds the reason and the
		// timer. the old version re-queried every user and checked the wrong field,
		// so a banned user could be skipped entirely.
		for (const [id, record] of list) {
			const info = (record && typeof record === "object") ? record : {};
			const name = global.data.userName.get(String(id)) || (await Users.getNameUser(id)) || "Unknown";
			msg += `${++i}. name: ${name}\nid: ${id}\nreason: ${info.reason || "none"}\ndate: ${info.dateAdded || "unknown"}\n\n`;
			if (i >= 30) break;
		}
		return api.sendMessage(`❎ banned users (${list.size}) :\n\n` + msg, event.threadID, event.messageID);
	}
	else if (sub == "thread" || sub == "group") {
		const list = global.data.threadBanned || new Map();
		if (list.size === 0)
			return api.sendMessage("there are no banned threads at the moment.", event.threadID, event.messageID);

		let msg = "";
		let i = 0;
		for (const [id, record] of list) {
			const info = (record && typeof record === "object") ? record : {};
			let name = (global.data.threadInfo.get(String(id)) || {}).threadName || "Unknown";
			if (name === "Unknown") {
				try { name = (await api.getThreadInfo(id)).threadName || "Unknown"; } catch {}
			}
			msg += `${++i}. name: ${name}\nid: ${id}\nreason: ${info.reason || "none"}\ndate: ${info.dateAdded || "unknown"}\n\n`;
			if (i >= 30) break;
		}
		return api.sendMessage(`❎ banned threads (${list.size}) :\n\n` + msg, event.threadID, event.messageID);
	}
	else {
		return api.sendMessage("syntax error, please use: banned user / banned thread", event.threadID, event.messageID);
	}
};
