module.exports.config = {
  name: "blackjack",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Play blackjack against the dealer and bet your money",
  category: "gambling",
  usages: "blackjack [amount]",
  cooldowns: 5
};

module.exports.languages = {
  "english": {
    "noAmount":     "❗ Enter a bet amount!\nUsage: blackjack [amount]",
    "invalidAmt":   "❗ Bet amount must be a positive number.",
    "minBet":       "❗ Minimum bet is $%1.",
    "noBalance":    "💸 You don't have enough balance! You have $%1.",
    "table":        "🃏 BLACKJACK — Bet: $%1\n\n👤 Your hand: %2 (%3)\n🎩 Dealer shows: %4\n\n💬 Reply with \"hit\" to draw or \"stand\" to hold.",
    "notYours":     "❗ This is not your game.",
    "invalidMove":  "⚠️ Invalid move! Reply with \"hit\" or \"stand\".",
    "bust":         "🃏 BLACKJACK\n\n👤 Your hand: %1 (%2)\n\n💥 Bust! You lost $%3.\n💵 Balance: $%4",
    "blackjack":    "🃏 BLACKJACK\n\n👤 Your hand: %1 (%2)\n🎩 Dealer: %3 (%4)\n\n🌟 Blackjack! You won $%5! (2.5× payout)\n💵 Balance: $%6",
    "win":          "🃏 BLACKJACK\n\n👤 Your hand: %1 (%2)\n🎩 Dealer: %3 (%4)\n\n✅ You win $%5!\n💵 Balance: $%6",
    "lose":         "🃏 BLACKJACK\n\n👤 Your hand: %1 (%2)\n🎩 Dealer: %3 (%4)\n\n❌ Dealer wins. You lost $%5.\n💵 Balance: $%6",
    "push":         "🃏 BLACKJACK\n\n👤 Your hand: %1 (%2)\n🎩 Dealer: %3 (%4)\n\n➖ Push! Your bet of $%5 is returned.\n💵 Balance: $%6",
    "timeout":      "⌛ Blackjack timed out — your bet of $%1 was forfeited."
  }
};

const MIN_BET = 100;
const SUITS   = ["♠", "♥", "♦", "♣"];
const RANKS   = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

function newDeck() {
  const deck = [];
  for (const suit of SUITS) for (const rank of RANKS) deck.push({ rank, suit });
  for (let i = deck.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

function handValue(hand) {
  let total = 0, aces = 0;
  for (const card of hand) {
    if (card.rank === "A") { total += 11; aces++; }
    else if (["J", "Q", "K"].includes(card.rank)) total += 10;
    else total += parseInt(card.rank);
  }
  // Downgrade aces from 11 to 1 while busting
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

function showHand(hand) {
  return hand.map(c => `${c.rank}${c.suit}`).join(" ");
}

/** Registers the next reply listener for an ongoing game. */
function listen({ api, event, botid, state, message, commandName }) {
  api.sendMessage(message, event.threadID, (err, info) => {
    if (err || !info) return;
    global.client.handleReply.get(botid).push({
      name: commandName,
      messageID: info.messageID,
      author: state.author,
      ...state,
      timeout: setTimeout(async () => {
        api.unsendMessage(info.messageID);
        api.sendMessage(state.getTimeoutText(), event.threadID);
        await state.onTimeout();
      }, 60000)
    });
  });
}

module.exports.run = async function({ api, event, args, Currencies, getText, botid }) {
  const { threadID, messageID, senderID } = event;

  if (!args[0]) return api.sendMessage(getText("noAmount"), threadID, messageID);

  const bet = parseInt(String(args[0]).replace(/,/g, ""));
  if (isNaN(bet) || bet <= 0) return api.sendMessage(getText("invalidAmt"), threadID, messageID);
  if (bet < MIN_BET)          return api.sendMessage(getText("minBet", MIN_BET.toLocaleString()), threadID, messageID);

  const userData = await Currencies.getData(senderID);
  const balance  = userData.money || 0;
  if (bet > balance) return api.sendMessage(getText("noBalance", balance.toLocaleString()), threadID, messageID);

  // Take the bet up front so a timeout can't be used to escape a bad hand
  await Currencies.decreaseMoney(senderID, bet);

  const deck   = newDeck();
  const player = [deck.pop(), deck.pop()];
  const dealer = [deck.pop(), deck.pop()];

  // Natural blackjack pays 2.5×
  if (handValue(player) === 21) {
    const prize = Math.floor(bet * 2.5);
    await Currencies.increaseMoney(senderID, prize);
    const newBal = balance - bet + prize;
    return api.sendMessage(
      getText("blackjack", showHand(player), 21, showHand(dealer), handValue(dealer), prize.toLocaleString(), newBal.toLocaleString()),
      threadID, messageID
    );
  }

  listen({
    api, event, botid,
    commandName: this.config.name,
    state: {
      author: senderID,
      bet, deck, player, dealer,
      getTimeoutText: () => getText("timeout", bet.toLocaleString()),
      onTimeout: async () => {}
    },
    message: getText("table", bet.toLocaleString(), showHand(player), handValue(player), showHand(dealer[0] ? [dealer[0]] : []))
  });
};

module.exports.handleReply = async function({ api, event, handleReply, Currencies, getText, botid }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID !== handleReply.author) return api.sendMessage(getText("notYours"), threadID, messageID);

  const move = String(body || "").toLowerCase().trim();
  if (!["hit", "h", "stand", "s"].includes(move)) return api.sendMessage(getText("invalidMove"), threadID, messageID);

  clearTimeout(handleReply.timeout);
  api.unsendMessage(handleReply.messageID);

  const { bet, deck, player, dealer } = handleReply;
  const balance = (await Currencies.getData(senderID)).money || 0;

  if (move === "hit" || move === "h") {
    player.push(deck.pop());
    const total = handValue(player);

    if (total > 21) {
      return api.sendMessage(
        getText("bust", showHand(player), total, bet.toLocaleString(), balance.toLocaleString()),
        threadID, messageID
      );
    }

    return listen({
      api, event, botid,
      commandName: module.exports.config.name,
      state: {
        author: senderID,
        bet, deck, player, dealer,
        getTimeoutText: () => getText("timeout", bet.toLocaleString()),
        onTimeout: async () => {}
      },
      message: getText("table", bet.toLocaleString(), showHand(player), total, showHand([dealer[0]]))
    });
  }

  // Stand — dealer draws to 17
  while (handValue(dealer) < 17) dealer.push(deck.pop());

  const pTotal = handValue(player);
  const dTotal = handValue(dealer);

  if (dTotal > 21 || pTotal > dTotal) {
    const prize = bet * 2;
    await Currencies.increaseMoney(senderID, prize);
    return api.sendMessage(
      getText("win", showHand(player), pTotal, showHand(dealer), dTotal, bet.toLocaleString(), (balance + prize).toLocaleString()),
      threadID, messageID
    );
  }

  if (pTotal === dTotal) {
    await Currencies.increaseMoney(senderID, bet);
    return api.sendMessage(
      getText("push", showHand(player), pTotal, showHand(dealer), dTotal, bet.toLocaleString(), (balance + bet).toLocaleString()),
      threadID, messageID
    );
  }

  return api.sendMessage(
    getText("lose", showHand(player), pTotal, showHand(dealer), dTotal, bet.toLocaleString(), balance.toLocaleString()),
    threadID, messageID
  );
};
