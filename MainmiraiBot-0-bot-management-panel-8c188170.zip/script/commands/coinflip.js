module.exports.config = {
    name: "coinflip",
    version: "1.0.0",
    permission: 0,
    credits: "YourName",
    prefix: false,
    premium: false,
    description: "Coin flip game - guess heads or tails",
    category: "gambling",
    usages: "coinflip [heads/tails] [amount]",
    cooldowns: 5
};

module.exports.languages = {
    "english": {
        "missingInput": "Please specify heads/tails and bet amount!",
        "invalidChoice": "Invalid choice! Please choose heads or tails.",
        "invalidAmount": "Invalid bet amount! Must be a positive number.",
        "minBet": "Minimum bet is 50!",
        "insufficientBalance": "You don't have enough balance for this bet!",
        "win": "The coin landed on %1! You won %2$!",
        "lose": "The coin landed on %1! You lost %2$!"
    }
};

module.exports.run = async function({ api, event, args, Currencies, getText }) {
    const { threadID, senderID } = event;
    const { getData, increaseMoney, decreaseMoney } = Currencies;
    const userData = await getData(senderID);
    const money = userData.money;

    // Validate input
    if (args.length < 2) return api.sendMessage(getText("missingInput"), threadID);
    
    const choice = args[0].toLowerCase();
    const amount = parseInt(args[1]);
    
    if (!['heads', 'tails'].includes(choice)) 
        return api.sendMessage(getText("invalidChoice"), threadID);
    
    if (isNaN(amount) || amount <= 0) 
        return api.sendMessage(getText("invalidAmount"), threadID);
    
    if (amount < 50) 
        return api.sendMessage(getText("minBet"), threadID);
    
    if (amount > money) 
        return api.sendMessage(getText("insufficientBalance"), threadID);

    // Generate random result
    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const isWin = choice === result;

    // Update balance
    if (isWin) {
        await increaseMoney(senderID, amount);
    } else {
        await decreaseMoney(senderID, amount);
    }

    // Send result
    const message = isWin 
        ? getText("win", result, amount) 
        : getText("lose", result, amount);

    api.sendMessage(message, threadID);
};
