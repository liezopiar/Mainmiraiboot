module.exports.config = {
	name: "daily",
	version: "1.5.0",
	permission: 0,
	credits: "Opiar",
	prefix: false,
	premium: false,
	description: "💰 Daily Reward System with Streak Bonuses",
	category: "without prefix",
	usages: "",
	cooldowns: 5
};

module.exports.languages = {
	"english": {
		"cooldown":      "⏰ You've already claimed your daily reward!\nNext claim in: %1 hours %2 minutes",
		"reward":        "✅ Claimed $%1 %2\n💵 Total Balance: $%3\n📅 Streak: %4 days\n\n🎁 Next Tier: %5 days ($%6)",
		"max_streak":    "🌟 MAX STREAK REACHED! (+50% bonus)",
		"resetting":     "♻️ Streak resets in %1 hours"
	}
};

module.exports.run = async function({ api, event, Currencies, getText }) {
	const { senderID, threadID, messageID } = event;
	const now = Date.now();

	// Load user data — create default streak block if missing
	const userData = await Currencies.getData(senderID);
	const streak   = (userData && userData.data && userData.data.dailystreak)
		? userData.data.dailystreak
		: { lastClaim: 0, streak: 0 };

	const timeDiff  = now - streak.lastClaim;
	const hoursDiff = Math.floor(timeDiff / (1000 * 60 * 60));

	// Still within 24-hour cooldown
	if (timeDiff < 86400000) {
		const remaining = 86400000 - timeDiff;
		const hours     = Math.floor(remaining / (1000 * 60 * 60));
		const minutes   = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
		return api.sendMessage(getText("cooldown", hours, minutes), threadID, messageID);
	}

	// Reset streak if gap is over 48 hours
	let newStreak = hoursDiff >= 48 ? 0 : streak.streak;

	// Tier system (caps at day 5)
	const rewardTiers = {
		1: { amount: 50000,  bonus: 0  },
		2: { amount: 100000, bonus: 10 },
		3: { amount: 150000, bonus: 20 },
		4: { amount: 200000, bonus: 35 },
		5: { amount: 250000, bonus: 50 }
	};

	const currentTier  = Math.min(newStreak + 1, 5);
	const { amount, bonus } = rewardTiers[currentTier];
	const totalReward  = amount + Math.floor(amount * (bonus / 100));

	// Save updated streak into the JSON data column
	const newData = Object.assign({}, (userData && userData.data) ? userData.data : {}, {
		dailystreak: {
			lastClaim: now,
			streak:    currentTier === 5 ? 5 : newStreak + 1
		}
	});
	await Currencies.increaseMoney(senderID, totalReward);
	await Currencies.setData(senderID, { data: newData });

	const currentBalance = (userData && userData.money ? userData.money : 0) + totalReward;
	const nextTier       = currentTier === 5 ? 1 : currentTier + 1;
	const bonusText      = bonus > 0 ? `(+${bonus}% bonus)` : "";

	let message = getText("reward",
		totalReward.toLocaleString(),
		bonusText,
		currentBalance.toLocaleString(),
		currentTier,
		nextTier,
		rewardTiers[nextTier].amount.toLocaleString()
	);

	if (currentTier === 5) message += `\n${getText("max_streak")}`;

	const resetTime = 24 - (hoursDiff % 24);
	message += `\n\n${getText("resetting", resetTime)}`;

	return api.sendMessage(message, threadID, messageID);
};
