const premiumUtil = require("../../main/utility/premium.js");

/**
 * resolve who the command is about, from a reply, from tags or from raw ids.
 * the leftover tokens keep their order and the tagged name words are removed,
 * so a duration or a reason after the tag is read correctly even when facebook
 * shortened the displayed name.
 */
function resolveTargets(args = [], event = {}, { multiple = true, minIDLength = 5 } = {}) {
	const tokens = (Array.isArray(args) ? args : []).map(a => String(a == null ? "" : a)).filter(Boolean);
	const mentions = event.mentions || {};
	const mentionedUsers = Object.keys(mentions);

	let ids = [];

	if (event.type === "message_reply" && event.messageReply) {
		// If the message is a reply, use the sender's ID of the replied message
		ids = [String(event.messageReply.senderID)];
	} else if (tokens.join(" ").indexOf("@") !== -1 || mentionedUsers.length) {
		// If the message contains mentions, check if there is more than one mention
		if (mentionedUsers.length > 1) {
			ids = multiple ? mentionedUsers.map(String) : [String(mentionedUsers[0])];
		} else if (mentionedUsers.length === 1) {
			ids = [String(mentionedUsers[0])];
		}
	}

	// drop the tagged name words so they never leak into the duration or reason
	const labels = Object.values(mentions).map(n => String(n || "").replace(/^@/, "").trim()).filter(Boolean);
	let rest = tokens.filter(t => t.charAt(0) !== "@");
	for (const label of labels) {
		for (const word of label.split(/\s+/).filter(Boolean)) {
			const at = rest.findIndex(t => t.replace(/^@/, "") === word);
			if (at !== -1) rest.splice(at, 1);
		}
	}

	// raw ids typed in the body still work, alone or together with tags
	const idPattern = new RegExp(`^\\d{${minIDLength},}$`);
	const leftover = [];
	for (const token of rest) {
		if (idPattern.test(token) && (multiple || !ids.length)) { ids.push(String(token)); continue; }
		leftover.push(token);
	}

	ids = [...new Set(ids)];
	if (!multiple) ids = ids.slice(0, 1);

	// whatever is left can hold a duration ("7d", "1 month", "perm")
	const { duration, rest: text } = premiumUtil.extractDuration(leftover);
	return { ids, duration, text: text.join(" ").trim() };
}

module.exports.config = {
  name: "premium",
  version: "3.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Manage the premium users list and premium requests",
  prefix: false,
  premium: false,
  category: "admin",
  usages: "premium [list | add | remove | pending | approve | deny | check] [@mention | userID] [duration]",
  cooldowns: 5,
};

module.exports.languages = {
  "english": {
    "listEmpty":        "📭 No premium users yet.",
    "notHavePermssion": "⛔ You have no permission to use \"%1\".",
    "addedNewAdmin":    "✅ Added %1 premium user(s) :\n\n%2",
    "removedAdmin":     "🗑️ Removed %1 premium user(s) :\n\n%2"
  },
  "bangla": {
    "listEmpty":        "📭 No premium users yet.",
    "notHavePermssion": "⛔ You have no permission to use \"%1\".",
    "addedNewAdmin":    "✅ Added %1 premium user(s) :\n\n%2",
    "removedAdmin":     "🗑️ Removed %1 premium user(s) :\n\n%2"
  }
};

module.exports.run = async function ({ api, event, args, Users, permssion, getText, prefix = "" }) {
  const { threadID, messageID, senderID } = event;
  // the handler always passes a prefix, but a manual call must not print "undefined"
  if (!prefix) prefix = "";

  // keep the stored shape current and drop everyone whose time already ran out
  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const action = (args[0] || "").toLowerCase();
  const content = args.slice(1);
  // bot admins are staff too, they used to be rejected from every management
  // action even though only operators sit above them
  const isStaff = permssion >= 2;

  const getName = async (id) => {
    try { return await Users.getNameUser(id); } catch { return "Facebook User"; }
  };

  // "premium add @a @b 7d" / "premium add 1000123 7d" / "premium add 1000123"
  //
  // the duration is found by scanning for a token that actually looks like a
  // duration, never by subtracting the mention labels out of the body. facebook
  // shortens long names, swaps in nicknames and drops the leading "@", so the
  // old subtraction regularly left the name words behind and they were then read
  // as the duration ("Invalid duration \"Juan Dela Cruz 7d\"").
  const parseTargets = (opts = {}) =>
    resolveTargets(content, event, { multiple: true, ...opts });

  switch (action) {

    // ── list ────────────────────────────────────────────────────────────────
    case "list":
    case "all":
    case "-a": {
      const list = premiumUtil.getList();
      if (!list.length) return api.sendMessage(getText("listEmpty"), threadID, messageID);

      const msg = [];
      for (const entry of list) {
        const name = await getName(entry.userID);
        msg.push(`👤 ${name}\n🆔 ${entry.userID}\n⏳ ${premiumUtil.formatRemaining(entry.expiresAt)}`);
      }
      return api.sendMessage(`⭐ Premium users (${list.length}) :\n\n${msg.join("\n\n")}`, threadID, messageID);
    }

    // ── check ───────────────────────────────────────────────────────────────
    case "check":
    case "me": {
      // a tag, a raw id or a reply all work here, and checking yourself is the
      // default when nothing was given
      const targetID = parseTargets({ multiple: false }).ids[0] || senderID;
      const entry = premiumUtil.find(targetID);
      const name = await getName(targetID);
      if (!entry) {
        return api.sendMessage(`❌ ${name} (${targetID}) is not a premium user.`, threadID, messageID);
      }
      return api.sendMessage(
        `⭐ ${name} (${targetID}) is premium.\n⏳ time left : ${premiumUtil.formatRemaining(entry.expiresAt)}`,
        threadID, messageID
      );
    }

    // ── add ─────────────────────────────────────────────────────────────────
    case "add": {
      if (!isStaff) return api.sendMessage(getText("notHavePermssion", "add"), threadID, messageID);

      const { ids, duration } = parseTargets();
      if (!ids.length) {
        return api.sendMessage(
          `❗ Who should get premium ?\n${prefix}premium add @mention 7d\n${prefix}premium add 100012345678 7d\n(no duration = permanent)`,
          threadID, messageID
        );
      }

      const added = [];
      for (const id of ids) {
        let result;
        try {
          result = premiumUtil.addPremium(id, { duration, addedBy: senderID });
        } catch (error) {
          return api.sendMessage(
            `❗ Invalid duration "${duration}".\nExamples : 7d, 12h, 1 month, perm`,
            threadID, messageID
          );
        }
        const name = await getName(id);
        const timeLabel = result.entry.expiresAt ? premiumUtil.formatRemaining(result.entry.expiresAt) : "permanent";
        added.push(`👤 ${name}\n🆔 ${id}\n⏳ ${timeLabel}`);
        api.sendMessage(
          `⭐ You have been ${result.extended ? "renewed as" : "added to"} a premium user.\n⏳ duration : ${timeLabel}\nYou can now use premium commands.`,
          id
        );
      }

      return api.sendMessage(getText("addedNewAdmin", added.length, added.join("\n\n")), threadID, messageID);
    }

    // ── remove ──────────────────────────────────────────────────────────────
    case "remove":
    case "rm":
    case "delete": {
      if (!isStaff) return api.sendMessage(getText("notHavePermssion", "delete"), threadID, messageID);

      const { ids } = parseTargets();
      if (!ids.length) {
        return api.sendMessage(
          `❗ Who should lose premium ?\n${prefix}premium remove @mention\n${prefix}premium remove 100012345678`,
          threadID, messageID
        );
      }

      const removed = [];
      const missing = [];
      for (const id of ids) {
        const name = await getName(id);
        if (!premiumUtil.removePremium(id)) { missing.push(`👤 ${name}\n🆔 ${id}`); continue; }
        removed.push(`👤 ${name}\n🆔 ${id}`);
        api.sendMessage("❌ You have been removed from the premium list.", id);
      }

      if (!removed.length) {
        return api.sendMessage(`⚠️ Not on the premium list :\n\n${missing.join("\n\n")}`, threadID, messageID);
      }
      let msg = getText("removedAdmin", removed.length, removed.join("\n\n"));
      if (missing.length) msg += `\n\n⚠️ Not on the list :\n\n${missing.join("\n\n")}`;
      return api.sendMessage(msg, threadID, messageID);
    }

    // ── pending requests ────────────────────────────────────────────────────
    case "pending":
    case "requests":
    case "request": {
      if (!isStaff) return api.sendMessage(getText("notHavePermssion", "pending"), threadID, messageID);

      const requests = premiumUtil.getRequests();
      if (!requests.length) return api.sendMessage("📭 There are no premium requests right now.", threadID, messageID);

      const msg = [];
      for (const r of requests) {
        const name = r.name || await getName(r.userID);
        msg.push(`👤 ${name}\n🆔 ${r.userID}\n💬 ${r.reason}\n🕒 ${new Date(r.requestedAt || Date.now()).toLocaleString()}`);
      }
      return api.sendMessage(
        `📩 Premium requests (${requests.length}) :\n\n${msg.join("\n\n")}\n\n` +
        `${prefix}premium approve <userID> [duration]\n${prefix}premium deny <userID> [reason]`,
        threadID, messageID
      );
    }

    // ── approve a request ───────────────────────────────────────────────────
    case "approve":
    case "accept": {
      if (!isStaff) return api.sendMessage(getText("notHavePermssion", "approve"), threadID, messageID);

      const { ids, duration } = parseTargets();
      const targetID = ids[0];
      if (!targetID) return api.sendMessage(`❗ Usage : ${prefix}premium approve <userID> [duration]`, threadID, messageID);

      const request = premiumUtil.findRequest(targetID);
      if (!request) return api.sendMessage(`⚠️ No pending premium request from ${targetID}.`, threadID, messageID);

      let result;
      try {
        result = premiumUtil.addPremium(targetID, { duration, addedBy: senderID });
      } catch (error) {
        return api.sendMessage(`❗ Invalid duration "${duration}".\nExamples : 7d, 12h, 1 month, perm`, threadID, messageID);
      }

      // an approval wipes any older deny cooldown
      premiumUtil.clearDenied(targetID);

      const name = request.name || await getName(targetID);
      const timeLabel = result.entry.expiresAt ? premiumUtil.formatRemaining(result.entry.expiresAt) : "permanent";
      api.sendMessage(`✅ Your premium request was approved.\n⏳ duration : ${timeLabel}`, targetID);
      if (request.threadID && String(request.threadID) !== String(targetID) && String(request.threadID) !== String(threadID)) {
        api.sendMessage(`✅ Premium request of ${name} has been approved.`, request.threadID);
      }
      return api.sendMessage(
        `✅ Approved premium request :\n\n👤 ${name}\n🆔 ${targetID}\n⏳ ${timeLabel}`,
        threadID, messageID
      );
    }

    // ── deny a request ──────────────────────────────────────────────────────
    case "deny":
    case "reject": {
      if (!isStaff) return api.sendMessage(getText("notHavePermssion", "deny"), threadID, messageID);

      // the leftover here is a reason, so tagged name words must be dropped
      // instead of being kept as the reason text
      const { ids: denyIDs, duration: denyDuration, text: denyText } = resolveTargets(content, event, { multiple: true });
      // a deny has no duration, so a token that looked like one is reason text
      const denyRest = [denyDuration, denyText].filter(Boolean).join(" ");
      const targetID = denyIDs[0];
      if (!targetID) return api.sendMessage(`❗ Usage : ${prefix}premium deny <userID> [reason]`, threadID, messageID);

      const request = premiumUtil.removeRequest(targetID);
      if (!request) return api.sendMessage(`⚠️ No pending premium request from ${targetID}.`, threadID, messageID);

      // the leftover text after the target is the reason, mention labels removed
      const reason = (denyRest || "").trim();
      const name = request.name || await getName(targetID);
      // remember the deny so the user cannot instantly spam another request
      premiumUtil.addDenied({ userID: targetID, reason: reason || null, by: senderID });
      const cooldownLabel = premiumUtil.formatDuration(premiumUtil.denyCooldown(targetID).msLeft);
      api.sendMessage(
        `❌ Your premium request was denied.${reason ? `\n💬 reason : ${reason}` : ""}\n🕒 you can request again in ${cooldownLabel}`,
        targetID
      );
      return api.sendMessage(
        `🗑️ Denied premium request of ${name} (${targetID}).\n🕒 they can request again in ${cooldownLabel}`,
        threadID, messageID
      );
    }

    default:
      return api.sendMessage(
        `⭐ premium usage :\n\n` +
        `${prefix}premium list - show every premium user with their time left\n` +
        `${prefix}premium check [@mention | userID] - check premium status\n` +
        `${prefix}premium add <@mention | userID> [duration] - grant premium (no duration = permanent)\n` +
        `${prefix}premium remove <@mention | userID> - revoke premium\n` +
        `${prefix}premium pending - show premium requests\n` +
        `${prefix}premium approve <userID> [duration] - approve a request\n` +
        `${prefix}premium deny <userID> [reason] - deny a request\n\n` +
        `member commands : ${prefix}premiumperks, ${prefix}premiumlist, ${prefix}premiumstats, ${prefix}premiumgift\n` +
        `operator only : ${prefix}premiumnoti <message> | ${prefix}premiumnoti expiring [days]\n\n` +
        `durations : 30m, 12h, 7d, 2w, 1 month, perm\n` +
        `redeem codes :\n` +
        `${prefix}redeem create [duration] [uses] - make a code\n` +
        `${prefix}redeem codes - list every code\n` +
        `${prefix}redeem <code> - what the member types to claim it`,
        threadID, messageID
      );
  }
};
