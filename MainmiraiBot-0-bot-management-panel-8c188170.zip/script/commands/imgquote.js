const fs = require("fs");
const {
  Jimp,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup,
  fitFont,
  loadFont
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgquote",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Turn a message into a shareable quote card",
  prefix: true,
  premium: true,
  category: "media",
  usages: "[reply to a message] | <text> [-a author] [-t theme]",
  cooldowns: 12
};

const THEMES = {
  dark: { bg: 0x101014ff, panel: 0x1b1b22ff, text: "white", accent: 0x6c8cffff },
  light: { bg: 0xf6f5f1ff, panel: 0xffffffff, text: "black", accent: 0x2f6bffff },
  ink: { bg: 0x0b1220ff, panel: 0x122036ff, text: "white", accent: 0x4fd1c5ff },
  rose: { bg: 0x1a0f16ff, panel: 0x2a1420ff, text: "white", accent: 0xff6f9cff },
  gold: { bg: 0x16130bff, panel: 0x241f10ff, text: "white", accent: 0xe8bf5cff }
};

const WIDTH = 1000;
const PAD = 70;

function guide(prefix) {
  return (
    "❝ 𝗤𝗨𝗢𝗧𝗘 𝗖𝗔𝗥𝗗 (premium)\n" +
    "━━━━━━━━━━━━━━━\n" +
    `${prefix}imgquote <text>\n` +
    `or reply to a message then send ${prefix}imgquote\n\n` +
    "flags :\n" +
    "• -a <author>   set the name under the quote\n" +
    `• -t <theme>    ${Object.keys(THEMES).join(", ")}\n\n` +
    "examples :\n" +
    `${prefix}imgquote stay humble, work hard\n` +
    `${prefix}imgquote dream big -a mainmirai -t gold\n` +
    `${prefix}imgquote -t light   (as a reply to a message)`
  );
}

function parseArgs(args) {
  const opts = { author: null, theme: "dark" };
  const words = [];

  for (let i = 0; i < args.length; i++) {
    const token = args[i].toLowerCase();
    if ((token === "-a" || token === "--author") && args[i + 1]) {
      // an author name can be several words, so take everything until the next flag
      const parts = [];
      while (args[i + 1] && !args[i + 1].startsWith("-")) parts.push(args[++i]);
      opts.author = parts.join(" ");
      continue;
    }
    if ((token === "-t" || token === "--theme") && args[i + 1]) {
      const name = args[++i].toLowerCase();
      if (THEMES[name]) opts.theme = name;
      continue;
    }
    words.push(args[i]);
  }

  return { opts, text: words.join(" ").trim() };
}

/** round the avatar and drop it on the card */
async function drawAvatar(card, url, x, y, size, ringColor) {
  try {
    const avatar = await Jimp.read(url);
    avatar.cover(size, size).circle();
    const ring = new Jimp(size + 8, size + 8, ringColor);
    ring.circle();
    card.composite(ring, x - 4, y - 4);
    card.composite(avatar, x, y);
    return true;
  } catch {
    return false;
  }
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID, messageReply } = event;
  const first = (args[0] || "").toLowerCase();

  if (["help", "list", "themes"].includes(first)) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const { opts, text: typed } = parseArgs(args);
  const quote = (typed || messageReply?.body || "").trim();

  if (!quote) {
    return api.sendMessage(`⚠️ Nothing to quote.\n\n${guide(prefix)}`, threadID, messageID);
  }
  if (quote.length > 400) {
    return api.sendMessage("⚠️ That quote is too long. Keep it under 400 characters.", threadID, messageID);
  }

  api.setMessageReaction("❝", messageID, () => {}, true);

  let filePath;
  try {
    // the author is the flag, else the person who wrote the replied message
    const sourceID = typed ? null : messageReply?.senderID;
    let author = opts.author;
    let avatarUrl = null;

    if (!author && sourceID) {
      const info = await api.getUserInfo(sourceID).catch(() => null);
      author = info?.[sourceID]?.name || "unknown";
      avatarUrl = info?.[sourceID]?.thumbSrc || null;
    }
    author = author || "anonymous";

    const theme = THEMES[opts.theme];
    const body = `“${quote}”`;

    const bodyFit = await fitFont(body, WIDTH - PAD * 2, 520, theme.text, 64);
    const nameFont = await loadFont(32, theme.text);

    const avatarSize = 96;
    const height = clamp(PAD * 2 + bodyFit.height + 60 + avatarSize, 420, 1400);

    const card = new Jimp(WIDTH, height, theme.bg);

    // inner panel so the quote sits on its own surface
    const panel = new Jimp(WIDTH - 32, height - 32, theme.panel);
    card.composite(panel, 16, 16);

    // accent bar down the left edge of the panel
    const bar = new Jimp(8, height - 32, theme.accent);
    card.composite(bar, 16, 16);

    card.print(
      bodyFit.font,
      PAD,
      PAD,
      { text: body, alignmentX: Jimp.HORIZONTAL_ALIGN_LEFT, alignmentY: Jimp.VERTICAL_ALIGN_TOP },
      WIDTH - PAD * 2
    );

    const footerY = PAD + bodyFit.height + 40;
    let nameX = PAD;

    if (avatarUrl) {
      const drawn = await drawAvatar(card, avatarUrl, PAD, footerY, avatarSize, theme.accent);
      if (drawn) nameX = PAD + avatarSize + 24;
    }

    card.print(
      nameFont,
      nameX,
      footerY + (avatarUrl ? Math.round(avatarSize / 2) - 20 : 0),
      { text: `— ${author}`, alignmentX: Jimp.HORIZONTAL_ALIGN_LEFT },
      WIDTH - nameX - PAD
    );

    filePath = await saveImage(card, "imgquote");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "❝ 𝗤𝗨𝗢𝗧𝗘 𝗖𝗔𝗥𝗗\n" +
          `✍️ ${author}\n` +
          `🎨 ${opts.theme} • ${WIDTH}x${height}\n` +
          `💾 ${humanSize(stats.size)}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to build the quote card : ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
