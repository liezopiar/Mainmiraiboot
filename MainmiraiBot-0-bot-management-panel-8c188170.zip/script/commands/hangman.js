module.exports.config = {
  name: "hangman",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Guess the hidden word letter by letter before you run out of lives",
  category: "game",
  usages: "hangman",
  cooldowns: 10
};

module.exports.languages = {
  "english": {
    "board":     "🪢 HANGMAN\n\n%1\n\n📚 Hint: %2\n❤️ Lives: %3\n🔤 Used: %4\n\n💬 Reply with a letter, or the whole word.",
    "notYours":  "❗ This is not your game.",
    "invalid":   "⚠️ Reply with a single letter (a-z) or the full word.",
    "repeated":  "⚠️ You already tried \"%1\".",
    "wrongWord": "❌ \"%1\" is not the word! You lost a life.",
    "won":       "🎉 You got it! The word was \"%1\".\n💰 You earned $%2!\n💵 Balance: $%3",
    "lost":      "💀 Out of lives! The word was \"%1\".\n💬 Type \"hangman\" to play again.",
    "timeout":   "⌛ Time's up! The word was \"%1\"."
  }
};

const LIVES        = 6;
const PRIZE_LETTER = 500;
const WORDS = [
  { word: "computer",   hint: "Runs your programs" },
  { word: "keyboard",   hint: "You type on it" },
  { word: "internet",   hint: "Global network" },
  { word: "elephant",   hint: "Largest land animal" },
  { word: "guitar",     hint: "Six-string instrument" },
  { word: "volcano",    hint: "Erupts with lava" },
  { word: "diamond",    hint: "Hardest gemstone" },
  { word: "penguin",    hint: "Bird that swims, not flies" },
  { word: "library",    hint: "Full of books" },
  { word: "rainbow",    hint: "Appears after rain" },
  { word: "airport",    hint: "Planes land here" },
  { word: "chocolate",  hint: "Made from cocoa" },
  { word: "umbrella",   hint: "Keeps you dry" },
  { word: "mountain",   hint: "Very tall landform" },
  { word: "language",   hint: "Used to communicate" },
  { word: "birthday",   hint: "Celebrated yearly" },
  { word: "dolphin",    hint: "Clever sea mammal" },
  { word: "treasure",   hint: "Pirates bury it" },
  { word: "sandwich",   hint: "Food between bread" },
  { word: "telescope",  hint: "Used to view stars" }
];

/** Masks unguessed letters as underscores. */
function mask(word, used) {
  return word.split("").map(c => (used.includes(c) ? c.toUpperCase() : "_")).join(" ");
}

/** Sends the board and registers the reply listener for the next turn. */
function ask({ api, event, botid, commandName, message, state, timeoutText }) {
  api.sendMessage(message, event.threadID, (err, info) => {
    if (err || !info) return;
    global.client.handleReply.get(botid).push({
      name: commandName,
      messageID: info.messageID,
      ...state,
      timeout: setTimeout(() => {
        api.unsendMessage(info.messageID);
        api.sendMessage(timeoutText, event.threadID);
      }, 90000)
    });
  });
}

module.exports.run = async function({ api, event, getText, botid }) {
  const pick = WORDS[Math.floor(Math.random() * WORDS.length)];
  const state = { author: event.senderID, word: pick.word, hint: pick.hint, used: [], lives: LIVES };

  ask({
    api, event, botid,
    commandName: this.config.name,
    message: getText("board", mask(pick.word, []), pick.hint, LIVES, "none"),
    state,
    timeoutText: getText("timeout", pick.word.toUpperCase())
  });
};

module.exports.handleReply = async function({ api, event, handleReply, Currencies, getText, botid }) {
  const { threadID, messageID, senderID, body } = event;
  if (senderID !== handleReply.author) return api.sendMessage(getText("notYours"), threadID, messageID);

  const { word, hint } = handleReply;
  const used  = [...handleReply.used];
  let lives   = handleReply.lives;
  const input = String(body || "").toLowerCase().trim();

  const isLetter = /^[a-z]$/.test(input);
  const isWord   = /^[a-z]{2,}$/.test(input);
  if (!isLetter && !isWord) return api.sendMessage(getText("invalid"), threadID, messageID);
  if (isLetter && used.includes(input)) return api.sendMessage(getText("repeated", input), threadID, messageID);

  clearTimeout(handleReply.timeout);
  api.unsendMessage(handleReply.messageID);

  let solved = false;
  let notice = "";

  if (isWord) {
    if (input === word) solved = true;
    else { lives--; notice = getText("wrongWord", input.toUpperCase()) + "\n\n"; }
  } else {
    used.push(input);
    if (!word.includes(input)) lives--;
    solved = word.split("").every(c => used.includes(c));
  }

  if (solved) {
    const prize = PRIZE_LETTER * word.length + lives * 1000;
    await Currencies.increaseMoney(senderID, prize);
    const balance = (await Currencies.getData(senderID)).money || 0;
    return api.sendMessage(
      getText("won", word.toUpperCase(), prize.toLocaleString(), balance.toLocaleString()),
      threadID, messageID
    );
  }

  if (lives <= 0) {
    return api.sendMessage(getText("lost", word.toUpperCase()), threadID, messageID);
  }

  ask({
    api, event, botid,
    commandName: module.exports.config.name,
    message: notice + getText("board", mask(word, used), hint, lives, used.length ? used.join(", ").toUpperCase() : "none"),
    state: { author: senderID, word, hint, used, lives },
    timeoutText: getText("timeout", word.toUpperCase())
  });
};
