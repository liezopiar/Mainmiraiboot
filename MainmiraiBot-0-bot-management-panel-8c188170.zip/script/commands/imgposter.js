const fs = require("fs");
const {
  Jimp,
  clamp,
  humanSize,
  hexToInt,
  saveImage,
  scheduleCleanup,
  collectPhotos,
  fitFont,
  loadFont
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgposter",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Build a titled poster out of a photo",
  prefix: true,
  premium: true,
  category: "media",
  usages: "[reply to a photo] <title> | <subtitle> [-t theme] [-c hex]",
  cooldowns: 15
};

const THEMES = {
  cinema: { bg: 0x0a0a0cff, text: "white", accent: 0xe5c07bff, fade: 0.55 },
  clean: { bg: 0xf7f6f2ff, text: "black", accent: 0x1f6feaff, fade: 0.0 },
  neon: { bg: 0x0b0416ff, text: "white", accent: 0xff2bd1ff, fade: 0.45 },
  forest: { bg: 0x0c1410ff, text: "white", accent: 0x7dd88aff, fade: 0.5 },
  paper: { bg: 0xefe7d6ff, text: "black", accent: 0xb4441fff, fade: 0.0 }
};

const WIDTH = 1000;
const MARGIN = 44;

function guide(prefix) {
  return (
    "🖼 𝗣𝗢𝗦𝗧𝗘𝗥 𝗠𝗔𝗞𝗘𝗥 (premium)\n" +
    "━━━━━━━━━━━━━━━\n" +
    "reply to a photo then send :\n" +
    `${prefix}imgposter <title> | <subtitle>\n\n` +
    "flags :\n" +
    `• -t <theme>   ${Object.keys(THEMES).join(", ")}\n` +
    "• -c <hex>     custom accent line color\n" +
    "• -tall        taller cinematic crop\n\n" +
    "examples :\n" +
    `${prefix}imgposter mainmirai | now streaming\n` +
    `${prefix}imgposter summer 2026 | a short film -t cinema\n` +
    `${prefix}imgposter new drop | limited -t neon -tall\n` +
    `${prefix}imgposter quiet mornings -t paper`
  );
}

function parseArgs(args) {
  const opts = { theme: "cinema", accent: null, tall: false };
  const words = [];

  for (let i = 0; i < args.length; i++) {
    const token = args[i].toLowerCase();
    if ((token === "-t" || token === "--theme") && args[i + 1]) {
      const name = args[++i].toLowerCase();
      if (THEMES[name]) opts.theme = name;
      continue;
    }
    if ((token === "-c" || token === "--color") && args[i + 1]) {
      opts.accent = args[++i];
      continue;
    }
    if (token === "-tall" || token === "--tall") {
      opts.tall = true;
      continue;
    }
    words.push(args[i]);
  }

  const [rawTitle = "", rawSub = ""] = words.join(" ").split("|");
  return { opts, title: rawTitle.trim(), subtitle: rawSub.trim() };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const first = (args[0] || "").toLowerCase();

  if (!args.length || ["help", "list", "themes"].includes(first)) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const { opts, title, subtitle } = parseArgs(args);
  if (!title) {
    return api.sendMessage(`⚠️ Please include a title.\n\n${guide(prefix)}`, threadID, messageID);
  }

  api.setMessageReaction("🖼", messageID, () => {}, true);

  let filePath;
  try {
    const [url] = collectPhotos(event, 1);
    if (!url) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage(
        `⚠️ A photo is required.\nReply to a photo then type ${prefix}imgposter ${title}`,
        threadID,
        messageID
      );
    }

    const theme = THEMES[opts.theme];
    const accent = opts.accent ? hexToInt(opts.accent, theme.accent) : theme.accent;

    const artWidth = WIDTH - MARGIN * 2;
    const artHeight = Math.round(artWidth * (opts.tall ? 1.35 : 1.0));

    const upper = title.toUpperCase();
    const titleFit = await fitFont(upper, artWidth, 200, theme.text, 128);
    const subFont = await loadFont(32, theme.text);
    const subHeight = subtitle ? Jimp.measureTextHeight(subFont, subtitle.toUpperCase(), artWidth) : 0;

    // margins : top art, then the accent rule, then the type block
    const textBlock = titleFit.height + (subtitle ? subHeight + 18 : 0);
    const height = MARGIN * 2 + artHeight + 34 + textBlock + MARGIN;

    const poster = new Jimp(WIDTH, height, theme.bg);

    const art = (await Jimp.read(url)).cover(artWidth, artHeight);
    if (theme.fade > 0) {
      // a dark wash at the bottom of the art blends it into the poster
      const wash = new Jimp(artWidth, Math.round(artHeight * 0.4), 0x000000ff);
      wash.opacity(clamp(theme.fade, 0, 1));
      art.composite(wash, 0, artHeight - wash.bitmap.height);
    }
    poster.composite(art, MARGIN, MARGIN);

    const ruleY = MARGIN + artHeight + 18;
    const rule = new Jimp(artWidth, 5, accent);
    poster.composite(rule, MARGIN, ruleY);

    poster.print(
      titleFit.font,
      MARGIN,
      ruleY + 24,
      { text: upper, alignmentX: Jimp.HORIZONTAL_ALIGN_LEFT, alignmentY: Jimp.VERTICAL_ALIGN_TOP },
      artWidth
    );

    if (subtitle) {
      poster.print(
        subFont,
        MARGIN,
        ruleY + 24 + titleFit.height + 12,
        { text: subtitle.toUpperCase(), alignmentX: Jimp.HORIZONTAL_ALIGN_LEFT },
        artWidth
      );
    }

    filePath = await saveImage(poster, "imgposter");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "🖼 𝗣𝗢𝗦𝗧𝗘𝗥 𝗥𝗘𝗔𝗗𝗬\n" +
          `🔠 ${upper}${subtitle ? `\n🔡 ${subtitle.toUpperCase()}` : ""}\n` +
          `🎨 ${opts.theme}${opts.tall ? " • tall" : ""} • ${WIDTH}x${height}\n` +
          `💾 ${humanSize(stats.size)}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to build the poster : ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
