const axios = require("axios");

module.exports.config = {
  name: "google",
  version: "2.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "search on google and get the actual answers, not just a link",
  category: "without prefix",
  usages: "google [text]",
  cooldowns: 10,
  dependencies: {
    axios: ""
  }
};

const LINE = "━━━━━━━━━━━━━━━━━━━━━━━";
const TIMEOUT = 15000;
const UA = "MainmiraiBot/2.0 (facebook messenger bot; search command)";
const MAX_RESULTS = 5;
const SNIPPET_LIMIT = 220;
/* Score earned when a query keyword appears in the result title. Anything
   lower means we only matched inside the body text, which is a weak signal. */
const STRONG_MATCH = 3;

/* Words that strongly suggest the query is written in Filipino/Tagalog,
   so we can search the Tagalog wikipedia first for better answers. */
const TAGALOG_HINTS = [
  "ano", "sino", "bakit", "paano", "saan", "kailan", "alin", "ilan",
  "pinaka", "mga", "ang", "sa", "ng", "kung", "yung", "ba", "po",
  "gaano", "magkano", "kanino", "tungkol", "kahulugan", "ibig sabihin"
];

function isTagalog(query) {
  const words = query.toLowerCase().split(/\s+/);
  return words.some((w) => TAGALOG_HINTS.includes(w)) || /pinaka\w+/.test(query.toLowerCase());
}

function clean(text) {
  if (!text) return "";
  return String(text)
    .replace(/<[^>]*>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&nbsp;/g, " ")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function trim(text, limit = SNIPPET_LIMIT) {
  const t = clean(text);
  if (t.length <= limit) return t;
  return t.slice(0, limit).replace(/\s+\S*$/, "") + "...";
}

/* Words too generic to prove a result actually matches the query. */
const STOP_WORDS = new Set([
  "ano", "sino", "bakit", "paano", "saan", "kailan", "alin", "ilan", "ang", "ng",
  "sa", "mga", "kung", "yung", "ba", "po", "tungkol", "ay", "na", "what", "who",
  "why", "how", "where", "when", "which", "is", "are", "was", "were", "the", "a",
  "an", "of", "in", "on", "to", "for", "and", "or", "about", "does", "do", "did"
]);

function keywordsOf(query) {
  return query
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2 && !STOP_WORDS.has(w));
}

/* Wikipedia matches titles poorly when the query is a full question
   ("ano ang kahulugan ng demokrasya" finds nothing), so we also try the
   query reduced to its meaningful keywords ("kahulugan demokrasya"). */
function searchVariants(query) {
  const keywords = keywordsOf(query);
  const reduced = keywords.join(" ");
  const variants = [query];
  if (reduced && reduced !== query.toLowerCase().trim()) variants.push(reduced);
  return variants;
}

/* Score a candidate so we can pick the best of several results instead of
   blindly taking the first one. More matched keywords = better answer. */
function scoreResult(query, data) {
  const keywords = keywordsOf(query);
  if (!keywords.length) return 1;

  const heading = String(data.heading || "").toLowerCase();
  const answer = String(data.answer || "").toLowerCase();

  /* Each keyword is counted once, weighted by where it appears. Matching more
     of the query wins, so "List of tallest buildings" beats the article simply
     titled "World" for "tallest building in the world" without needing to
     penalise short titles (which would wrongly demote "Tubig" or "Demokrasya"). */
  let score = 0;
  for (const w of keywords) {
    if (heading.includes(w)) score += 3;
    else if (answer.includes(w)) score += 1;
  }

  return score;
}

/* A result is only trusted when it shares a meaningful keyword with the query,
   otherwise the wiki search just handed us a loosely related article. */
function isRelevant(query, data) {
  const keywords = keywordsOf(query);
  if (!keywords.length) return true;

  const haystack = `${data.heading} ${data.answer}`.toLowerCase();
  return keywords.some((w) => haystack.includes(w));
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* Wikipedia and DuckDuckGo throttle bursts of requests, which shows up as a
   429/503 and would otherwise look like "no results". Retry briefly so a
   busy moment doesn't turn into a failed search for the user. */
async function fetchJSON(url, params) {
  let lastErr;

  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const res = await axios.get(url, {
        params,
        headers: { "User-Agent": UA },
        timeout: TIMEOUT,
        validateStatus: (s) => s < 500 && s !== 429
      });
      return res.data;
    } catch (err) {
      lastErr = err;
      const status = err.response?.status;
      const retryable = !status || status === 429 || status >= 500;
      if (!retryable) throw err;
      await sleep(400 * (attempt + 1));
    }
  }

  throw lastErr;
}

/* ---------- source 1: duckduckgo instant answer (direct answers) ---------- */
async function instantAnswer(query) {
  const data = (await fetchJSON("https://api.duckduckgo.com/", {
    q: query,
    format: "json",
    no_html: 1,
    skip_disambig: 1
  })) || {};
  const answer = clean(data.Answer) || clean(data.AbstractText);
  if (!answer) return null;

  return {
    heading: clean(data.Heading) || query,
    answer,
    source: clean(data.AbstractSource) || "DuckDuckGo",
    url: data.AbstractURL || null,
    image: data.Image ? (data.Image.startsWith("http") ? data.Image : `https://duckduckgo.com${data.Image}`) : null,
    related: (data.RelatedTopics || [])
      .filter((t) => t.Text && t.FirstURL)
      .slice(0, MAX_RESULTS)
      .map((t) => ({ title: clean(t.Text).split(" - ")[0], description: clean(t.Text), url: t.FirstURL }))
  };
}

/* ---------- source 2: wikipedia (search + summary) ---------- */
async function wikiSearch(query, lang) {
  const host = `https://${lang}.wikipedia.org`;

  const search = await fetchJSON(`${host}/w/api.php`, {
    action: "query",
    list: "search",
    srsearch: query,
    format: "json",
    srlimit: MAX_RESULTS
  });

  const hits = search?.query?.search || [];
  if (!hits.length) return null;

  // The summary endpoint gives a clean readable paragraph; if it is
  // unavailable we still have the search snippet to fall back on.
  let summary = null;
  try {
    summary = await fetchJSON(`${host}/api/rest_v1/page/summary/${encodeURIComponent(hits[0].title)}`);
  } catch (err) {
    summary = null;
  }

  return {
    heading: summary?.title || hits[0].title,
    answer: clean(summary?.extract) || trim(hits[0].snippet, 300),
    source: lang === "tl" ? "Wikipedia (Tagalog)" : "Wikipedia",
    url: summary?.content_urls?.desktop?.page || `${host}/wiki/${encodeURIComponent(hits[0].title)}`,
    image: summary?.thumbnail?.source || null,
    related: hits.slice(1).map((h) => ({
      title: h.title,
      description: trim(h.snippet, 140),
      url: `${host}/wiki/${encodeURIComponent(h.title)}`
    }))
  };
}

function settled(promise) {
  return promise.then(
    (value) => value,
    () => null
  );
}

/* Collect candidates from several sources, then keep the best match. */
async function runSearch(query) {
  const langs = isTagalog(query) ? ["tl", "en"] : ["en", "tl"];
  const variants = searchVariants(query);

  /* Sources are queried one after another with a short gap. Firing them all at
     once gets the bot throttled by wikipedia, which surfaced as bogus
     "no results" replies, so a small delay is cheaper than a failed search. */
  const fetchRound = async (q) => {
    const results = [];

    for (const task of [
      () => instantAnswer(q),
      () => wikiSearch(q, langs[0]),
      () => wikiSearch(q, langs[1])
    ]) {
      results.push(await settled(task()));

      // Stop early once we already have a confident match.
      const good = rank(query, results);
      if (good && good.score >= STRONG_MATCH) break;

      await sleep(150);
    }

    return results;
  };

  // Round 1: the user's exact wording across every source.
  let candidates = await fetchRound(variants[0]);
  let best = rank(query, candidates);

  /* A score below STRONG_MATCH means no keyword landed in the title, i.e. we
     only found a loosely related article ("ano ang tubig" -> "Danaw").
     Retry with the question words stripped ("tubig") and keep whichever
     round produced the better match overall. */
  if (variants.length > 1 && (!best || best.score < STRONG_MATCH)) {
    const extra = await fetchRound(variants[1]);
    const alt = rank(query, extra);
    if (alt && (!best || alt.score > best.score)) best = alt;
  }

  if (!best) return null;

  // Never answer with a completely unrelated article.
  if (best.score <= 0 && !isRelevant(query, best.data)) return null;

  return best.data;
}

/* Highest scoring candidate, or null when nothing is usable. */
function rank(query, candidates) {
  const ranked = candidates
    .filter((c) => c && c.answer)
    .map((c) => ({ data: c, score: scoreResult(query, c) }))
    .sort((a, b) => b.score - a.score);

  return ranked[0] || null;
}

function buildMessage(query, data) {
  const parts = [
    `🔎 GOOGLE SEARCH`,
    LINE,
    `❒ ${data.heading}`,
    "",
    data.answer
  ];

  if (data.related && data.related.length) {
    parts.push("", LINE, "📌 Other results:");
    data.related.forEach((r, i) => {
      parts.push(`${i + 1}. ${r.title}`);
      if (r.url) parts.push(`   ${r.url}`);
    });
  }

  parts.push(LINE, `🔗 ${data.url || "n/a"}`, `📚 Source: ${data.source}`);
  return parts.join("\n");
}

async function attachImage(url) {
  if (!url) return null;
  try {
    const res = await axios.get(url, {
      responseType: "stream",
      headers: { "User-Agent": UA },
      timeout: TIMEOUT
    });
    return res.data;
  } catch (err) {
    return null;
  }
}

module.exports.run = async function ({ api, event, args }) {
  const { threadID, messageID, messageReply, type } = event;

  const query = (type === "message_reply" && messageReply?.body
    ? messageReply.body
    : args.join(" ")
  ).trim();

  if (!query) {
    return api.sendMessage(
      `🔎 GOOGLE SEARCH\n${LINE}\ngoogle <what you want to search>\n\nExample: google who is jose rizal\nTip: you can also reply to a message to search its text.`,
      threadID,
      messageID
    );
  }

  api.sendMessage(`🔎 Searching for "${trim(query, 60)}"...`, threadID, messageID);

  let data;
  try {
    data = await runSearch(query);
  } catch (err) {
    return api.sendMessage(
      "⚠️ The search service is unreachable right now. Please try again later.",
      threadID,
      messageID
    );
  }

  if (!data) {
    return api.sendMessage(
      `❌ No results found for "${trim(query, 60)}".\nTry using different or more specific keywords.`,
      threadID,
      messageID
    );
  }

  const body = buildMessage(query, data);
  const image = await attachImage(data.image);

  if (!image) return api.sendMessage(body, threadID, messageID);

  return api.sendMessage({ body, attachment: image }, threadID, messageID);
};
