const fs = require("fs");
const {
  Jimp,
  collectPhotos,
  hexToInt,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "collage",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Combine 2-9 photos into a grid, row or column collage",
  prefix: true,
  premium: false,
  category: "tools",
  usages: "[reply to photos] -l <layout> -c <cols> -g <gap> -b <hex> -s <size> -f <fit>",
  cooldowns: 15
};

const MAX_PHOTOS = 9;
const LAYOUTS = ["grid", "row", "column"];
const FITS = ["cover", "contain"];

function guide(prefix) {
  return (
    "🧩 𝗖𝗢𝗟𝗟𝗔𝗚𝗘 𝗠𝗔𝗞𝗘𝗥\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━\n" +
    `Reply to a message with 2-${MAX_PHOTOS} photos then send:\n${prefix}collage\n\n` +
    "Options:\n" +
    "• -l <layout>  grid | row | column\n" +
    "• -c <cols>    number of columns (1-4)\n" +
    "• -g <gap>     spacing between cells (0-80)\n" +
    "• -b <hex>     background color\n" +
    "• -s <size>    size of each cell (200-900)\n" +
    "• -f <fit>     cover (fill) | contain (whole image)\n\n" +
    "Examples:\n" +
    `${prefix}collage -l grid -g 16 -b 111827\n` +
    `${prefix}collage -l row -f contain -b ffffff\n` +
    `${prefix}collage -c 3 -s 500`
  );
}

function parseFlags(args) {
  const flags = { layout: "grid", cols: null, gap: 14, background: "0f172a", size: 560, fit: "cover" };
  const unknown = [];

  for (let i = 0; i < args.length; i++) {
    const key = args[i].toLowerCase();
    const next = args[i + 1];

    if ((key === "-l" || key === "--layout") && next) {
      flags.layout = next.toLowerCase();
      i++;
    } else if ((key === "-c" || key === "--cols") && next) {
      flags.cols = clamp(parseInt(next, 10) || 2, 1, 4);
      i++;
    } else if ((key === "-g" || key === "--gap") && next) {
      flags.gap = clamp(parseInt(next, 10) || 0, 0, 80);
      i++;
    } else if ((key === "-b" || key === "--bg") && next) {
      flags.background = next;
      i++;
    } else if ((key === "-s" || key === "--size") && next) {
      flags.size = clamp(parseInt(next, 10) || 560, 200, 900);
      i++;
    } else if ((key === "-f" || key === "--fit") && next) {
      flags.fit = next.toLowerCase();
      i++;
    } else {
      unknown.push(args[i]);
    }
  }

  return { flags, unknown };
}

/** How many columns to use based on the layout and photo count. */
function resolveColumns(layout, count, requested) {
  if (layout === "row") return count;
  if (layout === "column") return 1;
  if (requested) return requested;
  if (count <= 2) return count;
  if (count <= 4) return 2;
  if (count <= 6) return 3;
  return 3;
}

async function buildCollage(urls, flags) {
  const cols = resolveColumns(flags.layout, urls.length, flags.cols);
  const rows = Math.ceil(urls.length / cols);
  const cell = flags.size;
  const gap = flags.gap;

  const width = cols * cell + gap * (cols + 1);
  const height = rows * cell + gap * (rows + 1);
  const canvas = new Jimp(width, height, hexToInt(flags.background, 0x0f172aff));

  for (let index = 0; index < urls.length; index++) {
    const tile = await Jimp.read(urls[index]);

    if (flags.fit === "contain") tile.contain(cell, cell);
    else tile.cover(cell, cell);

    const col = index % cols;
    const row = Math.floor(index / cols);
    const x = gap + col * (cell + gap) + Math.round((cell - tile.bitmap.width) / 2);
    const y = gap + row * (cell + gap) + Math.round((cell - tile.bitmap.height) / 2);

    canvas.composite(tile, x, y);
  }

  return { canvas, cols, rows };
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;

  if (args[0] && ["help", "guide"].includes(args[0].toLowerCase())) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const photos = collectPhotos(event, MAX_PHOTOS);
  if (photos.length < 2) {
    return api.sendMessage(
      `⚠️ Not enough photos (${photos.length}/2).\n` +
        `Reply to a message with 2-${MAX_PHOTOS} photos, or attach multiple photos along with the command.\n\n` +
        guide(prefix),
      threadID,
      messageID
    );
  }

  const { flags, unknown } = parseFlags(args);

  if (!LAYOUTS.includes(flags.layout)) {
    return api.sendMessage(`⚠️ Unknown layout "${flags.layout}".\nLayouts: ${LAYOUTS.join(", ")}`, threadID, messageID);
  }
  if (!FITS.includes(flags.fit)) {
    return api.sendMessage(`⚠️ Unknown fit "${flags.fit}".\nFits: ${FITS.join(", ")}`, threadID, messageID);
  }

  api.setMessageReaction("🧩", messageID, () => {}, true);

  let filePath;
  try {
    const { canvas, cols, rows } = await buildCollage(photos, flags);
    filePath = await saveImage(canvas, "collage");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "✅ 𝗖𝗢𝗟𝗟𝗔𝗚𝗘 𝗥𝗘𝗔𝗗𝗬\n" +
          `🖼 ${photos.length} photos • ${cols}x${rows} ${flags.layout}\n` +
          `📐 ${canvas.bitmap.width}x${canvas.bitmap.height} • fit: ${flags.fit}\n` +
          `💾 ${humanSize(stats.size)}` +
          (unknown.length ? `\n⚠️ Unknown options: ${unknown.join(", ")}` : ""),
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to build the collage: ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
