module.exports.config = {
  name: "approve",
  version: "3.0.0",
  permission: 0,
  credits: "ryuko",
  description: "review and approve pending requests, or approve a thread by name/id",
  prefix: false,
  category: "admin",
  premium: false,
  usages: "approve [pending] | approve <group name / group id> | approve [box/list/remove] [threadid]",
  cooldowns: 5,
};

module.exports.languages = {
    "bangla": {
        "listAdmin": 'approved list : \n\n%1',
        "notHavePermssion": 'you have no permission to use "%1"',
        "addedNewAdmin": 'approved %1 box :\n\n%2',
        "removedAdmin": 'remove %1 box in approve lists :\n\n%2'
    },
    "english": {
        "listAdmin": 'approved list : \n\n%1',
        "notHavePermssion": 'you have no permission to use "%1"',
        "addedNewAdmin": 'approved %1 box :\n\n%2',
        "removedAdmin": 'remove %1 box in approve lists :\n\n%2'
    }
}

module.exports.run = async function ({ api, event, args, Threads, Users, permssion, getText }) {
    const content = args.slice(1, args.length);
    const { threadID, messageID, mentions } = event;
    const configPath = '../../config.json'
    const { approvedgroups } = global.config;
    const { userName } = global.data;
    const { writeFileSync } = global.nodemodule["fs-extra"];
    const mention = Object.keys(mentions);
    delete require.cache[require.resolve('../../config.json')];
    var config = require('../../config.json');
    config.approvedgroups = config.approvedgroups || [];
    config.pendingrequests = config.pendingrequests || [];
    global.config.pendingrequests = config.pendingrequests;

    // helper: persist config and keep the runtime globals in sync
    const saveConfig = () => {
        writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
        global.config.approvedgroups = config.approvedgroups;
        global.config.pendingrequests = config.pendingrequests;
    };

    // helper: approve a thread id, notify the box and remove it from the pending list
    const approveThread = async (id, sourceName) => {
        id = String(id);
        if (config.approvedgroups.map(String).includes(id)) {
            return api.sendMessage('this box is already approved', threadID, messageID);
        }
        approvedgroups.push(id);
        config.approvedgroups.push(id);
        // drop it from the pending list if it was there
        config.pendingrequests = config.pendingrequests.filter(r => String(r.threadID) !== id);

        let boxname = sourceName ? `name : ${sourceName}\nid : ${id}` : null;
        if (!boxname) {
            try {
                const groupname = await global.data.threadInfo.get(id).threadName || "name does not exist";
                boxname = `group name : ${groupname}\ngroup id : ${id}`;
            } catch (error) {
                const username = await Users.getNameUser(id);
                boxname = `user name : ${username}\nuser id : ${id}`;
            }
        }
        saveConfig();
        return api.sendMessage('this box has been approved, you can now use the bot', id, () => {
            return api.sendMessage(getText("addedNewAdmin", 1, `${boxname}`), threadID, messageID);
        });
    };

    switch (args[0]) {
        // list all the requests that are waiting for approval
        case "pending":
        case "requests":
        case "request": {
            const pending = config.pendingrequests || [];
            if (pending.length == 0) return api.sendMessage("there are no pending requests right now.", threadID, messageID);

            let msg = "pending requests :\n";
            pending.forEach((r, i) => {
                msg += `\n${i + 1}. name : ${r.name || "unknown"}\n   id : ${r.threadID}`;
                if (r.time) msg += `\n   time : ${r.time}`;
                msg += "\n";
            });
            msg += `\nto approve, reply/send:\napprove <group name>\napprove <group id>`;
            return api.sendMessage(msg, threadID, messageID);
        }

        case "list":
        case "all":
        case "-a": {
            const listAdmin = approvedgroups || config.approvedgroups || [];
            var msg = [];

            for (const idAdmin of listAdmin) {
                if (parseInt(idAdmin)) {
                  let boxname;
                  try {
        const groupName = await global.data.threadInfo.get(idAdmin).threadName || "name does not exist"
        boxname = `group name : ${groupName}\ngroup id : ${idAdmin}`;
      } catch (error) {
        const userName = await Users.getNameUser(idAdmin);
        boxname = `user name : ${userName}\nuser id : ${idAdmin}`;
      }
                  msg.push(`\n${boxname}`);
                }
            };

            return api.sendMessage(`approved users and groups :\n${msg.join('\n')}`, threadID, messageID);
        }

        case "box": {
            if (permssion != 3) return api.sendMessage(getText("notHavePermssion", "add"), threadID, messageID);
          

          
            if (mention.length != 0 && isNaN(content[0])) {
              
                var listAdd = [];

                for (const id of mention) {
                  
                    approvedgroups.push(id);
                    config.approvedgroups.push(id);
                    config.pendingrequests = config.pendingrequests.filter(r => String(r.threadID) !== String(id));
                    listAdd.push(`${id} - ${event.mentions[id]}`);
                };

                saveConfig();
                return api.sendMessage(getText("addedNewAdmin", mention.length, listAdd.join("\n").replace(/\@/g, "")), threadID, messageID);
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                return approveThread(content[0]);
            }
            else return global.utils.throwError(this.config.name, threadID, messageID);
        }
        

        case "remove":
        case "rm":
        case "delete": {
            if (permssion != 3) return api.sendMessage(getText("notHavePermssion", "delete"), threadID, messageID);
            if (mentions.length != 0 && isNaN(content[0])) {
                const mention = Object.keys(mentions);
                var listAdd = [];

                for (const id of mention) {
                    const index = config.approvedgroups.findIndex(item => item == id);
                    approvedgroups.splice(index, 1);
                    config.approvedgroups.splice(index, 1);
                    listAdd.push(`${id} - ${event.mentions[id]}`);
                };

                saveConfig();
                return api.sendMessage(getText("removedAdmin", mention.length, listAdd.join("\n").replace(/\@/g, "")), threadID, messageID);
            }
            else if (content.length != 0 && !isNaN(content[0])) {
                const index = config.approvedgroups.findIndex(item => item.toString() == content[0]);
                approvedgroups.splice(index, 1);
                config.approvedgroups.splice(index, 1);
                
                  let boxname;
                  try {
        const groupname = await global.data.threadInfo.get(content[0]).threadName || "name does not exist";
        boxname = `group name : ${groupname}\ngroup id : ${content[0]}`;
      } catch (error) {
        const username = await Users.getNameUser(content[0]);
        boxname = `user name : ${username}\nuser id : ${content[0]}`
      }
                saveConfig();
                return api.sendMessage('this box has been removed from approved list', content[0], () => {
                return api.sendMessage(getText("removedAdmin", 1, `${boxname}`), threadID, messageID);
                });
            }
            else global.utils.throwError(this.config.name, threadID, messageID);
        }

        default: {
            // no argument -> show help/pending list hint
            if (!args[0]) {
                return api.sendMessage(
                    `usage :\napprove pending - show all pending requests\napprove <group name> - approve a pending request by name\napprove <group id> - approve by id`,
                    threadID, messageID
                );
            }

            // approving requires admin (2) or operator (3) permission
            if (permssion < 2) return api.sendMessage(getText("notHavePermssion", "approve"), threadID, messageID);

            const query = args.join(" ").trim();
            const pending = config.pendingrequests || [];

            // 1) exact id match against the pending list
            let target = pending.find(r => String(r.threadID) === query);

            // 2) name match (case-insensitive) against the pending list
            if (!target) {
                const q = query.toLowerCase();
                const matches = pending.filter(r => (r.name || "").toLowerCase().includes(q));
                if (matches.length > 1) {
                    let msg = `found ${matches.length} matching requests, please approve using the id :\n`;
                    matches.forEach((r, i) => { msg += `\n${i + 1}. ${r.name} (${r.threadID})`; });
                    return api.sendMessage(msg, threadID, messageID);
                }
                if (matches.length === 1) target = matches[0];
            }

            if (target) {
                return approveThread(target.threadID, target.name);
            }

            // 3) not in pending, but a raw numeric id was given -> approve it directly
            if (!isNaN(query) && query.length > 0) {
                return approveThread(query);
            }

            return api.sendMessage(`no pending request found matching "${query}".\nuse "approve pending" to see the list.`, threadID, messageID);
        }
    };
}
