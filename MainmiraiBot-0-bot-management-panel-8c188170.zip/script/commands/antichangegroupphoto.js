const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");

const CACHE_DIR = path.join(__dirname, "cache", "antichangegroupphoto");

module.exports.config = {
  name: "antichangegroupphoto",
  version: "1.0.0",
  permission: 1,
  credits: "mainmirai",
  prefix: true,
  description: "revert the group photo when someone changes it",
  category: "group",
  premium: false,
  usages: "antichangegroupphoto [on | off | status | sync]",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event, args, Threads }) {
  const { threadID, messageID, isGroup } = event;
  if (!isGroup) return api.sendMessage("this command only works in a group chat", threadID, messageID);

  const option = (args[0] || "").toLowerCase();
  const record = await Threads.getData(threadID);
  const data = (record && record.data) || global.data.threadData.get(String(threadID)) || {};
  const current = data.antichangegroupphoto || {};

  if (!option || option === "status") {
    return api.sendMessage(
      `antichangegroupphoto is currently ${current.enabled ? "ON" : "OFF"}` +
        (current.enabled ? `\nlocked photo : ${current.file ? "saved" : "(none saved)"}` : "") +
        `\n\nusage : antichangegroupphoto [on | off | status | sync]`,
      threadID,
      messageID
    );
  }

  if (!["on", "off", "sync"].includes(option)) {
    return api.sendMessage("usage : antichangegroupphoto [on | off | status | sync]", threadID, messageID);
  }

  if (option === "off") {
    data.antichangegroupphoto = { enabled: false, file: current.file || "" };
    await Threads.setData(threadID, { data });
    global.data.threadData.set(String(threadID), data);
    return api.sendMessage("antichangegroupphoto is now OFF", threadID, messageID);
  }

  // read the current group photo url
  let imageSrc = "";
  try {
    const info = await api.getThreadInfo(threadID);
    imageSrc = info.imageSrc || "";
  } catch (e) {}

  if (!imageSrc) {
    return api.sendMessage(
      "this group has no photo set yet, set one first then run this command again",
      threadID,
      messageID
    );
  }

  // facebook cdn links expire, so keep our own copy to re-upload later
  const file = path.join(CACHE_DIR, `${threadID}.jpg`);
  try {
    await fs.ensureDir(CACHE_DIR);
    const res = await axios.get(imageSrc, { responseType: "arraybuffer" });
    await fs.writeFile(file, Buffer.from(res.data));
  } catch (e) {
    return api.sendMessage("i can't save the current group photo right now, please try again", threadID, messageID);
  }

  data.antichangegroupphoto = { enabled: true, file };
  await Threads.setData(threadID, { data });
  global.data.threadData.set(String(threadID), data);

  return api.sendMessage(
    option === "sync"
      ? "locked photo updated to the current group photo"
      : `antichangegroupphoto is now ON\nlocked photo : saved\n\nif you want to change the group photo, turn this off first or use "antichangegroupphoto sync" after changing it`,
    threadID,
    messageID
  );
};
