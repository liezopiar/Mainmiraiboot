module.exports.config = {
  name: "antichangenickname",
  version: "1.0.0",
  permission: 1,
  credits: "mainmirai",
  prefix: true,
  description: "revert member nicknames when someone changes them",
  category: "group",
  premium: false,
  usages: "antichangenickname [on | off | status | sync]",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event, args, Threads }) {
  const { threadID, messageID, isGroup } = event;
  if (!isGroup) return api.sendMessage("this command only works in a group chat", threadID, messageID);

  const option = (args[0] || "").toLowerCase();
  const record = await Threads.getData(threadID);
  const data = (record && record.data) || global.data.threadData.get(String(threadID)) || {};
  const current = data.antichangenickname || {};

  if (!option || option === "status") {
    const count = Object.keys(current.nicknames || {}).length;
    return api.sendMessage(
      `antichangenickname is currently ${current.enabled ? "ON" : "OFF"}` +
        (current.enabled ? `\nlocked nicknames : ${count} member${count === 1 ? "" : "s"}` : "") +
        `\n\nusage : antichangenickname [on | off | status | sync]`,
      threadID,
      messageID
    );
  }

  if (!["on", "off", "sync"].includes(option)) {
    return api.sendMessage("usage : antichangenickname [on | off | status | sync]", threadID, messageID);
  }

  if (option === "off") {
    data.antichangenickname = { enabled: false, nicknames: current.nicknames || {} };
    await Threads.setData(threadID, { data });
    global.data.threadData.set(String(threadID), data);
    return api.sendMessage("antichangenickname is now OFF", threadID, messageID);
  }

  // snapshot every member's nickname, members with no nickname are stored as ""
  let nicknames = {};
  try {
    const info = await api.getThreadInfo(threadID);
    const saved = info.nicknames || {};
    for (const id of info.participantIDs || []) {
      nicknames[String(id)] = saved[String(id)] || "";
    }
  } catch (e) {
    return api.sendMessage("i can't read the member list right now, please try again", threadID, messageID);
  }

  const count = Object.keys(nicknames).length;
  if (count === 0) {
    return api.sendMessage("i can't read the member list right now, please try again", threadID, messageID);
  }

  data.antichangenickname = { enabled: true, nicknames };
  await Threads.setData(threadID, { data });
  global.data.threadData.set(String(threadID), data);

  return api.sendMessage(
    option === "sync"
      ? `locked nicknames updated, ${count} member${count === 1 ? "" : "s"} saved`
      : `antichangenickname is now ON\nlocked nicknames : ${count} member${count === 1 ? "" : "s"}\n\nif you want to change a nickname, turn this off first or use "antichangenickname sync" after changing it`,
    threadID,
    messageID
  );
};
