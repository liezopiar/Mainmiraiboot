const fs = require("fs-extra");
const path = require("path");
const axios = require("axios");

module.exports.config = {
  name: "antiunsend",
  version: "1.0.0",
  permission: 1,
  credits: "mainmirai",
  prefix: true,
  description: "copy back messages/images that a user unsends",
  category: "group",
  premium: false,
  usages: "antiunsend [on | off | status]",
  cooldowns: 5,
};

const CACHE_DIR = path.join(__dirname, "cache");
const MAX_AGE = 10 * 60 * 1000; // keep messages for 10 minutes
const MAX_PER_THREAD = 60; // how many recent messages to remember per thread

if (!global.antiunsend) global.antiunsend = new Map();

function isEnabled(threadID) {
  const data = global.data.threadData.get(String(threadID)) || {};
  return data.antiunsend === true;
}

function getStore(threadID) {
  const key = String(threadID);
  if (!global.antiunsend.has(key)) global.antiunsend.set(key, new Map());
  return global.antiunsend.get(key);
}

function cleanStore(store) {
  const now = Date.now();
  for (const [id, msg] of store) {
    if (now - msg.time > MAX_AGE) store.delete(id);
  }
  while (store.size > MAX_PER_THREAD) {
    store.delete(store.keys().next().value);
  }
}

function getUrls(attachments = []) {
  const urls = [];
  for (const atm of attachments) {
    const url = atm.url || atm.largePreviewUrl || atm.previewUrl || atm.image || atm.playableUrl;
    if (url) urls.push({ url, type: atm.type || "file", name: atm.filename || atm.ID || "file" });
  }
  return urls;
}

async function download(list) {
  const streams = [];
  const paths = [];
  await fs.ensureDir(CACHE_DIR);

  for (const item of list) {
    try {
      const res = await axios.get(item.url, { responseType: "arraybuffer" });
      const ctype = String(res.headers["content-type"] || "");
      let ext = "png";
      if (item.type === "video" || ctype.includes("video")) ext = "mp4";
      else if (item.type === "audio" || ctype.includes("audio")) ext = "mp3";
      else if (ctype.includes("gif")) ext = "gif";
      else if (ctype.includes("jpeg")) ext = "jpg";

      const file = path.join(CACHE_DIR, `antiunsend_${Date.now()}_${Math.floor(Math.random() * 1e5)}.${ext}`);
      await fs.writeFile(file, Buffer.from(res.data, "binary"));
      paths.push(file);
      streams.push(fs.createReadStream(file));
    } catch (error) {
      // skip attachments that can no longer be fetched
    }
  }
  return { streams, paths };
}

module.exports.handleEvent = async function ({ api, event, Users }) {
  try {
    const { type, threadID, senderID, messageID, body, attachments } = event;
    if (!isEnabled(threadID)) return;

    const botID = await api.getCurrentUserID();
    const store = getStore(threadID);

    if (type === "message" || type === "message_reply") {
      if (String(senderID) === String(botID)) return;
      const files = getUrls(attachments);
      if (!body && files.length === 0) return;

      store.set(String(messageID), {
        senderID: String(senderID),
        body: body || "",
        files,
        time: Date.now(),
      });
      cleanStore(store);
      return;
    }

    if (type !== "message_unsend") return;

    const cached = store.get(String(messageID));
    if (!cached) return;
    store.delete(String(messageID));
    if (String(cached.senderID) === String(botID)) return;

    const name = (await Users.getNameUser(cached.senderID)) || "someone";
    let text = `${name} unsent a message:`;
    if (cached.body) text += `\n\n${cached.body}`;

    if (cached.files.length === 0) {
      return api.sendMessage(text, threadID);
    }

    const { streams, paths } = await download(cached.files);
    if (streams.length === 0) return api.sendMessage(text, threadID);

    return api.sendMessage({ body: text, attachment: streams }, threadID, () => {
      paths.forEach((file) => fs.unlink(file).catch(() => {}));
    });
  } catch (error) {
    console.log("[antiunsend]", error.message || error);
  }
};

module.exports.run = async function ({ api, event, args, Threads }) {
  const { threadID, messageID, isGroup } = event;
  if (!isGroup) return api.sendMessage("this command only works in a group chat", threadID, messageID);

  const option = (args[0] || "").toLowerCase();
  const threadData = await Threads.getData(threadID);
  const data = threadData.data || {};

  if (option === "status" || !option) {
    return api.sendMessage(
      `antiunsend is currently ${data.antiunsend ? "ON" : "OFF"}\n\nuse "antiunsend on" or "antiunsend off" to change it`,
      threadID,
      messageID
    );
  }

  if (option !== "on" && option !== "off") {
    return api.sendMessage("usage: antiunsend [on | off | status]", threadID, messageID);
  }

  data.antiunsend = option === "on";
  await Threads.setData(threadID, { data });
  global.data.threadData.set(String(threadID), data);

  if (option === "off") global.antiunsend.delete(String(threadID));

  return api.sendMessage(
    option === "on"
      ? "antiunsend is now ON, i will copy back any message or image that gets unsent"
      : "antiunsend is now OFF",
    threadID,
    messageID
  );
};
