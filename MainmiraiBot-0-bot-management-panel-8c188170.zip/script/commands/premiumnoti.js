const premiumUtil = require("../../main/utility/premium.js");

module.exports.config = {
  name: "premiumnoti",
  version: "1.0.0",
  permission: 3,
  credits: "ryuko",
  prefix: true,
  premium: false,
  category: "operator",
  cooldowns: 15,
  aliases: ["premiumannounce", "notipremium"],
  description: "Send an announcement to every premium member, or ping only the ones about to expire",
  usages: "premiumnoti <message> | premiumnoti expiring [days] | premiumnoti test <message>",
};

const DAY = 24 * 60 * 60 * 1000;

module.exports.run = async function ({ api, event, args, Users, prefix }) {
  const { threadID, messageID, senderID } = event;

  premiumUtil.migrate();
  premiumUtil.sweepExpired();

  const action = (args[0] || "").toLowerCase();
  const getName = async (id) => {
    try { return await Users.getNameUser(id); } catch { return "Facebook User"; }
  };

  const list = premiumUtil.getList();
  if (!list.length) return api.sendMessage("📭 There are no premium members to notify.", threadID, messageID);

  // ── expiry reminder mode ────────────────────────────────────────────────────
  if (action === "expiring" || action === "expire" || action === "remind") {
    let days = parseInt(args[1], 10);
    if (isNaN(days) || days < 1) days = 3;

    const targets = list
      .filter(entry => entry.expiresAt && Number(entry.expiresAt) - Date.now() <= days * DAY)
      .sort((a, b) => Number(a.expiresAt) - Number(b.expiresAt));

    if (!targets.length) {
      return api.sendMessage(`✅ No premium member is expiring within ${days} day(s).`, threadID, messageID);
    }

    let sent = 0;
    let failed = 0;
    for (const entry of targets) {
      const left = premiumUtil.formatRemaining(entry.expiresAt);
      await new Promise(resolve => {
        api.sendMessage(
          `⏰ 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗥𝗘𝗠𝗜𝗡𝗗𝗘𝗥\n` +
          `━━━━━━━━━━━━━━━\n` +
          `your premium expires in ${left}.\n` +
          `type ${prefix}redeem <code> to extend it, or ${prefix}requestpremium to ask for a renewal.`,
          entry.userID,
          err => { err ? failed++ : sent++; resolve(); }
        );
      });
    }

    const preview = [];
    for (const entry of targets.slice(0, 5)) {
      preview.push(`• ${await getName(entry.userID)} — ${premiumUtil.formatRemaining(entry.expiresAt)}`);
    }

    return api.sendMessage(
      `⏰ 𝗘𝗫𝗣𝗜𝗥𝗬 𝗥𝗘𝗠𝗜𝗡𝗗𝗘𝗥𝗦 (≤ ${days}d)\n` +
      `━━━━━━━━━━━━━━━\n` +
      `${preview.join("\n")}${targets.length > preview.length ? `\n… +${targets.length - preview.length} more` : ""}\n` +
      `━━━━━━━━━━━━━━━\n` +
      `✅ sent : ${sent}  •  ⚠️ failed : ${failed}`,
      threadID, messageID
    );
  }

  // ── broadcast mode ──────────────────────────────────────────────────────────
  const testMode = action === "test" || action === "preview";
  const message = (testMode ? args.slice(1) : args).join(" ").trim();

  if (!message) {
    return api.sendMessage(
      `📢 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗡𝗢𝗧𝗜\n` +
      `━━━━━━━━━━━━━━━\n` +
      `${prefix}premiumnoti <message> - send to all ${list.length} premium members\n` +
      `${prefix}premiumnoti test <message> - send only to you as a preview\n` +
      `${prefix}premiumnoti expiring [days] - remind members whose time is almost up\n` +
      `━━━━━━━━━━━━━━━\n` +
      `📌 example : ${prefix}premiumnoti new premium command added : ${prefix}premiumgift`,
      threadID, messageID
    );
  }

  const fromName = await getName(senderID);
  const body =
    `📢 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧\n` +
    `━━━━━━━━━━━━━━━\n` +
    `${message}\n` +
    `━━━━━━━━━━━━━━━\n` +
    `👤 from : ${fromName}\n` +
    `⭐ you are getting this because you are a premium member.`;

  if (testMode) {
    api.sendMessage(body, senderID);
    return api.sendMessage(
      `🧪 Preview sent to you only. ${list.length} premium member(s) would receive it.`,
      threadID, messageID
    );
  }

  let sent = 0;
  let failed = 0;
  for (const entry of list) {
    await new Promise(resolve => {
      api.sendMessage(body, entry.userID, err => { err ? failed++ : sent++; resolve(); });
    });
  }

  return api.sendMessage(
    `📢 𝗔𝗡𝗡𝗢𝗨𝗡𝗖𝗘𝗠𝗘𝗡𝗧 𝗦𝗘𝗡𝗧\n` +
    `━━━━━━━━━━━━━━━\n` +
    `👥 premium members : ${list.length}\n` +
    `✅ delivered : ${sent}\n` +
    `⚠️ failed : ${failed}`,
    threadID, messageID
  );
};
