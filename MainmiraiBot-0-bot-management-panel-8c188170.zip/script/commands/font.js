const fancyfont = require("../../main/utility/fancyfont.js");

module.exports.config = {
	name: "font",
	version: "1.0.0",
	permission: 1,
	credits: "ryuko",
	prefix: true,
	description: "change the fancy text style used by every command",
	category: "system",
	usages: "[ on | off | list | preview | <style> ]",
	cooldowns: 3
};

const SAMPLE = "The quick brown fox 12345";

/**
 * saves a per group override into threadData. the font handler reads this on
 * every outgoing message, so changes apply instantly with no restart.
 */
async function saveThreadSetting(Threads, threadID, patch) {
	const id = String(threadID);
	const current = (await Threads.getData(id)) || {};
	const data = current.data || {};
	const next = { ...data, fancyfont: { ...(data.fancyfont || {}), ...patch } };

	await Threads.setData(id, { data: next });
	global.data.threadData.set(id, next);
	return next.fancyfont;
}

module.exports.run = async function ({ api, event, args, Threads }) {
	const { threadID, messageID } = event;
	const action = (args[0] || "").toLowerCase();
	const active = fancyfont.settingsFor(threadID);

	// status
	if (!action) {
		return api.sendMessage(
			`[ font ]\n\n`
			+ `status : ${active.enabled ? "on" : "off"}\n`
			+ `style : ${fancyfont.styleLabel(active.style)}\n`
			+ `numbers : ${active.convertNumbers ? "styled" : "plain"}\n\n`
			+ `preview\n${fancyfont.stylize(SAMPLE, active.style, active)}\n\n`
			+ `usage\nfont list - all styles\nfont preview - show every style\nfont <style> - set style\nfont on | off - toggle here\nfont numbers on | off`,
			threadID,
			messageID
		);
	}

	if (action === "list") {
		const styles = fancyfont.listStyles();
		return api.sendMessage(
			`[ font styles ]\n\n${styles.map((s, i) => `${i + 1}. ${s}`).join("\n")}\n\ncurrent : ${active.style}\nuse : font <style>`,
			threadID,
			messageID
		);
	}

	if (action === "preview") {
		// each sample is wrapped in raw() so the handler does not restyle the
		// already converted text on the way out
		const body = fancyfont.listStyles()
			.map(style => `${style}\n${fancyfont.raw(fancyfont.stylize(SAMPLE, style))}`)
			.join("\n\n");
		return api.sendMessage(`[ font preview ]\n\n${body}`, threadID, messageID);
	}

	if (action === "on" || action === "off") {
		const enabled = action === "on";
		await saveThreadSetting(Threads, threadID, { enabled });
		// clears the auto off safety switch tripped by a failed send
		if (enabled) fancyfont.reset(threadID);
		return api.sendMessage(
			enabled
				? `fancy font turned on for this group, style : ${fancyfont.styleLabel(active.style)}`
				: `fancy font turned off for this group, messages will send as plain text.`,
			threadID,
			messageID
		);
	}

	if (action === "numbers") {
		const mode = (args[1] || "").toLowerCase();
		if (mode !== "on" && mode !== "off") {
			return api.sendMessage("usage : font numbers on | off", threadID, messageID);
		}
		await saveThreadSetting(Threads, threadID, { convertNumbers: mode === "on" });
		return api.sendMessage(
			`numbers will now send as ${mode === "on" ? "styled" : "plain"} characters.`,
			threadID,
			messageID
		);
	}

	if (!fancyfont.isStyle(action)) {
		return api.sendMessage(
			`"${action}" is not a valid style.\n\navailable : ${fancyfont.listStyles().join(", ")}`,
			threadID,
			messageID
		);
	}

	await saveThreadSetting(Threads, threadID, { style: action, enabled: true });
	fancyfont.reset(threadID);
	return api.sendMessage(
		`[ font ]\n\nstyle set to ${fancyfont.styleLabel(action)}\n\n${fancyfont.stylize(SAMPLE, action)}`,
		threadID,
		messageID
	);
};
