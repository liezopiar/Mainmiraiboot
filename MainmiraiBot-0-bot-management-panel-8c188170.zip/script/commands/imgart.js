const fs = require("fs");
const {
  Jimp,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup,
  readPhoto
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgart",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Premium artistic filter presets for photos",
  prefix: true,
  premium: true,
  category: "media",
  usages: "[reply to a photo] <preset> | list",
  cooldowns: 12
};

/** blend a flat color over the image at a given strength */
function tint(image, color, strength) {
  const layer = new Jimp(image.bitmap.width, image.bitmap.height, color);
  layer.opacity(clamp(strength, 0, 1));
  return image.composite(layer, 0, 0);
}

/** soft glow: a blurred copy laid back on top of the original */
function glow(image, radius = 12, strength = 0.45) {
  const blurred = image.clone().blur(radius);
  blurred.opacity(clamp(strength, 0, 1));
  return image.composite(blurred, 0, 0);
}

/** fake chromatic aberration by nudging a tinted copy sideways */
function shift(image, offset, color, strength) {
  const copy = image.clone();
  tint(copy, color, 0.6);
  copy.opacity(clamp(strength, 0, 1));
  return image.composite(copy, offset, 0);
}

/** darken the corners like an old lens */
function vignette(image, strength = 0.75) {
  const { width, height } = image.bitmap;
  const cx = width / 2;
  const cy = height / 2;
  const max = Math.sqrt(cx * cx + cy * cy);

  image.scan(0, 0, width, height, function (x, y, idx) {
    const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2) / max;
    const factor = 1 - clamp(dist ** 2 * strength, 0, 0.9);
    this.bitmap.data[idx] *= factor;
    this.bitmap.data[idx + 1] *= factor;
    this.bitmap.data[idx + 2] *= factor;
  });
  return image;
}

/** scatter bright/dark pixels for a filmic grain */
function grain(image, amount = 22) {
  const { width, height } = image.bitmap;
  image.scan(0, 0, width, height, function (x, y, idx) {
    const noise = (Math.random() - 0.5) * amount;
    this.bitmap.data[idx] = clamp(this.bitmap.data[idx] + noise, 0, 255);
    this.bitmap.data[idx + 1] = clamp(this.bitmap.data[idx + 1] + noise, 0, 255);
    this.bitmap.data[idx + 2] = clamp(this.bitmap.data[idx + 2] + noise, 0, 255);
  });
  return image;
}

/** map every pixel between two colors based on its brightness */
function duotone(image, darkHex, lightHex) {
  const dark = Jimp.intToRGBA(darkHex);
  const light = Jimp.intToRGBA(lightHex);
  image.grayscale().scan(0, 0, image.bitmap.width, image.bitmap.height, function (x, y, idx) {
    const t = this.bitmap.data[idx] / 255;
    this.bitmap.data[idx] = dark.r + (light.r - dark.r) * t;
    this.bitmap.data[idx + 1] = dark.g + (light.g - dark.g) * t;
    this.bitmap.data[idx + 2] = dark.b + (light.b - dark.b) * t;
  });
  return image;
}

const PRESETS = {
  noir: {
    info: "high contrast black & white film",
    apply: (img) => grain(vignette(img.grayscale().contrast(0.45).brightness(-0.05), 0.85), 18)
  },
  vaporwave: {
    info: "pink & cyan retro haze",
    apply: (img) => glow(shift(tint(img.contrast(0.2), 0xff3fb5ff, 0.22), 6, 0x00e5ffff, 0.35), 14, 0.4)
  },
  vintage: {
    info: "faded 70s photograph",
    apply: (img) => grain(vignette(tint(img.sepia().contrast(0.12).brightness(0.06), 0xffd9a0ff, 0.18), 0.6), 14)
  },
  cyberpunk: {
    info: "neon magenta night city",
    apply: (img) => glow(tint(img.contrast(0.4).brightness(-0.12), 0x7b2dffff, 0.28), 18, 0.5)
  },
  dreamy: {
    info: "soft pastel glow",
    apply: (img) => glow(tint(img.brightness(0.12).contrast(-0.08), 0xffc8e0ff, 0.16), 16, 0.55)
  },
  glitch: {
    info: "broken signal color split",
    apply: (img) => shift(shift(img.contrast(0.25), -9, 0xff0044ff, 0.4), 9, 0x00ffccff, 0.4)
  },
  frost: {
    info: "cold blue winter tone",
    apply: (img) => tint(img.contrast(0.18).brightness(0.05), 0x5fa8ffff, 0.24)
  },
  ember: {
    info: "warm orange sunset",
    apply: (img) => vignette(tint(img.contrast(0.22), 0xff7a1aff, 0.25), 0.55)
  },
  blueprint: {
    info: "technical blue duotone",
    apply: (img) => duotone(img, 0x061a3cff, 0x8fd0ffff)
  },
  matcha: {
    info: "muted green duotone",
    apply: (img) => duotone(img, 0x14261aff, 0xd6e8b8ff)
  },
  comic: {
    info: "bold posterized cartoon",
    apply: (img) => img.posterize(5).contrast(0.4).convolute([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
  },
  polaroid: {
    info: "instant photo with white frame",
    apply: (img) => {
      const shot = grain(tint(img.brightness(0.08).contrast(0.1), 0xfff0d0ff, 0.14), 10);
      const pad = Math.round(Math.max(shot.bitmap.width, shot.bitmap.height) * 0.05);
      const canvas = new Jimp(shot.bitmap.width + pad * 2, shot.bitmap.height + pad * 5, 0xfbfbf6ff);
      canvas.composite(shot, pad, pad);
      return canvas;
    }
  }
};

const ALIASES = {
  bw: "noir",
  mono: "noir",
  retro: "vintage",
  neon: "cyberpunk",
  soft: "dreamy",
  cold: "frost",
  warm: "ember",
  cartoon: "comic",
  instant: "polaroid"
};

function guide(prefix) {
  const lines = Object.entries(PRESETS).map(([name, p]) => `• ${name.padEnd(11)} ${p.info}`);
  return (
    "🎨 𝗔𝗥𝗧 𝗙𝗜𝗟𝗧𝗘𝗥𝗦 (premium)\n" +
    "━━━━━━━━━━━━━━━\n" +
    `reply to a photo then send :\n${prefix}imgart <preset>\n\n` +
    lines.join("\n") +
    "\n\nyou can stack up to 3 presets :\n" +
    `${prefix}imgart noir\n` +
    `${prefix}imgart vaporwave glitch\n` +
    `${prefix}imgart blueprint comic polaroid`
  );
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const first = (args[0] || "").toLowerCase();

  if (!first || ["list", "help", "presets"].includes(first)) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  // resolve up to 3 presets, applied in the order they were typed
  const picked = [];
  const unknown = [];
  for (const token of args.slice(0, 3)) {
    const name = ALIASES[token.toLowerCase()] || token.toLowerCase();
    if (PRESETS[name]) picked.push(name);
    else unknown.push(token);
  }

  if (!picked.length) {
    return api.sendMessage(`⚠️ Unknown preset "${args[0]}".\n\n${guide(prefix)}`, threadID, messageID);
  }

  api.setMessageReaction("🎨", messageID, () => {}, true);

  let filePath;
  try {
    let image = await readPhoto(event, 1600);
    if (!image) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage(
        `⚠️ A photo is required.\nReply to a photo then type ${prefix}imgart ${picked[0]}`,
        threadID,
        messageID
      );
    }

    for (const name of picked) {
      const result = PRESETS[name].apply(image);
      if (result && result.bitmap) image = result;
    }

    filePath = await saveImage(image, "imgart");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "🎨 𝗔𝗥𝗧 𝗙𝗜𝗟𝗧𝗘𝗥 𝗔𝗣𝗣𝗟𝗜𝗘𝗗\n" +
          `✨ ${picked.join(" → ")}\n` +
          `📐 ${image.bitmap.width}x${image.bitmap.height}\n` +
          `💾 ${humanSize(stats.size)}` +
          (unknown.length ? `\n⚠️ skipped : ${unknown.join(", ")}` : ""),
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to apply the filter : ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
