module.exports.config = {
  name: "codeai",
  version: "1.1.0",
  permission: 0,
  credits: "Opiar",
  description: "AI-powered code assistant",
  prefix: false,
  premium: false,
  category: "coding",
  usage: "",
  cooldowns: 3,
  dependencies: {
    "axios": ""
  }
};

const axios = require('axios');

module.exports.run = async function({ api, event, args }) {
    const query = args.join(" ");
    
    if (!query) {
        return api.sendMessage("Please provide a coding-related question or query.", event.threadID, event.messageID);
    }
    
    try {
        const encodedQuery = encodeURIComponent(query);
        const apiUrl = `https://gis-rest-api.onrender.com/codeai?search=${encodedQuery}`;
        
        const response = await axios.get(apiUrl);
        const result = response.data;
        
        if (!result) {
            return api.sendMessage("No response from the API.", event.threadID, event.messageID);
        }
        
        return api.sendMessage(result, event.threadID, event.messageID);
        
    } catch (error) {
        console.error("API Error:", error);
        return api.sendMessage("An error occurred while processing your request. Please try again later.", event.threadID, event.messageID);
    }
};
