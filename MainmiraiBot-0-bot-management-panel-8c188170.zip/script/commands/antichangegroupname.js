module.exports.config = {
  name: "antichangegroupname",
  version: "1.0.1",
  permission: 1,
  credits: "mainmirai",
  prefix: true,
  description: "revert the group name when someone changes it",
  category: "group",
  premium: false,
  usages: "antichangegroupname [on | off | status | sync]",
  cooldowns: 5,
};

module.exports.run = async function ({ api, event, args, Threads }) {
  const { threadID, messageID, isGroup } = event;
  if (!isGroup) return api.sendMessage("this command only works in a group chat", threadID, messageID);

  const option = (args[0] || "").toLowerCase();
  const record = await Threads.getData(threadID);
  const data = (record && record.data) || global.data.threadData.get(String(threadID)) || {};
  const current = data.antichangegroupname || {};

  if (!option || option === "status") {
    return api.sendMessage(
      `antichangegroupname is currently ${current.enabled ? "ON" : "OFF"}` +
        (current.enabled ? `\nlocked name : ${current.name || "(none saved)"}` : "") +
        `\n\nusage : antichangegroupname [on | off | status | sync]`,
      threadID,
      messageID
    );
  }

  if (!["on", "off", "sync"].includes(option)) {
    return api.sendMessage("usage : antichangegroupname [on | off | status | sync]", threadID, messageID);
  }

  if (option === "off") {
    data.antichangegroupname = { enabled: false, name: current.name || "" };
    await Threads.setData(threadID, { data });
    global.data.threadData.set(String(threadID), data);
    return api.sendMessage("antichangegroupname is now OFF", threadID, messageID);
  }

  let threadName = "";
  try {
    const info = await api.getThreadInfo(threadID);
    threadName = info.threadName || "";
  } catch (e) {}

  if (!threadName) {
    return api.sendMessage("i can't read the current group name right now, please try again", threadID, messageID);
  }

  data.antichangegroupname = { enabled: true, name: threadName };
  await Threads.setData(threadID, { data });
  global.data.threadData.set(String(threadID), data);

  return api.sendMessage(
    option === "sync"
      ? `locked name updated to : ${threadName}`
      : `antichangegroupname is now ON\nlocked name : ${threadName}\n\nif you want to rename the group, turn this off first or use "antichangegroupname sync" after renaming`,
    threadID,
    messageID
  );
};
