const axios = require("axios");
const FormData = require("form-data");

module.exports.config = {
  name: "upload",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Upload a photo, video or file and get a direct shareable link",
  prefix: true,
  premium: false,
  category: "tools",
  usages: "[reply to photo/video/file] (-p litterbox|uguu|tmpfiles|imgbb)",
  cooldowns: 10
};

const MAX_FILES = 5;
const MAX_BYTES = 25 * 1024 * 1024; // 25 MB safety cap
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const EXT_BY_MIME = {
  "image/jpeg": "jpg",
  "image/jpg": "jpg",
  "image/png": "png",
  "image/gif": "gif",
  "image/webp": "webp",
  "image/bmp": "bmp",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/webm": "webm",
  "audio/mpeg": "mp3",
  "audio/mp4": "m4a",
  "audio/ogg": "ogg",
  "application/pdf": "pdf",
  "application/zip": "zip"
};

/** Every attachment in the replied message first, then the ones on this message. */
function collectFiles(event, max = MAX_FILES) {
  const buckets = [event?.messageReply?.attachments, event?.attachments];
  const files = [];

  for (const bucket of buckets) {
    if (!Array.isArray(bucket)) continue;
    for (const item of bucket) {
      const url = item?.url || item?.previewUrl || item?.largePreviewUrl;
      if (!url || files.some(f => f.url === url)) continue;
      files.push({ url, type: item?.type || "file" });
      if (files.length >= max) return files;
    }
  }

  return files;
}

function humanSize(bytes) {
  if (!bytes) return "0 KB";
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(2)} MB`;
}

async function download(url) {
  const res = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 60000,
    maxContentLength: MAX_BYTES,
    maxBodyLength: MAX_BYTES,
    headers: { "User-Agent": UA }
  });

  const mime = String(res.headers["content-type"] || "").split(";")[0].toLowerCase();
  const buffer = Buffer.from(res.data);

  return {
    buffer,
    mime: mime || "application/octet-stream",
    ext: EXT_BY_MIME[mime] || "bin",
    isImage: mime.startsWith("image/"),
    size: buffer.length
  };
}

async function post(url, form) {
  const res = await axios.post(url, form, {
    headers: { ...form.getHeaders(), "User-Agent": UA },
    timeout: 120000
  });
  return res.data;
}

/* ── Hosts ─────────────────────────────────────────────────────────── */

/** catbox's sister service — keeps files for up to 72 hours, any file type. */
async function toLitterbox(file, name) {
  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("time", "72h");
  form.append("fileToUpload", file.buffer, { filename: name, contentType: file.mime });

  const link = String(await post("https://litterbox.catbox.moe/resources/internals/api.php", form)).trim();
  if (!link.startsWith("http")) throw new Error(link || "litterbox rejected the upload");
  return link;
}

async function toUguu(file, name) {
  const form = new FormData();
  form.append("files[]", file.buffer, { filename: name, contentType: file.mime });

  const link = String(await post("https://uguu.se/upload?output=text", form)).trim().split("\n")[0];
  if (!link.startsWith("http")) throw new Error("uguu rejected the upload");
  return link;
}

async function toTmpfiles(file, name) {
  const form = new FormData();
  form.append("file", file.buffer, { filename: name, contentType: file.mime });

  const data = await post("https://tmpfiles.org/api/v1/upload", form);
  const link = data?.data?.url;
  if (!link) throw new Error(data?.message || "tmpfiles rejected the upload");
  // /dl/ serves the raw file instead of the preview page
  return link.replace("tmpfiles.org/", "tmpfiles.org/dl/");
}

/** Permanent, but only for images and only when an API key is configured. */
async function toImgbb(file, name) {
  const key = process.env.IMGBB_API_KEY;
  if (!key) throw new Error("imgbb needs an IMGBB_API_KEY in the .env file");
  if (!file.isImage) throw new Error("imgbb only accepts images");

  const form = new FormData();
  form.append("image", file.buffer.toString("base64"));
  form.append("name", name.replace(/\.[^.]+$/, ""));

  const data = await post(`https://api.imgbb.com/1/upload?key=${encodeURIComponent(key)}`, form);
  const link = data?.data?.url;
  if (!link) throw new Error(data?.error?.message || "imgbb rejected the upload");
  return link;
}

const HOSTS = {
  litterbox: { label: "litterbox", note: "expires in 72 hours", upload: toLitterbox },
  uguu: { label: "uguu.se", note: "expires in 3 hours", upload: toUguu },
  tmpfiles: { label: "tmpfiles.org", note: "expires in 1 hour", upload: toTmpfiles },
  imgbb: { label: "imgbb", note: "permanent", upload: toImgbb }
};

// imgbb is opt-in because it needs a key, so it is not part of the fallback chain
const ORDER = ["litterbox", "uguu", "tmpfiles"];

function parseHost(args) {
  for (let i = 0; i < args.length; i++) {
    const key = args[i].toLowerCase();
    const next = (args[i + 1] || "").toLowerCase();
    if ((key === "-p" || key === "--host") && HOSTS[next]) return next;
    if (HOSTS[key]) return key;
  }
  return null;
}

/** Try the requested host first, then fall back to the remaining free ones. */
async function uploadWithFallback(file, name, preferred) {
  const queue = preferred ? [preferred, ...ORDER.filter(h => h !== preferred)] : ORDER;
  let lastError;

  for (const host of queue) {
    try {
      return { host, link: await HOSTS[host].upload(file, name) };
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError || new Error("all hosts failed");
}

function guide(prefix) {
  return (
    "🔗 𝗨𝗣𝗟𝗢𝗔𝗗𝗘𝗥\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━\n" +
    `Reply to a photo, video or file then send:\n${prefix}upload\n\n` +
    "Hosts:\n" +
    "• -p litterbox  72 hours (default)\n" +
    "• -p uguu       3 hours\n" +
    "• -p tmpfiles   1 hour\n" +
    "• -p imgbb      permanent, images only (needs IMGBB_API_KEY)\n\n" +
    `Up to ${MAX_FILES} files per message, max ${humanSize(MAX_BYTES)} each.\n` +
    `If a host is down the bot automatically tries the next one.`
  );
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;

  if (args[0] && ["help", "guide"].includes(args[0].toLowerCase())) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const files = collectFiles(event);
  if (!files.length) {
    return api.sendMessage(
      `⚠️ No file found.\n\nReply to a photo, video or file then send ${prefix}upload\nType ${prefix}upload help to see the hosts.`,
      threadID,
      messageID
    );
  }

  const preferred = parseHost(args);
  api.sendMessage(`⏳ Uploading ${files.length} file${files.length > 1 ? "s" : ""}...`, threadID, messageID);

  const lines = [];
  let uploaded = 0;

  for (let i = 0; i < files.length; i++) {
    const label = files.length > 1 ? `${i + 1}. ` : "";

    try {
      const file = await download(files[i].url);
      if (file.size > MAX_BYTES) {
        lines.push(`${label}❌ too large (${humanSize(file.size)}, max ${humanSize(MAX_BYTES)})`);
        continue;
      }

      // some hosts reject names that start with a digit, so keep the letter prefix
      const name = `file_${Date.now()}_${i + 1}.${file.ext}`;
      const { host, link } = await uploadWithFallback(file, name, preferred);

      uploaded++;
      lines.push(`${label}${link}\n   ${HOSTS[host].label} • ${humanSize(file.size)} • ${HOSTS[host].note}`);
    } catch (error) {
      lines.push(`${label}❌ failed — ${error.message || "unknown error"}`);
    }
  }

  const header = uploaded ? "✅ 𝗨𝗣𝗟𝗢𝗔𝗗 𝗗𝗢𝗡𝗘" : "❌ 𝗨𝗣𝗟𝗢𝗔𝗗 𝗙𝗔𝗜𝗟𝗘𝗗";
  return api.sendMessage(`${header}\n━━━━━━━━━━━━━━━━━━━━━━━\n${lines.join("\n\n")}`, threadID, messageID);
};
