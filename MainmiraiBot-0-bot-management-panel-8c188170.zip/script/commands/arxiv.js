const axios = require("axios");

module.exports.config = {
  name: "arxiv",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Jonell Magallanes",
  description: "Search arXiv papers via Opiar API",
  premium: false,
  prefix: true,
  category: "search",
  usages: "[query]",
  cooldowns: 5
};

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;

  try {
    const query = args.join(" ").trim();

    if (!query) {
      return api.sendMessage(
        `please enter a search query.
example: ${prefix}arxiv transformer attention`,
        threadID,
        messageID
      );
    }

    const lod = await api.sendMessage("searching arXiv...", threadID, messageID);

    const apiUrl = `https://opiarnapi-v2-production.up.railway.app/api/arxiv-search?q=${encodeURIComponent(query)}`;
    console.log(`Fetching arXiv data from API: ${apiUrl}`);

    const res = await axios.get(apiUrl, { timeout: 30000 });
    const data = res.data;

    if (!data || !data.status || !data.results || data.results.length === 0) {
      return api.sendMessage(
        `No results found for your query "${query}". Please try with a different query.`,
        threadID,
        messageID
      );
    }

    const limit = Math.min(data.results.length, 10);
    const results = data.results.slice(0, limit);

    let body = `📚 arXiv search: "${query}"
`;
    body += `total: ${data.total} | showing: ${results.length}

`;

    results.forEach((r, i) => {
      const authors = r.authors.join(", ");
      const year = r.year || "n/a";
      const cats = (r.categories || []).slice(0, 3).join(", ");

      body += `${i + 1}. ${r.title}
`;
      body += `   authors: ${authors}
`;
      body += `   year: ${year} | categories: ${cats}
`;
      body += `   abstract: ${r.abstractUrl}
`;
      body += `   pdf: ${r.pdfUrl}

`;
    });

    await api.sendMessage(body, threadID, messageID);

    api.unsendMessage(lod.messageID);
    console.log(`arXiv results successfully sent to thread ${threadID}`);

  } catch (error) {
    console.error("error fetching arXiv data: ", error);
    return api.sendMessage(
      "An error occurred while searching arXiv. Please try again later.",
      threadID,
      messageID
    );
  }
};
