const fs = require("fs");
const {
  Jimp,
  clamp,
  hexToInt,
  humanSize,
  saveImage,
  scheduleCleanup,
  collectPhotos
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgpfp",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Make a clean profile picture from a photo or your avatar",
  prefix: true,
  premium: true,
  category: "media",
  usages: "[reply to a photo or mention] [-r ring] [-c color] [-s size] [-sq] [-blur]",
  cooldowns: 12
};

const RING_COLORS = {
  blue: 0x4f8cffff,
  gold: 0xe8bf5cff,
  rose: 0xff6f9cff,
  mint: 0x4fd1c5ff,
  violet: 0x9b6cffff,
  white: 0xfafafaff,
  black: 0x111114ff
};

function guide(prefix) {
  return (
    "🪞 𝗣𝗙𝗣 𝗠𝗔𝗞𝗘𝗥 (premium)\n" +
    "━━━━━━━━━━━━━━━\n" +
    "reply to a photo, mention someone, or send it plain\n" +
    "to use your own avatar :\n" +
    `${prefix}imgpfp [flags]\n\n` +
    "flags :\n" +
    "• -s <size>    output size 128-1024 (default 512)\n" +
    "• -r <px>      ring thickness 0-40 (default 14)\n" +
    `• -c <color>   ${Object.keys(RING_COLORS).join(", ")} or a hex\n` +
    "• -sq          keep it square instead of round\n" +
    "• -blur        blurred copy of the photo as backdrop\n\n" +
    "examples :\n" +
    `${prefix}imgpfp\n` +
    `${prefix}imgpfp -c gold -r 20\n` +
    `${prefix}imgpfp -s 1024 -blur\n` +
    `${prefix}imgpfp -sq -c 111114 -r 0`
  );
}

function parseArgs(args) {
  const opts = { size: 512, ring: 14, color: "blue", square: false, blur: false };

  for (let i = 0; i < args.length; i++) {
    const token = args[i].toLowerCase();
    if ((token === "-s" || token === "--size") && args[i + 1]) {
      const n = parseInt(args[++i], 10);
      if (!Number.isNaN(n)) opts.size = clamp(n, 128, 1024);
      continue;
    }
    if ((token === "-r" || token === "--ring") && args[i + 1]) {
      const n = parseInt(args[++i], 10);
      if (!Number.isNaN(n)) opts.ring = clamp(n, 0, 40);
      continue;
    }
    if ((token === "-c" || token === "--color") && args[i + 1]) {
      opts.color = args[++i].toLowerCase();
      continue;
    }
    if (token === "-sq" || token === "--square") opts.square = true;
    if (token === "-blur" || token === "--blur") opts.blur = true;
  }

  return opts;
}

function ringColor(name) {
  return RING_COLORS[name] || hexToInt(name, RING_COLORS.blue);
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID, senderID, mentions } = event;
  const first = (args[0] || "").toLowerCase();

  if (["help", "list", "colors"].includes(first)) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const opts = parseArgs(args);
  api.setMessageReaction("🪞", messageID, () => {}, true);

  let filePath;
  try {
    // source order : replied / attached photo → mentioned user → the sender
    let source = collectPhotos(event, 1)[0] || null;
    let label = "your photo";

    if (!source) {
      const mentionID = Object.keys(mentions || {})[0];
      const targetID = mentionID || event.messageReply?.senderID || senderID;
      const info = await api.getUserInfo(targetID).catch(() => null);
      source = info?.[targetID]?.thumbSrc || null;
      label = targetID === String(senderID) ? "your avatar" : `${info?.[targetID]?.name || targetID}'s avatar`;
    }

    if (!source) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage(
        `⚠️ No photo found.\nReply to a photo or mention someone, then type ${prefix}imgpfp`,
        threadID,
        messageID
      );
    }

    const photo = await Jimp.read(source);
    const { size, ring, square, blur } = opts;
    const inner = size - ring * 2;

    const canvas = new Jimp(size, size, 0x00000000);

    if (blur) {
      // a blurred, zoomed copy fills the frame behind the crop
      const backdrop = photo.clone().cover(size, size).blur(14).brightness(-0.15);
      if (!square) backdrop.circle();
      canvas.composite(backdrop, 0, 0);
    }

    if (ring > 0) {
      const ringLayer = new Jimp(size, size, ringColor(opts.color));
      if (!square) ringLayer.circle();
      canvas.composite(ringLayer, 0, 0);
    }

    const face = photo.clone().cover(inner, inner);
    if (!square) face.circle();
    canvas.composite(face, ring, ring);

    filePath = await saveImage(canvas, "imgpfp");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "🪞 𝗣𝗙𝗣 𝗥𝗘𝗔𝗗𝗬\n" +
          `🖼 source : ${label}\n` +
          `📐 ${size}x${size} • ${square ? "square" : "round"}\n` +
          `⭕ ring : ${ring ? `${ring}px ${opts.color}` : "none"}${blur ? " • blurred backdrop" : ""}\n` +
          `💾 ${humanSize(stats.size)}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to build the profile picture : ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
