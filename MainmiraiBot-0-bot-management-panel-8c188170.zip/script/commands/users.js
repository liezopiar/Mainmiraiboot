module.exports.config = {
	name: "user",
	version: "1.1.0",
	permission: 2,
	credits: "ryuko",
	prefix: true,
  premium: false,
	description: "ban or unban users",
	category: "admin",
	usages: "[ban/unban/banCommand/unbanCommand/search/list/info] [@mention | reply | id] [reason]",
	cooldowns: 5
};

const moment = require("moment-timezone");

const ONE_TARGET_ONLY = "you tagged more than one person. tag only one.";

/**
 * resolve a single target from a reply, a tag or a raw id, in that order.
 * a reply wins because it is unambiguous even when the replied-to message had
 * tags in it. more than one tag is reported instead of silently using the first.
 * the leftover words (mention labels removed) come back as `text` so they can be
 * used as a reason.
 */
function resolveOne(args = [], event = {}, { minIDLength = 5 } = {}) {
	const tokens = (Array.isArray(args) ? args : []).map(a => String(a == null ? "" : a)).filter(Boolean);
	const mentions = event.mentions || {};
	const mentionedUsers = Object.keys(mentions);

	let uid = null;
	let tooMany = false;

	if (event.type === "message_reply" && event.messageReply) {
		// If the message is a reply, use the sender's ID of the replied message
		uid = String(event.messageReply.senderID);
	} else if (tokens.join(" ").indexOf("@") !== -1 || mentionedUsers.length) {
		// If the message contains mentions, check if there is more than one mention
		if (mentionedUsers.length > 1) {
			tooMany = true;
			uid = String(mentionedUsers[0]);
		} else if (mentionedUsers.length === 1) {
			uid = String(mentionedUsers[0]);
		}
	}

	// strip the tagged name words so they are never mistaken for the reason
	const labels = Object.values(mentions).map(n => String(n || "").replace(/^@/, "").trim()).filter(Boolean);
	let rest = tokens.filter(t => t.charAt(0) !== "@");
	for (const label of labels) {
		const words = label.split(/\s+/).filter(Boolean);
		for (const word of words) {
			const at = rest.findIndex(t => t.replace(/^@/, "") === word);
			if (at !== -1) rest.splice(at, 1);
		}
	}

	// no reply and no tag : fall back to a raw numeric id in the arguments
	if (!uid) {
		const idIndex = rest.findIndex(t => new RegExp(`^\\d{${minIDLength},}$`).test(t));
		if (idIndex !== -1) uid = String(rest.splice(idIndex, 1)[0]);
	}

	return { uid, tooMany, text: rest.join(" ").trim() };
}

const now = () => moment.tz("Asia/Manila").format("HH:mm:ss DD/MM/YYYY");

const GUIDE = [
	"user - usage",
	"",
	"user ban @mention spamming",
	"user ban 100012345678 rule break",
	"user ban (reply) rule break",
	"user unban @mention",
	"user list / user info @mention",
	"user banCommand @mention all",
	"",
	"bans are permanent until you unban the user"
].join("\n");

module.exports.languages = {
	"bangla": {
		"reason": "reason",
		"at": "at",
		"allCommand": "all commands",
		"commandList": "commands",
		"banSuccess": "banned user : %1",
		"unbanSuccess": "unbanned user %1",
		"banCommandSuccess": "banned command with user : %1",
		"unbanCommandSuccess": "unbanned command %1 with user: %2",
		"errorReponse": "%1 can't do what you request",
		"IDNotFound": "%1 ID you import doesn't exist in database",
		"existBan": "user %1 has been banned before %2 %3",
		"notExistBan": "user hasn't been banned before",
		"missingCommandInput": "%1 you have to import the command you want to ban",
		"notExistBanCommand": "user ID hasn't been banned before",

		"returnBan": "you are requesting to ban user :\nuser id and name who you want to ban : %1%2\n\nreact to this message to complete",
		"returnUnban": "you are requesting to unban user :\nuser id and name who you want to ban : %1\n\nreact to this message to complete",
		"returnBanCommand": "you are requesting to ban command with user :\n - user ID and name who you want to ban : %1\n- commands : %2\n\nreact to this message to complete",
		"returnUnbanCommand": "you are requesting to unban command with user :\nuser id and name : %1\ncommands : %2\n\nreact to this message to complete",
	
		"returnResult": "this is your result : \n",
		"returnNull": "there is no result with your input",
		"returnList": "there are %1 banned user, here are %2 user\n\n%3",
		"returnInfo": "here is some information about the user who you want to find :\nuser id and name : %1n- banned? : %2 %3 %4\ncommand banned? : %5"
	},
	"english": {
		"reason": "reason",
		"at": "at",
		"allCommand": "all commands",
		"commandList": "commands",
		"banSuccess": "banned user : %1",
		"unbanSuccess": "unbanned user %1",
		"banCommandSuccess": "banned command with user : %1",
		"unbanCommandSuccess": "unbanned command %1 with user: %2",
		"errorReponse": "%1 can't do what you request",
		"IDNotFound": "%1 ID you import doesn't exist in database",
		"existBan": "user %1 has been banned before %2 %3",
		"notExistBan": "user hasn't been banned before",
		"missingCommandInput": "%1 you have to import the command you want to ban",
		"notExistBanCommand": "user ID hasn't been banned before",

		"returnBan": "you are requesting to ban user :\nuser id and name who you want to ban : %1%2\n\nreact to this message to complete",
		"returnUnban": "you are requesting to unban user :\nuser id and name who you want to ban : %1\n\nreact to this message to complete",
		"returnBanCommand": "you are requesting to ban command with user :\n - user ID and name who you want to ban : %1\n- commands : %2\n\nreact to this message to complete",
		"returnUnbanCommand": "you are requesting to unban command with user :\nuser id and name : %1\ncommands : %2\n\nreact to this message to complete",
	
		"returnResult": "this is your result : \n",
		"returnNull": "there is no result with your input",
		"returnList": "there are %1 banned user, here are %2 user\n\n%3",
		"returnInfo": "here is some information about the user who you want to find :\nuser id and name : %1n- banned? : %2 %3 %4\ncommand banned? : %5"
	}
}

module.exports.handleReaction = async ({ event, api, Users, handleReaction, getText, botid }) => {
	if (parseInt(event.userID) !== parseInt(handleReaction.author)) return;
	const { threadID } = event;
	const { messageID, type, targetID, reason, commandNeedBan, nameTarget } = handleReaction;

	const time = now();
	// handleReaction is a Map keyed by bot id, the pending list lives inside it
	const pending = global.client.handleReaction.get(botid) || [];
	const index = pending.findIndex(item => item.messageID == messageID);
	if (index !== -1) pending.splice(index, 1);

	switch (type) {
		case "ban": {
			try {
				let data = (await Users.getData(targetID)).data || {};
				data.banned = true;
				data.reason = reason || null;
				data.dateAdded = time;
				await Users.setData(targetID, { data });
				global.data.userBanned.set(String(targetID), {
					reason: data.reason,
					dateAdded: data.dateAdded
				});
				return api.sendMessage(getText("banSuccess", `${targetID} - ${nameTarget}`), threadID, () => {
					return api.unsendMessage(messageID);
				});
			} catch { return api.sendMessage(getText("errorReponse", "ban user - "), threadID) };
		}

		case "unban": {
			try {
				// clear the database row and the in-memory map together
				let data = (await Users.getData(targetID)).data || {};
				data.banned = false;
				data.reason = null;
				data.dateAdded = null;
				await Users.setData(targetID, { data });
				global.data.userBanned.delete(String(targetID));
				return api.sendMessage(getText("unbanSuccess", `${targetID} - ${nameTarget}`), threadID, () => {
					return api.unsendMessage(messageID);
				});
			} catch { return api.sendMessage(getText("errorReponse", "unban user - "), threadID) };
		}

		case "banCommand": {
			try {	
				let data = (await Users.getData(targetID)).data || {};
				data.commandBanned = [...data.commandBanned || [], ...commandNeedBan];
				await Users.setData(targetID, { data });
				global.data.commandBanned.set(String(targetID), data.commandBanned);
				return api.sendMessage(getText("banCommandSuccess", `${targetID} - ${nameTarget}`), threadID, () => {
					return api.unsendMessage(messageID);
				});
			} catch (e) { return api.sendMessage(getText("errorReponse", "command ban - "), threadID) };
		}

		case "unbanCommand": {
			try {
				let data = (await Users.getData(targetID)).data || {};
				data.commandBanned = [...(data.commandBanned || []).filter(item => !commandNeedBan.includes(item))];
				await Users.setData(targetID, { data });
				global.data.commandBanned.set(String(targetID), data.commandBanned);
				if (data.commandBanned.length == 0) global.data.commandBanned.delete(String(targetID))
				return api.sendMessage(getText("unbanCommandSuccess", ((data.commandBanned.length == 0) ? getText("allCommand") : `${getText("commandList")}: ${commandNeedBan.join(", ")}`), `${targetID} - ${nameTarget}`), threadID, () => {
					return api.unsendMessage(messageID);
				});
			} catch (e) { return api.sendMessage(getText("errorReponse", "unban command -"), threadID) };
		}
	}
}

module.exports.run = async ({ event, api, args, Users, getText, botid, admin }) => {
	const { threadID, messageID, senderID } = event;
	const type = (args[0] || "").toLowerCase();
	const rest = args.slice(1);

	// resolve the target from a reply, a tag or a raw id, in that order. a reply is
	// checked first because it is unambiguous even when the replied-to message had
	// tags in it. more than one tag is refused instead of silently using the first.
	// minIDLength 1 so short operator/admin ids still resolve and hit the guards
	// below instead of silently falling through as "no target"
	const resolved = resolveOne(rest, event, { minIDLength: 1 });
	const targetID = resolved.uid;
	const tooManyTags = resolved.tooMany;
	// bans are permanent now, so anything left over is just the reason
	let reason = (resolved.text || "").trim() || null;

	const operators = global.config.operators || [];
	const admins = admin || [];
	const botID = String(api.getCurrentUserID());
	const reply = (msg) => api.sendMessage(msg, threadID, messageID);

	// every action below works on one user, so two tags is a mistake worth telling
	// the user about rather than quietly banning whoever was tagged first
	const NEEDS_TARGET = ["ban", "-b", "unban", "-ub", "bancommand", "-bc", "unbancommand", "-ubc", "info", "-i"];
	if (tooManyTags && NEEDS_TARGET.includes(type)) return reply(ONE_TARGET_ONLY);

	switch (type) {
		case "ban":
		case "-b": {
			if (!targetID) return reply("mention someone, reply to their message, or pass their id.\n\n" + GUIDE);
			if (targetID === botID) return reply("i'm not going to ban myself.");
			if (targetID === String(senderID)) return reply("you can't ban yourself.");
			if (operators.includes(targetID)) return reply("that user is a bot operator and can't be banned.");
			if (admins.includes(targetID)) return reply("that user is a bot admin and can't be banned.");
			if (!global.data.allUserID.includes(targetID)) return reply(getText("IDNotFound", "ban user - "));

			const existing = global.data.userBanned.get(targetID);
			if (existing) {
				return reply(getText("existBan", targetID, (existing.reason ? `${getText("reason")}: "${existing.reason}"` : ""), (existing.dateAdded ? `${getText("at")} ${existing.dateAdded}` : "")));
			}

			const nameTarget = global.data.userName.get(targetID) || await Users.getNameUser(targetID);
			const info = reason ? `\n- ${getText("reason")}: ${reason}` : "";

			return api.sendMessage(getText("returnBan", `${targetID} - ${nameTarget}`, info), threadID, (error, message) => {
				if (error || !message) return;
				global.client.handleReaction.get(botid).push({
					type: "ban",
					targetID,
					reason,
					nameTarget,
					name: this.config.name,
					messageID: message.messageID,
					author: senderID
				});
			}, messageID);
		}

		case "unban":
		case "-ub": {
			if (!targetID) return reply("mention someone, reply to their message, or pass their id.\n\n" + GUIDE);
			if (!global.data.userBanned.has(targetID)) return reply(getText("notExistBan"));
			const nameTarget = global.data.userName.get(targetID) || await Users.getNameUser(targetID);
			return api.sendMessage(getText("returnUnban", `${targetID} - ${nameTarget}`), threadID, (error, message) => {
				if (error || !message) return;
				global.client.handleReaction.get(botid).push({
					type: "unban",
					targetID,
					nameTarget,
					name: this.config.name,
					messageID: message.messageID,
					author: senderID
				});
			}, messageID);
		}

		case "search":
		case "-s": {
			const contentJoin = rest.join(" ").trim();
			const getUsers = (await Users.getAll(['userID', 'name'])).filter(item => !!item.name);
			const matchUsers = [];
			let a = '', b = 0;
			getUsers.forEach(i => {
				if (i.name.toLowerCase().includes(contentJoin.toLowerCase())) {
					matchUsers.push({ name: i.name, id: i.userID });
				}
			});
			matchUsers.forEach(i => a += `\n${b += 1}. ${i.name} - ${i.id}`);
			return (matchUsers.length > 0) ? reply(getText("returnResult", a)) : reply(getText("returnNull"));
		}
		
		case "bancommand":
		case "-bc": {
			if (!targetID) return reply("mention someone, reply to their message, or pass their id.");
			if (!global.data.allUserID.includes(targetID)) return reply(getText("IDNotFound", "command ban - "));
			if (!reason || reason.length == 0) return reply(getText("missingCommandInput", "command ban - "));
			if (reason == "all") {
				reason = [...global.client.commands.keys()].join(" ");
			}
			const commandNeedBan = reason.split(" ").filter(Boolean);
			const nameTarget = global.data.userName.get(targetID) || await Users.getNameUser(targetID);
			return api.sendMessage(getText("returnBanCommand", `${targetID} - ${nameTarget}`, ((commandNeedBan.length == global.client.commands.size) ? getText("allCommand") : commandNeedBan.join(", "))), threadID, (error, message) => {
				if (error || !message) return;
				global.client.handleReaction.get(botid).push({
					type: "banCommand",
					targetID,
					commandNeedBan,
					nameTarget,
					name: this.config.name,
					messageID: message.messageID,
					author: senderID
				});
			}, messageID);
		}

		case "unbancommand":
		case "-ubc": {
			if (!targetID) return reply("mention someone, reply to their message, or pass their id.");
			if (!global.data.allUserID.includes(targetID)) return reply(getText("IDNotFound", "command unban - "));
			if (!global.data.commandBanned.has(targetID)) return reply(getText("notExistBanCommand"));
			if (!reason || reason.length == 0) return reply(getText("missingCommandInput", "command unban - "));
			if (reason == "all") {
				reason = (global.data.commandBanned.get(targetID) || []).join(" ");
			}
			const commandNeedBan = reason.split(" ").filter(Boolean);
			const nameTarget = global.data.userName.get(targetID) || await Users.getNameUser(targetID);
			return api.sendMessage(getText("returnUnbanCommand", `${targetID} - ${nameTarget}`, ((commandNeedBan.length == (global.data.commandBanned.get(targetID) || []).length) ? getText("allCommand") : commandNeedBan.join(", "))), threadID, (error, message) => {
				if (error || !message) return;
				global.client.handleReaction.get(botid).push({
					type: "unbanCommand",
					targetID,
					commandNeedBan,
					nameTarget,
					name: this.config.name,
					messageID: message.messageID,
					author: senderID
				});
			}, messageID);
		}

		case "list":
		case "-l": {
			// the old loop walked the iterator with an inverted "undefined" check so
			// it always produced an empty list, and could spin forever on an empty map
			if (global.data.userBanned.size === 0) return reply("no users are banned right now.");
			const limit = parseInt(reason) || 20;
			const listBan = [];
			for (const [id, record] of global.data.userBanned) {
				const userName = global.data.userName.get(String(id)) || "unknown";
				const info = (record && typeof record === "object") ? record : {};
				listBan.push(`${listBan.length + 1}. ${userName} (${id})\n   reason : ${info.reason || "none"}`);
				if (listBan.length >= limit) break;
			}
			return reply(getText("returnList", global.data.userBanned.size, listBan.length, listBan.join("\n")));
		}

		case "info":
		case "-i": {
			if (!targetID) return reply("mention someone, reply to their message, or pass their id.");
			const record = global.data.userBanned.get(targetID);
			const commandBanned = global.data.commandBanned.get(targetID) || null;
			const nameTarget = global.data.userName.get(targetID) || await Users.getNameUser(targetID);
			// the old version read an undefined `commandNeedBan` here and had the
			// banned yes/no flipped
			return reply([
				`user : ${nameTarget} (${targetID})`,
				`banned : ${record ? "YES" : "NO"}`,
				`reason : ${(record && record.reason) || "none"}`,
				`since : ${(record && record.dateAdded) || "-"}`,
				`command banned : ${commandBanned && commandBanned.length ? commandBanned.join(", ") : "NO"}`
			].join("\n"));
		}

		default:
			return reply(GUIDE);
	}
}
