const fs = require("fs");
const {
  Jimp,
  clamp,
  humanSize,
  saveImage,
  scheduleCleanup,
  readPhoto,
  fitFont,
  loadFont,
  printOutlined
} = require("../utils/imageTools.js");

module.exports.config = {
  name: "imgmeme",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Turn any photo into a meme with top and bottom captions",
  prefix: true,
  premium: true,
  category: "media",
  usages: "[reply to a photo] <top text> | <bottom text>",
  cooldowns: 12
};

function guide(prefix) {
  return (
    "😂 𝗠𝗘𝗠𝗘 𝗠𝗔𝗞𝗘𝗥 (premium)\n" +
    "━━━━━━━━━━━━━━━\n" +
    "reply to a photo then send :\n" +
    `${prefix}imgmeme <top> | <bottom>\n\n` +
    "the | separates the two captions.\n" +
    "leave one side empty to caption only the other.\n\n" +
    "flags :\n" +
    "• -white   white classic meme panels instead of overlay\n\n" +
    "examples :\n" +
    `${prefix}imgmeme when the code works | but you dont know why\n` +
    `${prefix}imgmeme me at 3am | -white\n` +
    `${prefix}imgmeme | bottom text only\n` +
    `${prefix}imgmeme top text only`
  );
}

/** add classic white panels above and below the photo */
function withPanels(image, topHeight, bottomHeight) {
  const canvas = new Jimp(
    image.bitmap.width,
    image.bitmap.height + topHeight + bottomHeight,
    0xffffffff
  );
  canvas.composite(image, 0, topHeight);
  return canvas;
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;
  const first = (args[0] || "").toLowerCase();

  if (!args.length || ["help", "list"].includes(first)) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  // strip the flag before splitting so it never ends up inside a caption
  const usePanels = args.some((a) => ["-white", "--white", "-panel"].includes(a.toLowerCase()));
  const raw = args.filter((a) => !["-white", "--white", "-panel"].includes(a.toLowerCase())).join(" ");
  const [rawTop = "", rawBottom = ""] = raw.split("|");
  const top = rawTop.trim().toUpperCase();
  const bottom = rawBottom.trim().toUpperCase();

  if (!top && !bottom) {
    return api.sendMessage(`⚠️ Please include at least one caption.\n\n${guide(prefix)}`, threadID, messageID);
  }

  api.setMessageReaction("😂", messageID, () => {}, true);

  let filePath;
  try {
    const photo = await readPhoto(event, 1400);
    if (!photo) {
      api.setMessageReaction("⚠️", messageID, () => {}, true);
      return api.sendMessage(
        `⚠️ A photo is required.\nReply to a photo then type ${prefix}imgmeme <top> | <bottom>`,
        threadID,
        messageID
      );
    }

    const width = photo.bitmap.width;
    const pad = Math.round(width * 0.03) || 10;
    const boxWidth = width - pad * 2;
    const maxBlock = Math.round(photo.bitmap.height * 0.28);
    const startSize = clamp(Math.round(width / 10), 16, 128);

    const topFit = top ? await fitFont(top, boxWidth, maxBlock, "black", startSize) : null;
    const bottomFit = bottom ? await fitFont(bottom, boxWidth, maxBlock, "black", startSize) : null;

    let image = photo;
    let topOffset = 0;

    if (usePanels) {
      // panels are the caption height plus breathing room on both sides
      const topPanel = topFit ? topFit.height + pad * 2 : 0;
      const bottomPanel = bottomFit ? bottomFit.height + pad * 2 : 0;
      image = withPanels(photo, topPanel, bottomPanel);
      topOffset = topPanel;

      if (topFit) {
        const font = await loadFont(topFit.size, "black");
        image.print(font, pad, pad, { text: top, alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER }, boxWidth);
      }
      if (bottomFit) {
        const font = await loadFont(bottomFit.size, "black");
        image.print(
          font,
          pad,
          topOffset + photo.bitmap.height + pad,
          { text: bottom, alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER },
          boxWidth
        );
      }
    } else {
      if (topFit) {
        await printOutlined(image, top, {
          x: pad,
          y: pad,
          maxWidth: boxWidth,
          size: topFit.size,
          thickness: Math.max(2, Math.round(topFit.size / 20))
        });
      }
      if (bottomFit) {
        await printOutlined(image, bottom, {
          x: pad,
          y: Math.max(0, image.bitmap.height - pad - bottomFit.height),
          maxWidth: boxWidth,
          size: bottomFit.size,
          thickness: Math.max(2, Math.round(bottomFit.size / 20))
        });
      }
    }

    filePath = await saveImage(image, "imgmeme");
    const stats = fs.statSync(filePath);

    api.setMessageReaction("✅", messageID, () => {}, true);
    await api.sendMessage(
      {
        body:
          "😂 𝗠𝗘𝗠𝗘 𝗥𝗘𝗔𝗗𝗬\n" +
          (top ? `⬆️ ${top}\n` : "") +
          (bottom ? `⬇️ ${bottom}\n` : "") +
          `🎞 ${usePanels ? "white panels" : "overlay"} • ${humanSize(stats.size)}`,
        attachment: fs.createReadStream(filePath)
      },
      threadID,
      messageID
    );
  } catch (error) {
    api.setMessageReaction("❌", messageID, () => {}, true);
    return api.sendMessage(`❌ Failed to build the meme : ${error.message}`, threadID, messageID);
  } finally {
    scheduleCleanup(filePath);
  }
};
