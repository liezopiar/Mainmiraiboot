const axios = require("axios");
const fs = require("fs-extra");
const path = require("path");

module.exports.config = {
  name: "tts",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  description: "Turn text into a voice message in the language you pick",
  prefix: true,
  premium: true,
  category: "premium",
  usages: "[text] | -l [language code] [text] | reply to a message",
  cooldowns: 12
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const CACHE_DIR = path.join(__dirname, "cache");
const CHUNK = 180;
const MAX_CHARS = 1800;
const DEFAULT_LANG = "tl";

const LANGUAGES = {
  tl: "filipino",
  en: "english",
  ja: "japanese",
  ko: "korean",
  es: "spanish",
  fr: "french",
  de: "german",
  it: "italian",
  pt: "portuguese",
  ru: "russian",
  hi: "hindi",
  id: "indonesian",
  ms: "malay",
  th: "thai",
  vi: "vietnamese",
  ar: "arabic",
  "zh-CN": "chinese"
};

/** Split on sentence and word boundaries so the audio never cuts mid word. */
function chunkText(text) {
  const words = text.split(/\s+/);
  const chunks = [];
  let current = "";

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length > CHUNK) {
      if (current) chunks.push(current);
      current = word.length > CHUNK ? word.slice(0, CHUNK) : word;
    } else {
      current = candidate;
    }
  }

  if (current) chunks.push(current);
  return chunks;
}

async function speak(chunk, lang, index, total) {
  const { data } = await axios.get("https://translate.google.com/translate_tts", {
    params: {
      ie: "UTF-8",
      client: "tw-ob",
      q: chunk,
      tl: lang,
      total,
      idx: index,
      textlen: chunk.length
    },
    responseType: "arraybuffer",
    headers: { "User-Agent": UA, Referer: "https://translate.google.com/" },
    timeout: 30000
  });

  return Buffer.from(data);
}

function parseLanguage(args) {
  const flagIndex = args.findIndex(item => ["-l", "--lang"].includes(item.toLowerCase()));
  if (flagIndex > -1 && args[flagIndex + 1]) {
    const raw = args[flagIndex + 1];
    const match = Object.keys(LANGUAGES).find(code => code.toLowerCase() === raw.toLowerCase());
    return { lang: match || raw, rest: args.filter((_, i) => i !== flagIndex && i !== flagIndex + 1) };
  }
  return { lang: DEFAULT_LANG, rest: args };
}

function guide(prefix) {
  const codes = Object.entries(LANGUAGES)
    .map(([code, name]) => `${code} ${name}`)
    .join(" • ");

  return (
    "🎙️ 𝗧𝗘𝗫𝗧 𝗧𝗢 𝗦𝗣𝗘𝗘𝗖𝗛\n" +
    "━━━━━━━━━━━━━━━━━━━━━━━\n" +
    `${prefix}tts kamusta ka na\n` +
    `${prefix}tts -l ja おはよう\n` +
    `reply to any message with ${prefix}tts to read it aloud\n\n` +
    `languages :\n${codes}\n\n` +
    `default language is filipino, max ${MAX_CHARS} characters.`
  );
}

module.exports.run = async function ({ api, event, args, prefix }) {
  const { threadID, messageID } = event;

  if (args[0] && ["help", "list"].includes(args[0].toLowerCase())) {
    return api.sendMessage(guide(prefix), threadID, messageID);
  }

  const { lang, rest } = parseLanguage(args);
  const text = (rest.join(" ").trim() || event?.messageReply?.body || "").trim();

  if (!text) {
    return api.sendMessage(
      `⚠️ what should i say?\n\nexample : ${prefix}tts kamusta ka na\ntype ${prefix}tts help for the language list.`,
      threadID,
      messageID
    );
  }

  if (text.length > MAX_CHARS) {
    return api.sendMessage(
      `⚠️ that is ${text.length} characters. keep it under ${MAX_CHARS}.`,
      threadID,
      messageID
    );
  }

  const loading = await api.sendMessage("🎙️ recording your voice message...", threadID, messageID);

  try {
    const chunks = chunkText(text);
    const parts = [];

    for (let i = 0; i < chunks.length; i++) {
      parts.push(await speak(chunks[i], lang, i, chunks.length));
    }

    const audio = Buffer.concat(parts);
    if (!audio.length) throw new Error("the voice service returned nothing");

    await fs.ensureDir(CACHE_DIR);
    const file = path.join(CACHE_DIR, `tts_${Date.now()}.mp3`);
    await fs.writeFile(file, audio);

    api.unsendMessage(loading.messageID);

    return api.sendMessage(
      {
        body:
          "🎙️ 𝗩𝗢𝗜𝗖𝗘 𝗥𝗘𝗔𝗗𝗬\n" +
          "━━━━━━━━━━━━━━━━━━━━━━━\n" +
          `language : ${LANGUAGES[lang] || lang}\n` +
          `length   : ${text.length} characters${chunks.length > 1 ? ` in ${chunks.length} parts` : ""}`,
        attachment: fs.createReadStream(file)
      },
      threadID,
      () => setTimeout(() => fs.unlink(file, () => {}), 8000),
      messageID
    );
  } catch (error) {
    api.unsendMessage(loading.messageID);
    const reason = error?.response?.status === 400 ? `"${lang}" is not a supported language code` : error.message;
    return api.sendMessage(`❌ failed to create the voice message — ${reason}`, threadID, messageID);
  }
};
