module.exports.config = {
  name: "rob",
  version: "1.0.0",
  permission: 0,
  credits: "ryuko",
  prefix: false,
  premium: false,
  description: "Attempt to rob a tagged user's money (risky!)",
  category: "economy",
  usages: "[@tag | reply | userID]",
  cooldowns: 5
};

module.exports.languages = {
  "english": {
    "noTag":        "❗ Tag someone to rob!\nUsage: rob @username (or reply to their message / pass their id)",
    "noSelf":       "🤦 You can't rob yourself!",
    "cooldown":     "🚔 Lay low! You can rob again in %1 minutes %2 seconds.",
    "targetPoor":   "😅 %1 is broke, not worth the risk!",
    "success":      "🦹 Success! You stole $%1 from %2!\n💵 Your balance: $%3",
    "fail":         "👮 You got caught robbing %1 and paid a $%2 fine!\n💵 Your balance: $%3",
    "youBroke":     "💸 You don't have enough money to risk a robbery (need at least $500)."
  }
};

const COOLDOWN_MS  = 2 * 60 * 60 * 1000; // 2 hours
const MIN_TARGET   = 500;   // target must have at least this much
const MIN_ROBBER   = 500;   // robber must have at least this much
const SUCCESS_RATE = 0.45;  // 45 % chance of success
const FINE_RATE    = 0.20;  // fine = 20 % of robber's balance on fail

module.exports.run = async function({ api, event, args = [], Users, Currencies, getText }) {
  const { threadID, messageID, senderID, mentions } = event;

  // Resolve the victim : reply first, then a tag, then a raw id
  let targetID = null;
  let targetName = null;

  if (event.type === "message_reply" && event.messageReply) {
    // If the message is a reply, use the sender's ID of the replied message
    targetID = String(event.messageReply.senderID);
  } else if (args.join(" ").indexOf("@") !== -1 || Object.keys(mentions).length) {
    // If the message contains mentions, check if there is more than one mention
    const mentionedUsers = Object.keys(mentions);
    if (mentionedUsers.length > 1) {
      return api.sendMessage("❗ Rob only one person at a time.", threadID, messageID);
    }
    if (mentionedUsers.length === 1) {
      targetID   = String(mentionedUsers[0]);
      targetName = String(Object.values(mentions)[0]).replace(/@/g, "");
    }
  }

  if (!targetID) {
    const idArg = args.find(a => /^\d{10,}$/.test(a));
    if (idArg) targetID = String(idArg);
  }

  if (!targetID) {
    return api.sendMessage(getText("noTag"), threadID, messageID);
  }

  if (String(targetID) === String(senderID)) {
    return api.sendMessage(getText("noSelf"), threadID, messageID);
  }

  const robberData = await Currencies.getData(senderID) || {};
  const targetData = await Currencies.getData(targetID) || {};
  const robberMoney = robberData.money || 0;
  const robberStore = robberData.data || {};

  // Robber minimum balance
  if (robberMoney < MIN_ROBBER) {
    return api.sendMessage(getText("youBroke"), threadID, messageID);
  }

  // Cooldown check
  const robData = robberStore.robData || { lastRob: 0 };
  const now     = Date.now();
  const elapsed = now - robData.lastRob;

  if (elapsed < COOLDOWN_MS) {
    const remaining = COOLDOWN_MS - elapsed;
    const mins = Math.floor(remaining / 60000);
    const secs = Math.floor((remaining % 60000) / 1000);
    return api.sendMessage(getText("cooldown", mins, secs), threadID, messageID);
  }

  if (!targetName) {
    try { targetName = await Users.getNameUser(targetID); }
    catch { targetName = "that user"; }
  }

  // Target minimum balance
  if ((targetData.money || 0) < MIN_TARGET) {
    return api.sendMessage(getText("targetPoor", targetName), threadID, messageID);
  }

  // Update cooldown (persist under the JSON data column)
  robberStore.robData = { lastRob: now };
  await Currencies.setData(senderID, { data: robberStore });

  // Attempt rob — steal 10–30 % of target's balance
  if (Math.random() < SUCCESS_RATE) {
    const stealPct  = Math.random() * 0.20 + 0.10;
    const stolen    = Math.floor((targetData.money || 0) * stealPct);
    await Currencies.increaseMoney(senderID, stolen);
    await Currencies.decreaseMoney(targetID,  stolen);
    const newBal = robberMoney + stolen;
    return api.sendMessage(
      getText("success", stolen.toLocaleString(), targetName, newBal.toLocaleString()),
      threadID, messageID
    );
  } else {
    // Fine = 20 % of robber's current balance
    const fine   = Math.floor(robberMoney * FINE_RATE);
    await Currencies.decreaseMoney(senderID, fine);
    const newBal = Math.max(0, robberMoney - fine);
    return api.sendMessage(
      getText("fail", targetName, fine.toLocaleString(), newBal.toLocaleString()),
      threadID, messageID
    );
  }
};
