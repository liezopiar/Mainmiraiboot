/* ===========================================================================
   OP AutoBot developer panel
   Talks to the /opiar/* api with the developer jwt. Every table below is drawn
   from the ledger in main/system/devlog.js, so a row only exists because a real
   deploy, sign in or panel request wrote it.
   =========================================================================== */

'use strict';

const TOKEN_KEY = 'opiar:dev-token';

const D = {
    token: null,
    dev: '',
    bots: [],
    past: [],
    events: [],
    addresses: [],
    summary: null,
    view: 'overview',
    inspecting: null,
    timer: null
};

const VIEWS = {
    overview: { title: 'Overview', sub: 'Everything happening on this host.' },
    users:    { title: 'Panel users', sub: 'Who is signed in to a bot panel and what they touched.' },
    addresses:{ title: 'Addresses', sub: 'Every address the ledger has seen, and who used it.' },
    deploys:  { title: 'Deployments', sub: 'Every deploy attempt, with the form the owner submitted.' },
    audit:    { title: 'Audit trail', sub: 'The full ledger, searchable.' },
    inspect:  { title: 'Inspect a bot', sub: 'Read any bot on this host without its owner token.' },
    host:     { title: 'Host controls', sub: 'Maintenance and the sessions running right now.' }
};

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function esc(value) {
    return String(value == null ? '' : value)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function el(id) { return document.getElementById(id); }

function fmtUptime(seconds) {
    const s = Math.max(0, Number(seconds) || 0);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${m}m`;
    return `${m}m ${s % 60}s`;
}

function relTime(iso) {
    const then = new Date(iso).getTime();
    if (!then) return 'never';
    const diff = Math.floor((Date.now() - then) / 1000);
    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

function stamp(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return '--:--:--';
    return d.toLocaleString([], { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function clockTime(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return '--:--:--';
    return d.toLocaleTimeString([], { hour12: false });
}

function toast(message, kind) {
    const stack = el('toastStack');
    const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-circle-info' };
    const type = kind || 'info';
    const node = document.createElement('div');
    node.className = `toast ${type}`;
    node.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i><span>${esc(message)}</span>`;
    stack.appendChild(node);
    setTimeout(() => {
        node.classList.add('leaving');
        setTimeout(() => node.remove(), 240);
    }, 3200);
}

async function api(path, body) {
    const res = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ token: D.token }, body || {}))
    });
    const data = await res.json().catch(() => null);
    if (res.status === 401) {
        lock('the developer session expired, please sign in again.');
        throw new Error('session ended');
    }
    if (!res.ok) throw new Error((data && data.error) || 'that request failed.');
    return data;
}

async function run(button, work, successMessage) {
    let original = null;
    if (button) {
        original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<span class="loading-spinner"></span>';
    }
    try {
        const result = await work();
        if (successMessage !== false) toast(successMessage || (result && result.data) || 'done.', 'success');
        return result;
    } catch (err) {
        if (err && err.message !== 'session ended') toast(err.message, 'error');
        return null;
    } finally {
        if (button) {
            button.disabled = false;
            button.innerHTML = original;
        }
    }
}

/* ------------------------------------------------------------------ */
/* shell                                                               */
/* ------------------------------------------------------------------ */

function toggleMenu(event) {
    if (event) event.stopPropagation();
    const open = el('sidebar').classList.toggle('open');
    el('scrim').classList.toggle('show', open);
}

function closeMenu() {
    el('sidebar').classList.remove('open');
    el('scrim').classList.remove('show');
}

function go(view) {
    D.view = view;
    document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.dataset.panel === view));
    document.querySelectorAll('.nav-item[data-view]').forEach(n => n.classList.toggle('active', n.dataset.view === view));
    const meta = VIEWS[view];
    if (meta) {
        el('viewTitle').textContent = meta.title;
        el('viewSub').textContent = meta.sub;
        document.title = `${meta.title} • OP AutoBot`;
    }
    closeMenu();
    if (view === 'deploys') loadDeploys();
    if (view === 'audit') loadAudit();
}

/* ------------------------------------------------------------------ */
/* sign in                                                             */
/* ------------------------------------------------------------------ */

function lock(message) {
    D.token = null;
    try { sessionStorage.removeItem(TOKEN_KEY); } catch (e) {}
    if (D.timer) clearInterval(D.timer);
    el('shell').classList.add('hidden');
    el('gate').classList.remove('hidden');
    if (message) toast(message, 'error');
}

function signOut() {
    lock(null);
    toast('the panel is locked.', 'info');
}

el('gateForm').addEventListener('submit', async event => {
    event.preventDefault();
    const button = el('gateBtn');
    const original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<span class="loading-spinner"></span>';
    try {
        const res = await fetch('/opiar/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: el('devUser').value, password: el('devPass').value })
        });
        const data = await res.json().catch(() => null);
        if (!res.ok) throw new Error((data && data.error) || 'sign in failed.');
        D.token = data.token;
        D.dev = data.username;
        try { sessionStorage.setItem(TOKEN_KEY, data.token); } catch (e) {}
        el('devPass').value = '';
        await openShell();
    } catch (err) {
        toast(err.message, 'error');
    } finally {
        button.disabled = false;
        button.innerHTML = original;
    }
});

// named openShell, never open : a top level `function open()` would shadow
// window.open and break the "Public console" link in the sidebar
async function openShell() {
    el('gate').classList.add('hidden');
    el('shell').classList.remove('hidden');
    el('footDev').textContent = D.dev ? `signed in as ${D.dev}` : 'developer session';
    await loadOverview();
    if (D.timer) clearInterval(D.timer);
    D.timer = setInterval(() => {
        if (D.view === 'overview' || D.view === 'host' || D.view === 'users') loadOverview();
        if (D.view === 'inspect' && D.inspecting) loadInspect();
    }, 15000);
}

/* ------------------------------------------------------------------ */
/* overview                                                            */
/* ------------------------------------------------------------------ */

async function loadOverview() {
    let data;
    try {
        data = await api('/opiar/overview');
    } catch (err) {
        el('footStatus').innerHTML = '<span class="dot-live off"></span> Disconnected';
        return;
    }

    D.summary = data.summary;
    D.bots = data.bots || [];
    D.past = data.past || [];

    el('footStatus').innerHTML = '<span class="dot-live"></span> Live';
    el('topUptime').textContent = fmtUptime(data.summary.host.uptime);
    el('navUsers').textContent = D.bots.length + D.past.length;
    el('navDeploys').textContent = data.summary.deploys24;

    renderMetrics(data.summary);
    renderTimeline(data.timeline || []);
    renderFeed(data.events || []);
    renderUsers();
    renderHost(data.maintenance);
    fillInspectPicker();
}

function renderMetrics(s) {
    const tiles = [
        { label: 'Bots hosted', value: s.bots, icon: 'fa-robot', sub: `${s.online} online right now`, tone: 'accent' },
        { label: 'Panel users', value: s.panelUsers, icon: 'fa-users', sub: `${s.liveSessions || 0} active in the last 15m` },
        { label: 'People served', value: s.people || 0, icon: 'fa-user-group', sub: 'across every bot here' },
        { label: 'Deploys today', value: s.deploys24, icon: 'fa-rocket', sub: `${s.failedDeploys24} failed`, tone: s.failedDeploys24 ? 'bad' : 'good' },
        { label: 'Sign ins today', value: s.signIns24, icon: 'fa-right-to-bracket', sub: `${s.rejected24} rejected` },
        { label: 'Panel changes', value: s.changes24, icon: 'fa-sliders', sub: 'settings touched today' },
        { label: 'Commands run', value: s.commands, icon: 'fa-terminal', sub: `${s.errors} errors`, tone: s.errors ? 'bad' : '' },
        { label: 'Ledger', value: s.events, icon: 'fa-list-check', sub: `since ${stamp(s.since)}` },
        { label: 'Memory', value: s.host.memory, icon: 'fa-microchip', sub: `${s.host.commandModules} command modules`, unit: 'mb' }
    ];

    el('metricGrid').innerHTML = tiles.map(t => `
        <div class="metric ${t.tone || ''}">
            <div class="metric-top">
                <span class="metric-label">${esc(t.label)}</span>
                <span class="metric-icon"><i class="fa-solid ${t.icon}"></i></span>
            </div>
            <span class="metric-value">${esc(t.value)}${t.unit ? `<span style="font-size:0.8rem;color:var(--muted)">${t.unit}</span>` : ''}</span>
            <span class="metric-sub">${esc(t.sub)}</span>
        </div>`).join('');
}

function renderTimeline(series) {
    const peak = series.reduce((max, p) => Math.max(max, p.count), 0);
    const total = series.reduce((sum, p) => sum + p.count, 0);

    el('usageChart').innerHTML = series.map(point => {
        const pct = peak ? Math.round((point.count / peak) * 100) : 0;
        return `
            <div class="usage-col" title="${esc(point.label)} — ${point.count} event${point.count === 1 ? '' : 's'}">
                <div class="usage-track">
                    <div class="usage-bar ${point.count ? '' : 'zero'}" style="height:${point.count ? Math.max(pct, 4) : 0}%"></div>
                </div>
                <b>${esc(point.label)}</b>
            </div>`;
    }).join('');

    el('usagePeak').textContent = `Peak ${peak} per 2 hours`;
    el('usageTotal').textContent = `${total} event${total === 1 ? '' : 's'} in the last day`;
}

function renderFeed(events) {
    const box = el('latestFeed');
    if (!events.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-wind"></i>Nothing has been recorded yet.</p>';
        return;
    }
    box.innerHTML = events.slice(0, 12).map(e => `
        <div class="feed-item">
            <span class="feed-icon"><i class="fa-solid ${esc(e.icon)}"></i></span>
            <div class="feed-body">
                <p>${esc(e.message)}</p>
                <span class="feed-meta">
                    <time>${esc(relTime(e.at))}</time>
                    ${e.owner ? `<span class="actor"><i class="fa-solid fa-user"></i>${esc(e.owner)}</span>` : ''}
                    ${e.ip ? `<span class="actor"><i class="fa-solid fa-location-dot"></i>${esc(e.ip)}</span>` : ''}
                </span>
            </div>
        </div>`).join('');
}

/* ------------------------------------------------------------------ */
/* panel users                                                         */
/* ------------------------------------------------------------------ */

function ownerCell(row) {
    return `
        <div class="owner-cell">
            <img src="${esc(row.thumbSrc || '/images/op-autobot-logo.svg')}" alt="">
            <div class="who">
                <b>${esc(row.owner || 'no username')}</b>
                <span>${esc(row.name || 'Unknown')} · ${esc(row.uid)}</span>
            </div>
        </div>`;
}

// the search box and the dropdown filter the rows we already hold, so typing
// never costs a request. an empty result says so instead of showing an empty table.
function matchesUserFilter(row) {
    const q = (el('usersSearch').value || '').trim().toLowerCase();
    const mode = el('usersFilter').value;

    if (q) {
        const hay = `${row.owner} ${row.name} ${row.botname} ${row.uid} ${(row.ips || []).join(' ')} ${row.lastAction || ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
    }
    if (mode === 'online' && !row.online) return false;
    if (mode === 'offline' && row.online) return false;
    if (mode === 'deployers' && !row.deploys) return false;
    if (mode === 'active') {
        const seen = new Date(row.lastSeen || 0).getTime();
        if (!seen || Date.now() - seen > 60 * 60 * 1000) return false;
    }
    return true;
}

function renderUsers() {
    const body = el('usersBody');
    const rows = D.bots.filter(matchesUserFilter);
    el('usersCount').textContent = `${rows.length} of ${D.bots.length} owner${D.bots.length === 1 ? '' : 's'}`;

    if (!D.bots.length) {
        body.innerHTML = '<tr><td colspan="7"><p class="empty-state"><i class="fa-solid fa-wind"></i>No bot has been deployed on this host yet.</p></td></tr>';
    } else if (!rows.length) {
        body.innerHTML = '<tr><td colspan="7"><p class="empty-state"><i class="fa-solid fa-filter-circle-xmark"></i>No owner matches that filter.</p></td></tr>';
    } else {
        body.innerHTML = rows.map(b => `
            <tr>
                <td>${ownerCell(b)}</td>
                <td>
                    <div class="cell-stack">
                        <b>${esc(b.botname)}</b>
                        <span class="cell-note">prefix "${esc(b.prefix)}" · ${b.admins} admin${b.admins === 1 ? '' : 's'} · ${b.featuresOn} feature${b.featuresOn === 1 ? '' : 's'} on</span>
                    </div>
                </td>
                <td class="tight">
                    ${b.online ? '<span class="badge badge-success">online</span>' : '<span class="badge badge-muted">offline</span>'}
                    ${b.maintenance ? '<span class="badge badge-warning">maintenance</span>' : ''}
                </td>
                <td class="tight">
                    <div class="cell-stack">
                        <b>${b.requests}</b>
                        <span class="cell-note">${b.sessions} session${b.sessions === 1 ? '' : 's'} · ${b.changes} change${b.changes === 1 ? '' : 's'}</span>
                    </div>
                </td>
                <td class="tight">
                    <div class="cell-stack">
                        <b>${b.deploys}</b>
                        <span class="cell-note">${b.failedDeploys} failed</span>
                    </div>
                </td>
                <td>
                    <div class="cell-stack">
                        <b>${esc(relTime(b.lastSeen))}</b>
                        <span class="cell-note">${esc(b.device || 'device unknown')}</span>
                        <span class="ip-list">${esc((b.ips || []).join(', ') || 'no address recorded')}</span>
                    </div>
                </td>
                <td class="tight">
                    <button class="btn btn-ghost btn-sm" onclick="inspect('${esc(b.uid)}')">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </td>
            </tr>
            ${b.lastAction ? `<tr><td colspan="7" style="padding-top:0"><span class="cell-note"><i class="fa-solid fa-turn-up fa-rotate-90"></i> last thing they did : ${esc(b.lastAction)}</span></td></tr>` : ''}
        `).join('');
    }

    el('pastCard').style.display = D.past.length ? '' : 'none';
    el('pastBody').innerHTML = D.past.map(p => `
        <tr>
            <td>${ownerCell(p)}</td>
            <td><div class="cell-stack"><b>${esc(p.botname || 'unnamed')}</b><span class="cell-note">removed from this host</span></div></td>
            <td class="tight"><div class="cell-stack"><b>${p.requests}</b><span class="cell-note">${p.changes} changes · ${p.deploys} deploys</span></div></td>
            <td><div class="cell-stack"><b>${esc(relTime(p.lastSeen))}</b><span class="ip-list">${esc((p.ips || []).join(', ') || '—')}</span></div></td>
        </tr>`).join('');
}

el('usersSearch').addEventListener('input', renderUsers);
el('usersFilter').addEventListener('change', renderUsers);

/* ------------------------------------------------------------------ */
/* deployments                                                         */
/* ------------------------------------------------------------------ */

async function loadDeploys() {
    const box = el('deployList');
    let data;
    try {
        data = await api('/opiar/events', { group: 'Deploy', limit: 80 });
    } catch (err) {
        return;
    }
    const events = data.events || [];
    if (!events.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-rocket"></i>No deploy has been attempted since the ledger started.</p>';
        return;
    }

    box.innerHTML = events.map(e => {
        const d = e.detail || {};
        const cells = [
            ['Owner', d.username || e.owner || '—'],
            ['Bot name', d.botname || '—'],
            ['Prefix', d.prefix || '—'],
            ['First admin', d.admin || 'none given'],
            ['Appstate', d.cookies ? `${d.cookies} cookies` : 'unreadable'],
            ['Device', d.device || '—'],
            ['Took', d.tookMs != null ? `${(d.tookMs / 1000).toFixed(1)}s` : '—'],
            ['Bot uid', e.botId || 'not created']
        ];
        return `
            <div class="deploy-item ${esc(e.level)}">
                <div class="deploy-head">
                    <i class="fa-solid ${esc(e.icon)}"></i>
                    <h4>${esc(e.label)}</h4>
                    <time>${esc(stamp(e.at))} · ${esc(relTime(e.at))}</time>
                </div>
                <p>${esc(e.message)}</p>
                ${d.reason ? `<p style="color:var(--error)"><i class="fa-solid fa-circle-exclamation"></i> ${esc(d.reason)}</p>` : ''}
                <div class="deploy-grid">
                    ${cells.map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('')}
                    <div><span>Address</span><b>${esc(e.ip || '—')}</b></div>
                </div>
            </div>`;
    }).join('');
}

/* ------------------------------------------------------------------ */
/* audit trail                                                         */
/* ------------------------------------------------------------------ */

async function loadAudit() {
    let data;
    try {
        data = await api('/opiar/events', {
            q: el('auditSearch').value,
            group: el('auditGroup').value,
            limit: 300
        });
    } catch (err) {
        return;
    }
    const events = data.events || [];
    const box = el('auditBody');
    if (!events.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-wind"></i>Nothing matches that filter.</p>';
        return;
    }
    box.innerHTML = events.map(e => `
        <div class="console-line ${esc(e.level)}">
            <time>${esc(clockTime(e.at))}</time>
            <span class="lvl">${esc(e.group)}</span>
            ${e.owner || e.actor ? `<span class="who">${esc(e.owner || e.actor)}</span>` : ''}
            <span class="msg">${esc(e.message)}${e.ip ? ` <span style="color:var(--muted-2)">· ${esc(e.ip)}</span>` : ''}</span>
        </div>`).join('');
}

let auditDebounce = null;
el('auditSearch').addEventListener('input', () => {
    clearTimeout(auditDebounce);
    auditDebounce = setTimeout(loadAudit, 250);
});
el('auditGroup').addEventListener('change', loadAudit);

// the ledger leaves as a plain json file, the same shape botdata/devlog.json has
async function exportLedger(button) {
    const data = await run(button, () => api('/opiar/export'), 'the ledger was downloaded.');
    if (!data) return;
    const blob = new Blob([JSON.stringify(data.dump, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = data.file || 'opiar-ledger.json';
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}

async function clearAudit() {
    if (!confirm('Clear the whole audit trail? The counters on the panel users page are kept.')) return;
    await run(null, () => api('/opiar/events/clear'));
    loadAudit();
    loadOverview();
}

/* ------------------------------------------------------------------ */
/* inspector                                                           */
/* ------------------------------------------------------------------ */

function fillInspectPicker() {
    const pick = el('inspectPick');
    const current = D.inspecting || pick.value;
    pick.innerHTML = ['<option value="">Choose a bot</option>']
        .concat(D.bots.map(b => `<option value="${esc(b.uid)}">${esc(b.botname)} — ${esc(b.owner || b.name)}</option>`))
        .join('');
    if (current) pick.value = current;
}

function inspect(uid) {
    D.inspecting = uid;
    go('inspect');
    el('inspectPick').value = uid;
    loadInspect();
}

async function loadInspect() {
    const uid = el('inspectPick').value;
    D.inspecting = uid;
    const box = el('inspectBody');
    if (!uid) {
        box.innerHTML = '<div class="empty-state"><i class="fa-solid fa-hand-pointer"></i>Pick a bot to inspect.</div>';
        return;
    }

    let data;
    let trail = [];
    try {
        // the bot's own telemetry and its slice of the ledger, in parallel
        const [logs, own] = await Promise.all([
            api('/opiar/logs', { botId: uid }),
            api('/opiar/events', { botId: uid, limit: 60 })
        ]);
        data = logs;
        trail = own.events || [];
    } catch (err) {
        box.innerHTML = '<div class="empty-state"><i class="fa-solid fa-triangle-exclamation"></i>That bot could not be read.</div>';
        return;
    }

    const s = data.stats;
    const people = data.people || [];
    const tiles = [
        ['State', s.online ? 'online' : 'offline'],
        ['Uptime', fmtUptime(s.uptime)],
        ['Commands', s.commands],
        ['Messages', s.messages],
        ['Errors', s.errors],
        ['Blocked', s.blocked],
        ['People', people.length],
        ['Threads', s.threads]
    ];

    box.innerHTML = `
        <div class="inspect-grid">
            ${tiles.map(([k, v]) => `<div><span>${esc(k)}</span><b>${esc(v)}</b></div>`).join('')}
        </div>

        <div class="section-title">The people using ${esc(data.bot.botname)}</div>
        ${people.length ? `
        <div class="table-wrap">
            <table>
                <thead><tr><th>Person</th><th class="tight">Commands</th><th class="tight">Messages</th><th>Last command</th><th>Last seen</th></tr></thead>
                <tbody>
                ${people.slice(0, 40).map(p => `
                    <tr>
                        <td><div class="cell-stack"><b>${esc(p.name || 'Unknown')}</b><span class="cell-note">${esc(p.id)}</span></div></td>
                        <td class="tight">${esc(p.commands)}</td>
                        <td class="tight">${esc(p.messages)}</td>
                        <td>${esc(p.lastCommand || '—')}</td>
                        <td>${esc(relTime(p.lastAt))}</td>
                    </tr>`).join('')}
                </tbody>
            </table>
        </div>` : '<p class="empty-state"><i class="fa-solid fa-user-slash"></i>Nobody has used this bot yet.</p>'}

        <div class="section-title">What the owner did in the panel</div>
        ${trail.length ? `
        <div class="console">
            ${trail.map(e => `
                <div class="console-line ${esc(e.level)}">
                    <time>${esc(clockTime(e.at))}</time>
                    <span class="lvl">${esc(e.group)}</span>
                    ${e.owner || e.actor ? `<span class="who">${esc(e.owner || e.actor)}</span>` : ''}
                    <span class="msg">${esc(e.message)}${e.ip ? ` <span style="color:var(--muted-2)">· ${esc(e.ip)}</span>` : ''}</span>
                </div>`).join('')}
        </div>` : '<p class="empty-state"><i class="fa-solid fa-wind"></i>This owner has not touched the panel since the ledger started.</p>'}

        <div class="section-title">Live console</div>
        <div class="console">
            ${(data.logs || []).length ? (data.logs || []).map(line => `
                <div class="console-line ${esc(line.level)}">
                    <time>${esc(clockTime(line.at))}</time>
                    <span class="lvl">${esc(line.level)}</span>
                    ${line.user ? `<span class="who">${esc(line.user)}</span>` : ''}
                    <span class="msg">${esc(line.message)}</span>
                </div>`).join('') : '<p class="empty-state"><i class="fa-solid fa-wind"></i>This bot has not logged anything yet.</p>'}
        </div>
        <p class="inspect-sub">Owner "${esc(data.bot.owner || 'no username')}" · prefix "${esc(data.settings.prefix)}" · timezone ${esc(data.settings.timezone)} · ${data.settings.schedules.length} schedule${data.settings.schedules.length === 1 ? '' : 's'}</p>`;
}

/* ------------------------------------------------------------------ */
/* host controls                                                       */
/* ------------------------------------------------------------------ */

function renderHost(maintenance) {
    const on = !!(maintenance && maintenance.status);
    el('maintenanceToggle').checked = on;
    el('maintenanceNote').textContent = on
        ? `on since ${stamp(maintenance.since)} — ${maintenance.reason || ''}`
        : 'off, every bot on this host is serving normally.';

    const lock = (D.summary && D.summary.deployLock) || { status: false };
    el('deployLockToggle').checked = !!lock.status;
    el('deployLockNote').textContent = lock.status
        ? `closed since ${stamp(lock.since)} — the deploy form answers "${lock.reason}"`
        : 'open, anyone with an appstate can deploy a bot on this host.';

    const box = el('hostList');
    if (!D.bots.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-wind"></i>No sessions on this host.</p>';
        return;
    }
    box.innerHTML = D.bots.map(b => `
        <div class="host-row">
            ${ownerCell(b)}
            <div class="cell-stack">
                <b>${b.online ? 'session live' : b.hasSession ? 'appstate saved' : 'no saved session'}</b>
                <span class="cell-note">deployed ${esc(relTime(b.deployedAt))} · uptime ${esc(fmtUptime(b.uptime))}</span>
            </div>
            <div class="host-actions">
                <button class="btn btn-ghost btn-sm" onclick="control(this, 'stop', '${esc(b.uid)}')" ${b.online ? '' : 'disabled'}>
                    <i class="fa-solid fa-stop"></i> Stop
                </button>
                <button class="btn btn-ghost btn-sm" onclick="control(this, 'restart', '${esc(b.uid)}')" ${b.hasSession ? '' : 'disabled'}>
                    <i class="fa-solid fa-rotate-right"></i> Reconnect
                </button>
                <button class="btn btn-outline-danger btn-sm" onclick="removeBot(this, '${esc(b.uid)}', '${esc(b.owner || b.name)}')">
                    <i class="fa-solid fa-trash-can"></i> Remove
                </button>
            </div>
        </div>`).join('');
}

async function control(button, action, uid) {
    const done = await run(button, () => api('/opiar/control', { action, botId: uid }));
    if (done) setTimeout(loadOverview, 1200);
}

async function removeBot(button, uid, who) {
    if (!confirm(`Remove the bot of ${who}? Their saved session and panel access are deleted.`)) return;
    const reason = prompt('Why are you removing it? This is written to the ledger.', 'removed by the developer') || '';
    const done = await run(button, () => api('/opiar/control', { action: 'remove', botId: uid, reason }));
    if (done) loadOverview();
}

async function toggleDeployLock(input) {
    const value = input.checked;
    let reason = '';
    if (value) {
        reason = prompt('What should the deploy form tell people while it is closed?',
            'new deployments are closed by the developer right now, please try again later.') || '';
    }
    const done = await run(null, () => api('/opiar/control', { action: 'deploylock', value, reason }));
    if (!done) input.checked = !value;
    else loadOverview();
}

async function toggleMaintenance(input) {
    const value = input.checked;
    const done = await run(null, () => api('/opiar/control', { action: 'maintenance', value }));
    if (!done) input.checked = !value;
    else loadOverview();
}

/* ------------------------------------------------------------------ */
/* boot                                                                */
/* ------------------------------------------------------------------ */

(async function boot() {
    let saved = null;
    try { saved = sessionStorage.getItem(TOKEN_KEY); } catch (e) {}
    if (!saved) return;
    D.token = saved;
    try {
        await api('/opiar/overview');
        await openShell();
    } catch (err) {
        lock(null);
    }
})();
