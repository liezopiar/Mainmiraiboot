const menuToggle = document.querySelector('.menu-toggle');
const menuContainer = document.getElementById('menu-container');
const containers = document.querySelectorAll('.container');
const views = {
    create: document.querySelector('.create-container'),
    login: document.querySelector('.login-container'),
    commands: document.querySelector('.command-container'),
    onlines: document.querySelector('.onlines-container'),
    tutorial: document.querySelector('.tutorial-container')
};

// Random Background Music
const audioFiles = [
    'sololeveling.mp3'
];
const randomAudio = audioFiles[Math.floor(Math.random() * audioFiles.length)];
document.getElementById('background-audio').src = randomAudio;

// Menu Toggle
function toggleMenu(event) {
    event.stopPropagation(); // Prevent click event from bubbling up
    if (menuContainer.style.display === 'flex') {
        closeMenu();
    } else {
        menuContainer.style.display = 'flex';
    }
}

// Close Menu
function closeMenu() {
    menuContainer.style.display = 'none';
}

// View Management
function switchView(view) {
    containers.forEach(container => {
        container.style.display = 'none';
    });
    views[view].style.display = 'block';
}

// Navigation Functions
function gotoCreate() { 
    switchView('create');
    document.title = "Create New Bot";
    closeMenu();
}

function gotoTutorial() {
    switchView('tutorial');
    document.title = "How to Use";
    closeMenu();
}

function gotoCommands() {
    switchView('commands');
    document.title = "Commands";
    getCmd();
    closeMenu();
}

function gotoOnlines() {
    switchView('onlines');
    document.title = "Online Users";
    listOfAi();
    closeMenu();
}

function gotoDeveloper() {
    window.open('https://www.facebook.com/hajaegar', '_blank'); // Opens the Facebook link in a new tab
    closeMenu();
}

// Form Toggles
document.getElementById('showLogin').addEventListener('click', () => {
    switchView('login');
    document.title = "𝗹𝗼𝗴𝗶𝗻";
});

document.getElementById('showCreate').addEventListener('click', () => {
    switchView('create');
    document.title = "𝗖𝗿𝗲𝗮𝘁𝗲 𝗡𝗲𝘄";
});

// Button Loading States
function setButtonLoading(button) {
    button.innerHTML = `<div class="loading-spinner"></div>`;
    button.disabled = true;
}

// API Functions
async function createBot() {
    const button = document.querySelector('.createButton');
    const status = document.querySelector('.whatsGoin');
    setButtonLoading(button);
    
    const appstate = document.getElementById('appState').value;
    const botname = document.getElementById('botName').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const botPrefix = document.getElementById('botPrefix').value;
    const botAdmin = document.getElementById('botAdmin').value;

    if (!appstate || !username || !password) {
        status.style.color = '#e53e3e';
        status.textContent = 'Please fill all required fields!';
        button.disabled = false;
        button.textContent = 'Submit';
        return;
    }

    try {
        const response = await fetch('/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                appstate,
                botname,
                botprefix: botPrefix,
                botadmin: botAdmin,
                username,
                password
            })
        });
        
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        
        status.style.color = '#48bb78';
        status.textContent = 'Bot created successfully!';
        setTimeout(() => {
            window.location.href = `/profile?botid=${data.botid}&token=${data.token}`;
        }, 2000);
    } catch (error) {
        status.style.color = '#e53e3e';
        status.textContent = error.message;
        button.disabled = false;
        button.textContent = 'Submit';
    }
}

async function login() {
    const button = document.querySelector('.loginButton');
    const status = document.querySelector('.loginInfo');
    setButtonLoading(button);
    
    const username = document.getElementById('lUsername').value;
    const password = document.getElementById('lPassword').value;

    if (!username || !password) {
        status.style.color = '#e53e3e';
        status.textContent = 'Please fill all fields!';
        button.disabled = false;
        button.textContent = 'Login';
        return;
    }

    try {
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        if (data.error) throw new Error(data.error);
        
        status.style.color = '#48bb78';
        status.textContent = 'Login successful!';
        setTimeout(() => {
            window.location.href = `/profile?botid=${data.botid}&token=${data.token}`;
        }, 2000);
    } catch (error) {
        status.style.color = '#e53e3e';
        status.textContent = error.message;
        button.disabled = false;
        button.textContent = 'Login';
    }
}

// Command List
async function getCmd() {
    const container = document.querySelector('.cmd-container');
    try {
        const response = await fetch('/commands');
        const commands = await response.json();
        
        container.innerHTML = `
            <h5>Available Commands (${commands.length})</h5>
            ${commands.map(cmd => `
                <div class="command-card">
                    <h4>${cmd.config.name}</h4>
                    <p>${cmd.config.description || 'No description'}</p>
                    <small>Permission: ${['User', 'Admin', 'Bot Admin'][cmd.config.permission]}</small>
                </div>
            `).join('')}
        `;
    } catch (error) {
        container.innerHTML = `<p class="error">Error loading commands</p>`;
    }
}

// Online Users
async function listOfAi() {
    const container = document.getElementById('user_online');
    try {
        const response = await fetch('/info');
        const users = await response.json();
        
        container.innerHTML = users.length ? 
            users.map(user => `
                <div class="user-card">
                    <img src="${user.thumbSrc}" alt="User avatar">
                    <div>
                        <h4>${user.name}</h4>
                        <p>Uptime: ${formatTime(user.time)}</p>
                    </div>
                </div>
            `).join('') : 
            '<p>No Active session</p>';
    } catch (error) {
        container.innerHTML = '<p>Error loading online users</p>';
    }
}

function formatTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
}

// Initial Setup
document.addEventListener('DOMContentLoaded', () => {
    switchView('create');
    listOfAi();
});

Here's the code with all lines commented using `//`:

```javascript
// // const menuToggle = document.querySelector('.menu-toggle');
// const menuContainer = document.getElementById('menu-container');
// const containers = document.querySelectorAll('.container');
// const views = {
//     create: document.querySelector('.create-container'),
//     login: document.querySelector('.login-container'),
//     commands: document.querySelector('.command-container'),
//     onlines: document.querySelector('.onlines-container'),
//     tutorial: document.querySelector('.tutorial-container')
// };

// // Random Background Music
// const audioFiles = [
//     'sololeveling.mp3'
// ];
// const randomAudio = audioFiles[Math.floor(Math.random() * audioFiles.length)];
// document.getElementById('background-audio').src = randomAudio;

// // Menu Toggle
// function toggleMenu(event) {
//     event.stopPropagation(); // Prevent click event from bubbling up
//     if (menuContainer.style.display === 'flex') {
//         closeMenu();
//     } else {
//         menuContainer.style.display = 'flex';
//     }
// }

// // Close Menu
// function closeMenu() {
//     menuContainer.style.display = 'none';
// }

// // View Management
// function switchView(view) {
//     containers.forEach(container => {
//         container.style.display = 'none';
//     });
//     views[view].style.display = 'block';
// }

// // Navigation Functions
// function gotoCreate() { 
//     switchView('create');
//     document.title = "Create New Bot";
//     closeMenu();
// }

// function gotoTutorial() {
//     switchView('tutorial');
//     document.title = "How to Use";
//     closeMenu();
// }

// function gotoCommands() {
//     switchView('commands');
//     document.title = "Commands";
//     getCmd();
//     closeMenu();
// }

// function gotoOnlines() {
//     switchView('onlines');
//     document.title = "Online Users";
//     listOfAi();
//     closeMenu();
// }

// function gotoDeveloper() {
//     window.open('https://www.facebook.com/hajaegar', '_blank'); // Opens the Facebook link in a new tab
//     closeMenu();
// }

// // Form Toggles
// document.getElementById('showLogin').addEventListener('click', () => {
//     switchView('login');
//     document.title = "𝗹𝗼𝗴𝗶𝗻";
// });

// document.getElementById('showCreate').addEventListener('click', () => {
//     switchView('create');
//     document.title = "𝗖𝗿𝗲𝗮𝘁𝗲 𝗡𝗲𝘄";
// });

// // Button Loading States
// function setButtonLoading(button) {
//     button.innerHTML = `<div class="loading-spinner"></div>`;
//     button.disabled = true;
// }

// // API Functions
// async function createBot() {
//     const button = document.querySelector('.createButton');
//     const status = document.querySelector('.whatsGoin');
//     setButtonLoading(button);
    
//     const appstate = document.getElementById('appState').value;
//     const botname = document.getElementById('botName').value;
//     const username = document.getElementById('username').value;
//     const password = document.getElementById('password').value;
//     const botPrefix = document.getElementById('botPrefix').value;
//     const botAdmin = document.getElementById('botAdmin').value;

//     if (!appstate || !username || !password) {
//         status.style.color = '#e53e3e';
//         status.textContent = 'Please fill all required fields!';
//         button.disabled = false;
//         button.textContent = 'Submit';
//         return;
//     }

//     try {
//         const response = await fetch('/create', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({
//                 appstate,
//                 botname,
//                 botprefix: botPrefix,
//                 botadmin: botAdmin,
//                 username,
//                 password
//             })
//         });
        
//         const data = await response.json();
//         if (data.error) throw new Error(data.error);
        
//         status.style.color = '#48bb78';
//         status.textContent = 'Bot created successfully!';
//         setTimeout(() => {
//             window.location.href = `/profile?botid=${data.botid}&token=${data.token}`;
//         }, 2000);
//     } catch (error) {
//         status.style.color = '#e53e3e';
//         status.textContent = error.message;
//         button.disabled = false;
//         button.textContent = 'Submit';
//     }
// }

// async function login() {
//     const button = document.querySelector('.loginButton');
//     const status = document.querySelector('.loginInfo');
//     setButtonLoading(button);
    
//     const username = document.getElementById('lUsername').value;
//     const password = document.getElementById('lPassword').value;

//     if (!username || !password) {
//         status.style.color = '#e53e3e';
//         status.textContent = 'Please fill all fields!';
//         button.disabled = false;
//         button.textContent = 'Login';
//         return;
//     }

//     try {
//         const response = await fetch('/login', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json'
//             },
//             body: JSON.stringify({ username, password })
//         });
        
//         const data = await response.json();
//         if (data.error) throw new Error(data.error);
        
//         status.style.color = '#48bb78';
//         status.textContent = 'Login successful!';
//         setTimeout(() => {
//             window.location.href = `/profile?botid=${data.botid}&token=${data.token}`;
//         }, 2000);
//     } catch (error) {
//         status.style.color = '#e53e3e';
//         status.textContent = error.message;
//         button.disabled = false;
//         button.textContent = 'Login';
//     }
// }

// // Command List
// async function getCmd() {
//     const container = document.querySelector('.cmd-container');
//     try {
//         const response = await fetch('/commands');
//         const commands = await response.json();
        
//         container.innerHTML = `
//             <h5>Available Commands (${commands.length})</h5>
//             ${commands.map(cmd => `
//                 <div class="command-card">
//                     <h4>${cmd.config.name}</h4>
//                     <p>${cmd.config.description || 'No description'}</p>
//                     <small>Permission: ${['User', 'Admin', 'Bot Admin'][cmd.config.permission]}</small>
//                 </div>
//             `).join('')}
//         `;
//     } catch (error) {
//         container.innerHTML = `<p class="error">Error loading commands</p>`;
//     }
// }

// // Online Users
// async function listOfAi() {
//     const container = document.getElementById('user_online');
//     try {
//         const response = await fetch('/info');
//         const users = await response.json();
        
//         container.innerHTML = users.length ? 
//             users.map(user => `
//                 <div class="user-card">
//                     <img src="${user.thumbSrc}" alt="User avatar">
//                     <div>
//                         <h4>${user.name}</h4>
//                         <p>Uptime: ${formatTime(user.time)}</p>
//                     </div>
//                 </div>
//             `).join('') : 
//             '<p>No Active session</p>';
//     } catch (error) {
//         container.innerHTML = '<p>Error loading online users</p>';
//     }
// }

// function formatTime(seconds) {
//     const hours = Math.floor(seconds / 3600);
//     const minutes = Math.floor((seconds % 3600) / 60);
//     return `${hours}h ${minutes}m`;
// }

// // Initial Setup
// document.addEventListener('DOMContentLoaded', () => {
//     switchView('create');
//     listOfAi();
// });
```
