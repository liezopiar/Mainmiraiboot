/* ===========================================================================
   OP AutoBot control panel
   Talks to the /panel/* api. Every request carries the bot id and the jwt the
   login route issued, so the server can prove this browser owns the bot before
   it reads or writes anything.
   =========================================================================== */

'use strict';

const QS = new URLSearchParams(window.location.search);

const S = {
    botid: QS.get('botid'),
    token: QS.get('token'),
    view: 'dashboard',
    settings: null,
    catalogue: [],
    commands: [],
    cooldownEnforced: false,
    logs: [],
    lastLogId: 0,
    schedules: [],
    armed: 0,
    editing: null,
    stats: null,
    people: [],
    approvals: null,
    groupBans: [],
    actions: [],
    actionsOnline: false,
    actionResults: {},
    booted: false
};

const VIEWS = {
    dashboard:  { title: 'Dashboard',  sub: 'Live telemetry for your bot session.' },
    features:   { title: 'Features',   sub: 'Turn bot behaviour on and off.' },
    commands:   { title: 'Commands',   sub: 'Enable, disable and rate limit each command.' },
    users:      { title: 'Users',      sub: 'Approvals, bot users, banned groups and access lists.' },
    actions:    { title: 'Bot Actions', sub: 'Fire a single operation at the live Facebook session.' },
    automation: { title: 'Automation', sub: 'Schedules, auto replies and greetings.' },
    console:    { title: 'Console',    sub: 'Everything your bot is logging, live.' },
    settings:   { title: 'Settings',   sub: 'Identity, notifications and the danger zone.' }
};

const TIMEZONES = [
    'Asia/Manila', 'Asia/Singapore', 'Asia/Hong_Kong', 'Asia/Tokyo', 'Asia/Seoul',
    'Asia/Jakarta', 'Asia/Bangkok', 'Asia/Kolkata', 'Asia/Dubai', 'Asia/Karachi',
    'Europe/London', 'Europe/Berlin', 'Europe/Paris', 'Europe/Madrid', 'Europe/Moscow',
    'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles',
    'America/Mexico_City', 'America/Sao_Paulo', 'Australia/Sydney', 'Pacific/Auckland', 'UTC'
];

const SESSION_KEY = 'mainmirai:session-ended';

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

function esc(value) {
    return String(value == null ? '' : value)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function el(id) { return document.getElementById(id); }

// after a sign out or delete this panel is dead, make sure the back button
// can never restore it from the browser cache
function goHome() {
    try { sessionStorage.setItem(SESSION_KEY, '1'); } catch (e) {}
    try { window.history.replaceState(null, '', '/'); } catch (e) {}
    window.location.replace('/');
}

function sessionEnded() {
    try { return sessionStorage.getItem(SESSION_KEY) === '1'; } catch (e) { return false; }
}

window.addEventListener('pageshow', () => {
    if (sessionEnded()) {
        try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}
        window.location.replace('/');
    }
});

function fmtUptime(seconds) {
    const s = Math.max(0, Number(seconds) || 0);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (d) return `${d}d ${h}h`;
    if (h) return `${h}h ${m}m`;
    return `${m}m ${s % 60}s`;
}

function relTime(iso) {
    const then = new Date(iso).getTime();
    if (!then) return '';
    const diff = Math.floor((Date.now() - then) / 1000);
    if (diff < 60) return 'just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return `${Math.floor(diff / 86400)}d ago`;
}

function clockTime(iso) {
    const d = new Date(iso);
    if (isNaN(d)) return '--:--:--';
    return d.toLocaleTimeString([], { hour12: false });
}

function toast(message, kind) {
    const stack = el('toastStack');
    const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-circle-info' };
    const type = kind || 'info';
    const node = document.createElement('div');
    node.className = `toast ${type}`;
    node.innerHTML = `<i class="fa-solid ${icons[type] || icons.info}"></i><span>${esc(message)}</span>`;
    stack.appendChild(node);
    setTimeout(() => {
        node.classList.add('leaving');
        setTimeout(() => node.remove(), 240);
    }, 3200);
}

/* ------------------------------------------------------------------ */
/* api                                                                 */
/* ------------------------------------------------------------------ */

async function api(path, body) {
    const res = await fetch(path, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ botid: S.botid, token: S.token }, body || {}))
    });
    const data = await res.json().catch(() => null);
    if (res.status === 401 || (data && data.redirect)) {
        goHome();
        throw new Error('session ended');
    }
    if (!res.ok) throw new Error((data && data.error) || 'that request failed.');
    return data;
}

// wraps an action so the button shows a spinner and errors surface as a toast
async function run(button, work, successMessage) {
    let original = null;
    if (button) {
        original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<span class="loading-spinner"></span>';
    }
    try {
        const result = await work();
        if (successMessage !== false) toast(successMessage || (result && result.data) || 'done.', 'success');
        return result;
    } catch (err) {
        if (err && err.message !== 'session ended') toast(err.message, 'error');
        return null;
    } finally {
        if (button) {
            button.disabled = false;
            button.innerHTML = original;
        }
    }
}

/* ------------------------------------------------------------------ */
/* shell                                                               */
/* ------------------------------------------------------------------ */

function toggleMenu(event) {
    if (event) event.stopPropagation();
    const open = el('sidebar').classList.toggle('open');
    el('scrim').classList.toggle('show', open);
}

function closeMenu() {
    el('sidebar').classList.remove('open');
    el('scrim').classList.remove('show');
}

function openPublic() {
    window.open('/', '_blank', 'noopener');
    closeMenu();
}

function go(view) {
    S.view = view;
    document.querySelectorAll('.panel').forEach(p => p.classList.toggle('active', p.dataset.panel === view));
    document.querySelectorAll('.nav-item[data-view]').forEach(n => n.classList.toggle('active', n.dataset.view === view));
    const meta = VIEWS[view];
    if (meta) {
        el('viewTitle').textContent = meta.title;
        el('viewSub').textContent = meta.sub;
        document.title = `${meta.title} • OP AutoBot`;
    }
    closeMenu();
    if (view === 'commands' && !S.commands.length) loadCommands();
    if (view === 'console') pollLogs();
    if (view === 'users') { loadApprovals(); loadGroupBans(); loadPeople(); }
    if (view === 'actions' && !S.actions.length) loadActions();
}

/* ------------------------------------------------------------------ */
/* boot                                                               */
/* ------------------------------------------------------------------ */

async function boot() {
    if (!S.botid || !S.token) return goHome();
    try {
        const data = await api('/panel/overview');
        S.settings = data.settings;
        S.catalogue = data.catalogue || [];
        S.schedules = data.settings.schedules || [];
        // the overview already carries the saved bans, so the Users page paints
        // once immediately and /panel/groupbans only enriches it with names
        S.groupBans = data.settings.groupBans || [];
        S.booted = true;

        renderIdentity(data.profile);
        renderStats(data.stats);
        renderFeatures();
        renderLists();
        renderGroupBans();
        renderSchedules();
        renderRules();
        fillSettings();
        pollLogs();
    } catch (err) {
        if (err && err.message !== 'session ended') toast(err.message, 'error');
        return;
    }

    // dashboard telemetry, and the console when it is the visible section
    setInterval(refreshStats, 10000);
    setInterval(() => { if (S.view === 'console') pollLogs(); }, 4000);
    // the approval queue and the user roster only move while you are looking at them
    setInterval(() => { if (S.view === 'users') { loadApprovals(); loadGroupBans(); loadPeople(); } }, 20000);
    // the action list only tracks whether the session is live, so it can be slow
    setInterval(() => { if (S.view === 'actions' && S.actions.length) refreshActionState(); }, 30000);
}

async function refreshStats() {
    try {
        renderStats(await api('/panel/stats'));
    } catch (err) { /* a transient failure just skips one tick */ }
}

/* ------------------------------------------------------------------ */
/* 1. dashboard                                                        */
/* ------------------------------------------------------------------ */

function renderIdentity(profile) {
    if (!profile) return;
    if (profile.thumbSrc) {
        const img = el('botAvatar');
        img.src = profile.thumbSrc;
        img.onerror = () => { img.onerror = null; img.src = '/images/op-autobot-logo.svg'; };
    }
    el('botDisplayName').textContent = profile.name || 'Unknown';
    el('botUid').textContent = `UID ${profile.uid}`;
    el('footUid').textContent = `UID ${profile.uid}`;
}

function renderStats(stats) {
    if (!stats) return;
    S.stats = stats;

    el('topUptime').textContent = stats.online ? fmtUptime(stats.uptime) : 'offline';
    el('footStatus').innerHTML = stats.online
        ? '<span class="dot-live"></span> Session online'
        : '<span class="dot-live off"></span> Session offline';

    el('botTags').innerHTML = [
        stats.online ? '<span class="badge badge-success">online</span>' : '<span class="badge badge-error">offline</span>',
        `<span class="badge">prefix ${esc(stats.prefix)}</span>`,
        `<span class="badge badge-muted">${stats.admins} admin${stats.admins === 1 ? '' : 's'}</span>`,
        stats.maintenance && stats.maintenance.status ? '<span class="badge badge-warning">maintenance</span>' : ''
    ].join('');

    renderBanner(stats);
    renderMetrics(stats);
    renderUsage(stats.usage || []);
    renderActivity(stats.activity || []);
}

function renderBanner(stats) {
    const box = el('dashBanner');
    if (stats.maintenance && stats.maintenance.status) {
        box.innerHTML = `
            <div class="banner">
                <i class="fa-solid fa-screwdriver-wrench"></i>
                <div>
                    <b>Maintenance mode is on.</b>
                    <p>${esc(stats.maintenance.reason || 'Only your admins can use the bot right now.')}</p>
                </div>
            </div>`;
        return;
    }
    if (!stats.online) {
        box.innerHTML = `
            <div class="banner offline">
                <i class="fa-solid fa-plug-circle-xmark"></i>
                <div>
                    <b>This bot is not connected to Facebook.</b>
                    <p>Open Settings and use Restart Session to reconnect from the saved appstate.</p>
                </div>
            </div>`;
        return;
    }
    box.innerHTML = '';
}

function renderMetrics(stats) {
    const tiles = [
        { label: 'Commands',   value: stats.commands,    icon: 'fa-terminal',     sub: `${stats.totalCommandModules} modules loaded`, tone: 'accent' },
        { label: 'Messages',   value: stats.messages,    icon: 'fa-comment-dots', sub: 'seen this session' },
        { label: 'Events',     value: stats.events,      icon: 'fa-bolt',         sub: 'joins, leaves, reactions' },
        { label: 'Errors',     value: stats.errors,      icon: 'fa-circle-exclamation', sub: 'check the console', tone: stats.errors ? 'bad' : '' },
        { label: 'Blocked',    value: stats.blocked,     icon: 'fa-shield-halved', sub: 'refused by access rules' },
        { label: 'People',     value: stats.activeUsers, icon: 'fa-users',        sub: 'unique users' },
        { label: 'Threads',    value: stats.threads,     icon: 'fa-comments',     sub: 'chats touched' },
        { label: 'Latency',    value: `${stats.latency}`, icon: 'fa-gauge-high',  sub: 'ms average', tone: 'good', unit: 'ms' }
    ];

    el('metricGrid').innerHTML = tiles.map(t => `
        <div class="metric ${t.tone || ''}">
            <div class="metric-top">
                <span class="metric-label">${esc(t.label)}</span>
                <span class="metric-icon"><i class="fa-solid ${t.icon}"></i></span>
            </div>
            <span class="metric-value">${esc(t.value)}${t.unit ? `<span style="font-size:0.8rem;color:var(--muted)">${t.unit}</span>` : ''}</span>
            <span class="metric-sub">${esc(t.sub)}</span>
        </div>`).join('');
}

function renderUsage(series) {
    const peak = series.reduce((max, point) => Math.max(max, point.count), 0);
    const total = series.reduce((sum, point) => sum + point.count, 0);

    el('usageChart').innerHTML = series.map(point => {
        const pct = peak ? Math.round((point.count / peak) * 100) : 0;
        return `
            <div class="usage-col" title="${esc(point.label)} — ${point.count} command${point.count === 1 ? '' : 's'}">
                <div class="usage-track">
                    <div class="usage-bar ${point.count ? '' : 'zero'}" style="height:${point.count ? Math.max(pct, 4) : 0}%"></div>
                </div>
                <b>${esc(point.label)}</b>
            </div>`;
    }).join('');

    el('usagePeak').textContent = `Peak ${peak} per 5 min`;
    el('usageTotal').textContent = `${total} command${total === 1 ? '' : 's'} in the last hour`;
}

function renderActivity(items) {
    const box = el('activityFeed');
    if (!items.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-wind"></i>Nothing has happened yet.</p>';
        return;
    }
    box.innerHTML = items.map(item => `
        <div class="feed-item">
            <span class="feed-icon"><i class="fa-solid ${esc(item.icon || 'fa-circle-dot')}"></i></span>
            <div class="feed-body">
                <p>${esc(item.text)}</p>
                <span class="feed-meta">
                    <time>${esc(relTime(item.at))}</time>
                    ${item.user ? `<span class="actor" title="UID ${esc(item.userId || 'unknown')}"><i class="fa-solid fa-user"></i>${esc(item.user)}</span>` : ''}
                </span>
            </div>
        </div>`).join('');
}

/* ------------------------------------------------------------------ */
/* 2. features                                                         */
/* ------------------------------------------------------------------ */

function renderFeatures() {
    const flags = S.settings.features || {};
    const order = ['Messaging', 'Groups', 'Protection', 'Automation'];
    const groups = {};
    S.catalogue.forEach(f => {
        (groups[f.group] = groups[f.group] || []).push(f);
    });

    const on = Object.keys(flags).filter(k => flags[k]).length;
    el('featureCount').textContent = `${on} of ${S.catalogue.length} on`;
    el('navFeatures').textContent = on;

    el('featureList').innerHTML = order
        .filter(group => groups[group])
        .map(group => `
            <div class="feature-group">
                <div class="section-title">${esc(group)}</div>
                ${groups[group].map(f => `
                    <label class="feature-row" for="ft-${esc(f.key)}">
                        <span class="row-icon"><i class="fa-solid ${esc(f.icon)}"></i></span>
                        <span class="row-main">
                            <h4>${esc(f.label)}${f.enforced ? '' : ' <span class="badge badge-warning">not wired yet</span>'}</h4>
                            <p>${esc(f.desc)}</p>
                            ${f.note ? `<p class="feature-note"><i class="fa-solid fa-triangle-exclamation"></i>${esc(f.note)}</p>` : ''}
                        </span>
                        <span class="switch">
                            <input type="checkbox" id="ft-${esc(f.key)}" ${flags[f.key] ? 'checked' : ''}
                                   onchange="toggleFeature('${esc(f.key)}', this)">
                            <span class="slider"></span>
                        </span>
                    </label>`).join('')}
            </div>`).join('');
}

async function toggleFeature(key, input) {
    const wanted = input.checked;
    input.disabled = true;
    try {
        const data = await api('/panel/feature', { key, value: wanted });
        S.settings.features = data.features;
        toast(data.data, 'success');
        renderFeatures();
        renderLists();
        renderSchedules();
        renderRules();
    } catch (err) {
        input.checked = !wanted;
        if (err.message !== 'session ended') toast(err.message, 'error');
    } finally {
        input.disabled = false;
    }
}

/* ------------------------------------------------------------------ */
/* 3. commands                                                         */
/* ------------------------------------------------------------------ */

async function loadCommands() {
    el('cmdBody').innerHTML = '<tr><td colspan="4"><div class="loading-block"><span class="loading-spinner"></span> Loading commands…</div></td></tr>';
    try {
        const data = await api('/panel/commands');
        S.commands = data.commands || [];
        S.cooldownEnforced = !!data.cooldownEnforced;

        const categories = Array.from(new Set(S.commands.map(c => c.category))).sort();
        el('cmdCategory').innerHTML = '<option value="">All categories</option>' +
            categories.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join('');

        el('cmdHint').textContent = S.cooldownEnforced
            ? 'Your per-command cooldowns are being enforced.'
            : 'Per-command cooldown is off in Features, so the author default applies instead.';

        renderCommands();
    } catch (err) {
        el('cmdBody').innerHTML = `<tr><td colspan="4"><p class="empty-state">${esc(err.message)}</p></td></tr>`;
    }
}

function renderCommands() {
    const query = (el('cmdSearch').value || '').trim().toLowerCase();
    const category = el('cmdCategory').value;
    const status = el('cmdStatus').value;

    const rows = S.commands.filter(c => {
        if (category && c.category !== category) return false;
        if (status === 'on' && !c.enabled) return false;
        if (status === 'off' && c.enabled) return false;
        if (query && !(c.name.toLowerCase().includes(query) || (c.description || '').toLowerCase().includes(query))) return false;
        return true;
    });

    el('cmdCount').textContent = `${S.commands.length} total`;
    el('navCommands').textContent = S.commands.length;

    if (!rows.length) {
        el('cmdBody').innerHTML = '<tr><td colspan="4"><p class="empty-state"><i class="fa-solid fa-magnifying-glass"></i>No command matches those filters.</p></td></tr>';
        return;
    }

    el('cmdBody').innerHTML = rows.map(c => `
        <tr>
            <td>
                <span class="cmd-name">${esc(c.usesPrefix ? S.settings.prefix : '')}${esc(c.name)}</span>
                ${c.premium ? ' <span class="badge badge-warning">premium</span>' : ''}
                <span class="cmd-desc">${esc(c.description)}</span>
            </td>
            <td class="tight"><span class="perm perm-${c.permission}">${esc(c.role)}</span></td>
            <td class="tight">
                <input class="input-sm cd-input input-mono" type="number" min="0" max="3600" value="${esc(c.cooldown)}"
                       aria-label="Cooldown for ${esc(c.name)}"
                       onchange="setCooldown('${esc(c.name)}', this)">
            </td>
            <td class="tight">
                <span class="switch">
                    <input type="checkbox" ${c.enabled ? 'checked' : ''}
                           aria-label="Enable ${esc(c.name)}"
                           onchange="setCommandEnabled('${esc(c.name)}', this)">
                    <span class="slider"></span>
                </span>
            </td>
        </tr>`).join('');
}

async function setCommandEnabled(name, input) {
    const wanted = input.checked;
    input.disabled = true;
    try {
        await api('/panel/command', { name, enabled: wanted });
        const found = S.commands.find(c => c.name === name);
        if (found) found.enabled = wanted;
        toast(`${name} ${wanted ? 'enabled' : 'disabled'}.`, 'success');
    } catch (err) {
        input.checked = !wanted;
        if (err.message !== 'session ended') toast(err.message, 'error');
    } finally {
        input.disabled = false;
    }
}

async function setCooldown(name, input) {
    const found = S.commands.find(c => c.name === name);
    const previous = found ? found.cooldown : 0;
    const value = Number(input.value);
    if (!Number.isFinite(value) || value < 0 || value > 3600) {
        input.value = previous;
        return toast('cooldown must be between 0 and 3600 seconds.', 'error');
    }
    input.disabled = true;
    try {
        await api('/panel/command', { name, cooldown: value });
        if (found) found.cooldown = value;
        toast(`${name} cooldown set to ${value}s.`, 'success');
    } catch (err) {
        input.value = previous;
        if (err.message !== 'session ended') toast(err.message, 'error');
    } finally {
        input.disabled = false;
    }
}

/* ------------------------------------------------------------------ */
/* 4. users                                                            */
/* ------------------------------------------------------------------ */

function renderLists() {
    const enforced = !!(S.settings.features && S.settings.features.accessControl);
    const state = el('wlState');
    state.textContent = enforced ? 'enforcement on' : 'enforcement off';
    state.className = `badge ${enforced ? 'badge-success' : 'badge-muted'}`;

    chipSet('adminChips', 'admins', S.settings.admins, 'No extra admins yet.');
    chipSet('whitelistChips', 'whitelist', S.settings.whitelist, 'Empty, so everyone is allowed.');
    chipSet('blacklistChips', 'blacklist', S.settings.blacklist, 'Nobody is blocked.');
}

function chipSet(target, list, ids, emptyText) {
    const box = el(target);
    if (!ids || !ids.length) {
        box.innerHTML = `<p class="hint">${esc(emptyText)}</p>`;
        return;
    }
    box.innerHTML = ids.map(id => `
        <span class="id-chip">
            ${esc(id)}
            <button onclick="removeFromList('${esc(list)}','${esc(id)}')" aria-label="Remove ${esc(id)}">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </span>`).join('');
}

async function addToList(list, inputId) {
    const input = el(inputId);
    const id = (input.value || '').trim();
    if (!/^\d{5,}$/.test(id)) return toast('user id must be numbers only.', 'error');
    try {
        const data = await api('/panel/users', { action: 'add', list, id });
        applyLists(data);
        input.value = '';
        toast(data.data, 'success');
    } catch (err) {
        if (err.message !== 'session ended') toast(err.message, 'error');
    }
}

async function removeFromList(list, id) {
    try {
        const data = await api('/panel/users', { action: 'remove', list, id });
        applyLists(data);
        toast(data.data, 'success');
    } catch (err) {
        if (err.message !== 'session ended') toast(err.message, 'error');
    }
}

function applyLists(data) {
    S.settings.admins = data.admins;
    S.settings.whitelist = data.whitelist;
    S.settings.blacklist = data.blacklist;
    renderLists();
}

/* ---- group approval queue ---------------------------------------- */

// a picture that fails to load reveals the initial behind it instead of
// leaving a broken image icon in the row
function avatar(src, name, kind) {
    const letter = esc(String(name || '?').trim().charAt(0).toUpperCase() || '?');
    const fallbackIcon = kind === 'group' ? 'fa-users' : '';
    const fallback = fallbackIcon
        ? `<span class="avatar-fallback"><i class="fa-solid ${fallbackIcon}"></i></span>`
        : `<span class="avatar-fallback">${letter}</span>`;
    if (!src) return `<span class="avatar">${fallback}</span>`;
    return `<span class="avatar">
        <img src="${esc(src)}" alt="" loading="lazy" referrerpolicy="no-referrer"
             onerror="this.remove()">
        ${fallback}
    </span>`;
}

async function loadApprovals(button) {
    const work = async () => {
        S.approvals = await api('/panel/approvals');
        renderApprovals();
    };
    if (button) return run(button, work, 'approval list refreshed.');
    try { await work(); } catch (err) { /* the empty state already explains it */ }
}

function renderApprovals() {
    const data = S.approvals || { pending: [], approved: [], enabled: false };
    const badge = el('approvalState');
    badge.textContent = data.enabled ? 'approval required' : 'approval off';
    badge.className = `badge ${data.enabled ? 'badge-success' : 'badge-muted'}`;

    el('pendingList').innerHTML = data.pending.length
        ? data.pending.map(request => `
            <div class="req-item">
                ${avatar(request.image, request.name, 'group')}
                <div class="req-body">
                    <h4>${esc(request.name)} <span class="badge badge-warning">waiting</span></h4>
                    <p class="mono">${esc(request.threadID)}</p>
                    <div class="req-meta">
                        <span>${avatar(request.requesterAvatar, request.requesterName)} requested by ${esc(request.requesterName)}</span>
                        ${request.at ? `<span><i class="fa-regular fa-clock"></i> ${esc(request.at)}</span>` : ''}
                    </div>
                </div>
                <div class="req-actions">
                    <button class="btn btn-primary btn-sm btn-inline" onclick="approveGroup('${esc(request.threadID)}', this)">
                        <i class="fa-solid fa-check"></i> Approve
                    </button>
                    <button class="btn btn-outline-danger btn-sm btn-inline" onclick="declineGroup('${esc(request.threadID)}','${esc(request.name)}')">
                        <i class="fa-solid fa-xmark"></i> Decline
                    </button>
                </div>
            </div>`).join('')
        : `<p class="empty-state"><i class="fa-solid fa-inbox"></i>No chat is waiting for approval.</p>`;

    el('approvedList').innerHTML = data.approved.length
        ? data.approved.map(group => `
            <div class="req-item">
                ${avatar(group.image, group.name, 'group')}
                <div class="req-body">
                    <h4>${esc(group.name)} <span class="badge badge-success">approved</span></h4>
                    <p class="mono">${esc(group.threadID)}</p>
                </div>
                <div class="req-actions">
                    <button class="btn btn-ghost btn-sm btn-inline" onclick="revokeGroup('${esc(group.threadID)}','${esc(group.name)}')">
                        <i class="fa-solid fa-ban"></i> Revoke
                    </button>
                </div>
            </div>`).join('')
        : `<p class="empty-state"><i class="fa-regular fa-circle-check"></i>No chat has been approved yet.</p>`;
}

function approveGroup(threadID, button) {
    return run(button, async () => {
        const data = await api('/panel/approvals', { action: 'approve', threadID });
        S.approvals = data.approvals;
        renderApprovals();
        return data;
    });
}

function declineGroup(threadID, name) {
    confirmAction('Decline this request?', `${name} will be told the request was declined and will stay locked out of the bot.`, async () => {
        const data = await api('/panel/approvals', { action: 'decline', threadID });
        S.approvals = data.approvals;
        renderApprovals();
        toast(data.data, 'success');
    });
}

function revokeGroup(threadID, name) {
    confirmAction('Remove bot access?', `${name} will need a new approval before it can run any command again.`, async () => {
        const data = await api('/panel/approvals', { action: 'revoke', threadID });
        S.approvals = data.approvals;
        renderApprovals();
        toast(data.data, 'success');
    });
}

/* ---- banned groups ----------------------------------------------- */

// a ban outranks approval, so this list is rendered even when the approval
// queue is empty. the server hands back the whole list after every write.
function renderGroupBans() {
    const bans = S.groupBans || [];
    const count = el('groupBanCount');
    count.textContent = `${bans.length} banned`;
    count.className = `badge ${bans.length ? 'badge-error' : 'badge-muted'}`;

    el('groupBanList').innerHTML = bans.length
        ? bans.map(group => `
            <div class="req-item">
                ${avatar(group.image, group.name, 'group')}
                <div class="req-body">
                    <h4>
                        ${esc(group.name)}
                        <span class="badge badge-error">banned</span>
                        ${group.approved ? '<span class="badge badge-muted">still approved</span>' : ''}
                    </h4>
                    <p class="mono">${esc(group.threadID)}</p>
                    <div class="req-meta">
                        <span><i class="fa-solid fa-circle-exclamation"></i> ${esc(group.reason || 'no reason given')}</span>
                        ${group.at ? `<span><i class="fa-regular fa-clock"></i> ${esc(group.at)}</span>` : ''}
                    </div>
                </div>
                <div class="req-actions">
                    <button class="btn btn-ghost btn-sm btn-inline" onclick="unbanGroup('${esc(group.threadID)}','${esc(group.name)}')">
                        <i class="fa-solid fa-lock-open"></i> Unban
                    </button>
                </div>
            </div>`).join('')
        : `<p class="empty-state"><i class="fa-solid fa-users"></i>No group is banned.</p>`;
}

async function loadGroupBans(button) {
    const work = async () => {
        const data = await api('/panel/groupbans');
        S.groupBans = data.groupBans || [];
        renderGroupBans();
    };
    if (button) return run(button, work, 'ban list refreshed.');
    try { await work(); } catch (err) { /* the empty state already explains it */ }
}

function banGroup(button) {
    const input = el('groupBanInput');
    const reasonInput = el('groupBanReason');
    const threadID = (input.value || '').trim();
    if (!/^\d{5,}$/.test(threadID)) return toast('thread id must be numbers only.', 'error');

    return run(button, async () => {
        const data = await api('/panel/groupbans', {
            action: 'ban',
            threadID,
            reason: (reasonInput.value || '').trim()
        });
        S.groupBans = data.groupBans || [];
        input.value = '';
        reasonInput.value = '';
        renderGroupBans();
        return data;
    });
}

function unbanGroup(threadID, name) {
    confirmAction('Let this group back in?', `${name} will be able to use the bot again, as long as it is still approved.`, async () => {
        const data = await api('/panel/groupbans', { action: 'unban', threadID });
        S.groupBans = data.groupBans || [];
        renderGroupBans();
        toast(data.data, 'success');
    });
}

/* ---- the people who used the bot --------------------------------- */

async function loadPeople(button) {
    const work = async () => {
        const data = await api('/panel/people');
        S.people = data.users || [];
        renderPeople();
    };
    if (button) return run(button, work, 'user list refreshed.');
    try { await work(); } catch (err) { /* the empty state already explains it */ }
}

function renderPeople() {
    const query = (el('peopleSearch').value || '').trim().toLowerCase();
    const filter = el('peopleFilter').value;

    const rows = S.people.filter(user => {
        if (filter === 'banned' && !user.banned) return false;
        if (filter === 'allowed' && user.banned) return false;
        if (!query) return true;
        return user.name.toLowerCase().includes(query) || user.id.includes(query);
    });

    const banned = S.people.filter(user => user.banned).length;
    const count = el('peopleCount');
    count.textContent = `${S.people.length} seen · ${banned} banned`;
    count.className = `badge ${banned ? 'badge-error' : 'badge-muted'}`;

    el('peopleList').innerHTML = rows.length
        ? rows.map(user => {
            const tags = [];
            if (user.isBot) tags.push('<span class="badge badge-muted">this bot</span>');
            if (user.isOperator) tags.push('<span class="badge">operator</span>');
            else if (user.isAdmin) tags.push('<span class="badge">admin</span>');
            if (user.banned) tags.push('<span class="badge badge-error">banned</span>');
            if (user.blacklisted) tags.push('<span class="badge badge-warning">blacklisted</span>');

            const action = user.banned
                ? `<button class="btn btn-ghost btn-sm btn-inline" onclick="unbanPerson('${esc(user.id)}','${esc(user.name)}')">
                       <i class="fa-solid fa-lock-open"></i> Unban
                   </button>`
                : `<button class="btn btn-outline-danger btn-sm btn-inline" onclick="banPerson('${esc(user.id)}','${esc(user.name)}')" ${user.isBot || user.isOperator ? 'disabled' : ''}>
                       <i class="fa-solid fa-user-slash"></i> Ban
                   </button>`;

            return `
            <div class="person">
                ${avatar(user.avatar, user.name)}
                <div class="person-body">
                    <h4>
                        <a class="link" href="${esc(user.profileUrl)}" target="_blank" rel="noopener">${esc(user.name)}</a>
                        ${tags.join('')}
                    </h4>
                    <p class="mono">${esc(user.id)}</p>
                    <div class="person-meta">
                        <span><i class="fa-solid fa-terminal"></i> ${user.commands} command${user.commands === 1 ? '' : 's'}</span>
                        <span><i class="fa-regular fa-comment"></i> ${user.messages} message${user.messages === 1 ? '' : 's'}</span>
                        <span><i class="fa-regular fa-clock"></i> ${esc(relTime(user.lastSeen))}</span>
                        ${user.lastCommand ? `<span><i class="fa-solid fa-play"></i> last ran <code>${esc(user.lastCommand)}</code></span>` : ''}
                    </div>
                    ${user.banned ? `<p class="person-ban"><i class="fa-solid fa-circle-exclamation"></i> ${esc(user.banReason || 'no reason given')}${user.bannedAt ? ` · ${esc(user.bannedAt)}` : ''}</p>` : ''}
                </div>
                <div class="person-actions">${action}</div>
            </div>`;
        }).join('')
        : `<p class="empty-state"><i class="fa-regular fa-user"></i>${S.people.length ? 'No user matches that search.' : 'Nobody has used the bot in this session yet.'}</p>`;
}

function banPerson(id, name) {
    confirmAction('Ban this user?', `${name} will be refused by every command and event until you unban them.`, async () => {
        const data = await api('/panel/people', { action: 'ban', id, reason: 'banned from the bot panel' });
        S.people = data.users || [];
        renderPeople();
        toast(data.data, 'success');
    });
}

function unbanPerson(id, name) {
    confirmAction('Unban this user?', `${name} will be able to use the bot again right away.`, async () => {
        const data = await api('/panel/people', { action: 'unban', id });
        S.people = data.users || [];
        renderPeople();
        toast(data.data, 'success');
    });
}

/* ------------------------------------------------------------------ */
/* 5. bot actions                                                      */
/* ------------------------------------------------------------------ */

// the background tick only cares whether the session came back, so it patches the
// badge and the buttons in place. a full repaint would wipe half typed fields.
async function refreshActionState() {
    try {
        const data = await api('/panel/actions');
        const online = !!data.online;
        const changed = online !== S.actionsOnline;
        S.actionsOnline = online;
        (data.actions || []).forEach(fresh => {
            const known = S.actions.find(a => a.key === fresh.key);
            if (known) known.available = fresh.available;
        });

        const badge = el('actionsState');
        badge.textContent = online ? 'session online' : 'session offline';
        badge.className = `badge ${online ? 'badge-success' : 'badge-error'}`;
        // only a real online/offline flip changes which buttons are usable
        if (changed) renderActions();
    } catch (err) { /* a transient failure just skips one tick */ }
}

async function loadActions(button) {
    const work = async () => {
        const data = await api('/panel/actions');
        S.actions = data.actions || [];
        S.actionsOnline = !!data.online;

        // rebuild the group filter, keeping whatever the user already picked
        const select = el('actionGroup');
        const chosen = select.value;
        const groups = Array.from(new Set(S.actions.map(a => a.group)));
        select.innerHTML = '<option value="all">Every group</option>' +
            groups.map(g => `<option value="${esc(g)}">${esc(g)}</option>`).join('');
        select.value = groups.includes(chosen) ? chosen : 'all';

        el('navActions').textContent = S.actions.length;
        renderActions();
    };
    if (button) return run(button, work, 'actions refreshed.');
    try { await work(); } catch (err) {
        el('actionList').innerHTML = '<div class="card"><p class="empty-state"><i class="fa-solid fa-plug-circle-xmark"></i>Could not load the action list.</p></div>';
    }
}

// one field of one action. `value` seeds a toggle or a select default.
function actionField(action, field) {
    const id = `af-${esc(action.key)}-${esc(field.name)}`;
    const label = `${esc(field.label)}${field.optional ? ' <span class="opt">optional</span>' : ''}`;

    if (field.type === 'toggle') {
        return `
            <label class="act-toggle" for="${id}">
                <span class="switch">
                    <input type="checkbox" id="${id}" data-field="${esc(field.name)}" ${field.value ? 'checked' : ''}>
                    <span class="slider"></span>
                </span>
                <span>${label}</span>
            </label>`;
    }

    if (field.type === 'select') {
        const options = (field.options || []).map(option =>
            `<option value="${esc(option)}" ${String(option) === String(field.value) ? 'selected' : ''}>${esc(option)}</option>`
        ).join('');
        return `
            <div class="field">
                <label class="field-label" for="${id}">${label}</label>
                <select id="${id}" data-field="${esc(field.name)}">${options}</select>
            </div>`;
    }

    if (field.type === 'textarea') {
        return `
            <div class="field field-full">
                <label class="field-label" for="${id}">${label}</label>
                <textarea id="${id}" data-field="${esc(field.name)}" rows="3"
                          ${field.max ? `maxlength="${Number(field.max)}"` : ''}
                          placeholder="${esc(field.placeholder || '')}"></textarea>
            </div>`;
    }

    // id fields are numeric only, url fields get the browser's url keyboard
    const numeric = field.type === 'id';
    return `
        <div class="field">
            <label class="field-label" for="${id}">${label}</label>
            <input id="${id}" data-field="${esc(field.name)}"
                   class="${numeric || field.type === 'text' ? 'input-mono' : ''}"
                   type="${field.type === 'url' ? 'url' : 'text'}"
                   ${numeric ? 'inputmode="numeric"' : ''}
                   ${field.max ? `maxlength="${Number(field.max)}"` : ''}
                   placeholder="${esc(field.placeholder || '')}" autocomplete="off">
        </div>`;
}

function renderActions() {
    const state = el('actionsState');
    state.textContent = S.actionsOnline ? 'session online' : 'session offline';
    state.className = `badge ${S.actionsOnline ? 'badge-success' : 'badge-error'}`;

    const query = (el('actionSearch').value || '').trim().toLowerCase();
    const group = el('actionGroup').value;

    const rows = S.actions.filter(action => {
        if (group && group !== 'all' && action.group !== group) return false;
        if (!query) return true;
        return action.label.toLowerCase().includes(query) ||
            action.desc.toLowerCase().includes(query) ||
            action.group.toLowerCase().includes(query);
    });

    if (!rows.length) {
        el('actionList').innerHTML = `<div class="card"><p class="empty-state"><i class="fa-solid fa-magnifying-glass"></i>${
            S.actions.length ? 'No action matches those filters.' : 'The action list is empty.'
        }</p></div>`;
        return;
    }

    el('actionList').innerHTML = rows.map(action => {
        const locked = !action.available;
        return `
        <div class="card act-card ${action.danger ? 'act-danger' : ''}">
            <div class="act-head">
                <span class="row-icon"><i class="fa-solid ${esc(action.icon)}"></i></span>
                <div class="act-title">
                    <h3>
                        <span class="act-no">${esc(action.no)}</span>
                        ${esc(action.label)}
                        ${action.unverified ? '<span class="badge badge-warning">unverified</span>' : ''}
                        ${action.danger ? '<span class="badge badge-error">destructive</span>' : ''}
                    </h3>
                    <p>${esc(action.desc)}</p>
                </div>
                <span class="badge badge-muted">${esc(action.group)}</span>
            </div>

            ${action.unverified ? `
                <p class="act-warn">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    Facebook exposes no official method for this, so the panel calls GraphQL directly. It may stop working without warning.
                </p>` : ''}

            <div class="act-form" data-action="${esc(action.key)}">
                ${(action.fields || []).map(field => actionField(action, field)).join('')}
            </div>

            <div class="act-foot">
                ${locked ? '<span class="hint"><i class="fa-solid fa-lock"></i> Needs a live session. Start the bot from Settings.</span>' : '<span></span>'}
                <button class="btn ${action.danger ? 'btn-danger' : 'btn-primary'} btn-sm btn-inline"
                        onclick="runActionKey('${esc(action.key)}', this)" ${locked ? 'disabled' : ''}>
                    <i class="fa-solid ${action.reads ? 'fa-download' : 'fa-bolt'}"></i> ${esc(action.verb)}
                </button>
            </div>

            <div class="act-result" id="ares-${esc(action.key)}">${renderActionResult(action.key)}</div>
        </div>`;
    }).join('');
}

// read every field back out of the card the button lives in
function collectAction(key) {
    const form = document.querySelector(`.act-form[data-action="${key}"]`);
    const input = {};
    if (!form) return input;
    form.querySelectorAll('[data-field]').forEach(node => {
        input[node.dataset.field] = node.type === 'checkbox' ? node.checked : node.value;
    });
    return input;
}

function runActionKey(key, button) {
    const action = S.actions.find(a => a.key === key);
    if (!action) return;

    const fire = async () => {
        const data = await api('/panel/actions', { key, input: collectAction(key) });
        S.actionResults[key] = {
            message: data.data,
            rows: data.rows || null,
            kind: data.kind || null,
            at: new Date().toISOString()
        };
        const box = el(`ares-${key}`);
        if (box) box.innerHTML = renderActionResult(key);
        return data;
    };

    // anything destructive gets a confirm step first
    if (action.danger) {
        return confirmAction(`${action.label}?`, 'This runs against the live Facebook account straight away and cannot be undone.', fire);
    }
    return run(button, fire);
}

function renderActionResult(key) {
    const result = S.actionResults[key];
    if (!result) return '';

    const head = `
        <div class="act-result-head">
            <i class="fa-solid fa-circle-check"></i>
            <span>${esc(result.message)}</span>
            <time>${esc(clockTime(result.at))}</time>
        </div>`;

    if (result.kind !== 'threads' || !result.rows || !result.rows.length) return head;

    return head + `
        <div class="act-rows">
            ${result.rows.map(row => `
                <div class="act-row">
                    ${avatar(row.image, row.name, row.group ? 'group' : '')}
                    <div class="act-row-body">
                        <h4>
                            ${esc(row.name)}
                            ${row.group ? '<span class="badge badge-muted">group</span>' : ''}
                            ${row.unread ? `<span class="badge badge-warning">${esc(row.unread)} unread</span>` : ''}
                        </h4>
                        <p class="mono">${esc(row.id)}</p>
                        ${row.snippet ? `<p class="act-snippet">${esc(row.snippet)}</p>` : ''}
                    </div>
                    ${row.at ? `<time>${esc(relTime(row.at))}</time>` : ''}
                </div>`).join('')}
        </div>`;
}

/* ------------------------------------------------------------------ */
/* 6. automation - schedules                                           */
/* ------------------------------------------------------------------ */

function useCron(expression) {
    el('schedCron').value = expression;
}

function renderSchedules() {
    const flags = S.settings.features || {};
    el('schedTz').textContent = S.settings.timezone;
    el('schedArmed').textContent = `${S.armed} armed`;
    el('navSchedules').textContent = S.schedules.length;

    el('schedWarn').innerHTML = flags.schedules ? '' : `
        <div class="banner">
            <i class="fa-solid fa-pause"></i>
            <div>
                <b>Scheduled Tasks is off.</b>
                <p>Your tasks are saved but nothing will run until you turn the feature on in Features.</p>
            </div>
        </div>`;

    const box = el('schedList');
    if (!S.schedules.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-calendar-xmark"></i>No scheduled tasks yet.</p>';
        return;
    }

    box.innerHTML = S.schedules.map(task => `
        <div class="sched-item">
            <span class="row-icon"><i class="fa-solid ${task.action === 'message' ? 'fa-paper-plane' : task.action === 'post' ? 'fa-newspaper' : 'fa-share-nodes'}"></i></span>
            <div class="sched-body">
                <h4>
                    ${esc(task.label)}
                    ${task.enabled ? '<span class="badge badge-success">on</span>' : '<span class="badge badge-muted">paused</span>'}
                </h4>
                <div class="sched-meta">
                    <span><i class="fa-solid fa-clock"></i> <code>${esc(task.cron)}</code></span>
                    <span><i class="fa-solid fa-bolt"></i> ${esc(task.action)}</span>
                    ${task.target ? `<span><i class="fa-solid fa-crosshairs"></i> ${esc(task.target)}</span>` : ''}
                </div>
            </div>
            <button class="icon-btn" onclick="editSchedule('${esc(task.id)}')" aria-label="Edit ${esc(task.label)}">
                <i class="fa-solid fa-pen"></i>
            </button>
            <button class="icon-btn" onclick="toggleSchedule('${esc(task.id)}')" aria-label="${task.enabled ? 'Pause' : 'Resume'} ${esc(task.label)}">
                <i class="fa-solid ${task.enabled ? 'fa-pause' : 'fa-play'}"></i>
            </button>
            <button class="icon-btn danger" onclick="deleteSchedule('${esc(task.id)}')" aria-label="Delete ${esc(task.label)}">
                <i class="fa-solid fa-trash-can"></i>
            </button>
        </div>`).join('');
}

function scheduleForm() {
    return {
        id: S.editing,
        label: el('schedLabel').value,
        cron: el('schedCron').value,
        action: el('schedAction').value,
        target: el('schedTarget').value,
        message: el('schedMessage').value,
        enabled: true
    };
}

function resetScheduleForm() {
    S.editing = null;
    ['schedLabel', 'schedCron', 'schedTarget', 'schedMessage'].forEach(id => { el(id).value = ''; });
    el('schedAction').value = 'message';
    el('schedSaveLabel').textContent = 'Add task';
    el('schedCancel').style.display = 'none';
}

function editSchedule(id) {
    const task = S.schedules.find(t => String(t.id) === String(id));
    if (!task) return;
    S.editing = task.id;
    el('schedLabel').value = task.label;
    el('schedCron').value = task.cron;
    el('schedAction').value = task.action;
    el('schedTarget').value = task.target || '';
    el('schedMessage').value = task.message || '';
    el('schedSaveLabel').textContent = 'Update task';
    el('schedCancel').style.display = '';
    el('schedLabel').focus();
}

async function saveSchedule() {
    const task = scheduleForm();
    if (!task.label.trim()) return toast('please name the task.', 'error');
    if (!task.cron.trim()) return toast('please enter a cron expression.', 'error');

    // an edit must keep whatever paused state the task already had
    if (S.editing) {
        const existing = S.schedules.find(t => String(t.id) === String(S.editing));
        if (existing) task.enabled = existing.enabled;
    }

    try {
        const data = await api('/panel/schedules', { action: 'save', task });
        S.schedules = data.schedules;
        S.settings.schedules = data.schedules;
        resetScheduleForm();
        renderSchedules();
        toast(data.data, 'success');
    } catch (err) {
        if (err.message !== 'session ended') toast(err.message, 'error');
    }
}

async function toggleSchedule(id) {
    const task = S.schedules.find(t => String(t.id) === String(id));
    if (!task) return;
    try {
        const data = await api('/panel/schedules', {
            action: 'save',
            task: Object.assign({}, task, { enabled: !task.enabled })
        });
        S.schedules = data.schedules;
        S.settings.schedules = data.schedules;
        renderSchedules();
        toast(`${task.label} ${task.enabled ? 'paused' : 'resumed'}.`, 'success');
    } catch (err) {
        if (err.message !== 'session ended') toast(err.message, 'error');
    }
}

function deleteSchedule(id) {
    const task = S.schedules.find(t => String(t.id) === String(id));
    if (!task) return;
    confirmAction('Delete this task?', `"${task.label}" will stop running and be removed.`, async () => {
        const data = await api('/panel/schedules', { action: 'delete', task: { id } });
        S.schedules = data.schedules;
        S.settings.schedules = data.schedules;
        renderSchedules();
        toast(data.data, 'success');
    });
}

/* ------------------------------------------------------------------ */
/* 5b. automation - auto reply rules and greetings                     */
/* ------------------------------------------------------------------ */

function renderRules() {
    const flags = S.settings.features || {};
    const state = el('arState');
    state.textContent = flags.autoReply ? 'feature on' : 'feature off';
    state.className = `badge ${flags.autoReply ? 'badge-success' : 'badge-muted'}`;

    const rules = S.settings.autoReplyRules || [];
    const box = el('ruleList');
    if (!rules.length) {
        box.innerHTML = '<p class="empty-state"><i class="fa-solid fa-comment-slash"></i>No auto reply rules yet.</p>';
        return;
    }
    box.innerHTML = rules.map((rule, index) => `
        <div class="row-item">
            <span class="row-icon"><i class="fa-solid fa-quote-left"></i></span>
            <div class="row-main">
                <h4>
                    <span class="mono">${esc(rule.keyword)}</span>
                    ${rule.exact ? '<span class="badge badge-muted">exact</span>' : '<span class="badge badge-muted">contains</span>'}
                </h4>
                <p>${esc(rule.reply)}</p>
            </div>
            <button class="icon-btn danger" onclick="removeRule(${index})" aria-label="Delete rule ${esc(rule.keyword)}">
                <i class="fa-solid fa-trash-can"></i>
            </button>
        </div>`).join('');
}

async function saveRules(rules, message) {
    try {
        const data = await api('/panel/settings', { patch: { autoReplyRules: rules } });
        S.settings = data.settings;
        renderRules();
        toast(message, 'success');
    } catch (err) {
        if (err.message !== 'session ended') toast(err.message, 'error');
    }
}

function addRule() {
    const keyword = el('arKeyword').value.trim();
    const reply = el('arReply').value.trim();
    if (!keyword || !reply) return toast('a rule needs both a keyword and a reply.', 'error');

    const rules = (S.settings.autoReplyRules || []).concat([{ keyword, reply, exact: el('arExact').checked }]);
    if (rules.length > 50) return toast('you have reached the 50 rule limit.', 'error');

    el('arKeyword').value = '';
    el('arReply').value = '';
    el('arExact').checked = false;
    saveRules(rules, 'rule added.');
}

function removeRule(index) {
    const rules = (S.settings.autoReplyRules || []).slice();
    rules.splice(index, 1);
    saveRules(rules, 'rule removed.');
}

function saveGreetings() {
    run(null, () => api('/panel/settings', {
        patch: {
            greetJoin: el('greetJoin').value,
            greetLeave: el('greetLeave').value,
            reactEmoji: el('reactEmoji').value
        }
    }).then(data => { S.settings = data.settings; return data; }), 'greetings saved.');
}

/* ------------------------------------------------------------------ */
/* 6. console                                                          */
/* ------------------------------------------------------------------ */

async function pollLogs() {
    try {
        const data = await api('/panel/logs', { since: S.lastLogId });
        const incoming = data.logs || [];
        if (incoming.length) {
            // a cleared console restarts the sequence, so drop our copy and take theirs
            if (S.lastLogId && incoming[0].id <= S.lastLogId) S.logs = [];
            S.logs = S.logs.concat(incoming);
            if (S.logs.length > 400) S.logs.splice(0, S.logs.length - 400);
            S.lastLogId = S.logs[S.logs.length - 1].id;
            renderLogs();
        }
        el('streamLabel').textContent = 'Streaming';
    } catch (err) {
        el('streamLabel').textContent = 'Stream interrupted';
    }
}

function renderLogs() {
    const box = el('consoleBody');
    const query = (el('logSearch').value || '').trim().toLowerCase();
    const level = el('logLevel').value;

    const rows = S.logs.filter(line => {
        if (level && line.level !== level) return false;
        // searching by name or uid finds every line a person is responsible for
        if (query) {
            const haystack = `${line.message} ${line.user || ''} ${line.userId || ''}`.toLowerCase();
            if (!haystack.includes(query)) return false;
        }
        return true;
    });

    el('logCount').textContent = `${S.logs.length} line${S.logs.length === 1 ? '' : 's'}`;

    if (!rows.length) {
        box.innerHTML = `<p class="empty-state"><i class="fa-solid fa-inbox"></i>${
            S.logs.length ? 'Nothing matches that filter.' : 'The console is quiet. Activity shows up here as it happens.'
        }</p>`;
        return;
    }

    const atBottom = el('autoScroll').checked;
    box.innerHTML = rows.map(line => `
        <div class="console-line ${esc(line.level)}">
            <time>${esc(clockTime(line.at))}</time>
            <span class="lvl">${esc(line.level)}</span>
            <span class="who" title="${line.user ? `UID ${esc(line.userId || 'unknown')}` : 'system'}">${esc(line.user || 'system')}</span>
            <span class="msg">${esc(line.message)}</span>
        </div>`).join('');

    if (atBottom) box.scrollTop = box.scrollHeight;
}

function clearConsole() {
    confirmAction('Clear the console?', 'The stored output is discarded. New activity keeps streaming in.', async () => {
        await api('/panel/logs/clear');
        S.logs = [];
        S.lastLogId = 0;
        renderLogs();
        await pollLogs();
        toast('console cleared.', 'success');
    });
}

/* ------------------------------------------------------------------ */
/* 7. settings                                                         */
/* ------------------------------------------------------------------ */

function fillSettings() {
    const s = S.settings;

    el('setBotname').value = s.botname;
    el('setPrefix').value = s.prefix;
    el('setCooldown').value = s.defaultCooldown;

    // keep whatever zone the bot already has, even if it is not in our short list
    const zones = TIMEZONES.includes(s.timezone) ? TIMEZONES : [s.timezone].concat(TIMEZONES);
    el('setTimezone').innerHTML = zones
        .map(z => `<option value="${esc(z)}" ${z === s.timezone ? 'selected' : ''}>${esc(z)}</option>`)
        .join('');

    el('greetJoin').value = s.greetJoin;
    el('greetLeave').value = s.greetLeave;
    el('reactEmoji').value = s.reactEmoji;

    const labels = {
        commandErrors: ['Command errors', 'Log a line whenever a command throws.'],
        featureChanges: ['Feature changes', 'Log every flag you flip from this panel.'],
        newMembers: ['New members', 'Log when somebody joins a group the bot is in.'],
        schedules: ['Schedule runs', 'Log each time a scheduled task fires.']
    };
    el('notifyList').innerHTML = Object.keys(labels).map(key => `
        <label class="feature-row" for="nt-${key}">
            <span class="row-main">
                <h4>${esc(labels[key][0])}</h4>
                <p>${esc(labels[key][1])}</p>
            </span>
            <span class="switch">
                <input type="checkbox" id="nt-${key}" ${s.notify[key] ? 'checked' : ''} onchange="saveNotify('${key}', this)">
                <span class="slider"></span>
            </span>
        </label>`).join('');

    fillMaintenance(s.maintenance);
}

function fillMaintenance(maintenance) {
    const on = !!(maintenance && maintenance.status);
    el('mtToggle').checked = on;
    el('mtReason').value = (maintenance && maintenance.reason) || '';
    const state = el('mtState');
    state.textContent = on ? 'on' : 'off';
    state.className = `badge ${on ? 'badge-warning' : 'badge-muted'}`;
    el('mtSince').textContent = on && maintenance.since
        ? `On since ${new Date(maintenance.since).toLocaleString()}.`
        : on ? 'Maintenance mode is on.' : 'Currently off.';
}

async function saveIdentity() {
    const patch = {
        botname: el('setBotname').value,
        prefix: el('setPrefix').value,
        defaultCooldown: Number(el('setCooldown').value),
        timezone: el('setTimezone').value
    };
    try {
        const data = await api('/panel/settings', { patch });
        S.settings = data.settings;
        renderSchedules();
        renderCommands();
        await refreshStats();
        toast('settings saved.', 'success');
    } catch (err) {
        if (err.message !== 'session ended') toast(err.message, 'error');
    }
}

async function saveNotify(key, input) {
    const wanted = input.checked;
    input.disabled = true;
    try {
        const data = await api('/panel/settings', { patch: { notify: { [key]: wanted } } });
        S.settings = data.settings;
        toast('notifications updated.', 'success');
    } catch (err) {
        input.checked = !wanted;
        if (err.message !== 'session ended') toast(err.message, 'error');
    } finally {
        input.disabled = false;
    }
}

// maintenance lives on the older /configure route, which takes botId, not botid
async function saveMaintenance() {
    const body = {
        botId: S.botid,
        type: 'maintenance',
        content: { status: el('mtToggle').checked, reason: el('mtReason').value }
    };
    try {
        const res = await fetch('/configure', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        const data = await res.json().catch(() => null);
        if (!res.ok) throw new Error((data && data.error) || 'could not update maintenance mode.');
        S.settings.maintenance = data.maintenance;
        fillMaintenance(data.maintenance);
        await refreshStats();
        toast(data.data, 'success');
    } catch (err) {
        el('mtToggle').checked = !el('mtToggle').checked;
        toast(err.message, 'error');
    }
}

/* ------------------------------------------------------------------ */
/* power and session                                                   */
/* ------------------------------------------------------------------ */

function power(action) {
    const copy = {
        stop: ['Stop the session?', 'The bot disconnects from Facebook and every schedule pauses. Your settings are kept.'],
        restart: ['Restart the session?', 'The bot reconnects from the saved appstate. This takes a few seconds.']
    }[action];

    confirmAction(copy[0], copy[1], async () => {
        const data = await api('/panel/power', { action });
        toast(data.data, 'success');
        setTimeout(refreshStats, 2500);
        if (action === 'restart') setTimeout(refreshStats, 8000);
    });
}

function confirmSignOut() {
    closeMenu();
    confirmAction('Sign out of this panel?', 'Your panel token is invalidated. The bot keeps running in the background.', async () => {
        const res = await fetch('/configure', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ botId: S.botid, type: 'logout' })
        });
        const data = await res.json().catch(() => null);
        if (!res.ok) throw new Error((data && data.error) || 'could not sign out.');
        goHome();
    });
}

function confirmDelete() {
    confirmAction(
        'Delete this bot for good?',
        'The account is logged out, the saved session file is deleted and the bot record is removed. This cannot be undone.',
        async () => {
            const res = await fetch('/logout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ botid: S.botid })
            });
            const data = await res.json().catch(() => null);
            if (!res.ok) throw new Error((data && data.error) || 'could not delete this bot.');
            goHome();
        }
    );
}

/* ------------------------------------------------------------------ */
/* confirm dialog                                                      */
/* ------------------------------------------------------------------ */

function confirmAction(heading, text, work) {
    el('modalHeading').textContent = heading;
    el('modalText').textContent = text;
    el('modalScrim').classList.add('show');

    const button = el('modalConfirm');
    const fresh = button.cloneNode(true);
    button.parentNode.replaceChild(fresh, button);

    fresh.addEventListener('click', async () => {
        const original = fresh.innerHTML;
        fresh.disabled = true;
        fresh.innerHTML = '<span class="loading-spinner"></span>';
        try {
            await work();
            closeModal();
        } catch (err) {
            if (err && err.message !== 'session ended') toast(err.message, 'error');
            closeModal();
        } finally {
            fresh.disabled = false;
            fresh.innerHTML = original;
        }
    });
}

function closeModal() {
    el('modalScrim').classList.remove('show');
}

el('modalScrim').addEventListener('click', event => {
    if (event.target === el('modalScrim')) closeModal();
});

document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { closeModal(); closeMenu(); }
});

// pressing enter in any of the id fields adds to that list
[['adminInput', 'admins'], ['whitelistInput', 'whitelist'], ['blacklistInput', 'blacklist']].forEach(([id, list]) => {
    el(id).addEventListener('keydown', event => {
        if (event.key === 'Enter' && !event.isComposing && event.keyCode !== 229) {
            event.preventDefault();
            addToList(list, id);
        }
    });
});

// enter anywhere in the group ban row submits the ban
['groupBanInput', 'groupBanReason'].forEach(id => {
    el(id).addEventListener('keydown', event => {
        if (event.key === 'Enter' && !event.isComposing && event.keyCode !== 229) {
            event.preventDefault();
            banGroup(null);
        }
    });
});

boot();
